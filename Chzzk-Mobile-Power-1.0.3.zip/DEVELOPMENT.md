# Mobile power port 1.0.3

Source base: All-IN-ONE-power-status-1.4.9.55 (local retained archive size 2553141 bytes matches Library metadata).
`activity.js` derives from the original status observer. The mobile namespace is independent. The first eligible playback is an estimate; fresh WATCH_5_MIN evidence is not displaced by a newer playback start. UI labels expose this distinction.

Public client inspection:
- Desktop: https://ssl.pstatic.net/static/nng/glive/resource/p/static/js/index-BcgE118t.js
- Mobile: https://ssl.pstatic.net/static/nng/glive/resource/m/static/js/index-D6mEQTDn.js
- Desktop `Sv` reads channel log-power content; `content.claims` maps claimId, claimType, amount into reward buttons. `Tv` uses PUT /channels/{channelId}/log-power/claims/{claimId} and returns content.amount.
- The existing extension confirms the service/v1 base for GET /channels/{channelId}/log-power.
- Mobile inspected entry includes watch-event handling but lacks the desktop LOG_POWER and hourly-claim UI identifiers. This does not establish that mobile earns or does not earn power.

No reward is invented from elapsed time. The worker only claims WATCH_1_HOUR entries returned in current-channel content.claims. Site sender URL and channel must match. Claims are serialized per channel, attempts persisted for cooldown, and confirmed results logged only after success. No arbitrary URL/request relay is exposed to pages. Logs/settings are stored in extension local storage; a short presence/confirmation cache is stored on the CHZZK origin. No external telemetry.

Run pure tests:
```
node --test tests/background.test.cjs tests/activity.test.mjs
```
Seven test entries passed on 2026-11-12. Browser test is included for continuation, but did NOT run successfully in this environment: Chromium launch was denied at socket creation. It is not proof of rendered layout or mobile compatibility. `tests/browser.cjs` uses mock API replies and mobile viewports; even a pass would not replace Android Quetta/account testing.

No GitHub push or store publication performed. The deliverable is a local ZIP intended for trial installation, with manifest.json at its root.


## 1.0.1 logging fix
Balance snapshots are persisted per channel even when automatic claiming is disabled. Initial observation is a baseline, subsequent positive/negative net changes are logged independently from claim receipts. The panel subscribes to storage changes and displays the two categories separately with no combined total. Unobserved past events cannot be reconstructed. PUT content.amount is the resulting balance, so receipt increments now use claim.amount; legacy records are not displayed as trustworthy increments.
11 test entries passed on 2026-11-17, including ordinary +10 gains, no-change polls, spending, long gaps, automatic claim reconciliation, and migration from receipt-only storage. Android rendering and real-account verification remain untested.

1.0.2 연결·버튼 호환 수정 (2026-11-23)
- 모바일 확장 API의 콜백/Promise 응답 방식을 모두 지원합니다.
- 응답이 없으면 25초 후 조회 대기를 해제하여 다시 확인할 수 있습니다.
- 연결 상태, 조회 오류, 마지막 잔액 확인을 구분하고 페이지 새로고침 버튼을 추가했습니다.
- 화면에 표시되는 버전은 1.0.2입니다. 이전 버전은 끄고 치지직 탭을 닫았다가 다시 여세요.
- 벌목중은 시청 적립 알림이며, 1시간 보상의 수령 성공을 뜻하지 않습니다. 자동 수령 처리 내역과 보유량 변화를 확인하세요.
- 코드 기반 검사 16개 통과. 실제 Quetta 기기의 터치·실방송 수령은 미검증입니다.


1.0.3 방송 이동 후 연결 수정 (2026-11-23)
- 홈→방송, 방송→다른 방송 이동 시 이전 문서 주소와 현재 방송 주소 불일치로 요청을 응답 없이 거절하던 조건 수정.
- 허용된 치지직 출처와 채널 ID 형식 검증은 유지하며 현재 화면이 요청한 채널을 조회합니다.
- 기존 버전에서 위 두 경로의 실패를 모의 재현하고 수정 후 통과 확인. 전체 코드 검사 18개 통과.
- 실제 Quetta 홈 화면 바로가기에서 재현·해결 여부는 미검증입니다.
- 업데이트 후 기존 모바일판을 끄고 치지직 탭을 닫았다가 다시 여세요. 패널 제목 1.0.3 확인.
