const {test} = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const id = 'a'.repeat(32), other = 'b'.repeat(32);
function harness({auto=true, claims=[], fail=false, initial={}}={}) {
  const store = {autoClaim:auto, ...initial}, calls=[]; let listener, amount=100, now=1000000;
  const chrome={storage:{local:{get:async defaults=>Object.assign({},defaults,store),set:async value=>Object.assign(store,structuredClone(value))}},runtime:{onMessage:{addListener:f=>listener=f}}};
  const fetch=async(url, options)=>{
    calls.push({url,method:options.method});
    if (options.method === 'PUT') {
      if(fail)return {ok:false,status:403};
      amount+=100; claims=[]; return {ok:true,json:async()=>({code:200,content:{amount}})};
    }
    return {ok:true,json:async()=>({code:200,content:{amount,claims}})};
  };
  vm.runInNewContext(fs.readFileSync(__dirname+'/../background.js','utf8'),{chrome,fetch,URL,AbortSignal,Date:class extends Date {static now(){return now;}},Map,Number,Object,String,Error,encodeURIComponent});
  const send=(message={type:'CQC_MOBILE_POLL',channelId:id},sender={url:'https://m.chzzk.naver.com/live/'+id})=>new Promise(resolve=>{const keep=listener(message,sender,resolve);if(!keep)resolve(undefined)});
  return {send,calls,store,setAmount(value){amount=value;},advance(ms=30001){now+=ms;}};
}
test('only server-issued hourly claims are redeemed; log after success',async()=>{
  const h=harness({claims:[{claimId:'hour-1',claimType:'WATCH_1_HOUR',amount:100},{claimId:'follow',claimType:'FOLLOW'}]});
  const result=await h.send();assert.equal(result.amount,200);assert.equal(h.calls.filter(c=>c.method==='PUT').length,1);assert.equal(h.store['channel_'+id].logs[0].amount,100);
});
test('off switch prevents redemption',async()=>{const h=harness({auto:false,claims:[{claimId:'x',claimType:'WATCH_1_HOUR',amount:100}]});await h.send();assert.equal(h.calls.length,1)});
test('simultaneous tabs and fast polls do not duplicate claims',async()=>{const h=harness({claims:[{claimId:'x',claimType:'WATCH_1_HOUR',amount:100}]});await Promise.all([h.send(),h.send()]);await h.send();assert.equal(h.calls.filter(c=>c.method==='PUT').length,1)});
test('failed claim never becomes success log',async()=>{const h=harness({fail:true,claims:[{claimId:'x',claimType:'WATCH_1_HOUR',amount:100}]});const r=await h.send();assert.match(r.claimError,/로그인/);assert.equal(h.store['channel_'+id].logs.length,0)});
test('reject offsite sender and channel mismatch',async()=>{const h=harness();assert.equal(await h.send(undefined,{url:'https://example.com/live/'+id}),undefined);assert.equal(await h.send({type:'CQC_MOBILE_POLL',channelId:other}),undefined);assert.equal(h.calls.length,0)});
test('reject malformed claim ids and no reward when claims missing',async()=>{const h=harness({claims:[{claimId:'../bad',claimType:'WATCH_1_HOUR',amount:100}]});await h.send();assert.equal(h.calls.length,1)});

test('5-minute gains recorded with auto claim OFF, no initial fake earnings',async()=>{
 const h=harness({auto:false});await h.send();assert.equal(h.store['channel_'+id].balanceLogs.length,0);
 h.setAmount(110);h.advance();await h.send();const rows=h.store['channel_'+id].balanceLogs;
 assert.equal(rows.length,1);assert.equal(rows[0].amount,10);assert.equal(rows[0].gap,false);
 h.advance();await h.send();assert.equal(h.store['channel_'+id].balanceLogs.length,1);
});
test('spending and gaps are labelled as net balance changes',async()=>{
 const h=harness();await h.send();h.setAmount(70);h.advance(120000);await h.send();
 assert.equal(h.store['channel_'+id].balanceLogs[0].amount,-30);assert.equal(h.store['channel_'+id].balanceLogs[0].gap,true);
});
test('automatic claim balance delta is recorded once and response total is not reward amount',async()=>{
 const h=harness({claims:[{claimId:'a',claimType:'WATCH_1_HOUR',amount:100}]});await h.send();h.advance();await h.send();
 const saved=h.store['channel_'+id];assert.equal(saved.logs[0].amount,100);assert.equal(saved.balance,200);
 assert.equal(saved.balanceLogs.length,1);assert.equal(saved.balanceLogs[0].amount,100);
});
test('upgrade preserves old receipt records and starts a fresh balance baseline',async()=>{
 const old={at:10,claimId:'old',amount:500};const h=harness({initial:{['channel_'+id]:{logs:[old],attempts:{}}}});
 await h.send();assert.deepEqual(h.store['channel_'+id].logs,[old]);assert.equal(h.store['channel_'+id].balanceLogs.length,0);
});
