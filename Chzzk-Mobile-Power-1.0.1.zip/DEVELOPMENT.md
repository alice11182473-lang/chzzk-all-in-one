# Mobile power port 1.0.1

Source base: All-IN-ONE-power-status-1.4.9.55 (local retained archive size 2553141 bytes matches Library metadata).
`activity.js` derives from the original status observer. The mobile namespace is independent. The first eligible playback is an estimate; fresh WATCH_5_MIN evidence is not displaced by a newer playback start. UI labels expose this distinction.

Public client inspection:
- Desktop: https://ssl.pstatic.net/static/nng/glive/resource/p/static/js/index-BcgE118t.js
- Mobile: https://ssl.pstatic.net/static/nng/glive/resource/m/static/js/index-D6mEQTDn.js
- Desktop `Sv` reads channel log-power content; `content.claims` maps claimId, claimType, amount into reward buttons. `Tv` uses PUT /channels/{channelId}/log-power/claims/{claimId} and returns content.amount.
- The existing extension confirms the service/v1 base for GET /channels/{channelId}/log-power.
- Mobile inspected entry includes watch-event handling but lacks the desktop LOG_POWER and hourly-claim UI identifiers. This does not establish that mobile earns or does not earn power.

No reward is invented from elapsed time. The worker only claims WATCH_1_HOUR entries returned in current-channel content.claims. Site sender URL and channel must match. Claims are serialized per channel, attempts persisted for cooldown, and confirmed results logged only after success. No arbitrary URL/request relay is exposed to pages. Logs/settings are stored in extension local storage; a short presence/confirmation cache is stored on the CHZZK origin. No external telemetry.

Run pure tests:
```
node --test tests/background.test.cjs tests/activity.test.mjs
```
Seven test entries passed on 2026-11-12. Browser test is included for continuation, but did NOT run successfully in this environment: Chromium launch was denied at socket creation. It is not proof of rendered layout or mobile compatibility. `tests/browser.cjs` uses mock API replies and mobile viewports; even a pass would not replace Android Quetta/account testing.

No GitHub push or store publication performed. The deliverable is a local ZIP intended for trial installation, with manifest.json at its root.


## 1.0.1 logging fix
Balance snapshots are persisted per channel even when automatic claiming is disabled. Initial observation is a baseline, subsequent positive/negative net changes are logged independently from claim receipts. The panel subscribes to storage changes and displays the two categories separately with no combined total. Unobserved past events cannot be reconstructed. PUT content.amount is the resulting balance, so receipt increments now use claim.amount; legacy records are not displayed as trustworthy increments.
11 test entries passed on 2026-11-17, including ordinary +10 gains, no-change polls, spending, long gaps, automatic claim reconciliation, and migration from receipt-only storage. Android rendering and real-account verification remain untested.
