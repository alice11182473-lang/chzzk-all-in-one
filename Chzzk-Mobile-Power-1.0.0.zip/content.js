(() => {
  if (window.top !== window || document.getElementById('cqc-mobile-power')) return;
  const host = document.createElement('div');
  host.id = 'cqc-mobile-power';
  const shadow = host.attachShadow({mode: 'open'});
  shadow.innerHTML = `<style>
    :host{all:initial!important;position:fixed!important;right:max(10px,env(safe-area-inset-right))!important;bottom:max(90px,calc(env(safe-area-inset-bottom) + 80px))!important;z-index:2147483646!important;font:14px/1.5 system-ui,sans-serif!important;color:#eef7f4!important;max-width:calc(100vw - 20px)!important}
    :host([hidden]){display:none!important}:host([data-top]){bottom:auto!important;top:max(12px,env(safe-area-inset-top))!important}
    *{box-sizing:border-box}button{font:inherit;color:inherit;border:1px solid #3b5652;border-radius:12px;background:#172925;min-height:44px;padding:9px 12px;touch-action:manipulation;cursor:pointer}button:focus-visible{outline:2px solid #00e6ad;outline-offset:2px}
    #bar{display:flex;align-items:center;gap:10px;box-shadow:0 3px 16px #0007;max-width:100%;flex-wrap:wrap}#state{font-size:12px;color:#a8b7b3}#state[data-state=confirmed]{color:#00e6ad}
    #panel{position:absolute;bottom:54px;right:0;background:#101e1b;border:1px solid #3b5652;border-radius:16px;padding:16px;width:min(330px,calc(100vw - 20px));max-height:calc(100dvh - 180px);overflow:auto;box-shadow:0 8px 30px #0009}
    :host([data-top]) #panel{top:54px;bottom:auto}h2{font-size:18px;margin:0 0 12px}p{margin:10px 0;color:#bacac5}label{display:flex;gap:10px;align-items:center;min-height:44px}input{width:22px;height:22px;accent-color:#00dba5}#buttons{display:flex;gap:8px;flex-wrap:wrap}ol{padding-left:22px;font-size:12px}#error{color:#ffc48e}#support{font-size:12px}#close{float:right}a{color:#00e6ad}small{display:block;color:#a8b7b3}
    @media(max-height:450px){:host{bottom:12px!important}:host([data-top]){bottom:auto!important}#panel{max-height:calc(100dvh - 80px)}}
  </style><button id="bar" type="button" aria-expanded="false" aria-controls="panel"><strong id="balance">🪵 확인 중</strong><span id="state">적립 확인 중</span></button>
  <section id="panel" hidden aria-label="통나무 설정"><button id="close" type="button" aria-label="닫기">닫기</button><h2>모바일 통나무</h2>
  <label><input id="auto" type="checkbox">1시간 보상 자동 수령</label>
  <div id="buttons"><button id="position" type="button">표시 위치 변경</button><button id="refresh" type="button">보유량 확인</button></div>
  <p id="detail"></p><p id="error" role="status"></p><small id="updated"></small>
  <p id="support">서버에 수령 가능한 1시간 보상이 생기면 받습니다. 화면 잠금·백그라운드에서는 중단될 수 있습니다. 적립이 늘지 않으면 PC 웹 보기로 비교해 주세요.</p>
  <a id="desktop">같은 방송 PC 웹 주소 열기</a><h3>자동 수령 기록</h3><ol id="logs"></ol><small>성공 응답을 확인한 기록만 표시합니다. 이 브라우저에만 저장됩니다.</small></section>`;
  document.documentElement.append(host);
  const $ = id => shadow.getElementById(id);
  let channel = '', amount = null, status = 'unknown', busy = false, lastPoll = 0, error = '', updated = 0;
  let settings = {autoClaim: true, top: false};
  let generation = 0;
  const getChannel = () => /\/chat\/?$/.test(location.pathname) ? '' : location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1] || '';
  const setText = (id, value) => { if ($(id).textContent !== value) $(id).textContent = value; };
  function render() {
    host.hidden = !channel || !!document.fullscreenElement;
    host.toggleAttribute('data-top', settings.top);
    $('auto').checked = settings.autoClaim;
    const labels = {confirmed: '벌목중 · 적립 확인', estimated: '적립 확인 중', waiting: '벌목대기중 · 추정', unknown: '적립 확인 중'};
    setText('balance', '🪵 ' + (amount === null ? '확인 중' : amount.toLocaleString()));
    setText('state', labels[status] || labels.unknown);
    $('state').dataset.state = status;
    setText('detail', status === 'confirmed' ? '최근 5분 시청 적립 알림이 확인됐습니다. 현재도 계속 적립되는지는 다음 알림으로 확인합니다.' : '재생·탭 상태만으로 실제 적립 여부를 확정하지 않습니다. 다른 기기의 시청 상태는 확인할 수 없습니다.');
    setText('error', error);
    setText('updated', updated ? '보유량 확인: ' + new Date(updated).toLocaleTimeString('ko-KR') : '보유량 확인 전');
    $('desktop').href = 'https://chzzk.naver.com/live/' + channel;
  }
  async function logs() {
    const id = channel;
    const values = await chrome.storage.local.get('channel_' + id);
    if (id !== channel) return;
    const list = values['channel_' + id]?.logs || [];
    $('logs').replaceChildren(...list.slice(0, 10).map(log => {
      const item = document.createElement('li');
      item.textContent = `${new Date(log.at).toLocaleString('ko-KR')} · +${log.amount}`;
      return item;
    }));
    if (!list.length) { const li = document.createElement('li'); li.textContent = '확인된 수령 기록이 없습니다.'; $('logs').append(li); }
  }
  function setPanel(open) { $('panel').hidden = !open; $('bar').setAttribute('aria-expanded', String(open)); if(open) logs().catch(()=>{}); }
  $('bar').onclick = () => setPanel($('panel').hidden);
  $('close').onclick = () => {setPanel(false); $('bar').focus();};
  shadow.addEventListener('keydown', e => { if (e.key === 'Escape') setPanel(false); });
  $('auto').onchange = async () => {
    settings.autoClaim = $('auto').checked;
    try { await chrome.storage.local.set({autoClaim: settings.autoClaim}); }
    catch { error = '설정 저장 실패 · 다시 시도하세요.'; }
    render();
  };
  $('position').onclick = async () => { settings.top = !settings.top; render(); await chrome.storage.local.set({top: settings.top}).catch(()=>{}); };
  $('refresh').onclick = () => {lastPoll = 0; tick();};
  window.addEventListener('cqc-mobile-status', e => {
    try {
      const data = JSON.parse(e.detail);
      if (data.channelId === channel && ['confirmed','estimated','waiting','unknown'].includes(data.status)) { status = data.status; render(); }
    } catch {}
  });
  async function tick() {
    const next = getChannel();
    if (channel !== next) {
      channel = next; generation++; amount = null; status = 'unknown'; lastPoll = 0; updated = 0; error = ''; setPanel(false);
    }
    render();
    if (!channel) return;
    window.dispatchEvent(new Event('cqc-mobile-query'));
    if (busy || Date.now() - lastPoll < 30000) return;
    busy = true; lastPoll = Date.now(); const token = generation, id = channel;
    try {
      const response = await chrome.runtime.sendMessage({type: 'CQC_MOBILE_POLL', channelId: id});
      if (token !== generation || getChannel() !== id) return;
      if (!response?.ok) throw Error(response?.error || '확장프로그램 연결을 확인하세요.');
      amount = response.amount; updated = Date.now(); error = response.claimError || '';
      if (!$('panel').hidden) await logs();
    } catch (e) { if (token === generation) error = e.message; }
    finally {busy = false; render();}
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const key of ['autoClaim','top']) if (changes[key]) settings[key] = !!changes[key].newValue;
    render();
  });
  chrome.storage.local.get(settings).then(value => {settings = value; tick();}).catch(() => {error = '설정을 읽지 못했습니다.'; render();});
  setInterval(tick, 3000);
  document.addEventListener('visibilitychange', () => {if(!document.hidden) {lastPoll = 0; tick();}});
  window.addEventListener('pageshow', tick);
  window.addEventListener('popstate', tick);
  document.addEventListener('fullscreenchange', render);
})();
