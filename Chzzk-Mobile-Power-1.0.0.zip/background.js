// Endpoints and claims schema verified in CHZZK's public desktop client.
// Only server-issued WATCH_1_HOUR claims are redeemed. Never send watch events.
const running = new Map();
const cache = new Map();
async function api(id, suffix = '', method = 'GET') {
  const response = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${id}/log-power${suffix}`, {
    method, credentials: 'include', cache: 'no-store', signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) throw Error(response.status === 401 || response.status === 403 ? '로그인 상태를 확인하세요.' : `서버 요청 실패 (${response.status})`);
  const data = await response.json();
  if (data.code !== 200 || !data.content) throw Error('서버 응답을 확인할 수 없습니다.');
  return data.content;
}
async function poll(id) {
  const key = 'channel_' + id;
  const settings = await chrome.storage.local.get({autoClaim: true, [key]: {logs: [], attempts: {}}});
  const saved = settings[key];
  let data = await api(id), claimError = '';
  if (settings.autoClaim && Array.isArray(data.claims)) {
    const attempts = Object.fromEntries(Object.entries(saved.attempts || {}).filter(([, at]) => Date.now() - at < 86400000));
    const logs = Array.isArray(saved.logs) ? saved.logs.slice(0, 100) : [];
    const claims = data.claims.filter(c => c?.claimType === 'WATCH_1_HOUR' && /^[a-zA-Z0-9_-]{1,128}$/.test(String(c.claimId ?? '')));
    for (const claim of claims.slice(0, 10)) {
      if (Date.now() - (attempts[claim.claimId] || 0) < 60000) continue;
      if (logs.some(log => log.claimId === String(claim.claimId))) continue;
      // Re-read the switch so turning it off stops subsequent claims immediately.
      if (!(await chrome.storage.local.get({autoClaim: true})).autoClaim) break;
      attempts[claim.claimId] = Date.now();
      await chrome.storage.local.set({[key]: {logs, attempts}});
      try {
        const result = await api(id, '/claims/' + encodeURIComponent(claim.claimId), 'PUT');
        if (!Number.isFinite(result.amount) || result.amount < 0) throw Error('수령 응답을 확인할 수 없습니다.');
        logs.unshift({at: Date.now(), claimId: String(claim.claimId), amount: result.amount});
        logs.splice(100);
        await chrome.storage.local.set({[key]: {logs, attempts}});
      } catch (error) { claimError = error.message; break; }
    }
    if (claims.length) data = await api(id);
  }
  if (!Number.isFinite(data.amount) || data.amount < 0) throw Error('보유량을 확인할 수 없습니다.');
  return {ok: true, amount: data.amount, claimError};
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  let url;
  try { url = new URL(sender.url); } catch { return; }
  if (!['https://chzzk.naver.com', 'https://m.chzzk.naver.com'].includes(url.origin)) return;
  const id = message?.channelId;
  if (message?.type !== 'CQC_MOBILE_POLL' || !/^[a-f0-9]{32}$/i.test(id || '') ||
      url.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1] !== id) return;
  if (running.has(id)) { running.get(id).then(respond); return true; }
  const previous = cache.get(id);
  if (previous && Date.now() - previous.at < 30000) { respond(previous.result); return; }
  const task = poll(id).catch(error => ({ok: false, error: error.message})).then(result => {
    cache.set(id, {at: Date.now(), result});
    if (cache.size > 100) cache.delete(cache.keys().next().value);
    running.delete(id);
    return result;
  });
  running.set(id, task);
  task.then(respond);
  return true;
});
