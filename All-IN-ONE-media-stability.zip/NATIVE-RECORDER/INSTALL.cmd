@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
if not exist "%~dp0install.py" goto missing_files
py -3 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto run_py
python -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>&1
if not errorlevel 1 goto run_python
echo Python 3.10 or newer was not found.
echo Install Python from https://www.python.org/downloads/windows/
echo Then close this window and run this file again.
pause
exit /b 1
:run_py
py -3 -X utf8 "%~dp0install.py"
goto finished
:run_python
python -X utf8 "%~dp0install.py"
goto finished
:missing_files
echo Extract the complete ZIP before running this file.
echo Keep install.py and native_host.py in the same folder as this file.
pause
exit /b 1
:finished
if errorlevel 1 echo Setup failed. Please send the error message shown above.
pause
