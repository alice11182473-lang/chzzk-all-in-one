"""Windows per-user setup; run explicitly by user, no administrator privileges."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import venv
import uuid

HOST='com.chzzk.allinone.recorder'
KEYS=[rf'Software\Naver\Whale\NativeMessagingHosts\{HOST}',
      rf'Software\Naver\Naver Whale\NativeMessagingHosts\{HOST}',
      rf'Software\Google\Chrome\NativeMessagingHosts\{HOST}']

def canonical_folder(folder):
    # Store Python redirects LocalAppData. Resolve AFTER creating the directory
    # so venv, subprocesses and the browser all use its physical location.
    folder.mkdir(parents=True, exist_ok=True)
    return Path(os.path.realpath(folder))

def prepare_environment(folder):
    env = canonical_folder(folder / 'venv')
    python = env / 'Scripts' / 'python.exe'
    probe = 'import sys; assert sys.prefix != sys.base_prefix; import pip'
    healthy = False
    if (env / 'pyvenv.cfg').is_file() and python.is_file():
        try:
            healthy = subprocess.run([str(python), '-c', probe],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30).returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            pass
    if not healthy:
        # Keep failed installs intact; never delete recordings or user files.
        if any(env.iterdir()):
            env = canonical_folder(folder / ('venv-' + uuid.uuid4().hex[:12]))
        venv.EnvBuilder(with_pip=True).create(str(env))
        python = env / 'Scripts' / 'python.exe'
        subprocess.run([str(python), '-c', probe], check=True, timeout=30)
    return python

def main():
    if os.name!='nt': raise RuntimeError('이 설치 도우미는 Windows용입니다.')
    if sys.version_info<(3,10): raise RuntimeError('Python 3.10 이상이 필요합니다.')
    import winreg
    folder=Path(os.environ['LOCALAPPDATA'])/'ChzzkAllInOneRecorder'
    if '--uninstall' in sys.argv:
        for path in KEYS:
            try:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER,path) as key: value=winreg.QueryValue(key,None)
                if value in {str(folder/'host.json'), str(Path(os.path.realpath(folder))/'host.json')}: winreg.DeleteKey(winreg.HKEY_CURRENT_USER,path)
            except FileNotFoundError: pass
        print('보조 프로그램 연결 등록을 해제했습니다. 녹화 파일은 삭제하지 않았습니다.');return
    print('치지직 올인원 원본 녹화 보조 프로그램 설치')
    print('먼저 새 확장을 불러오고 설정의 [확장 ID 복사]를 눌러 주세요.')
    extension_id=input('확장 ID: ').strip()
    if not re.fullmatch(r'[a-p]{32}',extension_id): raise ValueError('확장 ID는 a~p로 된 32글자입니다.')
    print('Streamlink와 FFmpeg 패키지를 PyPI에서 전용 환경에 설치합니다.')
    folder=canonical_folder(folder)
    print('실제 설치 폴더:', folder)
    python=prepare_environment(folder)
    subprocess.run([str(python),'-m','pip','install','--upgrade','streamlink>=8,<9','imageio-ffmpeg>=0.6,<0.7'],check=True)
    source=Path(__file__).with_name('native_host.py')
    shutil.copy2(source,folder/'native_host.py')
    output=Path.home()/'Downloads'
    try:
        import tkinter as tk
        from tkinter import filedialog
        root=tk.Tk();root.withdraw();root.attributes('-topmost',True)
        selected=filedialog.askdirectory(title='원본 녹화 기본 저장 폴더 선택',initialdir=str(output))
        root.destroy()
        if selected: output=Path(selected)
    except Exception: print('폴더 선택 창을 열지 못해 사용자 Downloads 폴더를 사용합니다.')
    origins=[f'chrome-extension://{extension_id}/']
    config={'outputRoot':str(output.resolve()),'allowedOrigins':origins}
    (folder/'config.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    # Percent is escaped for a batch file; delayed expansion stays off.
    def batch_path(path): return str(path).replace('%','%%')
    launcher='@echo off\r\nchcp 65001 >nul\r\nsetlocal DisableDelayedExpansion\r\n"'+batch_path(python)+'" -u "'+batch_path(folder/'native_host.py')+'" %*\r\n'
    (folder/'host.cmd').write_bytes(launcher.encode('utf-8'))
    manifest={'name':HOST,'description':'CHZZK original stream recorder','path':str(folder/'host.cmd'),'type':'stdio','allowed_origins':origins}
    (folder/'host.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    for path in KEYS:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER,path) as key: winreg.SetValueEx(key,'',0,winreg.REG_SZ,str(folder/'host.json'))
    # Check dependencies using the actual installed interpreter.
    subprocess.run([str(python),'-c','import streamlink,imageio_ffmpeg; print("FFmpeg:",imageio_ffmpeg.get_ffmpeg_exe())'],check=True)
    print('설치 완료. 확장 설정에서 [원본 녹화 연결 확인]을 누르세요.')
    print('기본 저장 폴더:',output)
    print('설치 폴더:',folder)
if __name__=='__main__':
    try: main()
    except Exception as exc: print('설치 실패:',exc);sys.exit(1)
