import io
import json
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import native_host as n

CID='a'*32
class Tests(unittest.TestCase):
    def test_protocol_and_validation(self):
        pipe=io.BytesIO();n.send_message(pipe,{'id':1,'text':'치지직'});pipe.seek(0)
        self.assertEqual(n.read_message(pipe),{'id':1,'text':'치지직'})
        self.assertIsNone(n.read_message(pipe))
        with self.assertRaises(ValueError): n.read_message(io.BytesIO(struct.pack('<I',70000)))
        with self.assertRaises(ValueError): n.read_message(io.BytesIO(b'\x02'))
        with tempfile.TemporaryDirectory() as root:
            self.assertEqual(n.output_folder(root,'치지직/녹화'),Path(root)/'치지직'/'녹화')
            for bad in ['../x','C:/x','/x','a//b','CON','a?','a.']:
                with self.assertRaises(ValueError): n.output_folder(root,bad)
            with self.assertRaises(ValueError): n.commands('../../bad',Path(root)/'a.mp4','ffmpeg')
            for fmt in ['mp4','mkv']:
                source,sink=n.commands(CID,Path(root)/('file.'+fmt),'ffmpeg')
                self.assertEqual(sink[sink.index('-c')+1],'copy')
                self.assertNotIn('-t',sink);self.assertNotIn('-segment_time',sink)
    def test_dedup_and_cancel(self):
        with tempfile.TemporaryDirectory() as root:
            manager=n.Manager({'outputRoot':root})
            with patch.object(manager,'dependencies',return_value=True),patch.object(n,'ffmpeg_path',return_value='ffmpeg'),patch.object(n.Job,'start') as start:
                r=manager.handle({'op':'start','channelId':CID,'format':'mp4'})
                job=manager.jobs[CID]
                with patch.object(job.thread,'is_alive',return_value=True):
                    manager.handle({'op':'start','channelId':CID,'format':'mp4'});self.assertEqual(start.call_count,1)
                manager.handle({'op':'stop','channelId':CID});self.assertTrue(job.cancel.is_set())
    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'FFmpeg required')
    def test_real_mp4_mkv_copy_and_manual_stop(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);fixture=root/'fixture.ts'
            subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=320x180:rate=25','-f','lavfi','-i','sine=frequency=440:sample_rate=48000','-t','2','-c:v','libx264','-preset','ultrafast','-g','25','-c:a','aac','-f','mpegts',str(fixture)],check=True)
            original=n.commands
            def probe(path):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=codec_name,width,height','-of','json',str(path)]))['streams']
            for fmt in ['mp4','mkv']:
                def commands(cid,dest,ffmpeg):
                    _,sink=original(cid,dest,ffmpeg)
                    return [sys.executable,'-c','import sys;sys.stdout.buffer.write(open(sys.argv[1],"rb").read())',str(fixture)],sink
                job=n.Job(CID,root,fmt,'ffmpeg')
                with patch.object(n,'commands',commands):job.start();job.thread.join(15)
                self.assertFalse(job.dest.with_suffix('.log').exists());self.assertFalse(job.thread.is_alive());self.assertEqual(job.state,'stopped',str(job.error))
                self.assertEqual(probe(fixture),probe(job.dest))
            def endless(cid,dest,ffmpeg):
                _,sink=original(cid,dest,ffmpeg)
                return ['ffmpeg','-hide_banner','-loglevel','error','-re','-stream_loop','-1','-i',str(fixture),'-c','copy','-f','mpegts','pipe:1'],sink
            job=n.Job(CID,root,'mp4','ffmpeg')
            with patch.object(n,'commands',endless):
                job.start();time.sleep(3);job.stop();job.thread.join(25)
            self.assertFalse(job.dest.with_suffix('.log').exists());self.assertFalse(job.thread.is_alive());self.assertEqual(job.state,'stopped',str(job.error))
            self.assertEqual(probe(fixture),probe(job.dest))
            self.assertIsNotNone(job.producer.poll());self.assertIsNotNone(job.consumer.poll())
if __name__=='__main__': unittest.main()
