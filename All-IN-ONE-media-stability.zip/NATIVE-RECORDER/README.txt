상위 폴더 READ-ME.txt의 설치 순서를 따라 주세요.
INSTALL.cmd: Python 전용 환경 + Streamlink/FFmpeg + 보조 프로그램 등록.
UNINSTALL.cmd: 등록 해제(녹화 파일 삭제 없음).
설치 도중 패키지 다운로드 또는 등록 오류가 나면 표시된 오류를 그대로 보내 주세요.
Windows/웨일 실행은 아직 검증되지 않았습니다. 확장 설정의 연결 확인을 먼저 수행하세요.

설치 실행 파일 수정판: INSTALL.cmd/UNINSTALL.cmd는 ASCII 및 Windows CRLF 형식입니다. py가 없으면 python 명령도 확인합니다. 현재 확장 버전은 1.4.9.45입니다. 이전 설치 실행에 실패했다면 새 ZIP을 모두 풀고 NATIVE-RECORDER/INSTALL.cmd만 다시 실행하세요.

설치 오류 106 / Microsoft Store Python 경로 수정:
INSTALL.cmd를 다시 실행하세요. 설치 폴더의 실제 경로를 사용하며, 실패한 가상환경은 보존하고 새 환경을 만듭니다. Python을 삭제할 필요는 없습니다.

1.4.9.45부터 녹화 폴더에 .log 파일을 만들지 않습니다. 오류의 최근 내용은 메모리에만 제한적으로 보관됩니다. 적용 시 모든 녹화를 정지하고 확장을 새로고침한 뒤 이 INSTALL.cmd를 다시 실행하세요.
