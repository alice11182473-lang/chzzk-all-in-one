import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, Mock
import install


class InstallerTests(unittest.TestCase):
    def test_redirect_is_resolved_after_creation(self):
        with tempfile.TemporaryDirectory() as tmp:
            requested = Path(tmp) / 'requested'
            actual = Path(tmp) / 'physical'
            def resolve(path):
                self.assertTrue(requested.is_dir())
                self.assertEqual(path, requested)
                return str(actual)
            with patch.object(install.os.path, 'realpath', side_effect=resolve):
                self.assertEqual(install.canonical_folder(requested), actual)

    def test_healthy_environment_reused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            env = root / 'venv'
            (env / 'Scripts').mkdir(parents=True)
            (env / 'Scripts/python.exe').touch()
            (env / 'pyvenv.cfg').touch()
            with patch.object(install.subprocess, 'run', return_value=Mock(returncode=0)), patch.object(install.venv, 'EnvBuilder') as builder:
                self.assertEqual(install.prepare_environment(root), env / 'Scripts/python.exe')
                builder.assert_not_called()

    def test_broken_environment_preserved_and_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            env = root / 'venv'
            (env / 'Scripts').mkdir(parents=True)
            (env / 'Scripts/python.exe').touch()
            (env / 'pyvenv.cfg').touch()
            saved = root / 'recording.mp4'
            saved.write_bytes(b'keep')
            with patch.object(install.subprocess, 'run', side_effect=[Mock(returncode=106), Mock(returncode=0)]) as run, patch.object(install.venv, 'EnvBuilder') as builder:
                python = install.prepare_environment(root)
                self.assertNotEqual(python.parent.parent, env)
                builder.return_value.create.assert_called_once_with(str(python.parent.parent))
                self.assertEqual(run.call_args.args[0][0], str(python))
            self.assertTrue((env / 'pyvenv.cfg').exists())
            self.assertEqual(saved.read_bytes(), b'keep')

if __name__ == '__main__':
    unittest.main()
