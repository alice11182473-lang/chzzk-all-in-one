"""CHZZK Native Messaging recorder. stdin/stdout are protocol-only.
Streamlink acquisition -> FFmpeg -c copy. No captureStream, browser cookies,
re-encoding, HTTP control server, or timed file splitting.
"""
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import struct
import subprocess
import sys
import threading
import time
import uuid

BASE = Path(__file__).resolve().parent
CID = re.compile(r'^[a-f0-9]{32}$', re.I)
LOCK = threading.Lock()

def read_exact(stream, size):
    result = bytearray()
    while len(result) < size:
        part = stream.read(size-len(result))
        if not part:
            if not result: return None
            raise ValueError('Truncated native message')
        result.extend(part)
    return bytes(result)

def read_message(stream):
    header = read_exact(stream, 4)
    if header is None: return None
    size = struct.unpack('<I', header)[0]
    if not 0 < size <= 65536: raise ValueError('Invalid native message length')
    payload = read_exact(stream, size)
    if payload is None: raise ValueError('Missing native message')
    obj = json.loads(payload.decode('utf-8'))
    if not isinstance(obj, dict): raise ValueError('Object required')
    return obj

def send_message(stream, obj):
    payload = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    with LOCK:
        stream.write(struct.pack('<I', len(payload)) + payload)
        stream.flush()

def output_folder(root, subfolder):
    value = str(subfolder or '').replace('\\', '/').strip()
    if len(value) > 180: raise ValueError('저장 폴더명이 너무 깁니다.')
    parts = value.split('/') if value else []
    for part in parts:
        if not part or part in ('.', '..') or re.search(r'[<>:"|?*\x00-\x1f]', part) or part.endswith(('.', ' ')) or re.match(r'^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)', part, re.I):
            raise ValueError('저장 폴더는 기본 경로 아래의 상대 경로여야 합니다.')
    root = Path(root).resolve()
    dest = root.joinpath(*parts).resolve()
    if not dest.is_relative_to(root): raise ValueError('저장 경로를 벗어났습니다.')
    return dest

def ffmpeg_path():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        return shutil.which('ffmpeg')

def commands(cid, dest, ffmpeg):
    if not CID.fullmatch(cid): raise ValueError('Invalid CHZZK channel ID')
    source = [sys.executable, '-m', 'streamlink', '--http-timeout', '15',
              '--stream-timeout', '60', '--stream-segment-attempts', '5',
              '--retry-open', '3', '--ringbuffer-size', '16M',
              '--ffmpeg-ffmpeg', str(ffmpeg), '--stdout',
              f'https://chzzk.naver.com/live/{cid}', 'best']
    sink = [str(ffmpeg), '-hide_banner', '-loglevel', 'warning', '-nostdin', '-n',
            '-i', 'pipe:0', '-map', '0:v:0', '-map', '0:a:0?', '-c', 'copy']
    if Path(dest).suffix == '.mp4':
        sink += ['-bsf:a', 'aac_adtstoasc', '-movflags', '+frag_keyframe+empty_moov+default_base_moof', '-f', 'mp4']
    else:
        sink += ['-f', 'matroska']
    return source, sink + [str(dest)]

def terminate_tree(proc):
    if not proc or proc.poll() is not None: return
    try:
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(proc.pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW, timeout=10)
        else: os.killpg(proc.pid, signal.SIGTERM)
        proc.wait(timeout=5)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        if proc.poll() is None: proc.kill(); proc.wait(timeout=5)

class DiagnosticOutput:
    """Drain both child pipes continuously; retain at most 16 KiB per process."""
    def __init__(self): self.entries = []
    def __enter__(self): return self
    def capture(self, process):
        tail = bytearray()
        def drain():
            try:
                while True:
                    data = process.stderr.read(4096)
                    if not data: break
                    tail.extend(data)
                    del tail[:-16384]
            finally:
                process.stderr.close()
        thread = threading.Thread(target=drain, daemon=True)
        self.entries.append((tail, thread))
        thread.start()
    def __exit__(self, *args):
        for tail, thread in self.entries: thread.join(timeout=1)
    def summary(self):
        return '\n'.join(bytes(tail).decode('utf-8', errors='replace')[-2000:]
                         for tail, thread in self.entries).strip()

class Job:
    def __init__(self, cid, folder, fmt, ffmpeg):
        self.cid, self.ffmpeg = cid, ffmpeg
        self.dest = Path(folder) / f'chzzk_{cid}_{time.strftime("%Y%m%d-%H%M%S")}_{uuid.uuid4().hex[:8]}.{fmt}'
        self.cancel = threading.Event()
        self.state, self.error, self.started = 'starting', None, None
        self.producer = self.consumer = None
        self.thread = threading.Thread(target=self.run, daemon=False)
    def start(self): self.thread.start()
    def stop(self): self.cancel.set()
    def snapshot(self):
        try: size = self.dest.stat().st_size
        except OSError: size = 0
        return {'channelId':self.cid, 'status':self.state, 'error':self.error, 'path':str(self.dest), 'bytes':size, 'startedAt':self.started, 'mode':'native-stream-copy', 'format':self.dest.suffix[1:]}
    def run(self):
        opts = {'creationflags':subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {'start_new_session':True}
        log = DiagnosticOutput()
        try:
            self.dest.parent.mkdir(parents=True, exist_ok=True)
            source, sink = commands(self.cid, self.dest, self.ffmpeg)
            with log:
                try:
                    if self.cancel.is_set(): self.state='stopped';return
                    self.producer = subprocess.Popen(source, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **opts)
                    log.capture(self.producer)
                    self.consumer = subprocess.Popen(sink, stdin=self.producer.stdout, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, **opts)
                    log.capture(self.consumer)
                    self.producer.stdout.close()
                    deadline=time.monotonic()+120
                    while self.producer.poll() is None and self.consumer.poll() is None:
                        if self.cancel.wait(.25): break
                        if self.started is None:
                            if self.dest.exists() and self.dest.stat().st_size > 0:
                                self.started=int(time.time()*1000);self.state='recording'
                            elif time.monotonic()>deadline:
                                raise RuntimeError('원본 스트림 연결 시간 초과')
                    # Only our producer is terminated. FFmpeg consumes EOF and finalizes.
                    self.state='stopping'
                    producer_code=self.producer.poll()
                    terminate_tree(self.producer)
                    try: code=self.consumer.wait(timeout=20)
                    except subprocess.TimeoutExpired: raise RuntimeError('파일 마무리 시간 초과')
                    if code or not self.dest.exists() or self.dest.stat().st_size==0:
                        raise RuntimeError('원본 저장 실패 · 로그인 제한/방송 종료/코덱 지원을 확인하세요.')
                    if not self.cancel.is_set() and producer_code not in (0,None):
                        raise RuntimeError('스트림 연결이 끊겼습니다. 저장된 부분을 확인하세요.')
                    self.state='stopped'
                finally:
                    terminate_tree(self.producer);terminate_tree(self.consumer)
        except Exception as exc:
            self.state='error'
            self.error=str(exc) + ('\n' + log.summary() if log.summary() else '')

class Manager:
    def __init__(self, config): self.config=config;self.jobs={}
    def dependencies(self):
        return bool(importlib.util.find_spec('streamlink')) and bool(ffmpeg_path())
    def snapshot(self): return {cid:j.snapshot() for cid,j in list(self.jobs.items())}
    def handle(self, message):
        op=message.get('op')
        if op=='ping': return {'ready':self.dependencies(),'outputRoot':self.config['outputRoot'],'version':'1.4.9.45','jobs':self.snapshot()}
        if op=='status': return {'jobs':self.snapshot()}
        if op=='stop_all':
            for job in self.jobs.values(): job.stop()
            return {'jobs':self.snapshot()}
        cid=message.get('channelId','')
        if not isinstance(cid,str) or not CID.fullmatch(cid): raise ValueError('잘못된 채널 ID')
        if op=='stop':
            if cid in self.jobs: self.jobs[cid].stop()
            return {'job':self.jobs[cid].snapshot() if cid in self.jobs else None}
        if op!='start': raise ValueError('지원하지 않는 명령')
        old=self.jobs.get(cid)
        if old and old.thread.is_alive(): return {'job':old.snapshot()}
        if not self.dependencies(): raise RuntimeError('보조 프로그램 설치를 다시 실행해 주세요. Streamlink/FFmpeg가 없습니다.')
        if sum(j.thread.is_alive() for j in self.jobs.values())>=8: raise RuntimeError('동시 녹화는 최대 8개입니다.')
        fmt=message.get('format','mp4')
        if fmt not in ('mp4','mkv'): raise ValueError('MP4 또는 MKV만 지원합니다.')
        folder=output_folder(self.config['outputRoot'],message.get('folder',''))
        job=Job(cid,folder,fmt,ffmpeg_path());self.jobs[cid]=job;job.start()
        # Bound completed session history.
        for key in list(self.jobs):
            if len(self.jobs)<=32: break
            if key!=cid and not self.jobs[key].thread.is_alive(): del self.jobs[key]
        return {'job':job.snapshot()}
    def close(self):
        for job in self.jobs.values(): job.stop()
        for job in self.jobs.values(): job.thread.join(timeout=40)

def main():
    if os.name=='nt':
        import msvcrt
        msvcrt.setmode(sys.stdin.fileno(),os.O_BINARY);msvcrt.setmode(sys.stdout.fileno(),os.O_BINARY)
    config=json.loads((BASE/'config.json').read_text(encoding='utf-8'))
    if len(sys.argv)<2 or sys.argv[1] not in config['allowedOrigins']: return
    manager=Manager(config)
    try:
        while True:
            message=read_message(sys.stdin.buffer)
            if message is None: break
            try: response={'id':message.get('id'),'ok':True,**manager.handle(message)}
            except Exception as exc: response={'id':message.get('id'),'ok':False,'error':str(exc)}
            send_message(sys.stdout.buffer,response)
    finally: manager.close()
if __name__=='__main__': main()
