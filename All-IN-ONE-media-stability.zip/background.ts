import './compatibility/recording-downloads.js';
import { installBackgroundActions } from './compatibility/background-actions.js';
// @ts-nocheck
import { runMigration } from './src/utils/StorageBridge';
import browser from 'webextension-polyfill';
import { nanoid } from 'nanoid';
import dayjs from 'dayjs';
import { safeParseSettings } from './settings-schema';

/**
 * @fileoverview 배경 서비스 워커 (리팩토링 버전)
 * - 관심사 분리 (SoC): 설정 관리, 탭 통신, 알림 로직 모듈화
 * - 안정성 강화: webextension-polyfill 도입 및 비동기 처리 개선
 * - 가독성 향상: nanoid, dayjs 활용
 */

class BackgroundService {
  constructor() {
    this.lastLiveIds = new Set();
    this.lastWatchlistLiveIds = new Set();
    this.isCheckingLive = false;
    this.isFirstCheck = true;
    this.isFirstWatchlistCheck = true;
    this.FALLBACK_ICON = browser.runtime.getURL('icons/icon128.png');

    // MV3 service workers can receive popup messages immediately after waking.
    // Register listeners synchronously before any async startup work.
    browser.runtime.onMessage.addListener((msg, sender) => {
      return this.handleMessage(msg, sender);
    });

    browser.runtime.onInstalled.addListener(() => this.handleInstall());

    browser.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'CQC_LIVE_CHECK') this.checkLiveStatus();
    });

    browser.storage.onChanged.addListener((changes, area) => {
      if (area === 'sync' && changes.settings) this.setupLiveCheckAlarm();
    });

    browser.notifications.onClicked.addListener((id) => this.handleNotificationClick(id));

    installBackgroundActions(this, browser);
    this.init();
  }

  async init() {
    // 0. 저장소 마이그레이션 실행
    await runMigration();

    // 0. 광고 차단 네트워크 룰 등록
    await this.setupAdBlockRules();

    // 3. 라이브 알림 초기화
    await this.loadLastLiveIds();
    await this.setupLiveCheckAlarm();

    // 최초 1회 실행 (5초 후)
    setTimeout(() => {
      this.checkLiveStatus();
      this.checkWatchlistStatus();
    }, 5000);
  }

  /**
   * declarativeNetRequest 광고 차단 규칙 클리어
   */
  async setupAdBlockRules() {
    try {
      if (!browser.declarativeNetRequest) return;
      await browser.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1, 2],
        addRules: []
      });
      console.log('[CQC:BG] Declarative adblock rules cleared.');
    } catch (err) {
      console.error('[CQC:BG] Failed to clear declarative adblock rules:', err);
    }
  }

  /**
   * 확장프로그램 설치/업데이트 처리
   */
  async handleInstall() {
    const { settings } = await browser.storage.sync.get('settings');
    const validated = safeParseSettings(settings);
    await browser.storage.sync.set({ settings: validated });
    console.log(`[CQC:BG] Settings validated on install at ${dayjs().format('YYYY-MM-DD HH:mm:ss')}`);
  }

  /**
   * 메시지 라우팅 핸들러
   */
  async handleMessage(msg, sender) {
    const tab = await this.getActiveChzzkTab();

    switch (msg.type || msg.action) {
      case 'GET_SETTINGS':
      case 'CQC_GET_SETTINGS': {
        const { settings } = await browser.storage.sync.get('settings');
        return safeParseSettings(settings);
      }

      case 'SAVE_SETTINGS': {
        const validated = safeParseSettings(msg.payload);
        await browser.storage.sync.set({ settings: validated });
        this.broadcastToChzzkTabs({ type: 'SETTINGS_UPDATED', payload: validated });
        return { success: true };
      }

      case 'CQC_SAVE_SELECTOR': {
        const { settings: currentSettings } = await browser.storage.sync.get('settings');
        const validated = safeParseSettings(currentSettings);
        if (!validated.customSelectors) {
          validated.customSelectors = {};
        }
        validated.customSelectors[msg.key] = msg.selector;
        await browser.storage.sync.set({ settings: validated });
        this.broadcastToChzzkTabs({ type: 'CQC_SELECTORS_UPDATED', payload: validated.customSelectors });
        return { success: true, customSelectors: validated.customSelectors };
      }

      case 'CQC_RESET_SELECTOR': {
        const { settings: currentSettings } = await browser.storage.sync.get('settings');
        const validated = safeParseSettings(currentSettings);
        if (validated.customSelectors) {
          delete validated.customSelectors[msg.key];
        }
        await browser.storage.sync.set({ settings: validated });
        this.broadcastToChzzkTabs({ type: 'CQC_SELECTORS_UPDATED', payload: validated.customSelectors || {} });
        return { success: true, customSelectors: validated.customSelectors || {} };
      }

      case 'START_SELECTOR_INSPECTOR':
        if (tab?.id) {
          browser.tabs.sendMessage(tab.id, { type: 'START_SELECTOR_INSPECTOR' }).catch(() => {});
          return { success: true };
        }
        return { success: false, error: 'no_active_tab' };

      case 'CQC_SELECTORS_UPDATED':
        this.broadcastToChzzkTabs({ type: 'CQC_SELECTORS_UPDATED', payload: msg.payload });
        return { success: true };

      case 'GET_PLAYER_STATE':
        return tab?.id ? browser.tabs.sendMessage(tab.id, { type: 'REQUEST_STATE' }, { frameId: 0 }).catch(() => null) : null;

      case 'CHANGE_QUALITY':
        return tab?.id ? browser.tabs.sendMessage(tab.id, { type: 'CHANGE_QUALITY', payload: msg.payload }, { frameId: 0 }).catch(() => ({ success: false })) : { success: false };

      case 'FORCE_REAPPLY':
        return tab?.id ? browser.tabs.sendMessage(tab.id, { type: 'FORCE_REAPPLY' }, { frameId: 0 }).catch(() => ({ success: false })) : { success: false };

      case 'GET_POWER_CHANNELS':
        return tab?.id ? browser.tabs.sendMessage(tab.id, { type: 'GET_POWER_CHANNELS' }).catch(() => []) : [];

      case 'POWER_RESET_CHANNELS':
        if (tab?.id) await browser.tabs.sendMessage(tab.id, { type: 'POWER_RESET_CHANNELS', payload: msg.payload }).catch(() => { });
        return { success: true };

      case 'OPEN_SETTINGS':
        browser.windows.create({ url: 'popup.html', type: 'popup', width: 500, height: 800 });
        return { success: true };

      case 'FETCH_NOTICES':
        try {
          const res = await fetch('https://comm-api.game.naver.com/nng_main/v1/community/lounge/chzzk/feed?boardId=1&buffFilteringYN=N&limit=25&offset=0&order=NEW');
          if (!res.ok) throw new Error('API request failed');
          const data = await res.json();
          return { success: true, data: data.content };
        } catch (e) {
          console.error('[CQC:BG] FETCH_NOTICES error:', e);
          return { success: false, error: e.message };
        }

      case 'RESOLVE_CHANNEL_ID': {
        try {
          const input = msg.payload?.trim();
          if (!input) return { success: false, error: 'invalid_url' };
          // URL에서 ID 추출 또는 ID 직접 입력 지원
          let channelId = null;
          const urlMatch = input.match(/chzzk\.naver\.com\/live\/([a-f0-9]+)/i)
            || input.match(/chzzk\.naver\.com\/([a-f0-9]+)/i);
          if (urlMatch) {
            channelId = urlMatch[1];
          } else if (/^[a-f0-9]{20,}$/i.test(input)) {
            // 20자 이상 hex 문자열이면 채널 ID로 간주
            channelId = input;
          } else {
            return { success: false, error: 'invalid_url' };
          }
          const resp = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${channelId}`, { credentials: 'include' });
          const json = await resp.json();
          if (json.code !== 200 || !json.content) return { success: false, error: 'channel_not_found' };
          return { success: true, channelId, channelName: json.content.channelName };
        } catch (e) {
          console.error('[CQC:BG] RESOLVE_CHANNEL_ID error:', e);
          return { success: false, error: e.message };
        }
      }

      default:
        return { error: 'unhandled_type', type: msg.type || msg.action };
    }
  }

  /**
   * 치지직 관련 탭 중 활성화된 탭 혹은 첫 번째 탭 반환
   */
  async getActiveChzzkTab() {
    const [activeTab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (activeTab?.url?.includes('chzzk.naver.com')) return activeTab;

    const chzzkTabs = await browser.tabs.query({ url: '*://chzzk.naver.com/*' });
    return chzzkTabs[0] || null;
  }

  /**
   * 모든 치지직 탭에 메시지 전송
   */
  async broadcastToChzzkTabs(msg) {
    const tabs = await browser.tabs.query({ url: '*://chzzk.naver.com/*' });
    tabs.forEach(t => t.id && browser.tabs.sendMessage(t.id, msg).catch(() => { }));
  }

  /* ═══════════════════════════════════════════
     라이브 모니터링 로직
     ═══════════════════════════════════════════ */

  async loadLastLiveIds() {
    const { lastLiveIds: savedIds } = await browser.storage.local.get('lastLiveIds');
    if (Array.isArray(savedIds)) this.lastLiveIds = new Set(savedIds);
  }

  async setupLiveCheckAlarm() {
    const { settings } = await browser.storage.sync.get('settings');
    const interval = settings?.liveNotificationInterval || 3;
    await browser.alarms.clear('CQC_LIVE_CHECK');
    browser.alarms.create('CQC_LIVE_CHECK', { periodInMinutes: interval });
  }

  async checkLiveStatus() {
    if (this.isCheckingLive) return;
    this.isCheckingLive = true;

    try {
      const { settings } = await browser.storage.sync.get('settings');
      const needAutoOpen = settings?.liveAutoOpenEnabled && settings?.liveAutoOpenChannels?.length > 0;
      if (!settings?.enabled || (!settings?.liveNotificationEnabled && !settings?.liveAutoReloadEnabled && !needAutoOpen)) return;

      const resp = await fetch('https://api.chzzk.naver.com/service/v1/channels/followings/live', { credentials: 'include' });
      const json = await resp.json();
      if (json.code !== 200 || !json.content?.followingList) return;

      // 자동 열기 대상 채널 ID Set (팔로우 기반 A안)
      const autoOpenIds = new Set((settings?.liveAutoOpenChannels || []).map(ch => ch.channelId));

      const currentLiveIds = new Set();
      for (const item of json.content.followingList) {
        if (item.streamer?.openLive) {
          const chId = item.channelId;
          currentLiveIds.add(chId);

          if (!this.lastLiveIds.has(chId)) {
            if (!this.isFirstCheck && settings?.liveNotificationEnabled) {
              const isBlocked = (settings?.liveNotificationDisabledChannels || []).some(ch => ch.channelId === chId);
              if (!isBlocked) {
                const chName = item.channel?.channelName ?? item.channelName;
                await this.sendLiveNotification(chId, chName, item.liveInfo?.liveTitle, item.channel?.channelImageUrl);
              }
            }
            if (settings?.liveAutoReloadEnabled && !(needAutoOpen && autoOpenIds.has(chId))) this.reloadStreamerTab(chId);

            // A안: 팔로우 채널 자동 열기
            if (needAutoOpen && autoOpenIds.has(chId)) {
              await this.openStreamerTab(chId);
            }
          }
        }
      }

      this.isFirstCheck = false;
      this.lastLiveIds = currentLiveIds;
      await browser.storage.local.set({ lastLiveIds: Array.from(this.lastLiveIds) });
    } catch (err) {
      console.error('[CQC:BG] Live check failed:', err);
    } finally {
      this.isCheckingLive = false;
    }

    // B안: watchlist 채널도 함께 체크
    await this.checkWatchlistStatus();
  }

  /**
   * B안: URL 직접 등록된 채널 중 팔로우하지 않은 채널의 라이브 상태 체크
   */
  async checkWatchlistStatus() {
    try {
      const { settings } = await browser.storage.sync.get('settings');
      if (!settings?.enabled || !settings?.liveAutoOpenEnabled) return;
      const channels = settings?.liveAutoOpenChannels || [];
      if (channels.length === 0) return;

      // 팔로우 목록에서 이미 체크된 채널 제외
      const followChecked = this.lastLiveIds || new Set();
      const watchOnly = channels.filter(ch => !followChecked.has(ch.channelId));
      if (watchOnly.length === 0) return;

      for (const ch of watchOnly) {
        try {
          const resp = await fetch(`https://api.chzzk.naver.com/polling/v1/channels/${ch.channelId}/live-status`, { credentials: 'include' });
          const json = await resp.json();
          const isLive = json.content?.status === 'OPEN';

          if (isLive && !this.lastWatchlistLiveIds.has(ch.channelId)) {
            if (!this.isFirstWatchlistCheck) {
              await this.openStreamerTab(ch.channelId);
              console.log(`[CQC:BG] Watchlist auto-open: ${ch.channelName} (${ch.channelId})`);
            }
          }

          if (isLive) this.lastWatchlistLiveIds.add(ch.channelId);
          else this.lastWatchlistLiveIds.delete(ch.channelId);
        } catch (e) {
          console.warn(`[CQC:BG] Watchlist check failed for ${ch.channelId}:`, e);
        }
      }
      this.isFirstWatchlistCheck = false;
    } catch (err) {
      console.error('[CQC:BG] Watchlist check failed:', err);
    }
  }

  /**
   * 채널 라이브 탭 자동 열기 (중복 방지)
   */
  async openStreamerTab(chId) {
    const { settings } = await browser.storage.sync.get('settings');
    if (!settings?.enabled || !settings.liveAutoOpenEnabled || !settings.liveAutoOpenChannels?.some(ch => ch.channelId === chId)) return;
    const record = settings.liveAutoRecordChannels?.includes(chId);
    const existing = await browser.tabs.query({ url: `*://chzzk.naver.com/live/${chId}*` });
    if (existing.length) {
      if (record && existing[0].id) {
        try { await browser.tabs.sendMessage(existing[0].id, {type:'CQC_AUTO_RECORD_START'}); } catch {}
      }
      return;
    }
    await browser.tabs.create({url:`https://chzzk.naver.com/live/${chId}${record ? '?cqc_auto_record=1' : ''}`,active:false});
  }

  async reloadStreamerTab(chId) {
    const tabs = await browser.tabs.query({ url: `*://chzzk.naver.com/live/${chId}*` });
    for (const tab of tabs) {
      if (!tab.id) continue;
      try { const status = await browser.tabs.sendMessage(tab.id, {type:'CQC_RECORD_STATUS'}); if(status?.recording) continue; } catch {}
      await browser.tabs.reload(tab.id);
    }
  }

  async sendLiveNotification(chId, name, title, icon) {
    const iconUrl = icon ? (await this.fetchImageAsDataUrl(icon) ?? this.FALLBACK_ICON) : this.FALLBACK_ICON;
    // nanoid를 사용하여 고유한 알림 ID 생성
    const notificationId = `cqc-live-${chId}-${nanoid(8)}`;

    browser.notifications.create(notificationId, {
      type: 'basic',
      iconUrl,
      title: `[치지직] ${name} 생방송 시작!`,
      message: title || '방송을 시작했습니다.',
      contextMessage: `알림 시간: ${dayjs().format('HH:mm')}`,
      priority: 2
    });
  }

  async fetchImageAsDataUrl(url) {
    try {
      const resp = await fetch(url);
      const buffer = await resp.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = '';
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
      return `data:${resp.headers.get('content-type') || 'image/jpeg'};base64,${btoa(binary)}`;
    } catch {
      return null;
    }
  }

  handleNotificationClick(id) {
    if (id.startsWith('cqc-live-')) {
      const parts = id.split('-');
      // nanoid 도입으로 인덱스가 변경됨: cqc-live-{chId}-{nanoid}
      const chId = parts[2];
      if (chId) browser.tabs.create({ url: `https://chzzk.naver.com/live/${chId}` });
    }
  }
}

// 서비스 실행
new BackgroundService();
