// @ts-nocheck
import { InjectedModule } from '../core/InjectedRuntime';
import {
  getChannelData,
  SELECTORS,
  REGEX,
  triggerReact,
  ConsoleLogger
} from '../../../dom-utils';
import { initAdPopupWatch, retryDismissAdPopup } from '../../../ad-popup';
import { initPlayerUIHooks } from '../../../playback-bar';

const POLL_INTERVAL = 200;
const MAX_POLL_ATTEMPTS = 100;
const SAFE_LIVE_GAP = 2;

/**
 * 플레이어 미디어 트랙 정규식 패턴 정의
 */
const REGEX_TRACK = {
  BYPASS: /^muxed\.bw_|^ABR/,
  GRID: /HLS_DRM_FREE/,
  LOW_LATENCY: /\.lowlatency$|_lowlatency/
};

/**
 * 플레이어 미디어 트랙 유형 판별식 정의
 */
const TRACK_TYPES = {
  /**
   * 그리드 프로그램이 필요 없는 우회 트랙 여부 판별
   * @param {any} t - 트랙 객체
   */
  BYPASS: (t: any) => {
    if (!t || typeof t.id !== 'string') {
      return false;
    }
    return REGEX_TRACK.BYPASS.test(t.id) || (typeof t.label === 'string' && REGEX_TRACK.BYPASS.test(t.label));
  },
  /**
   * 그리드 프로그램이 필요한 트랙 여부 판별 (DRM Free HLS)
   * @param {any} t - 트랙 객체
   */
  GRID: (t: any) => {
    if (!t || typeof t.id !== 'string') {
      return false;
    }
    return REGEX_TRACK.GRID.test(t.id) || (typeof t.label === 'string' && REGEX_TRACK.GRID.test(t.label));
  },
  /**
   * 저지연(Low Latency) 트랙 여부 판별
   * @param {any} t - 트랙 객체
   */
  LOW_LATENCY: (t: any) => {
    if (!t || typeof t.id !== 'string') {
      return false;
    }
    return REGEX_TRACK.LOW_LATENCY.test(t.id);
  }
};

export class PlayerModule implements InjectedModule {
  name = 'PlayerModule';
  runtime: any;
  pollTimer: any = null;
  monitorTimer: any = null;
  lastReapplyTime = 0;
  lastPlayerPath: string | null = null;
  watchStartTime = 0;
  lastGoLiveTime = 0;
  lastHasAes: boolean | null = null;
  lastIsAudioOnly: boolean | null = null;
  lastLivePlaybackJson: string | null = null;
  lastRadioModePlaybackJson: string | null = null;
  lastAbsoluteLatency?: number;
  private qualityMenuListener: ((e: MouseEvent) => void) | null = null;

  // URL 변경 감시용 (SPA 대응)
  lastUrl = location.href;

  mount(settings: any) {
    this.runtime.state.manualPlaybackRate = 1.0;
    this.runtime.state.nativeLLForced = false;
    this.runtime.state.hasBeenBehind = false;

    this.hookNav();
    initPlayerUIHooks(this.runtime.state, settings);
    if (this.hasPlayer()) {
      this.startPoll();
    } else {
      // MutationObserver 대신 DomPresencePoller 사용
      this.runtime.observer.poller.waitFor(
        'playerWait',
        SELECTORS.PLAYER,
        () => this.startPoll(),
        { interval: 500, timeout: 10000 }
      );
    }

    initAdPopupWatch(settings, (type: any, payload: any) => this.runtime.post(type, payload));
    this.applyWideView();
    this.hookQualityMenu();
  }

  cleanup() {
    this.stopPoll();
    this.stopMonitor();

    document.getElementById('cqc-playback-speed-btn')?.remove();
    document.querySelectorAll('.cqc-volume-indicator').forEach(el => el.remove());

    this.lastPlayerPath = null;
    this.watchStartTime = 0;
    this.lastUrl = location.href;

    window.removeEventListener('popstate', this.onUrlBound);

    if (this.qualityMenuListener) {
      document.removeEventListener('click', this.qualityMenuListener, true);
      this.qualityMenuListener = null;
    }
  }

  applyWideView() {
    const isMv = document.body.classList.contains('cqc-is-mv-iframe');
    const enabled = this.runtime.settings?.enabled;
    const wideEnabled = this.runtime.settings?.wideViewEnabled;
    if (!enabled || (!wideEnabled && !isMv) || !this.hasPlayer()) return;

    let attemptCount = 0;
    const attempt = () => {
      const isMvActive = document.body.classList.contains('cqc-is-mv-iframe');
      const currentWideEnabled = this.runtime.settings?.wideViewEnabled;
      if ((!currentWideEnabled && !isMvActive) || !this.runtime.state.ready) return;

      const player = document.querySelector(SELECTORS.PLAYER);
      if (!player) {
        if (attemptCount < 20) {
          attemptCount++;
          setTimeout(attempt, 200);
        }
        return;
      }

      const btn = player.querySelector(SELECTORS.VIEW_MODE_BTN);

      if (!btn) {
        if (attemptCount < 20) {
          attemptCount++;
          setTimeout(attempt, 200);
        }
        return;
      }

      const label = btn.getAttribute('aria-label');
      const isActuallyWide = label === SELECTORS.VIEW_MODE_DEFAULT_LABEL || label === SELECTORS.VIEW_MODE_NARROW_LABEL || label === SELECTORS.VIEW_MODE_FULL_EXIT_LABEL ||
        player.classList.contains(SELECTORS.PLAYER_WIDE_CLASS_PC) ||
        player.classList.contains(SELECTORS.PLAYER_WIDE_CLASS);

      const isMvForced = document.body.classList.contains('cqc-mv-wide-forced');

      if (!isActuallyWide && (label === SELECTORS.VIEW_MODE_WIDE_LABEL || !label || isMvForced)) {
        ConsoleLogger.log('info', 'Player', '[자동 넓은 화면] 적용 시도');
        if (!triggerReact(btn as HTMLElement)) {
          (btn as any).click();
        }
      }
    };
    attempt();
  }

  // messageListener 내부 switch 문 대응
  async onMessage(type: string, payload: any, id: number): Promise<boolean> {
    switch (type) {
      case 'REQUEST_STATE':
        if (this.runtime.state.ready && this.runtime.state.core) {
          this.refreshTracks();
        }
        this.runtime.respond(id, this.exportState());
        return true;

      case 'CHANGE_QUALITY':
        ConsoleLogger.log('info', 'Player', '화질 변경 요청', payload);
        this.runtime.respond(id, this.changeQuality(payload, true));
        return true;

      case 'GO_LIVE': {
        ConsoleLogger.log('info', 'Player', 'goLive 요청 (안전 시크)');
        const v = document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video');
        if (v && v.seekable && v.seekable.length > 0) {
          const end = v.seekable.end(v.seekable.length - 1);
          v.currentTime = end - SAFE_LIVE_GAP;
        }
        this.runtime.respond(id, { ok: true });
        return true;
      }

      case 'RESET_PLAYBACK_SPEED':
        this.runtime.respond(id, { ok: true });
        return true;

      case 'SET_PLAYBACK_SPEED':
        //ConsoleLogger.log('info', 'Player', '수동 배속 설정 요청', payload);
        //console.log('[CQC:Injected] 수동 배속 설정 요청 수신:', payload);
        this.runtime.state.manualPlaybackRate = typeof payload === 'number' ? payload : 1.0;
        const video = document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video');
        if (video) {
          video.playbackRate = this.runtime.state.manualPlaybackRate;
        }
        this.runtime.respond(id, { ok: true });
        return true;

      case 'FORCE_REAPPLY':
        ConsoleLogger.log('info', 'Player', '강제 재적용 요청');
        this.runtime.state.manualQualitySelection = false;
        this.runtime.respond(id, { success: this.applyPreferred(true) });
        return true;

      case 'REQUEST_STATS': {
        const stats = this.getDetailedStats();
        this.runtime.respond(id, stats);
        return true;
      }

      case 'DISMISS_AD_POPUP':
        retryDismissAdPopup(this.runtime.settings, (type: any, payload: any) => this.runtime.post(type, payload));
        this.runtime.respond(id, { ok: true });
        return true;

      case 'CQC_SEEK': {
        const { time } = payload;
        const store = this.runtime.state.root?.$store;
        const video = document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video');

        if (typeof time === 'number' && isFinite(time)) {
          ConsoleLogger.log('info', 'Player', `[CQC:SEEK] 요청: ${time.toFixed(2)}s (Store: ${!!store}, Video: ${!!video})`);

          if (video) {
            video.dataset.cqcTimeshifting = 'true';
            video.dataset.cqcLastSeekTime = Date.now().toString();
          }

          if (store) {
            store.dispatch('seek', time).catch(() => { });
          }

          if (video) {
            try {
              video.currentTime = time;
            } catch (e) {
              ConsoleLogger.log('error', 'Player', '[CQC:SEEK] 물리적 시크 실패', e);
            }
          }
        }
        this.runtime.respond(id, { ok: true });
        return true;
      }

      case 'CQC_GO_LIVE': {
        const store = this.runtime.state.root?.$store;
        const video = document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video');

        ConsoleLogger.log('info', 'Player', `[CQC:GO_LIVE] 요청 수신 (Store: ${!!store}, Video: ${!!video})`);

        if (video) video.dataset.cqcTimeshifting = 'false';

        if (store) {
          try {
            store.dispatch('goLive');
          } catch (e: any) {
            ConsoleLogger.log('error', 'Player', '[CQC:GO_LIVE] 네이티브 액션 에러', e.message);
          }

          if (video) {
            if (video.seekable && video.seekable.length > 0) {
              const end = video.seekable.end(video.seekable.length - 1);
              if (isFinite(end)) {
                video.currentTime = end;
                ConsoleLogger.log('info', 'Player', `[CQC:GO_LIVE] 물리적 시크 성공: ${end.toFixed(2)}s`);
              } else {
                ConsoleLogger.log('warn', 'Player', '[CQC:GO_LIVE] seekable.end가 Finite가 아님');
              }
            } else {
              ConsoleLogger.log('warn', 'Player', '[CQC:GO_LIVE] video.seekable이 비어있음');
            }
          }

          store.dispatch('seek', 1e9).catch(() => { });
        } else {
          ConsoleLogger.log('warn', 'Player', '[CQC:GO_LIVE] Store를 찾을 수 없어 명령을 처리할 수 없습니다.');
        }
        this.runtime.respond(id, { ok: true });
        return true;
      }
    }
    return false;
  }

  isLiveRoute() {
    if (location.pathname.startsWith('/video/')) return false;
    return /^\/live\//.test(location.pathname) || (this.runtime.state.root?.$store?.state?.live === true);
  }

  private hasAesStream(): boolean {
    if (!this.isLiveRoute()) return false;
    try {
      const el = document.querySelector(SELECTORS.PLAYER_LAYOUT)
        || document.querySelector(SELECTORS.LIVE_PLAYER_ALT)
        || document.querySelector(`${SELECTORS.PLAYER}, ${SELECTORS.PLAYER_PC}`)
        || document.body;
      if (!el) return false;

      const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
      const startFiber = fiberKey ? (el as any)[fiberKey] : null;
      if (!startFiber) return false;

      let foundJson: string | null = null;
      let foundRadioJson: string | null = null;
      const visitedFibers = new Set<any>();

      const fiberStack = [startFiber];
      while (fiberStack.length > 0 && !(foundJson && foundRadioJson)) {
        const node = fiberStack.pop();
        if (!node || visitedFibers.has(node)) continue;
        visitedFibers.add(node);

        const targets = ['memoizedProps', 'memoizedState', 'pendingProps'];
        for (const t of targets) {
          try {
            const obj = node[t];
            if (obj && typeof obj === 'object') {
              const objStack: [any, number][] = [[obj, 0]];
              const visitedObj = new Set<any>();
              while (objStack.length > 0) {
                const [curr, depth] = objStack.pop()!;
                if (!curr || visitedObj.has(curr) || depth > 10) continue;
                visitedObj.add(curr);

                if (typeof curr.livePlaybackJson === 'string') {
                  foundJson = curr.livePlaybackJson;
                }
                if (curr.live && typeof curr.live.livePlaybackJson === 'string') {
                  foundJson = curr.live.livePlaybackJson;
                }
                if (typeof curr.radioModePlaybackJson === 'string') {
                  foundRadioJson = curr.radioModePlaybackJson;
                }
                if (curr.live && typeof curr.live.radioModePlaybackJson === 'string') {
                  foundRadioJson = curr.live.radioModePlaybackJson;
                }

                if (foundJson && foundRadioJson) break;

                for (const k in curr) {
                  if (curr[k] && typeof curr[k] === 'object' && !(curr[k] instanceof HTMLElement)) {
                    objStack.push([curr[k], depth + 1]);
                  }
                }
              }
            }
          } catch { }
          if (foundJson && foundRadioJson) break;
        }

        if (node.child) fiberStack.push(node.child);
        if (node.sibling) fiberStack.push(node.sibling);
      }

      this.lastLivePlaybackJson = foundJson;
      this.lastRadioModePlaybackJson = foundRadioJson;

      let detected = false;
      if (foundJson) {
        detected = foundJson.includes('"aes"') || foundJson.includes('"hls_aes"');
      }
      if (!detected && foundRadioJson) {
        detected = foundRadioJson.includes('"aes"') || foundRadioJson.includes('"hls_aes"');
      }

      if (detected !== this.lastHasAes) {
        this.lastHasAes = detected;
        ConsoleLogger.log(
          'info',
          'Player',
          `[AES 감지] 상태 변경: ${detected ? '감지됨 (그리드 우회 강제 비활성화)' : '감지되지 않음'}`
        );

        const core = this.runtime.state.core;
        ConsoleLogger.log('info', 'Player', '[AES 감지] RAW DUMP:', {
          livePlaybackJson: foundJson,
          radioModePlaybackJson: foundRadioJson,
          videoTracks: typeof core?.getVideoTracksList === 'function' ? core.getVideoTracksList() : null,
          audioTracks: typeof core?.getAudioTracksList === 'function' ? core.getAudioTracksList() : null
        });
      }

      return detected;
    } catch (e: any) {
      ConsoleLogger.log('error', 'Player', '[AES 감지] 치명적 오류 발생', e.message);
    }
    return false;
  }

  getRoot() {
    const el = document.querySelector(SELECTORS.PLAYER) || document.querySelector(SELECTORS.PLAYER_PC) || document.querySelector('.webplayer-internal-video')?.parentElement;
    if (!el) return null;
    let vue = (el as any).__vue__;
    if (!vue) {
      const children = el.querySelectorAll('*');
      for (const child of Array.from(children)) {
        if ((child as any).__vue__) {
          vue = (child as any).__vue__;
          break;
        }
      }
    }
    return vue ?? null;
  }

  findCore(node: any, d = 0): any {
    if (d > 10) return null;
    if (typeof node.getVideoTracksList === 'function') return node;
    for (const c of (node.$children ?? [])) {
      const f = this.findCore(c, d + 1);
      if (f) return f;
    }
    return null;
  }

  forceLowLatency() {
    if (!this.runtime.state.ready || !this.runtime.state.root || !this.isLiveRoute()) return;
    const targetLL = !!this.runtime.settings?.preferLowLatency;

    try {
      const store = this.runtime.state.root.$store;
      if (!store || !store.state || !store._actions) return;

      const s = store.state;
      const isCurrentlyEnabled = !!(s.lowLatencyEnabled || s.lowLatency || s.lowLatencyMode);

      if (isCurrentlyEnabled !== targetLL) {
        ConsoleLogger.log('info', 'Player', `[저지연] 네이티브 저지연 모드 ${targetLL ? '활성화' : '비활성화'} 시도`);

        store.dispatch('updatePlayerState', { lowLatencyEnabled: targetLL });

        const mut = targetLL ? true : false;
        if (store._mutations['setLowLatencyEnabled']) {
          store.commit('setLowLatencyEnabled', mut);
        } else if (store._mutations['SET_LOW_LATENCY_ENABLED']) {
          store.commit('SET_LOW_LATENCY_ENABLED', mut);
        } else if (store._mutations['updatePlayerState']) {
          store.commit('updatePlayerState', { lowLatencyEnabled: mut });
        }

        this.runtime.state.nativeLLForced = targetLL;

        setTimeout(() => {
          const fs = store.state;
          const isActuallyEnabled = !!(fs.lowLatencyEnabled || fs.lowLatency || fs.lowLatencyMode);
          ConsoleLogger.log('info', 'Player', `[저지연] 상태 검증: ${isActuallyEnabled === targetLL ? '성공' : '실패'}`);

          if (isActuallyEnabled === targetLL && this.runtime.settings?.autoQuality) {
            ConsoleLogger.log('info', 'Player', `[저지연] 모드 ${targetLL ? '활성화' : '비활성화'}됨. 적절한 트랙으로 전환합니다.`);
            this.applyPreferred();
          }
        }, 500);
      }
    } catch (e) {
      ConsoleLogger.log('error', 'Player', '[저지연] 동기화 실패', e);
    }
  }

  getTracks(core: any) {
    try {
      const rawTracks = Object.values(core.getVideoTracksList());
      const tracks = rawTracks.filter((t: any) => t && typeof t.label === 'string');

      if (!this.runtime.settings) {
        return tracks;
      }

      if (!this.isLiveRoute()) {
        return tracks.filter((t: any) => Number(t.height) > 0 && t.label !== 'ABR');
      }

      // DRM 스트림 확인 (트랙 ID에 DRM이 있고 DRM_FREE가 없는 경우)
      const hasDrm = tracks.some((t: any) => typeof t.id === 'string' && t.id.includes('DRM') && !t.id.includes('DRM_FREE'));
      const hasAes = this.hasAesStream();
      const isAudioOnly = (!this.lastLivePlaybackJson || this.lastLivePlaybackJson === 'null') &&
        (typeof this.lastRadioModePlaybackJson === 'string' && this.lastRadioModePlaybackJson !== 'null');

      // 오디오 전용 상태 변경 감지 디버그 로그
      if (isAudioOnly !== this.lastIsAudioOnly) {
        this.lastIsAudioOnly = isAudioOnly;
        ConsoleLogger.log(
          'info',
          'Player',
          `[오디오 전용 감지] 상태 변경: ${isAudioOnly ? '감지됨 (그리드 우회 강제 비활성화)' : '감지되지 않음'}`
        );
        ConsoleLogger.log('info', 'Player', '[오디오 전용 감지] RAW DUMP:', {
          livePlaybackJson: this.lastLivePlaybackJson,
          radioModePlaybackJson: this.lastRadioModePlaybackJson,
          videoTracks: typeof core?.getVideoTracksList === 'function' ? core.getVideoTracksList() : null
        });
      }

      // DRM 또는 AES 스트림이거나 오디오만 있는 상태이면 우회를 강제 비활성화하여 라이브 DRM/암호화 오디오 트랙을 보존
      let isBypassActive = this.runtime.settings?.gridBypassEnabled !== false;
      if (hasDrm || hasAes || isAudioOnly) {
        isBypassActive = false;
      }

      // 우회 옵션이 켜져있다면 P2P(그리드) 경로를 명시적으로 제거하여 일반 CDN 재생 유도
      if (isBypassActive) {
        tracks.forEach((t: any) => {
          if (t.dataset) {
            if (t.dataset.p2pPath) t.dataset.p2pPath = null;
            if (t.dataset.p2pPathUrlEncoding) t.dataset.p2pPathUrlEncoding = null;
          }
        });
      }

      return tracks.filter((t: any) => {
        if (t.label === 'ABR') return true;

        const h = Number(t.height);
        const isHighRes = (h === 720 || h === 1080);

        if (isBypassActive) {
          if (isHighRes) {
            return TRACK_TYPES.BYPASS(t);
          }
        } else {
          if (isHighRes) {
            return TRACK_TYPES.GRID(t);
          }
        }
        return true;
      });
    } catch { return []; }
  }

  detectLL(tracks: any[]) {
    const cur = tracks.find(t => t._selected);
    const isLL = (id: string) => id?.includes('.lowlatency') || id?.includes('_lowlatency');
    return cur ? (isLL(cur.id) ?? false) : tracks.some(t => isLL(t.id));
  }

  refreshTracks() {
    if (!this.runtime.state.core) return;
    const tracks = this.getTracks(this.runtime.state.core);
    const cur = tracks.find((t: any) => t._selected);
    if (cur) {
      this.runtime.state.currentTrack = cur;
      this.runtime.state.gridBypassed = TRACK_TYPES.BYPASS(cur);
      const nativeLL = !!(this.runtime.state.root?.$store?.state?.lowLatencyEnabled || this.runtime.state.root?.$store?.state?.lowLatency);
      this.runtime.state.isLowLatency = TRACK_TYPES.LOW_LATENCY(cur) || nativeLL;
    }
  }

  private matchTrack(availableTracks: any[], heightNum: number, isBypassActive: boolean, targetLL: boolean): any {
    const filter = isBypassActive ? TRACK_TYPES.BYPASS : TRACK_TYPES.GRID;
    const isNotABR = (x: any) => x.id !== 'ABR' && x.label !== 'ABR' && x.label?.toLowerCase() !== 'abr';
    return availableTracks.find((x: any) => x.height === heightNum && isNotABR(x) && filter(x) && TRACK_TYPES.LOW_LATENCY(x) === targetLL)
      || availableTracks.find((x: any) => x.height === heightNum && isNotABR(x) && filter(x))
      || availableTracks.find((x: any) => x.height === heightNum && isNotABR(x) && (!isBypassActive ? !TRACK_TYPES.BYPASS(x) : true) && TRACK_TYPES.LOW_LATENCY(x) === targetLL)
      || availableTracks.find((x: any) => x.height === heightNum && isNotABR(x));
  }

  changeQuality(targetHeight: any, isManual = false) {
    if (!this.runtime.state.ready || !this.runtime.state.root) return { success: false, reason: '플레이어 미준비' };
    if (!this.runtime.settings) return { success: false, reason: '설정 미준비' };

    const tracks = this.getTracks(this.runtime.state.core);
    const hasDrm = tracks.some((t: any) => typeof t.id === 'string' && t.id.includes('DRM') && !t.id.includes('DRM_FREE'));
    const hasAes = this.hasAesStream();
    const isAudioOnly = (!this.lastLivePlaybackJson || this.lastLivePlaybackJson === 'null') &&
      (typeof this.lastRadioModePlaybackJson === 'string' && this.lastRadioModePlaybackJson !== 'null');

    let isBypassActive = this.runtime.settings?.gridBypassEnabled !== false;
    if (hasDrm || hasAes || isAudioOnly) {
      isBypassActive = false;
    }

    const isLive = this.isLiveRoute();

    // 라이브 환경이고 오디오만 있다면 자동(ABR) 화질 선택 차단
    if (isLive && isAudioOnly && targetHeight === 'ABR') {
      ConsoleLogger.log('warn', 'Player', '[화질 변경 제한] 오디오 전용 스트림에서 ABR 화질 변경 차단');
      return { success: false, reason: '오디오 전용 스트림 자동 화질 차단' };
    }

    // 라이브 환경에서 일반 자동(ABR) 화질 선택 시 차단 (단, AES/DRM 스트림 제외)
    if (isLive && !hasDrm && !hasAes && targetHeight === 'ABR') {
      ConsoleLogger.log('warn', 'Player', '[화질 변경 제한] 라이브 환경에서 ABR 화질 변경 차단 (GRID 필수)');
      return { success: false, reason: '라이브 자동 화질 차단' };
    }

    const targetLL = !!this.runtime.settings?.preferLowLatency;

    let t: any;
    if (targetHeight === 'ABR') {
      if (!this.isLiveRoute()) {
        const fallbackQualities = [1080, 720, 480, 360, 144];
        for (const q of fallbackQualities) {
          t = tracks.find((x: any) => x.height === q);
          if (t) break;
        }
      } else {
        t = tracks.find((x: any) => x.label === 'ABR' || x.label?.toLowerCase() === 'abr' || x.height === 0);
      }
    } else {
      const heightNum = typeof targetHeight === 'string' ? parseInt(targetHeight, 10) : targetHeight;
      t = this.matchTrack(tracks, heightNum, isBypassActive, targetLL);
    }

    if (!t && !isManual) {
      const heightNum = Number(targetHeight);
      if (!isNaN(heightNum)) {
        const fallbackHeights = [...new Set(tracks.map((x: any) => x.height))]
          .filter(h => h > 0 && h <= heightNum)
          .sort((a, b) => b - a);
        const h = fallbackHeights[0];
        if (h) {
          t = this.matchTrack(tracks, h, isBypassActive, targetLL);
        }
      }
    }

    if (!t) {
      ConsoleLogger.log('warn', 'Player', `[화질] ${targetHeight}p 트랙을 매칭하지 못함`);
      return { success: false, reason: `${targetHeight}${targetHeight === 'ABR' ? '' : 'p'} 없음`, available: tracks.map((x: any) => x.label) };
    }

    try {
      if (this.runtime.state.lastAppliedQuality === targetHeight && this.runtime.state.currentTrack?.id === t.id) {
        if (isManual) this.runtime.state.manualQualitySelection = true;
        return { success: true };
      }

      if (isManual) {
        this.runtime.state.manualQualitySelection = true;
      }

      this.runtime.state.isApplyingQuality = true;
      this.runtime.state.root.$store.dispatch('selectVideoTrack', t.id);
      this.runtime.state.currentTrack = t;
      this.runtime.state.gridBypassed = TRACK_TYPES.BYPASS(t);
      this.runtime.state.lastAppliedQuality = targetHeight;

      ConsoleLogger.log('groupCollapsed', 'Player', `[화질 전환 완료] ${t.height}p 적용됨`, {
        '대상 화질': targetHeight,
        '트랙 명': t.label,
        '트랙 ID': t.id,
        '비트레이트': t.videoBitrate,
        '수동 선택 여부': isManual
      });

      setTimeout(() => {
        try {
          const p = this.runtime.state.root.player;
          const core = p || this.runtime.state.root;
          if (core && typeof core.play === 'function') {
            core.play();
          } else {
            const video = (document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video')) as HTMLVideoElement | null;
            if (video && video.paused) {
              const playPromise = video.play();
              if (playPromise !== undefined) playPromise.catch(() => { });
            }
          }
        } catch (e) { }
      }, 500);

      this.runtime.post('QUALITY_CHANGED', { track: t.label, id: t.id, height: t.height });
      return { success: true, track: t.label, id: t.id };
    } catch (e: any) {
      this.runtime.state.isApplyingQuality = false;
      return { success: false, reason: e.message };
    }
  }

  applyPreferred(force = false) {
    if (!this.runtime.settings?.enabled || (!force && !this.runtime.settings?.autoQuality)) return false;
    if (!force && this.runtime.state.manualQualitySelection) {
      ConsoleLogger.log('info', 'Player', '[선호 화질] 수동 화질 선택이 활성화되어 있어 자동 적용을 건너뜁니다.');
      return false;
    }

    const tracks = this.getTracks(this.runtime.state.core);
    const hasDrm = tracks.some((t: any) => typeof t.id === 'string' && t.id.includes('DRM') && !t.id.includes('DRM_FREE'));
    const hasAes = this.hasAesStream();
    const isAudioOnly = (!this.lastLivePlaybackJson || this.lastLivePlaybackJson === 'null') &&
      (typeof this.lastRadioModePlaybackJson === 'string' && this.lastRadioModePlaybackJson !== 'null');

    let isBypassActive = this.runtime.settings?.gridBypassEnabled !== false;
    if (hasDrm || hasAes || isAudioOnly) {
      isBypassActive = false;
    }

    const isLive = this.isLiveRoute();

    // 라이브 페이지이고, GRID 또는 BYPASS 트랙이 없다면 선호 화질 변경 생략 (네이티브 플레이어 상태 유지)
    // 단, AES/DRM 스트림이거나 오디오 전용 상태인 경우 제외
    if (isLive && !hasDrm && !hasAes && !isAudioOnly) {
      const filter = isBypassActive ? TRACK_TYPES.BYPASS : TRACK_TYPES.GRID;
      const hasTargetTrack = tracks.some(t => filter(t));
      if (!hasTargetTrack) {
        ConsoleLogger.log('info', 'Player', `[선호 화질] ${isBypassActive ? 'BYPASS' : 'GRID'} 트랙 미보유로 품질 적용 생략`);
        return false;
      }
    }

    // 선호 화질 바로 적용
    const result = this.changeQuality(this.runtime.settings.preferredQuality, false);
    return result.success;
  }

  getAvailable() {
    if (!this.runtime.state.ready || !this.runtime.state.core) return [];
    if (!this.runtime.settings) return [];
    const tracks = this.getTracks(this.runtime.state.core);
    const targetLL = !!this.runtime.settings?.preferLowLatency;

    const hasDrm = tracks.some((t: any) => typeof t.id === 'string' && t.id.includes('DRM') && !t.id.includes('DRM_FREE'));
    const hasAes = this.hasAesStream();
    const isAudioOnly = (!this.lastLivePlaybackJson || this.lastLivePlaybackJson === 'null') &&
      (typeof this.lastRadioModePlaybackJson === 'string' && this.lastRadioModePlaybackJson !== 'null');

    let isBypassActive = this.runtime.settings?.gridBypassEnabled !== false;
    if (hasDrm || hasAes || isAudioOnly) {
      isBypassActive = false;
    }

    const isLive = this.isLiveRoute();
    const seen = new Set();

    const filter = isBypassActive ? TRACK_TYPES.BYPASS : TRACK_TYPES.GRID;
    const sortedTracks = [...tracks].sort((a, b) => {
      const aMatch = filter(a);
      const bMatch = filter(b);
      if (aMatch !== bMatch) return aMatch ? -1 : 1;
      return (b.height || 0) - (a.height || 0);
    });

    return sortedTracks
      .filter((t: any) => {
        // 오디오만 있는 상태이면 UI 화질 메뉴에서 자동(ABR) 제외
        if (isLive && isAudioOnly && t.label === 'ABR') return false;

        // 라이브 상태이면 UI 화질 메뉴에서 자동(ABR) 제외 (AES/DRM 제외)
        if (isLive && !hasDrm && !hasAes && t.label === 'ABR') return false;

        if (!isLive && t.label === 'ABR') return false;

        const ll = TRACK_TYPES.LOW_LATENCY(t);
        const hasPreferredLatency = tracks.some(tr => tr.label !== 'ABR' && (targetLL ? TRACK_TYPES.LOW_LATENCY(tr) : !TRACK_TYPES.LOW_LATENCY(tr)));
        if (hasPreferredLatency) {
          if (t.label !== 'ABR' && (targetLL ? !ll : ll)) return false;
        }

        const key = t.label === 'ABR' ? 'ABR' : t.height;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => {
        if (a.label === 'ABR') return -1;
        if (b.label === 'ABR') return 1;
        return (b.height || 0) - (a.height || 0);
      })
      .map(t => ({
        label: t.label === 'ABR' ? '자동' : (t.label || `${t.height}p`),
        height: t.label === 'ABR' ? 'ABR' : t.height,
        id: t.id,
        selected: !!t._selected,
        bitrate: t.videoBitrate
      }));
  }

  exportState() {
    const s = this.runtime.state.root?.$store?.state;
    const nativeLLActive = s ? (s.lowLatencyEnabled === true || s.lowLatency === true || s.lowLatencyMode === true) : false;
    const channel = getChannelData(document.body);

    // 실제 해상도/fps: Vue store + 원본 트랙 기반 (getTracks 필터 무관, StreamStatsRoot와 동일 소스)
    const resolution = `${s?.videoWidth ?? 0}x${s?.videoHeight ?? 0}`;
    let fps = 0;
    try {
      const rawTracks = this.runtime.state.core
        ? Object.values(this.runtime.state.core.getVideoTracksList())
        : [];
      const rawSelected = rawTracks.find((t: any) => t?._selected);
      fps = parseInt(rawSelected?.id?.match(/\d+/g)?.find((n: string) => n.length === 2) || '0', 10);
    } catch { /* core 미준비 시 무시 */ }

    return {
      ready: !!(this.runtime.state.ready && s),
      channelName: channel?.channelName || '',
      liveTitle: channel?.liveTitle || '',
      currentTrack: this.runtime.state.currentTrack
        ? {
          label: this.runtime.state.currentTrack.label,
          height: this.runtime.state.currentTrack.height,
          id: this.runtime.state.currentTrack.id
        }
        : null,
      resolution,
      fps,
      isLowLatency: this.runtime.state.isLowLatency,
      nativeLLActive,
      currentLatency: this.runtime.state.currentLatency,
      absoluteLatency: this.runtime.state.absoluteLatency,
      bufferLength: this.runtime.state.bufferLength,
      gridBypassed: this.runtime.state.gridBypassed,
      lastAppliedQuality: this.runtime.state.lastAppliedQuality,
      isQualityRestoring: this.runtime.state.isQualityRestoring,
      manualQualitySelection: this.runtime.state.manualQualitySelection,
      seekableStart: (document.querySelector('video') as any)?.seekable?.length
        ? (document.querySelector('video') as any).seekable.start(0)
        : 0,
      isLive: this.isLiveRoute(),
      availableQualities: this.getAvailable(),
      settings: this.runtime.settings,
      debug: {
        lowLatencyEnabled: s?.lowLatencyEnabled,
        nativeLLForced: this.runtime.state.nativeLLForced,
        live: s?.live,
        onLive: s?.onLive,
        timeMachine: s?.timeMachine,
        currentTime: s?.currentTime,
        duration: (typeof s?.duration === 'number' && isFinite(s.duration)) ? s.duration : (
          (() => {
            const v = document.querySelector('video') as any;
            return v?.seekable?.length ? v.seekable.end(v.seekable.length - 1) : (s?.currentTime || 0);
          })()
        ),
        playState: s?.playState,
        liveViewerCount: s?.liveViewerCount,
        videoWidth: s?.videoWidth,
        videoHeight: s?.videoHeight
      }
    };
  }

  getDetailedStats() {
    if (!this.runtime.state.ready || !this.runtime.state.core) return null;

    const store = this.runtime.state.root?.$store;
    const s = store?.state;
    const video = (document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video')) as HTMLVideoElement | null;

    const tracks = this.getTracks(this.runtime.state.core);
    const cur = tracks.find(t => t._selected);

    let bufferLength = 0;
    if (video?.buffered?.length) {
      for (let i = 0; i < video.buffered.length; i++) {
        if (video.currentTime >= video.buffered.start(i) - 0.5 && video.currentTime <= video.buffered.end(i) + 0.5) {
          bufferLength = Math.max(0, video.buffered.end(i) - video.currentTime);
          break;
        }
      }
    }

    const quality = video?.getVideoPlaybackQuality?.();
    const ptsOffset = s?.ptsOffset ?? 0;
    const absoluteLatency = (ptsOffset > 0 && video)
      ? (Date.now() - (ptsOffset + video.currentTime * 1000)) / 1000
      : -1;

    return {
      resolution: `${s?.videoWidth ?? 0}x${s?.videoHeight ?? 0}`,
      bitrate: cur?.videoBitrate ?? 0,
      buffer: bufferLength,
      latency: this.runtime.state.currentLatency,
      absoluteLatency: absoluteLatency,
      fps: parseInt(cur?.id?.match(/\d+/g)?.find((n: string) => n.length === 2) || '30', 10),
      trackId: cur?.id ?? '',
      trackLabel: cur?.label ?? '',
      playbackRate: video?.playbackRate ?? 1,
      viewers: s?.liveViewerCount ?? 0,
      connectionType: s?.connectionType ?? '',
      targetLatency: this.runtime.settings?.targetLatency ?? 0,
      preferLowLatency: this.runtime.settings?.preferLowLatency ?? false,
      chaserMode: this.runtime.settings?.chaserMode ?? 'gradual',
      lowLatency: this.runtime.state.isLowLatency,
      nativeLLActive: (s?.lowLatencyEnabled === true) || (s?.lowLatency === true),
      adState: s?.adState ?? '',
      playState: s?.playState ?? '',
      droppedFrames: quality?.droppedVideoFrames ?? 0,
      totalFrames: quality?.totalVideoFrames ?? 0,
      ptsOffset: ptsOffset,
      seekableStart: video?.seekable?.length ? video.seekable.start(0) : 0,
      volume: s?.volume ?? 0,
      muted: s?.muted ?? false,
      protocol: s?.protocol ?? '',
      readyState: video?.readyState ?? 0,
      networkState: video?.networkState ?? 0,
      watchElapsed: this.watchStartTime > 0 ? Date.now() - this.watchStartTime : 0,
      rawVue: Object.fromEntries(Object.entries(s || {}).filter(([k, v]) => typeof v !== 'object' && typeof v !== 'function')),
      rawVideo: (() => {
        try {
          const video = document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video');
          if (!video) return { status: 'No video element found' };

          let res: any = {};
          const props = ['currentTime', 'duration', 'playbackRate', 'defaultPlaybackRate', 'networkState', 'readyState', 'volume', 'muted', 'paused', 'seeking', 'ended', 'crossOrigin', 'currentSrc'];
          for (let p of props) {
            res[p] = (video as any)[p];
          }

          if (video.buffered && video.buffered.length > 0) {
            res['buffered.length'] = video.buffered.length;
            for (let i = 0; i < video.buffered.length; i++) {
              res[`buffered[${i}]`] = `${video.buffered.start(i).toFixed(2)} - ${video.buffered.end(i).toFixed(2)}`;
            }
          } else {
            res['buffered.length'] = 0;
          }

          if (video.seekable && video.seekable.length > 0) {
            res['seekable.length'] = video.seekable.length;
            for (let i = 0; i < video.seekable.length; i++) {
              res[`seekable[${i}]`] = `${video.seekable.start(i).toFixed(2)} - ${video.seekable.end(i).toFixed(2)}`;
            }
          } else {
            res['seekable.length'] = 0;
          }

          if (video.getVideoPlaybackQuality) {
            const q = video.getVideoPlaybackQuality();
            res['quality.dropped'] = q.droppedVideoFrames;
            res['quality.total'] = q.totalVideoFrames;
          }

          return res;
        } catch (e: any) {
          return { error: e.message };
        }
      })()
    };
  }

  initPlayer() {
    const root = this.getRoot();
    if (!root) return false;
    const core = this.findCore(root);
    if (!core) return false;
    const tracks = this.getTracks(core);
    if (!tracks.length) return false;

    const currentPath = location.pathname.match(REGEX.PLAYER_URL)?.[0] ?? null;
    const isSameStream = currentPath != null && currentPath === this.lastPlayerPath;
    this.lastPlayerPath = currentPath;

    this.runtime.state.root = root;
    this.runtime.state.core = core;
    this.runtime.state.currentTrack = tracks.find((t: any) => t._selected) ?? null;
    this.runtime.state.gridBypassed = this.runtime.state.currentTrack ? TRACK_TYPES.BYPASS(this.runtime.state.currentTrack) : false;
    this.runtime.state.isLowLatency = this.detectLL(tracks);
    this.runtime.state.ready = true;

    if (!isSameStream) {
      this.watchStartTime = Date.now();
      this.runtime.state.manualQualitySelection = false;
    }

    ConsoleLogger.log('groupCollapsed', 'Player', `[플레이어 초기화 완료] (PLAYER_READY)${isSameStream ? ' [재연결]' : ''}`, {
      '경로': currentPath,
      '동일 스트림 여부': isSameStream,
      '현재 화질': this.runtime.state.currentTrack?.label,
      '저지연 활성': this.runtime.state.isLowLatency
    });
    this.runtime.post('PLAYER_READY', this.exportState());

    if (!isSameStream && this.isLiveRoute()) {
      this.forceLowLatency();
    }
    this.applyWideView();
    this.startMonitor();

    return isSameStream ? 'reconnect' : true;
  }

  reset() {
    this.runtime.state.ready = false;
    this.runtime.state.root = null;
    this.runtime.state.core = null;
    this.runtime.state.currentTrack = null;
    this.runtime.state.gridBypassed = false;
    this.runtime.state.lastAppliedQuality = null;
    this.runtime.state.nativeLLForced = false;
    this.runtime.state.currentLatency = -1;
    this.runtime.state.isQualityRestoring = false;
    this.runtime.state.isApplyingQuality = false;
    this.runtime.state.hasBeenBehind = false;
    this.lastReapplyTime = 0;
    this.watchStartTime = 0;
    this.stopMonitor();
    this.runtime.post('PLAYER_LOST', null);
  }

  startMonitor() {
    this.stopMonitor();
    if (this.runtime.settings?.enabled === false) return;
    let stallCount = 0;

    this.monitorTimer = setInterval(() => {
      if (!this.runtime.settings?.enabled || !this.runtime.state.ready) return;

      const video = (document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video')) as HTMLVideoElement | null;
      const curPlayer = document.querySelector(SELECTORS.PLAYER);
      const rootVue = this.getRoot();
      const currentCore = rootVue ? this.findCore(rootVue) : null;

      // 1. 물리적 비디오 요소 유실 검사 (즉시 재연결)
      const isLive = this.isLiveRoute();
      const isVideoLost = isLive
        ? (!video || !curPlayer || !document.body.contains(video))
        : (!video || !curPlayer); // VOD/클립 등에서는 일시적 detach에 관대하게 대응

      if (isVideoLost) {
        ConsoleLogger.log('warn', 'Player', '[플레이어 감시] 물리적 비디오 요소 유실 감지 -> 플레이어 재연결 수행');
        this.reset();
        this.startPoll();
        return;
      }

      // 2. 인스턴스 불일치 검사 (두 인스턴스가 모두 정상 추출된 상황에서만 불일치 검증하여 일시적 렌더링 중 null 상태 오감지 방지)
      if (rootVue && currentCore && (this.runtime.state.root !== rootVue || this.runtime.state.core !== currentCore)) {
        ConsoleLogger.log('warn', 'Player', '[플레이어 감시] 플레이어 인스턴스 변경 감지 -> 플레이어 재연결 수행');
        this.reset();
        this.startPoll();
        return;
      }

      if (!this.runtime.state.core) return;

      try {
        const tracks = this.getTracks(this.runtime.state.core);
        const cur = tracks.find((t: any) => t._selected);
        if (cur) {
          const curId = cur.id;
          const prevTrack = this.runtime.state.currentTrack;
          if (curId !== prevTrack?.id) {
            const gridPrefix = this.runtime.state.gridBypassed ? '[GRID_ON]' : '[GRID_OFF]';
            const curLastDot = curId.lastIndexOf('.');
            const curFilename = curLastDot > 0 ? curId.slice(0, curLastDot) : curId;
            const curExt = curLastDot > 0 ? curId.slice(curLastDot) : '';
            const prevId = prevTrack?.id || '';
            const prevLastDot = prevId.lastIndexOf('.');
            const prevFilename = prevLastDot > 0 ? prevId.slice(0, prevLastDot) : prevId;
            const prevExt = prevLastDot > 0 ? prevId.slice(prevLastDot) : '';

            ConsoleLogger.log('groupCollapsed', 'Player', `${gridPrefix} 트랙 변경 감지: ${prevTrack?.label || '없음'} ➔ ${cur.label}`, {
              '이전 트랙 ID': prevId,
              '이전 트랙 파일': prevFilename,
              '이전 트랙 확장자': prevExt,
              '새 트랙 ID': curId,
              '새 트랙 파일': curFilename,
              '새 트랙 확장자': curExt,
              '새 화질 높이': cur.height,
              '우회 여부': this.runtime.state.gridBypassed
            });

            this.runtime.state.currentTrack = cur;
            this.runtime.state.gridBypassed = TRACK_TYPES.BYPASS(cur);
            this.runtime.state.isLowLatency = this.detectLL(tracks);

            if (this.runtime.state.isApplyingQuality) {
              this.runtime.state.isApplyingQuality = false;
            } else {
              //ConsoleLogger.log('info', 'Player', '[품질 가드] 외부 트랙 변경 감지 -> 수동 화질 선택 모드 활성화');
              this.runtime.state.manualQualitySelection = true;
            }

            this.runtime.post('TRACK_CHANGED', this.exportState());
          }

          if (this.runtime.settings?.enabled && this.runtime.settings?.autoQuality && this.runtime.settings?.gridVisible !== false &&
            this.runtime.settings?.preferredQuality === 1080 &&
            cur.height <= 480 && !this.runtime.state.manualQualitySelection) {
            const now = Date.now();
            if (now - this.lastReapplyTime > 10000) {
              this.lastReapplyTime = now;
              this.runtime.state.isQualityRestoring = true;
              //ConsoleLogger.log('warn', 'Player', `[품질 가드] 저화질 하락(${cur.height}p) 감지. 1080p 복구 예약.`);
              setTimeout(() => {
                this.applyPreferred();
                this.runtime.state.isQualityRestoring = false;
              }, 3000);
            }
          }
        }

        if (!video || video.paused || video.seeking) {
          this.runtime.state.currentLatency = -1;
          stallCount = 0;
          return;
        }

        const isLive = this.isLiveRoute();

        if (isLive) {
          this.forceLowLatency();
        }

        const seekable = video.seekable;
        let currentLatency = -1;

        if (isLive && seekable.length) {
          const liveEdge = seekable.end(seekable.length - 1);
          currentLatency = liveEdge - video.currentTime;
        }

        const ptsOffset = this.runtime.state.root?.$store?.state?.ptsOffset ?? 0;
        //console.log('[CQC:DEBUG] ptsOffset:', ptsOffset, 'video:', !!video);
        let absoluteLatency = -1;
        if (ptsOffset > 0 && video) {
          const rawLatency = (Date.now() - (ptsOffset + video.currentTime * 1000)) / 1000;
          //console.log('[CQC:DEBUG] rawLatency:', rawLatency);
          if (rawLatency > -100 && rawLatency < 1000) {
            if (this.lastAbsoluteLatency === undefined || Math.abs(rawLatency - this.lastAbsoluteLatency) > 2) {
              this.lastAbsoluteLatency = rawLatency;
            } else {
              this.lastAbsoluteLatency = this.lastAbsoluteLatency * 0.9 + rawLatency * 0.1;
            }
            absoluteLatency = this.lastAbsoluteLatency;
          }
        } else {
          this.lastAbsoluteLatency = undefined;
        }

        this.runtime.state.currentLatency = currentLatency;
        this.runtime.state.absoluteLatency = absoluteLatency;

        let bufferLength = 0;
        if (video.buffered?.length) {
          for (let i = 0; i < video.buffered.length; i++) {
            if (video.currentTime >= video.buffered.start(i) - 0.5 && video.currentTime <= video.buffered.end(i) + 0.5) {
              bufferLength = Math.max(0, video.buffered.end(i) - video.currentTime);
              break;
            }
          }
        }
        this.runtime.state.bufferLength = bufferLength;

        const lastSeekTime = Number(video.dataset?.cqcLastSeekTime || 0);
        const isRecentlySeeked = Date.now() - lastSeekTime < 5000;
        const isTimeshifting = video.dataset?.cqcTimeshifting === 'true' || this.runtime.state.root?.$store?.state?.timeMachine === true || isRecentlySeeked;
        const isBehind = currentLatency > 3.0;
        const target = this.runtime.settings?.targetLatency || 0;
        const lowLatency = this.runtime.settings?.preferLowLatency && this.runtime.state.isLowLatency;
        const isChaserActive = lowLatency && target > 0 && !isTimeshifting && currentLatency >= 0;

        const resetEnabled = !isChaserActive;
        const playbackSpeedEnabled = this.runtime.settings?.playbackSpeedEnabled !== false;

        if (playbackSpeedEnabled) {
          if (resetEnabled && isLive && isBehind && !isTimeshifting) {
            this.runtime.state.hasBeenBehind = true;
          }

          const isManualSpeed = this.runtime.state.manualPlaybackRate !== 1.0;
          const hasBeenBehind = this.runtime.state.hasBeenBehind === true;

          if (resetEnabled && isLive && !isTimeshifting) {
            const restoreThreshold = 1.2; // 1초 대로 조절시킬 목표 지연시간

            if (isBehind || (hasBeenBehind && currentLatency >= restoreThreshold)) {
              if (!isManualSpeed) {
                // 동적 배속: 목표 지점과의 거리에 따른 가변 속도
                const distance = currentLatency - restoreThreshold;
                let targetRate = 1.00;

                if (distance > 5.0) {
                  targetRate = 1.15; // 5초 이상 크게 밀렸을 때: 1.15x 급가속
                } else if (distance > 2.0) {
                  targetRate = 1.10; // 2초~5초 사이로 밀렸을 때: 1.10x 추격
                } else {
                  targetRate = 1.05; // 0.5초~2초 사이: 1.05x 완만한 추격
                }

                if (video.playbackRate !== targetRate) {
                  document.querySelectorAll('video').forEach(v => { try { v.playbackRate = targetRate; } catch (e) { } });
                }
              } else {
                if (video.playbackRate !== this.runtime.state.manualPlaybackRate) {
                  document.querySelectorAll('video').forEach(v => { try { v.playbackRate = this.runtime.state.manualPlaybackRate; } catch (e) { } });
                }
              }
            } else if (currentLatency >= 0 && currentLatency < restoreThreshold) {
              if (isManualSpeed) {
                this.runtime.post('RESET_PLAYBACK_SPEED_REQ');
                this.runtime.state.manualPlaybackRate = 1.0;
                document.querySelectorAll('video').forEach(v => { try { v.playbackRate = 1.0; } catch (e) { } });
                this.runtime.state.hasBeenBehind = false;
              } else {
                if (video.playbackRate !== 1.0) {
                  document.querySelectorAll('video').forEach(v => { try { v.playbackRate = 1.0; } catch (e) { } });
                }
              }
            }
          } else {
            // 기능이 비활성화되었거나 타임머신(isTimeshifting) 작동 중인 경우: 자동 배속 제거 및 복원
            if (video.playbackRate > 1.0 && !isManualSpeed) {
              document.querySelectorAll('video').forEach(v => { try { v.playbackRate = 1.0; } catch (e) { } });
            }
            this.runtime.state.hasBeenBehind = false;
          }

          if (isManualSpeed && video.playbackRate !== this.runtime.state.manualPlaybackRate) {
            document.querySelectorAll('video').forEach(v => { try { v.playbackRate = this.runtime.state.manualPlaybackRate; } catch (e) { } });
          }

          if (isLive && !isManualSpeed && !(resetEnabled && (isBehind || video.playbackRate === 1.10))) {
            const target = this.runtime.settings?.targetLatency || 0;
            const lowLatency = this.runtime.settings?.preferLowLatency && this.runtime.state.isLowLatency;

            if (lowLatency && target > 0 && !isTimeshifting && currentLatency >= 0) {
              let nextRate = 1.0;
              const mode = this.runtime.settings?.chaserMode || 'gradual';
              const jumpThreshold = mode === 'immediate' ? (target + 0.3) : (target + 2.0);

              if (currentLatency > jumpThreshold) {
                const now = Date.now();
                const coolDown = mode === 'immediate' ? 1000 : 10000;
                if (now - this.lastGoLiveTime > coolDown && video.readyState >= 3) {
                  this.lastGoLiveTime = now;
                  if (video.seekable?.length) {
                    const liveEnd = video.seekable.end(video.seekable.length - 1);
                    const isForced = mode === 'immediate' || target < 1.2;
                    isForced ? (
                      document.querySelectorAll('video').forEach(v => { try { v.currentTime = liveEnd - target; } catch (e) { } }),
                      ConsoleLogger.log('info', 'Player', `[체이서] ${mode}: 강제 시크 점프 (지연: ${currentLatency.toFixed(2)}s ➔ 목표: ${target}s)`)
                    ) : (
                      this.runtime.state.root?.$store?.dispatch('goLive'),
                      ConsoleLogger.log('info', 'Player', `[체이서] ${mode}: 네이티브 goLive 동기화 (지연: ${currentLatency.toFixed(2)}s)`)
                    );
                  }
                }
              }
              if (currentLatency <= jumpThreshold) {
                if (currentLatency > target + 0.3) {
                  nextRate = bufferLength < 1.0 ? 1.0 : 1.05; // 버퍼 부족 시 1.05배속 강행 방지 (버퍼링 방어)
                } else if (currentLatency < target - 0.2) {
                  nextRate = 0.98;
                } else {
                  nextRate = 1.0;
                }
              }

              if (video.playbackRate !== nextRate) {
                document.querySelectorAll('video').forEach(v => { try { v.playbackRate = nextRate; } catch (e) { } });
              }
            }
            if (!lowLatency || target <= 0 || isTimeshifting || currentLatency < 0) {
              if (video.playbackRate > 1.1 || video.playbackRate < 0.9) {
                document.querySelectorAll('video').forEach(v => { try { v.playbackRate = 1.0; } catch (e) { } });
              }
            }
          }
        } // End of if (playbackSpeedEnabled)

        this.runtime.post('PLAYER_STATE', this.exportState());
      } catch (e) { }
    }, 1000);
  }

  stopMonitor() {
    if (this.monitorTimer) {
      clearInterval(this.monitorTimer);
      this.monitorTimer = null;
    }
    try {
      const video = (document.querySelector('video.webplayer-internal-video') ?? document.querySelector('video')) as HTMLVideoElement | null;
      if (video && video.playbackRate !== 1.0 && this.runtime.settings?.playbackSpeedEnabled !== false) video.playbackRate = 1.0;
    } catch { }
  }

  startPoll() {
    this.stopPoll();
    if (this.runtime.settings?.enabled === false) return;
    let n = 0;
    this.pollTimer = setInterval(() => {
      if (++n > MAX_POLL_ATTEMPTS) { this.stopPoll(); return; }
      const result = this.initPlayer();
      if (result) {
        this.stopPoll();
        this.applyPreferred(true);
      }
    }, POLL_INTERVAL);
  }

  stopPoll() {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
  }

  hookQualityMenu() {
    if (this.qualityMenuListener) {
      document.removeEventListener('click', this.qualityMenuListener, true);
    }

    this.qualityMenuListener = (e: MouseEvent) => {
      if (!this.runtime.settings?.enabled) return;
      const target = (e.target as HTMLElement).closest('.pzp-ui-setting-quality-item');
      if (!target) return;

      const textElement = target.querySelector('.pzp-ui-setting-quality-item__prefix');
      const text = textElement ? textElement.textContent : target.textContent;
      const match = text?.match(/(\d+)p/i);
      if (match) {
        const height = parseInt(match[1], 10);

        // 그리드 우회 사용 옵션이 꺼져 있으면 확장의 가로채기를 중단하고 네이티브 클릭을 허용합니다.
        if (this.runtime.settings?.gridBypassEnabled === false) return;

        // Never swallow native clicks unless the legacy controller is ready.
        if (!this.runtime.state.ready || !this.runtime.state.core || !this.runtime.state.root?.$store) return;

        // 그리드 우회 사용 시에는 무조건 이벤트를 가로채서 HLS_DRM_FREE 트랙으로 전환합니다.
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        const gridVisible = this.runtime.settings?.gridVisible !== false;
        const gridPrefix = gridVisible ? '[GRID_ON]' : '[GRID_OFF]';
        ConsoleLogger.log('info', 'Player', `${gridPrefix} 화질 메뉴 클릭 가로채기: ${height}p (우회 적용)`);

        const result = this.changeQuality(height, true);
        if (result.success) {
          const settingsBtn = document.querySelector('.pzp-pc-setting-button') as HTMLElement | null;
          if (settingsBtn) {
            if (!triggerReact(settingsBtn, 'onClick')) settingsBtn.click();
          }
        }
      }
    };

    document.addEventListener('click', this.qualityMenuListener, true);
  }

  hasPlayer(u?: string) {
    return REGEX.PLAYER_URL.test(u ?? location.href);
  }

  onUrlBound = () => this.onUrl();

  hookNav() {
    const op = history.pushState.bind(history);
    const or = history.replaceState.bind(history);
    history.pushState = (...a: any[]) => { op(...a); this.onUrl(); };
    history.replaceState = (...a: any[]) => { or(...a); this.onUrl(); };
    window.addEventListener('popstate', this.onUrlBound);
  }

  onUrl() {
    const u = location.href;
    if (u === this.lastUrl) return;
    const was = this.hasPlayer(this.lastUrl);
    const now = this.hasPlayer(u);
    this.lastUrl = u;

    this.runtime.post('URL_CHANGED', { url: u, isLive: now });

    if (now) {
      this.reset();
      this.startPoll();
    } else if (was) {
      this.stopPoll();
      this.reset();
    }
  }
}
