// @ts-nocheck
import { InjectedModule } from '../core/InjectedRuntime';
import { SELECTORS, getFiberNode, getComponentFiber, triggerReact, getReactProps } from '../../../dom-utils';
import { evaluateMessageFilter, initChatStateInterceptor, activeChatters } from '../../modules/chat/ChatFilter';
import { initChatStamp } from '../../../chatstamp';
import { initBlindedChat, cleanupBlindedChat } from '../../../chat-blinded';
import { initPowerClick, updatePowerStatusUI, cleanupPowerClick, getPowerChannels, resetPowerChannels } from '../../../powerclick';
import { initChatCollector, updateChatCollectorUIState, cleanupChatCollector } from '../../../chat-collector';
import { initCustomVideoSort } from '../../../custom-video-sort';
import { initChatDeviceIcon } from '../../../chat-device-icon';
import { ChatMacro } from '../../modules/chat/ChatMacro';

export class ChatFilterModule implements InjectedModule {
  name = 'ChatFilterModule';
  runtime: any;
  retriggerChatStamp: any = null;
  chatStampHandle: any = null;
  chatDeviceIconHandle: any = null;

  // ── 직접 API 호출 + Fiber State 주입 방식 ──

  /**
   * Fiber 체인을 올라가며 lives 배열(useState)과 cursor hook을 탐색
   */
  private _findLivesHooks(): { livesHook: any; cursorHook: any; sortType: string } | null {
    const listEl = document.querySelector('ul[class*="_list_"][class*="_type_video_"]')
      || document.querySelector(SELECTORS.VIDEO_LIST as string);
    if (!listEl) return null;

    const fiberKey = Object.keys(listEl).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
    if (!fiberKey) return null;

    let fiber = (listEl as any)[fiberKey];
    let livesHook: any = null;
    let cursorHook: any = null;
    let sortType = 'POPULAR';
    let depth = 0;

    while (fiber && depth < 30) {
      if (fiber.memoizedState) {
        let hook = fiber.memoizedState;
        let hookIdx = 0;
        while (hook && hookIdx < 40) {
          const val = hook.memoizedState;
          // lives 배열 감지: liveId 포함 객체 배열
          if (Array.isArray(val) && val.length > 0 && val[0]?.liveId && hook.queue?.dispatch) {
            livesHook = hook;
          }
          // cursor 감지: concurrentUserCount 필드 포함 객체
          if (val && typeof val === 'object' && !Array.isArray(val) && val.concurrentUserCount !== undefined && hook.queue?.dispatch) {
            cursorHook = hook;
          }
          // sortType 감지
          if (typeof val === 'string' && (val === 'POPULAR' || val === 'LATEST' || val === 'RECOMMEND')) {
            sortType = val;
          }
          hookIdx++;
          hook = hook.next;
        }
        if (livesHook) break; // 찾으면 즉시 종료
      }
      fiber = fiber.return;
      depth++;
    }

    if (!livesHook) return null;
    return { livesHook, cursorHook, sortType };
  }

  async loadMoreChannels(count: number) {
    this.runtime.log(`[loadMoreChannels] 시작 - count: ${count} (직접 API 방식)`);

    const hooks = this._findLivesHooks();
    if (!hooks) {
      this.runtime.log(`[loadMoreChannels] lives Fiber hook을 찾을 수 없음. 리스트 페이지가 아닌 것으로 판단.`);
      return;
    }

    const { livesHook, cursorHook, sortType } = hooks;
    const currentLives: any[] = livesHook.memoizedState;
    let cursor = cursorHook?.memoizedState;

    this.runtime.log(`[loadMoreChannels] 현재 lives: ${currentLives.length}개, sortType: ${sortType}, cursor:`, cursor);

    const urlParams = new URLSearchParams(location.search);
    const tags = urlParams.get('tags');
    let allNewItems: any[] = [];

    for (let page = 0; page < count; page++) {
      const params = new URLSearchParams({ size: '20', sortType });
      if (cursor?.concurrentUserCount) params.set('concurrentUserCount', String(cursor.concurrentUserCount));
      if (cursor?.liveId) params.set('liveId', String(cursor.liveId));

      let apiUrl: string;
      if (tags) {
        params.set('tags', tags);
        apiUrl = `https://api.chzzk.naver.com/service/v1/tag/lives?${params}`;
      } else {
        apiUrl = `https://api.chzzk.naver.com/service/v1/lives?${params}`;
      }

      try {
        const resp = await fetch(apiUrl, { credentials: 'include' });
        const json = await resp.json();
        const content = json.content;

        if (!content?.data || content.data.length === 0) {
          this.runtime.log(`[loadMoreChannels] 페이지 ${page + 1}: 데이터 없음. 중단.`);
          break;
        }

        allNewItems.push(...content.data);
        cursor = content.page?.next || null;

        this.runtime.log(`[loadMoreChannels] 페이지 ${page + 1}/${count}: ${content.data.length}개 취득`);

        if (!cursor) {
          this.runtime.log(`[loadMoreChannels] 마지막 페이지 도달. 중단.`);
          break;
        }
      } catch (e: any) {
        this.runtime.log(`[loadMoreChannels] API 호출 실패: ${e.message}`, e, 'error');
        break;
      }
    }

    if (allNewItems.length === 0) {
      this.runtime.log(`[loadMoreChannels] 추가 아이템 없음`);
      return;
    }

    // Fiber state에 dispatch로 주입
    try {
      livesHook.queue.dispatch((prev: any[]) => {
        const seen = new Set(prev.map((item: any) => item.liveId));
        const unique = allNewItems.filter((item: any) => !seen.has(item.liveId));
        return [...prev, ...unique];
      });
      this.runtime.log(`[loadMoreChannels] ✅ ${allNewItems.length}개 아이템 주입 완료 (기존 ${currentLives.length}개)`);
    } catch (e: any) {
      this.runtime.log(`[loadMoreChannels] dispatch 주입 실패: ${e.message}`, e, 'error');
      return;
    }

    // cursor도 갱신
    if (cursorHook?.queue?.dispatch && cursor) {
      try {
        cursorHook.queue.dispatch(cursor);
        this.runtime.log(`[loadMoreChannels] cursor 갱신 완료`);
      } catch (e) {
        this.runtime.log(`[loadMoreChannels] cursor 갱신 실패 (비치명적)`, e);
      }
    }
  }


  _chatFilterCleanup = { intervalId: null };
  _profileClickHandler: ((e: MouseEvent) => void) | null = null;
  _chatMacro: ChatMacro | null = null;
  _styleObserver: MutationObserver | null = null;

  mount(settings: any) {
    initChatStateInterceptor(settings, this.runtime.observer);
    initChatCollector(settings, (type, payload) => this.runtime.post(type, payload));

    (window as any).cqcToggleChatCollector = () => {
      window.cqcChatCollectorActive = !window.cqcChatCollectorActive;
      this.runtime.log(`[채팅 모아보기] 토글 -> ${window.cqcChatCollectorActive}`);

      if (this.runtime.settings) {
        this.runtime.settings.chatCollectorEnabled = window.cqcChatCollectorActive;
        this.runtime.post('CHZZK_SAVE_SETTINGS', {
          settings: { chatCollectorEnabled: window.cqcChatCollectorActive }
        });
      }

      if (window.cqcCurrentChatHooks && window.cqcCurrentChatHooks.size > 0) {
        try {
          // Hook #11(전체 채팅 데이터 훅)만 대상
          window.cqcCurrentChatHooks.forEach(hook => {
            if (typeof hook.queue?.dispatch === 'function') {
              hook.queue.dispatch(prev => {
                if (Array.isArray(prev)) return [...prev];
                return prev;
              });
            }
          });
        } catch (e: any) {
          this.runtime.log(`[채팅 모아보기] 채팅창 즉시 리프레시 실패: ${e.message}`, null, 'error');
        }
      } else if (window.cqcCurrentChatHook && typeof window.cqcCurrentChatHook.queue?.dispatch === 'function') {
        try {
          window.cqcCurrentChatHook.queue.dispatch(prev => {
            if (Array.isArray(prev)) return [...prev];
            return prev;
          });
        } catch (e: any) {
          this.runtime.log(`[채팅 모아보기] 폴백 리프레시 실패: ${e.message}`, null, 'error');
        }
      }

      const isSplitMode = this.runtime.settings?.chatCollectorSplitMode === true;
      if (!isSplitMode) {
        updateChatCollectorUIState();
      }
      if (typeof (window as any).cqcUpdateCollectorButtonState === 'function') {
        (window as any).cqcUpdateCollectorButtonState();
      }
    };

    if (this.chatStampHandle) {
      this.chatStampHandle.cleanup();
    }
    this.chatStampHandle = initChatStamp(settings, this.runtime.observer);
    this.retriggerChatStamp = this.chatStampHandle.retrigger;

    // 디바이스 아이콘 초기화
    if (this.chatDeviceIconHandle) {
      this.chatDeviceIconHandle.cleanup();
    }
    this.chatDeviceIconHandle = initChatDeviceIcon(settings, this.runtime.observer);

    initBlindedChat(settings);
    initCustomVideoSort(settings);

    if (settings.powerClickEnabled) {
      initPowerClick(settings);
    }

    this.initChatFilterObserver();
    this.initProfilePopupObserver();

    // 이모티콘 매크로 초기화
    if (!this._chatMacro) {
      this._chatMacro = new ChatMacro();
    }
    this._chatMacro.updateSettings(settings);

    // 폰트 크기 및 아이콘 크기 스타일 적용
    this._applyFontSizeCSS(settings);

    // 뱃지, 닉네임 숨기기 및 복구 스타일 적용
    this._applyGlobalSettingsCSS(settings);

    // 스타일 보호용 MutationObserver 시작
    this.initStyleProtection(settings);

    if (this._classesFoundListener) {
      window.removeEventListener('cqc-chat-classes-found', this._classesFoundListener);
    }
    this._classesFoundListener = () => {
      this._applyFontSizeCSS(this.runtime.settings);
    };
    window.addEventListener('cqc-chat-classes-found', this._classesFoundListener);

    // 설정 변경 즉시 반영
    this.refreshAllFilters();

    // 콘솔 직접 호출용 전역 노출
    (window as any).cqcLoadMoreChannels = (count: number = 1) => {
      this.runtime.log(`[콘솔 수동 호출] loadMoreChannels(count: ${count})`);
      this.loadMoreChannels(count);
    };
  }

  // settings가 런타임에서 업데이트될 때 호출됨
  onSettingsUpdate(newSettings: any) {
    if (this._chatMacro) {
      this._chatMacro.updateSettings(newSettings);
    }
    this._applyFontSizeCSS(newSettings);
    this._applyGlobalSettingsCSS(newSettings);

    if (typeof (window as any).cqcUpdateChatCollectorSettings === 'function') {
      (window as any).cqcUpdateChatCollectorSettings(newSettings);
    }
  }

  initStyleProtection(settings: any) {
    if (this._styleObserver) {
      this._styleObserver.disconnect();
    }

    this._styleObserver = new MutationObserver((mutations) => {
      let needsReapplyFont = false;
      let needsReapplyGlobal = false;

      for (const mutation of mutations) {
        for (const removedNode of mutation.removedNodes) {
          if (removedNode instanceof Element) {
            if (removedNode.id === 'cqc-chat-dynamic-style' || removedNode.id === 'cqc-chat-stamp-dynamic-style') {
              needsReapplyFont = true;
            } else if (removedNode.id === 'cqc-chat-global-settings-style') {
              needsReapplyGlobal = true;
            }
          }
        }
      }

      if (needsReapplyFont || needsReapplyGlobal) {
        this._styleObserver.disconnect();
        const currentSettings = this.runtime?.settings || settings;
        if (needsReapplyFont) {
          this._applyFontSizeCSS(currentSettings);
        }
        if (needsReapplyGlobal) {
          this._applyGlobalSettingsCSS(currentSettings);
        }
        this._styleObserver.observe(document.documentElement, { childList: true, subtree: true });
      }
    });

    this._styleObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  _classesFoundListener: (() => void) | null = null;

  cleanup() {
    if (this._classesFoundListener) {
      window.removeEventListener('cqc-chat-classes-found', this._classesFoundListener);
      this._classesFoundListener = null;
    }

    if (this._styleObserver) {
      this._styleObserver.disconnect();
      this._styleObserver = null;
    }

    const styleEl = document.getElementById('cqc-chat-dynamic-style');
    if (styleEl) styleEl.remove();
    const stampStyle = document.getElementById('cqc-chat-stamp-dynamic-style');
    if (stampStyle) stampStyle.remove();
    const globalStyle = document.getElementById('cqc-chat-global-settings-style');
    if (globalStyle) globalStyle.remove();

    if (this._chatFilterCleanup.intervalId) {
      clearInterval(this._chatFilterCleanup.intervalId);
    }
    if (this._profileClickHandler) {
      document.removeEventListener('click', this._profileClickHandler, true);
      this._profileClickHandler = null;
    }

    if (this.runtime?.observer) {
      this.runtime.observer.poller.stop('chatInterceptorWait');
      this.runtime.observer.hooks.unintercept('chatInterceptor');
    }

    cleanupPowerClick();
    cleanupBlindedChat();
    cleanupChatCollector();

    if (activeChatters?.clear) {
      activeChatters.clear();
    }
    delete (window as any).cqcCurrentChatHook;
    delete (window as any).cqcCurrentChatHooks;
    delete (window as any).cqcToggleChatCollector;
    delete (window as any).cqcLoadMoreChannels;
    if ((window as any).cqcChatInterceptorPoll) {
      clearInterval((window as any).cqcChatInterceptorPoll);
      (window as any).cqcChatInterceptorPoll = null;
    }

    if (this.chatStampHandle) {
      this.chatStampHandle.cleanup();
      this.chatStampHandle = null;
    }
    this.retriggerChatStamp = null;

    if (this.chatDeviceIconHandle) {
      this.chatDeviceIconHandle.cleanup();
      this.chatDeviceIconHandle = null;
    }
  }

  async onMessage(type: string, payload: any, id: number): Promise<boolean> {
    switch (type) {
      case 'LOAD_MORE_CHANNELS': {
        const count = payload?.count || 1;
        this.loadMoreChannels(count);
        this.runtime.respond(id, { ok: true });
        return true;
      }

      case 'GET_ACTIVE_CHATTERS':
        this.runtime.respond(id, Array.from(activeChatters.entries()));
        return true;

      case 'INIT_CHAT_STAMP':
        if (this.chatStampHandle) {
          this.chatStampHandle.cleanup();
        }
        this.chatStampHandle = initChatStamp(this.runtime.settings, this.runtime.observer);
        this.retriggerChatStamp = this.chatStampHandle.retrigger;
        this.runtime.respond(id, { ok: true });
        return true;

      case 'INIT_POWER_CLICK':
        initPowerClick();
        this.runtime.respond(id, { ok: true });
        return true;

      case 'GET_POWER_CHANNELS': {
        const channels = await getPowerChannels();
        this.runtime.respond(id, channels);
        return true;
      }

      case 'POWER_RESET_CHANNELS': {
        const channelIds = payload?.channelIds;
        await resetPowerChannels(channelIds);
        this.runtime.respond(id, { ok: true });
        return true;
      }

      case 'INIT_BLINDED_CHAT':
        initBlindedChat(this.runtime.settings);
        this.runtime.respond(id, { ok: true });
        return true;

      case 'INIT_CHAT_DEVICE_ICON':
        if (this.chatDeviceIconHandle) {
          this.chatDeviceIconHandle.cleanup();
        }
        this.chatDeviceIconHandle = initChatDeviceIcon(this.runtime.settings, this.runtime.observer);
        this.runtime.respond(id, { ok: true });
        return true;

      case 'GET_HEADER_TAB_TITLES': {
        const container = document.querySelector(SELECTORS.TOPIC_TAB_CONTAINER);
        if (!container) {
          this.runtime.respond(id, []);
          return true;
        }
        const elements = container.querySelectorAll(SELECTORS.TOPIC_TAB_ELEMENTS);
        const titles: string[] = [];

        const getTabTitleFromReactLocal = (el: any) => {
          const fiber = getFiberNode(el);
          if (!fiber) return null;

          const findTextInProps = (obj: any): string | null => {
            if (!obj) return null;
            if (typeof obj === 'string') {
              const trimmed = obj.trim();
              if (trimmed) return trimmed;
            }
            if (Array.isArray(obj)) {
              for (const item of obj) {
                const text = findTextInProps(item);
                if (text) return text;
              }
            }
            if (typeof obj === 'object') {
              if (obj.props && obj.props.children) {
                return findTextInProps(obj.props.children);
              }
              if (obj.children) {
                return findTextInProps(obj.children);
              }
            }
            return null;
          };

          const findTextFromFiber = (node: any): string | null => {
            if (!node) return null;

            if (node.memoizedProps) {
              const text = findTextInProps(node.memoizedProps.children);
              if (text) return text;
            }

            if (node.tag === 6 || typeof node.memoizedState === 'string') {
              const text = (node.memoizedState || '').trim();
              if (text) return text;
            }

            let child = node.child;
            while (child) {
              const text = findTextFromFiber(child);
              if (text) return text;
              child = child.sibling;
            }

            return null;
          };

          let title = findTextFromFiber(fiber);

          if (title && title.endsWith(' 페이지로 이동')) {
            title = title.replace(' 페이지로 이동', '');
          }
          return title;
        };

        elements.forEach(el => {
          const title = getTabTitleFromReactLocal(el);
          titles.push(title || '');
        });
        this.runtime.respond(id, titles);
        return true;
      }
    }
    return false;
  }

  refreshAllFilters() {
    if (window.cqcCurrentChatHooks && window.cqcCurrentChatHooks.size > 0) {
      window.cqcCurrentChatHooks.forEach(hook => {
        if (typeof hook.queue?.dispatch === 'function') {
          try {
            hook.queue.dispatch(prev => {
              if (!Array.isArray(prev)) return prev;
              return [...prev];
            });
          } catch (e) {
            console.error('[채팅 필터] 훅 리렌더링 실패:', e);
          }
        }
      });
    } else if (window.cqcCurrentChatHook && typeof window.cqcCurrentChatHook.queue?.dispatch === 'function') {
      try {
        window.cqcCurrentChatHook.queue.dispatch(prev => {
          if (!Array.isArray(prev)) return prev;
          return [...prev];
        });
      } catch (e) {
        console.error('[채팅 필터] 폴백 리렌더링 실패:', e);
      }
    }
  }

  initChatFilterObserver() {
    if (this._chatFilterCleanup.intervalId) {
      clearInterval(this._chatFilterCleanup.intervalId);
      this._chatFilterCleanup.intervalId = null;
    }

    const STYLE_ID = 'cqc-chat-filter-style';
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = `
        .cqc-hidden { display: none !important; }
        .cqc-blurred { 
          filter: blur(6px) !important; 
          transition: filter 0.2s ease-in-out, opacity 0.2s !important; 
          cursor: pointer !important;
          opacity: 0.5 !important;
        }
        .cqc-blurred:hover { 
          filter: blur(0) !important; 
          opacity: 1 !important;
        }
      `;
      document.head.appendChild(style);
    }

    const checkAndApplyFilter = (el: HTMLElement) => {
      if (el.classList.contains('cqc-processed')) return;

      let fiber = getFiberNode(el);
      const findChatMessage = (f: any): any => {
        if (!f) return null;
        if (f.memoizedProps?.chatMessage) return f.memoizedProps.chatMessage;
        let child = f.child;
        while (child) {
          const res = findChatMessage(child);
          if (res) return res;
          child = child.sibling;
        }
        return null;
      };

      const findChatMessageInProps = (obj: any): any => {
        if (!obj) return null;
        if (obj.chatMessage) return obj.chatMessage;
        if (obj.props?.chatMessage) return obj.props.chatMessage;
        if (obj.children) {
          const res = findChatMessageInProps(obj.children);
          if (res) return res;
        }
        if (obj.props?.children) {
          const res = findChatMessageInProps(obj.props.children);
          if (res) return res;
        }
        return null;
      };

      let chatMessage = findChatMessageInProps(getReactProps(el)) || findChatMessage(fiber);
      const isDomDonation = el.querySelector(SELECTORS.CHAT_DONATION as string) || el.matches(SELECTORS.CHAT_DONATION as string);

      if (isDomDonation && !chatMessage) {
        chatMessage = {
          messageTypeCode: 10,
          donation: true,
          profile: {
            nickname: el.querySelector('[class*="nickname"], [class*="_nickname_"]')?.textContent?.trim() || '익명의 후원자'
          },
          content: el.querySelector('p[class*="_text_"], [class*="_text_"]')?.textContent?.trim() || ''
        };
      }

      if (chatMessage) {
        let shouldHide = false;
        let shouldBlur = false;

        // 1) 일반 채팅 필터
        if (this.runtime.settings?.chatFilterEnabled) {
          const evalRes = evaluateMessageFilter(chatMessage, this.runtime.settings);
          shouldHide = !!evalRes.hidden;
          shouldBlur = !!evalRes.blurred;
        }
        el.classList.toggle('cqc-hidden', shouldHide);
        el.classList.toggle('cqc-blurred', shouldBlur);

        // 모아보기 분리 모드 상단 패널 전송 콜백 호출
        if (window.cqcChatCollectorActive && this.runtime.settings?.chatCollectorSplitMode) {
          if (typeof (window as any).cqcAddMessageToCollectedPanel === 'function') {
            (window as any).cqcAddMessageToCollectedPanel(el, chatMessage);
          }
        }
      }

      el.classList.add('cqc-processed');
    };

    let activeContainer: HTMLElement | null = null;

    const attachToContainer = () => {
      const chatContainer = document.querySelector(SELECTORS.CHAT_LIST_CONTAINER) as HTMLElement;
      if (!chatContainer) {
        if (activeContainer) {
          activeContainer = null;
          this.runtime.log('[ChatFilter] 채팅 컨테이너 분리됨');
        }
        return;
      }
      if (activeContainer === chatContainer) return;
      activeContainer = chatContainer;

      // 초기 스캔
      chatContainer.querySelectorAll(SELECTORS.CHAT_ITEM).forEach(el => {
        checkAndApplyFilter(el as HTMLElement);
      });
      this.runtime.log('[ChatFilter] 컨테이너 연결됨 (setInterval 폴링)');
    };

    // MutationObserver 대신 setInterval 폴링만 사용
    this._chatFilterCleanup.intervalId = setInterval(() => {
      attachToContainer();
      const isFilterActive = !!this.runtime.settings?.chatFilterEnabled;
      const isCollectorActive = !!window.cqcChatCollectorActive;
      if ((isFilterActive || isCollectorActive) && activeContainer) {
        activeContainer.querySelectorAll(`${SELECTORS.CHAT_ITEM}:not(.cqc-processed)`).forEach(el => {
          checkAndApplyFilter(el as HTMLElement);
        });
      }
    }, 1000);

    attachToContainer();
  }

  initProfilePopupObserver() {
    // 기존 리스너 제거
    if (this._profileClickHandler) {
      document.removeEventListener('click', this._profileClickHandler, true);
    }

    // MutationObserver 대신 이벤트 위임 사용
    this._profileClickHandler = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target?.closest) return;

      // 채팅 닉네임 클릭 시 프로필 팝업이 뜸 → 약간 지연 후 팝업 탐색
      const chatNickEl = target.closest(SELECTORS.CHAT_ITEM) || target.closest('[class*="nickname"]');
      if (!chatNickEl) return;

      setTimeout(() => {
        const popup = document.querySelector(SELECTORS.CHAT_PROFILE_POPUP);
        if (!popup) return;

        const nickEl = popup.querySelector(`${SELECTORS.CHAT_PROFILE_INFO} strong span`);
        const nickname = nickEl?.textContent?.trim();

        const imgEl = popup.querySelector(`${SELECTORS.CHAT_PROFILE_INFO} > span`);
        let imgUrl = '';
        if (imgEl) {
          const bgImg = window.getComputedStyle(imgEl).backgroundImage;
          const match = bgImg?.match(/url\("?(.+?)"?\)/);
          if (match) imgUrl = match[1];
        }

        if (nickname && nickname !== 'unknown') {
          activeChatters.set(nickname, imgUrl);
          if (activeChatters.size > 100) {
            const first = activeChatters.keys().next().value;
            activeChatters.delete(first);
          }
          this.runtime.log(`[ChatFilter] 프로필 수집: ${nickname} ${imgUrl ? '(이미지 O)' : '(이미지 X)'}`);
        }
      }, 300);
    };

    document.addEventListener('click', this._profileClickHandler, true);
    this.runtime.log('[ChatFilter] 프로필 팝업 감시: 이벤트 위임 방식 활성화');
  }

  private _applyFontSizeCSS(settings: any) {
    if (!settings) return;
    const fontSize = settings.chatFontSize ?? 0;
    const isStamp = settings.chatStampEnabled ?? false;
    const stampSize = settings.chatStampSize ?? 10;
    const isStampLinked = settings.chatStampSizeLinked ?? false;

    if (fontSize <= 0 && !isStamp) {
      document.documentElement.classList.remove('cqc-chat-font-size-active');
      document.documentElement.classList.remove('cqc-chat-stamp-size-active');
      const styleEl = document.getElementById('cqc-chat-dynamic-style');
      if (styleEl) styleEl.remove();
      const stampStyle = document.getElementById('cqc-chat-stamp-dynamic-style');
      if (stampStyle) stampStyle.remove();
      return;
    }

    if (fontSize > 0) {
      const iconSize = Math.round(fontSize * 1.2);
      const emojiSize = iconSize + 4;

      document.documentElement.style.setProperty('--cqc-chat-font-size', `${fontSize}px`);
      document.documentElement.style.setProperty('--cqc-chat-icon-size', `${iconSize}px`);
      document.documentElement.style.setProperty('--cqc-chat-emoji-size', `${emojiSize}px`);
      document.documentElement.classList.add('cqc-chat-font-size-active');

      const classes = (window as any).cqcChatClassNames;
      if (classes) {
        let css = '';
        const item = '.' + classes.itemClass;

        if (classes.messageClass) {
          css += `${item} .${classes.messageClass} { font-size: ${fontSize}px !important; line-height: 1.5 !important; }\n`;
        }
        if (classes.nicknameClass) {
          css += `${item} .${classes.nicknameClass} { font-size: ${fontSize}px !important; }\n`;
          css += `${item} .${classes.nicknameClass} * { font-size: ${fontSize}px !important; }\n`;
        }
        if (classes.badgeClass) {
          css += `${item} .${classes.badgeClass}, ${item} .${classes.badgeClass} img { width: ${iconSize}px !important; height: ${iconSize}px !important; }\n`;
        }
        if (classes.emojiClass) {
          css += `${item} .${classes.emojiClass} { width: ${emojiSize}px !important; height: ${emojiSize}px !important; }\n`;
        }

        let styleEl = document.getElementById('cqc-chat-dynamic-style');
        if (!styleEl) {
          styleEl = document.createElement('style');
          styleEl.id = 'cqc-chat-dynamic-style';
          document.head.appendChild(styleEl);
        }
        styleEl.textContent = css;
      }
    } else {
      document.documentElement.classList.remove('cqc-chat-font-size-active');
      const styleEl = document.getElementById('cqc-chat-dynamic-style');
      if (styleEl) styleEl.remove();
    }

    if (isStamp) {
      let stampFontSize = stampSize;
      if (isStampLinked) {
        stampFontSize = fontSize || 14;
      }
      document.documentElement.style.setProperty('--cqc-chat-stamp-font-size', `${stampFontSize}px`);
      document.documentElement.classList.add('cqc-chat-stamp-size-active');

      const classes = (window as any).cqcChatClassNames;
      if (classes && classes.itemClass) {
        let styleEl = document.getElementById('cqc-chat-stamp-dynamic-style');
        if (!styleEl) {
          styleEl = document.createElement('style');
          styleEl.id = 'cqc-chat-stamp-dynamic-style';
          document.head.appendChild(styleEl);
        }
        styleEl.textContent = `.${classes.itemClass} .cqc-stamp { font-size: ${stampFontSize}px !important; }\n`;
      }
    } else {
      document.documentElement.classList.remove('cqc-chat-stamp-size-active');
      const styleEl = document.getElementById('cqc-chat-stamp-dynamic-style');
      if (styleEl) styleEl.remove();
    }
  }

  _applyGlobalSettingsCSS(settings: any) {
    const STYLE_ID = 'cqc-chat-global-settings-style';
    let styleEl = document.getElementById(STYLE_ID);
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = STYLE_ID;
      document.head.appendChild(styleEl);
    }

    let css = '';
    if (settings.hideChatBadge) {
      const keepTypes: string[] = [];
      if (settings.keepBadgeSubscription) keepTypes.push('SUBSCRIPTION');
      if (settings.keepBadgeActivity) keepTypes.push('ACTIVITY');
      if (settings.keepBadgeCheatkey) keepTypes.push('CHEATKEY');
      if (settings.keepBadgeRole) keepTypes.push('ROLE');

      if (keepTypes.length === 0) {
        // 전체 숨김 (기존 동작): 컨테이너 통째로 숨김
        css += `
          [class*="_wrapper_o04z9_"],
          [class*="_icon_o04z9_"],
          [class*="badge_container"],
          [class*="_badge_"],
          [class*="live_chatting_username_icon"],
          [class*="live_chatting_message_icon"] {
            display: none !important;
          }
        `;
      } else {
        // 선택 유지: 뱃지 이미지 URL로 판별 — CSS가 렌더 시점에 즉시 적용(태깅/폴링/JS 없음 → 지연·깜빡임 0).
        // /glive/icon/ 에 역할(streamer)과 활동(cheese)이 섞여 있으므로 경로가 아니라 '파일명 단위'로 매칭.
        // 새 뱃지 종류가 나오면 아래 패턴만 추가하면 됨. (URL은 렌더 시 이미 존재 → 즉시 반영)
        const KEEP_SRC: Record<string, string[]> = {
          SUBSCRIPTION: ['/glive/subscription/'],
          ACTIVITY: ['fan_', 'cheese'],          // 팬, 치즈(cheese01/02), 최근치즈(recent_cheese)
          CHEATKEY: ['cheatkey'],
          ROLE: ['/icon/streamer', '/icon/manager'],
        };
        const patterns = keepTypes.flatMap(t => KEEP_SRC[t] || []);
        const notKept = patterns.map(p => `:not(:has(img[src*="${p}"]))`).join('');
        const iconSel = SELECTORS.CHAT_BADGE_ICON as string;
        const wrapSel = SELECTORS.CHAT_BADGE_WRAPPER as string;
        if (notKept) {
          // 1) 유지 뱃지가 하나도 없는 리스트 래퍼는 통째로 숨김 (여백 제거 → 닉네임 정렬 유지)
          if (wrapSel) css += `${wrapSel}:has(img)${notKept} { display: none !important; }\n`;
          // 2) 노출된 래퍼 안에서 유지 아닌 개별 뱃지 숨김
          if (iconSel) css += `${iconSel}:has(img)${notKept} { display: none !important; }\n`;
        }
      }
    }
    if (settings.hideChatNickname) {
      css += `
        :is([class*="live_chatting_message_nickname"], [class*="live_chatting_username_nickname"], [class*="_nickname_"]) {
          display: none !important;
        }
      `;
    }
    if (settings.restoreTransparentNickname !== false) {
      css += `
        [class*="_nickname_"][style*=", 0)"],
        [class*="_nickname_"][style*=",0)"],
        [class*="_nickname_"][style*="rgba(20, 21, 23, 0)"] {
          color: inherit !important;
        }
      `;
    }

    styleEl.textContent = css;
  }

}
