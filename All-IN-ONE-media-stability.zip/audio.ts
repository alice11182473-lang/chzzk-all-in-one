import Browser from 'webextension-polyfill';
import { SELECTORS, isPlayerPage } from './dom-utils';

/**
 * 오디오 설정을 위한 저장소 키 매핑
 */
const STORAGE_KEYS = {
    enabled: 'audioEnabled',
    gain: 'audioGain',
    eq: 'audioEqBands',
    preset: 'audioEqPreset',
    compressor: 'audioCompressor',
} as const;

const BANDS = [30, 60, 120, 250, 1000, 2000, 4000, 8000, 16000] as const;
const BAND_LABELS = ['30', '60', '120', '250', '1K', '2K', '4K', '8K', '16K'] as const;

interface PresetConfig {
    name: string;
    values: number[];
}

const PRESETS: Record<string, PresetConfig> = {
    flat: { name: '플랫', values: [0, 0, 0, 0, 0, 0, 0, 0, 0] },
    bass_boost: { name: '베이스 부스트', values: [6, 5, 4, 2, 0, 0, 0, 0, 0] },
    treble_boost: { name: '고음 부스트', values: [0, 0, 0, 0, 0, 2, 4, 5, 6] },
    vocal: { name: '보컬', values: [-2, -1, 0, 3, 5, 4, 2, 0, -1] },
    asmr_inner: { name: 'ASMR (귀 속)', values: [-7, -1, 4, -1, -6, 1, -12, -2, -14] },
    asmr_outer: { name: 'ASMR (귀 밖)', values: [-7, -13, -6, -7, -1, -6, -18, -12, -7] },
    night: { name: '나이트 모드', values: [-3, -2, 0, 2, 4, 3, 1, -1, -3] },
    live_concert: { name: '라이브 공연', values: [4, 3, 0, -1, 2, 4, 5, 3, 1] },
    custom: { name: '커스텀', values: [0, 0, 0, 0, 0, 0, 0, 0, 0] },
};

const videoSourceMap = new WeakMap<HTMLVideoElement, { ctx: AudioContext; source: MediaElementAudioSourceNode }>();
const taintedVideos = new WeakSet<HTMLVideoElement>();

export interface AudioState {
    enabled: boolean;
    gain: number;
    eq: number[];
    preset: string;
    compressor: boolean;
}

/**
 * 치지직 오디오 개선 클래스 (React-inspired State 구조)
 */
export class AudioEnhancer {
    static #instance: AudioEnhancer | null = null;

    #state: AudioState = {
        enabled: false,
        gain: 1.0,
        eq: Array(BANDS.length).fill(0),
        preset: 'flat',
        compressor: false
    };

    #ctx: AudioContext | null = null;
    #source: MediaElementAudioSourceNode | null = null;
    #gainNode: GainNode | null = null;
    #eqFilters: BiquadFilterNode[] = [];
    #compressor: DynamicsCompressorNode | null = null;
    #isConnecting = false;
    #connectedVideo: HTMLVideoElement | null = null;
    #videoInterval: number | null = null;

    #onVolumeChange = () => {
        this.#updateAudioNodes();
    };

    constructor() {
        if (AudioEnhancer.#instance) return AudioEnhancer.#instance;
        AudioEnhancer.#instance = this;
    }

    /** 리소스 완전 해제 (페이지 이탈 등) */
    destroy() {
        this.#softDisconnect();
        if (this.#videoInterval) {
            clearInterval(this.#videoInterval);
            this.#videoInterval = null;
        }
    }

    #softDisconnect() {
        if (this.#connectedVideo) {
            this.#connectedVideo.removeEventListener('volumechange', this.#onVolumeChange);
        }

        // 기존 노드 연결 해제
        try {
            this.#eqFilters.forEach(f => f.disconnect());
            this.#compressor?.disconnect();
            this.#gainNode?.disconnect();
        } catch (_) { }

        // source→destination bypass 유지 (tainted video 소리 보장)
        if (this.#source && this.#ctx && this.#ctx.state !== 'closed') {
            try {
                this.#source.disconnect();
                this.#source.connect(this.#ctx.destination);
            } catch (_) { }
        }

        // AudioContext, source는 videoSourceMap에 캐시되므로 참조만 해제
        this.#ctx = null;
        this.#source = null;
        this.#gainNode = null;
        this.#eqFilters = [];
        this.#compressor = null;
        this.#connectedVideo = null;
    }

    #disconnectNodes() {
        if (this.#connectedVideo) {
            this.#connectedVideo.removeEventListener('volumechange', this.#onVolumeChange);
        }

        // 기존 노드 연결 해제 (destination으로 가는 경로 차단)
        try {
            this.#source?.disconnect();
            this.#eqFilters.forEach(f => f.disconnect());
            this.#compressor?.disconnect();
            this.#gainNode?.disconnect();
        } catch (_) { }

        this.#source = null;
        this.#gainNode = null;
        this.#eqFilters = [];
        this.#compressor = null;
        this.#connectedVideo = null;
    }

    /** 싱글톤 인스턴스 반환 */
    static getInstance(): AudioEnhancer {
        return AudioEnhancer.#instance || new AudioEnhancer();
    }

    /** 초기화 및 설정 로드 */
    async init() {
        const data = await Browser.storage.sync.get({
            [STORAGE_KEYS.enabled]: false,
            [STORAGE_KEYS.gain]: 1.0,
            [STORAGE_KEYS.eq]: Array(BANDS.length).fill(0),
            [STORAGE_KEYS.preset]: 'flat',
            [STORAGE_KEYS.compressor]: false
        });

        this.#state = {
            enabled: Boolean(data[STORAGE_KEYS.enabled]),
            gain: Number(data[STORAGE_KEYS.gain]),
            eq: (data[STORAGE_KEYS.eq] as number[]) || Array(BANDS.length).fill(0),
            preset: String(data[STORAGE_KEYS.preset]),
            compressor: Boolean(data[STORAGE_KEYS.compressor])
        };

        if ((this.#state.enabled || this.#state.compressor) && isPlayerPage()) {
            this.#tryConnect();
        }
        this.#startVideoWatch();
    }

    /** 
     * 상태 업데이트 및 UI 반영 (setState) 
     * @param newState
     */
    #setState(newState: Partial<AudioState>) {
        this.#state = { ...this.#state, ...newState };

        // Storage 동기화
        const toSave: Record<string, any> = {};
        if ('enabled' in newState) toSave[STORAGE_KEYS.enabled] = this.#state.enabled;
        if ('gain' in newState) toSave[STORAGE_KEYS.gain] = this.#state.gain;
        if ('eq' in newState) toSave[STORAGE_KEYS.eq] = this.#state.eq;
        if ('preset' in newState) toSave[STORAGE_KEYS.preset] = this.#state.preset;
        if ('compressor' in newState) toSave[STORAGE_KEYS.compressor] = this.#state.compressor;

        if (Object.keys(toSave).length > 0) {
            Browser.storage.sync.set(toSave);
        }

        // 오디오 엔진 업데이트
        if (this.#state.enabled || this.#state.compressor) {
            this.#tryConnect();
        } else {
            this.#updateAudioNodes();
        }

        // UI 갱신
        this.#refreshUI();
    }

    #startVideoWatch() {
        if (this.#videoInterval) clearInterval(this.#videoInterval);
        this.#videoInterval = window.setInterval(() => {
            if (!isPlayerPage()) return;
            const video = document.querySelector('video.webplayer-internal-video') as HTMLVideoElement | null;
            if (video && video !== this.#connectedVideo) {
                // Firefox 버그 우회: 한 번이라도 Web Audio API에 연결된 비디오는 오디오 엔진을 꺼도 bypass 경로 유지가 필수
                if (this.#state.enabled || this.#state.compressor || taintedVideos.has(video)) {
                    this.#tryConnect();
                }
            }
        }, 1000);
    }

    async #tryConnect() {
        if (this.#isConnecting) return;
        const video = document.querySelector('video.webplayer-internal-video') as HTMLVideoElement | null;
        if (!video) return;

        const isFirefox = navigator.userAgent.toLowerCase().includes('firefox');

        // Firefox 버그 우회 1: WebRTC(MediaStream) 재생 시 createMediaElementSource 연결하면 스트림 깨짐
        if (isFirefox && video.srcObject instanceof MediaStream) {
            console.warn('[CQC:Audio] Firefox + MediaStream detected. Bypassing AudioEnhancer to prevent stream crash.');
            return;
        }

        // Firefox 버그 우회 2: 비디오 버퍼가 충분히 로드되기 전(readyState < 3)에 연결하면 MSE 스트림 재생이 멈춤
        if (isFirefox && video.readyState < 3) {
            // 다음 setInterval 주기에 다시 시도하도록 connectedVideo 갱신 보류
            return;
        }

        if (video === this.#connectedVideo && this.#ctx) {
            this.#updateAudioNodes();
            return;
        }

        this.#isConnecting = true;
        this.#disconnectNodes();

        try {
            const cached = videoSourceMap.get(video);
            if (cached && cached.ctx.state !== 'closed') {
                this.#ctx = cached.ctx;
                this.#source = cached.source;
            } else {
                // @ts-ignore
                const AudioContextClass = window.AudioContext || window.webkitAudioContext;
                this.#ctx = new AudioContextClass();
                if (this.#ctx) {
                    this.#source = this.#ctx.createMediaElementSource(video);
                    videoSourceMap.set(video, { ctx: this.#ctx, source: this.#source });
                    taintedVideos.add(video);
                }
            }

            if (!this.#ctx) throw new Error('AudioContext failed to initialize');

            this.#eqFilters = BANDS.map((freq, i) => {
                if (!this.#ctx) throw new Error('AudioContext lost');
                const f = this.#ctx.createBiquadFilter();
                f.type = i === 0 ? 'lowshelf' : (i === BANDS.length - 1 ? 'highshelf' : 'peaking');
                f.frequency.value = freq;
                if (f.type === 'peaking') f.Q.value = 1.4;
                return f;
            });

            this.#compressor = this.#ctx.createDynamicsCompressor();
            this.#compressor.threshold.value = -35;
            this.#compressor.knee.value = 15;
            this.#compressor.ratio.value = 8;
            this.#compressor.attack.value = 0.005;
            this.#compressor.release.value = 0.15;
            this.#gainNode = this.#ctx.createGain();
            this.#connectedVideo = video;
            this.#connectedVideo.addEventListener('volumechange', this.#onVolumeChange);

            this.#buildChain();
            this.#updateAudioNodes();
        } catch (e) {
            console.error('[CQC:Audio] Connection failed', e);
            this.#connectedVideo = null;
        } finally {
            this.#isConnecting = false;
        }
    }

    /** Firefox 등에서 AudioContext가 멈춰있는 경우를 대비한 킥 로직 */
    #kickContext() {
        if (!this.#ctx || this.#ctx.state !== 'running') return;
        try {
            const osc = this.#ctx.createOscillator();
            const g = this.#ctx.createGain();
            g.gain.value = 0.0001;
            osc.connect(g);
            g.connect(this.#ctx.destination);
            osc.start();
            osc.stop(this.#ctx.currentTime + 0.05);
        } catch (e) { }
    }

    #buildChain() {
        if (!this.#source || !this.#ctx) return;
        try {
            this.#source.disconnect();
            this.#eqFilters.forEach(f => f.disconnect());
            this.#compressor?.disconnect();
            this.#gainNode?.disconnect();
        } catch (e) { }

        console.log('[CQC:Audio] Rebuilding audio chain. State:', {
            enabled: this.#state.enabled,
            compressor: this.#state.compressor
        });

        let lastNode: AudioNode = this.#source;

        if (this.#state.enabled && this.#eqFilters.length > 0) {
            console.log('[CQC:Audio] Connecting EQ filters to chain');
            this.#eqFilters.forEach(f => {
                lastNode.connect(f);
                lastNode = f;
            });
        }

        if (this.#state.compressor && this.#compressor) {
            console.log('[CQC:Audio] Connecting Compressor to chain');
            lastNode.connect(this.#compressor);
            lastNode = this.#compressor;
        }

        if (this.#gainNode) {
            console.log('[CQC:Audio] Connecting GainNode to chain');
            lastNode.connect(this.#gainNode);
            this.#gainNode.connect(this.#ctx.destination);
        } else {
            console.log('[CQC:Audio] Connecting lastNode directly to destination');
            lastNode.connect(this.#ctx.destination);
        }
    }

    #updateAudioNodes() {
        if (!this.#gainNode) return;
        const active = this.#state.enabled;

        // Web Audio API는 비디오의 volume/muted 속성을 무시하므로 수동으로 곱해줌
        let videoVolume = 1.0;
        if (this.#connectedVideo) {
            videoVolume = this.#connectedVideo.muted ? 0 : this.#connectedVideo.volume;
        }

        let baseGain = active ? this.#state.gain : 1.0;
        if (this.#state.compressor) {
            baseGain *= 2.2; // 음량 정규화 활성화 시 볼륨 저하를 막기 위해 메이크업 게인 +6.8dB 적용
        }

        this.#gainNode.gain.value = baseGain * videoVolume;

        this.#eqFilters.forEach((f, i) => {
            f.gain.value = active ? (this.#state.eq[i] ?? 0) : 0;
        });
        this.#buildChain();
    }

    /** UI 선언적 갱신 */
    #refreshUI() {
        const menu = document.querySelector('.cqc-audio-menu') as HTMLElement | null;
        if (!menu) return;

        const $ = (s: string) => menu.querySelector(s) as HTMLElement | null;

        const mainToggle = $('.audio-main-toggle') as HTMLInputElement | null;
        const mainWrapper = $('.audio-toggle-wrapper');
        const compToggle = $('.audio-comp-toggle') as HTMLInputElement | null;
        const compWrapper = $('.audio-comp-wrapper');
        const gainSlider = $('.audio-gain-slider') as HTMLInputElement | null;
        const gainLabel = $('.audio-gain-label');
        const presetSelect = $('.aeq-preset') as HTMLSelectElement | null;
        const bandSliders = menu.querySelectorAll('.aeq-band') as NodeListOf<HTMLInputElement>;
        const bandValLabels = menu.querySelectorAll('.aeq-val');

        if (mainToggle) {
            mainToggle.checked = this.#state.enabled;
            mainWrapper?.setAttribute('aria-checked', String(this.#state.enabled));
        }
        if (compToggle) {
            compToggle.checked = this.#state.compressor;
            compWrapper?.setAttribute('aria-checked', String(this.#state.compressor));
        }
        if (gainSlider) {
            gainSlider.value = String(this.#state.gain);
            gainSlider.disabled = !this.#state.enabled;
        }
        if (gainLabel) gainLabel.textContent = `${Math.round(this.#state.gain * 100)}%`;
        if (presetSelect) {
            presetSelect.value = this.#state.preset;
            presetSelect.disabled = !this.#state.enabled;
        }

        bandSliders.forEach((s, i) => {
            s.value = String(this.#state.eq[i] ?? 0);
            s.disabled = !this.#state.enabled;
            s.style.accentColor = this.#state.enabled ? '#00ffa3' : '#555';
        });
        bandValLabels.forEach((l, i) => {
            const val = this.#state.eq[i] ?? 0;
            l.textContent = (val > 0 ? '+' : '') + val;
        });
    }

    /** 
     * 메뉴 컨트롤 주입 
     * @param menu
     */
    injectControls(menu: HTMLElement) {
        if (menu.querySelector('.cqc-audio-menu')) return;

        const item = document.createElement('div');
        item.className = 'pzp-ui-setting-home-item cqc-audio-menu';
        item.setAttribute('role', 'menuitem');
        item.tabIndex = 0;

        item.insertAdjacentHTML('beforeend', `
            <div class="pzp-ui-setting-home-item__top">
                <div class="pzp-ui-setting-home-item__left"><span class="pzp-ui-setting-home-item__label">오디오 개선</span></div>
                <div class="pzp-ui-setting-home-item__right">
                    <div role="switch" class="pzp-ui-toggle audio-toggle-wrapper" aria-label="오디오 개선 토글" tabindex="0">
                        <input type="checkbox" class="pzp-ui-toggle__checkbox audio-main-toggle" tabindex="-1">
                        <div class="pzp-ui-toggle__handle"></div>
                    </div>
                </div>
            </div>
            <div class="pzp-ui-setting-home-item__bottom" style="padding:8px;display:flex;flex-direction:column;gap:6px;">
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="min-width:36px;font-size:12px;color:#ccc;">음량</span>
                    <input type="range" class="audio-gain-slider" min="0.5" max="3" step="0.1" style="flex:1;accent-color:#00ffa3;">
                    <span class="audio-gain-label" style="min-width:36px;text-align:right;font-size:11px;color:#aaa;">100%</span>
                </div>
                <div style="display:flex;align-items:center;gap:8px;">
                    <span style="min-width:36px;font-size:12px;color:#ccc;">EQ</span>
                    <select class="aeq-preset" style="flex:1;padding:4px 6px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:5px;color:#e0e0e0;font-size:11px;outline:none;cursor:pointer;">
                    </select>
                </div>
                <div style="display:flex;gap:2px;padding:4px 0;" class="aeq-bands-row">
                </div>
                <div style="display:flex;align-items:center;justify-content:space-between;padding-top:4px;">
                    <span style="font-size:12px;color:#ccc;">음량 정규화</span>
                    <div role="switch" class="pzp-ui-toggle audio-comp-wrapper" aria-label="컴프레서 토글" tabindex="0">
                        <input type="checkbox" class="pzp-ui-toggle__checkbox audio-comp-toggle" tabindex="-1">
                        <div class="pzp-ui-toggle__handle"></div>
                    </div>
                </div>
            </div>`);

        const selectEl = item.querySelector('.aeq-preset') as HTMLSelectElement | null;
        if (selectEl) {
            Object.entries(PRESETS).forEach(([k, p]) => {
                const opt = document.createElement('option');
                opt.value = k;
                opt.style.background = '#141517';
                opt.style.color = '#e0e0e0';
                opt.textContent = p.name;
                selectEl.appendChild(opt);
            });
        }

        const bandsRow = item.querySelector('.aeq-bands-row');
        if (bandsRow) {
            BANDS.forEach((_, i) => {
                const col = document.createElement('div');
                col.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:2px;flex:1;';

                const valSpan = document.createElement('span');
                valSpan.className = 'aeq-val';
                valSpan.style.cssText = 'font-size:9px;color:#888;min-height:14px;';
                valSpan.textContent = '0';
                col.appendChild(valSpan);

                const input = document.createElement('input');
                input.type = 'range';
                input.className = 'aeq-band';
                input.dataset.idx = String(i);
                input.min = '-20';
                input.max = '12';
                input.step = '1';
                input.style.cssText = 'writing-mode:vertical-lr;direction:rtl;height:60px;width:20px;accent-color:#00ffa3;';
                col.appendChild(input);

                const labelSpan = document.createElement('span');
                labelSpan.style.cssText = 'font-size:8px;color:#666;';
                labelSpan.textContent = BAND_LABELS[i] ?? '';
                col.appendChild(labelSpan);

                bandsRow.appendChild(col);
            });
        }

        // 선제적 차단: 모든 마우스 이벤트가 부모(설정 메뉴)로 전파되지 않도록 완벽히 격리
        const preventGlobal = (e: Event) => e.stopPropagation();
        item.addEventListener('click', preventGlobal);
        item.addEventListener('mousedown', preventGlobal);
        item.addEventListener('mouseup', preventGlobal);
        item.addEventListener('contextmenu', preventGlobal);

        // 개별 요소 핸들러 바인딩
        const $ = (s: string) => item.querySelector(s) as any;

        const mainToggle = $('.audio-main-toggle') as HTMLInputElement | null;
        const mainWrapper = $('.audio-toggle-wrapper') as HTMLElement | null;
        const compToggle = $('.audio-comp-toggle') as HTMLInputElement | null;
        const compWrapper = $('.audio-comp-wrapper') as HTMLElement | null;
        const gainSlider = $('.audio-gain-slider') as HTMLInputElement | null;
        const presetSelect = $('.aeq-preset') as HTMLSelectElement | null;
        const bandSliders = item.querySelectorAll('.aeq-band') as NodeListOf<HTMLInputElement>;

        // 토글 처리 (Wrapper 클릭 대행 및 Checkbox 직접 제어 분리)
        const toggleMain = () => this.#setState({ enabled: !this.#state.enabled });
        if (mainWrapper) {
            mainWrapper.onclick = (e: MouseEvent) => { e.preventDefault(); e.stopPropagation(); toggleMain(); };
        }
        if (mainToggle) {
            mainToggle.onchange = (e: Event) => { e.stopPropagation(); const target = e.target as HTMLInputElement; this.#setState({ enabled: target.checked }); };
        }

        const toggleComp = () => this.#setState({ compressor: !this.#state.compressor });
        if (compWrapper) {
            compWrapper.onclick = (e: MouseEvent) => { e.preventDefault(); e.stopPropagation(); toggleComp(); };
        }
        if (compToggle) {
            compToggle.onchange = (e: Event) => { e.stopPropagation(); const target = e.target as HTMLInputElement; this.#setState({ compressor: target.checked }); };
        }

        // 슬라이더 및 셀렉트 (mousedown 전파 차단 필수 - 메뉴 닫힘 방지)
        const preventMenuClose = (e: Event) => e.stopPropagation();

        if (gainSlider) {
            gainSlider.oninput = (e: Event) => { const target = e.target as HTMLInputElement; this.#setState({ gain: parseFloat(target.value) }); };
            gainSlider.onmousedown = preventMenuClose;
        }

        if (presetSelect) {
            presetSelect.onchange = (e: Event) => {
                const target = e.target as HTMLSelectElement;
                const name = target.value;
                const updates: Partial<AudioState> = { preset: name };
                if (name !== 'custom') {
                    const presetConf = PRESETS[name];
                    if (presetConf) {
                        updates.eq = [...presetConf.values];
                    }
                }
                this.#setState(updates);
            };
            presetSelect.onmousedown = preventMenuClose;
        }

        bandSliders.forEach((s) => {
            s.oninput = (e: Event) => {
                const target = e.target as HTMLInputElement;
                const idx = parseInt(target.dataset.idx || '0');
                const newEq = [...this.#state.eq];
                newEq[idx] = parseFloat(target.value);
                this.#setState({ eq: newEq, preset: 'custom' });
            };
            s.onmousedown = preventMenuClose;
        });

        menu.append(item);
        this.#refreshUI();
    }
}

/** 오디오 모듈 초기화 */
export const initAudio = () => {
    const enhancer = AudioEnhancer.getInstance();
    enhancer.init();

    setInterval(() => {
        const menu = document.querySelector(SELECTORS.SETTINGS_MENU) as HTMLElement | null;
        if (menu) enhancer.injectControls(menu);
    }, 1500);

    let lastPath = location.pathname;
    const checkNav = () => {
        if (location.pathname !== lastPath) {
            lastPath = location.pathname;

            // SPA 라우팅 대응: 노드만 정리하고 AudioContext/source bypass 유지
            enhancer.destroy();

            if (isPlayerPage()) {
                // React/Vue DOM 업데이트(비디오 요소 교체 등)를 기다린 후 재초기화
                setTimeout(() => enhancer.init(), 800);
            }
        }
    };
    window.addEventListener('popstate', checkNav);
    const originalPush = history.pushState;
    // @ts-ignore
    history.pushState = function (...args) { originalPush.apply(this, args); checkNav(); };
    const originalReplace = history.replaceState;
    // @ts-ignore
    history.replaceState = function (...args) { originalReplace.apply(this, args); checkNav(); };
};
