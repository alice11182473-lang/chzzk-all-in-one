import assert from 'node:assert/strict';
import {normalizeRecordingFolder, recordingDownloadName} from './recording-path.js';
assert.equal(normalizeRecordingFolder(' 치지직\\녹화 '), '치지직/녹화');
for (const bad of ['C:\\record','/record','../record','a/../b','a//b','CON','test.','a?']) {
  assert.throws(() => normalizeRecordingFolder(bad), bad);
}
const auto = {url:'blob:https://chzzk.naver.com/123',filename:'C:\\Users\\test\\Downloads\\chzzk_channel_2026.webm'};
const manual = {...auto,filename:'chzzk_2026.mp4'};
assert.equal(recordingDownloadName(auto,'치지직/녹화'),'치지직/녹화/chzzk_channel_2026.webm');
assert.equal(recordingDownloadName(manual,'녹화'),'녹화/chzzk_2026.mp4');
assert.equal(recordingDownloadName(auto,''),null);
assert.equal(recordingDownloadName({...auto,url:'blob:https://example.com/id'},'녹화'),null);
assert.equal(recordingDownloadName({...auto,filename:'chzzk_2026.png'},'녹화'),null);
let listener;
globalThis.chrome = {downloads:{onDeterminingFilename:{addListener: fn => {listener=fn;}}},storage:{local:{get:async () => ({cqcRecordingFolder:'녹화'})}}};
await import('./recording-downloads.js');
let response;
assert.equal(listener(auto, value => {response=value;}), true);
await new Promise(resolve => setImmediate(resolve));
assert.deepEqual(response,{filename:'녹화/chzzk_channel_2026.webm',conflictAction:'uniquify'});
globalThis.chrome.storage.local.get=async()=>{throw new Error('unavailable');};
response='pending';listener(auto,value=>{response=value;});
await new Promise(resolve => setImmediate(resolve));assert.equal(response,undefined);
console.log('Recording folder validation, routing, unrelated files, and storage failure checks passed');
