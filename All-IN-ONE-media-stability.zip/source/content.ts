// @ts-nocheck
import './src/utils/StorageBridge';
import Browser from 'webextension-polyfill';

import { updateScreenshotSettings } from './screenshot';
import { updateRecorderSettings } from './recorder';
import { initMultiview, handleMultiviewIframe } from './multiview';
import { initGCMonitor } from './gc-monitor';
import { log as cqcLog } from './dom-utils';
import { SetupWizard } from './setup-wizard';
import { safeParseSettings } from './settings-schema';
import { initSelectors } from './dom-utils';

import './powerclick.css';
import './overlay.css';
import './sidebar-folder-modal.css';

import { runtime } from './src/core/RuntimeManager';
import { IpcModule } from './src/modules/core/IpcModule';
import { LayoutModule } from './src/modules/core/LayoutModule';
import { RouterModule } from './src/modules/core/RouterModule';
import { ShortcutModule } from './src/modules/shortcuts/ShortcutModule';
import { OverlayModule } from './src/modules/overlay/OverlayModule';
import { FolderModule } from './src/modules/sidebar/FolderModule';
import { ChatModule } from './src/modules/chat/ChatModule';
import { PlayerModule } from './src/modules/player/PlayerModule';
import { NoticeModule } from './src/modules/overlay/NoticeModule';

/**
 * @param {any[]} args
 */
const log = (...args) => { };

// 1. 코어 모듈 및 런타임 초기화
const ipcModule = new IpcModule();
const send = ipcModule.send;

runtime.register(ipcModule);
runtime.register(new LayoutModule());
runtime.register(new RouterModule());
runtime.register(new ShortcutModule());
runtime.register(new OverlayModule());
runtime.register(new FolderModule());
runtime.register(new ChatModule());
runtime.register(new PlayerModule());

runtime.register(new NoticeModule());
// 2. 글로벌 상태
/** @type {any} */
let settings = null;

const loadSettings = async () => {
  try {
    const res = await Browser.storage.sync.get('settings');
    settings = safeParseSettings(res.settings);
    // 마이그레이션 로직
    if (settings.videoFilterEnabled !== undefined) {
      if (settings.sharpnessEnabled === undefined) settings.sharpnessEnabled = settings.videoFilterEnabled;
      delete settings.videoFilterEnabled;
      await Browser.storage.sync.set({ settings });
    }
  } catch (e) {
    log('Failed to load settings:', e);
    settings = safeParseSettings({});
  }
};

const injectMainWorldScript = () => {
  return new Promise((resolve) => {
    const sEarly = document.createElement('script');
    sEarly.src = Browser.runtime.getURL('ad-skip.js');
    sEarly.async = false;

    const s = document.createElement('script');
    s.type = 'module';
    s.src = Browser.runtime.getURL('injected.js');
    s.async = false;

    sEarly.onload = () => sEarly.remove();
    s.onload = () => s.remove();

    const onReady = (/** @type {any} */ e) => {
      if (e.source !== window || e.data?.direction !== 'CQC_TO_CONTENT') return;
      if (e.data.type === 'INJECTED_READY') {
        log('Main World script ready.');
        window.removeEventListener('message', onReady);
        resolve(undefined);
      }
    };
    window.addEventListener('message', onReady);

    const target = document.head ?? document.documentElement;
    target.appendChild(sEarly);
    target.appendChild(s);
  });
};

const isContextValid = () => !!Browser.runtime?.id;

const boot = async () => {
  if (/^\/clips?(\/|$)/.test(location.pathname)) {
    //log('Excluding extension logic on clip pages.');
    return;
  }

  if (!document.body) {
    await new Promise(resolve => {
      const observer = new MutationObserver(() => {
        if (document.body) {
          observer.disconnect();
          resolve(undefined);
        }
      });
      observer.observe(document.documentElement, { childList: true });
    });
  }

  initMultiview();
  handleMultiviewIframe();

  await loadSettings();
  if (settings) {
    if (settings.setupCompleted === false && window.self === window.top) {
      SetupWizard.show();
    }
    updateScreenshotSettings(settings);
    updateRecorderSettings(settings);
    if (settings.customSelectors) {
      initSelectors(settings.customSelectors);
    }
  }

  if (settings?.enabled === false) {
    log('Extension is disabled by user.');
    return;
  }

  await injectMainWorldScript();
  send('INIT', settings);
  setTimeout(() => {
    if (settings?.enabled !== false) {
      send('INIT', settings);
    }
  }, 1000);

  setInterval(() => {
    if (isContextValid() && ipcModule.syncState) {
      ipcModule.syncState().catch(() => { });
    }
  }, 3000);

  try {
    if (isContextValid()) {
      Browser.storage.sync.get({ hideSharpMenu: false, hideAudioMenu: false }).then((res) => {
        if (!isContextValid()) return;
        if (settings) {
          settings.hideSharpMenu = res.hideSharpMenu;
          settings.hideAudioMenu = res.hideAudioMenu;
          runtime.eventBus.emit('UI_VISIBILITY_UPDATE');
        }
      });
    }
  } catch (e) { }

  /**
   * @param {any} changes
   */
  const onStorageChanged = (changes) => {
    if (!isContextValid()) return;
    if (!('hideSharpMenu' in changes) && !('hideAudioMenu' in changes)) return;
    try {
      Browser.storage.sync.get({ hideSharpMenu: false, hideAudioMenu: false }).then((res) => {
        if (!isContextValid()) return;
        if (settings) {
          settings.hideSharpMenu = res.hideSharpMenu;
          settings.hideAudioMenu = res.hideAudioMenu;
        }
        runtime.eventBus.emit('UI_VISIBILITY_UPDATE');
      });
    } catch (e) {
      console.error(e);
    }
  };
  Browser.storage.onChanged.addListener(onStorageChanged);
  if (runtime && runtime.cleanups) {
    // @ts-ignore
    runtime.cleanups.push(() => Browser.storage.onChanged.removeListener(onStorageChanged));
  }

  // 코어 매니저에 모듈 마운트 명령
  runtime.mount(settings, send);

  if (settings?.gcMonitorEnabled) {
    initGCMonitor();
  }
};

boot();
