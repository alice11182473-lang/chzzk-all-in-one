// @ts-nocheck
export const applyMediaButtonVisibility = (settings) => {
  document.body.classList.toggle('cqc-screenshot-on', settings?.screenshotEnabled !== false);
  document.body.classList.toggle('cqc-recorder-on', settings?.recorderEnabled !== false);
};

export const applyPlayerMenuVisibility = (settings) => {
  document.body.classList.toggle('cqc-hide-sharp-menu', !!settings?.hideSharpMenu);
  document.body.classList.toggle('cqc-hide-audio-menu', !!settings?.hideAudioMenu);
};
