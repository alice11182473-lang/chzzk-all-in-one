# 치지직 채팅 리액트 내부 분석 및 가로채기(Interception) 가이드

이 문서는 치지직(Chzzk)의 리액트 내부 구조를 분석하여, 채팅 메시지를 렌더링 전 단계에서 가로채고 필터링하기 위한 기술 가이드입니다. 다른 AI 에이전트 혹은 개발자가 코드를 구현할 때 참고할 수 있도록 상세히 적었습니다.

## 1. 구조적 개요 (Structural Overview)

치지직은 functional component와 React Fiber 트리 구조를 사용합니다. 채팅 목록은 Fiber 트리의 특정 컴포넌트 내에서 `useReducer` 또는 `useState` 훅으로 관리됩니다.

### 기반 요소 (Anchor Point)

- **DOM 컨테이너**: `div[class*="live_chatting_list_container"]`
- **Fiber 노드 접근**: `element[Object.keys(element).find(k => k.startsWith('__reactFiber$'))]`를 통해 접근합니다.

### 컴포넌트 식별 (`Mne`)

- **계층 구조**: 목록 컨테이너의 직계 부모 Fiber(Depth 1)가 주요 상태(State)를 보유하고 있습니다.
- **내부 명칭**: 현재 `Mne` (난독화된 이름이므로 변경될 수 있음. 훅 시그니처를 통한 검증 권장).

## 2. 훅 및 디스패치 분석 (Hook & Dispatch Analysis)

`Mne` 컴포넌트는 `memoizedState`라는 연결 리스트(Linked List) 형태의 훅들을 사용합니다.

### 훅 체인 (0번부터 시작)

| 인덱스 | 네이티브 타입 | 역할 | 세부 내용 |
| :--- | :--- | :--- | :--- |
| **0** | `useSyncExternalStore` | 스토어 연결 | 리액트 외부 상태 동기화 |
| **1-9** | various | 설정/UI | 폰트 크기, 슬로우 모드 등 |
| **10** | `useReducer` | **메시지 리스트** | **핵심 타겟.** 처리된 메시지 객체들의 배열. |
| **11** | `useState` | 버퍼 | 최근/대기 중인 메시지 배치 처리용. |

### 메시지 객체 구조 (Native Data)

Hook 10에서 다루는 메시지 객체는 다음과 같은 구조를 가집니다:

```typescript
interface ChzzkChatMessage {
    key: string;              // 메시지 고유 UUID
    user: string;             // 유저 고유 해시값
    time: number;             // 타임스탬프 (ms)
    type: number;             // 1: 일반 채팅, 10: 후원, 12: 시스템
    originalContent: string;  // 원문 (이모티콘 토큰 포함: {:emoji:})
    originalExtras: string;   // JSON 문자열: { "emojis": {}, "osType": "PC", ... }
    profile: {
        nickname: string;
        userRoleCode: string; // "streamer", "manager", "common_user"
    }
}
```

## 3. 핵심 기술: 디스패치 후킹 (Dispatch Hooking)

메시지가 화면에 잠깐 나타났다가 사라지는 '깜빡임' 현상을 방지하려면, 렌더링(Commit) 단계가 아니라 **상태 전이(State Transition) 단계**에서 가로채야 합니다.

### 실행 경로

1. **디스패치 큐 탐색**: `fiber.memoizedState.next[...10].queue`로 접근합니다.
2. **원본 보존**: `originalDispatch = queue.dispatch`로 원본 함수를 저장합니다.
3. **몽키 패치(Monkey Patch)**: `queue.dispatch(action)`를 사용자 정의 함수로 덮어씁니다.

### 구현 로직 (AI를 위한 가이드)

`useReducer`의 `action`은 두 가지 형태일 수 있습니다:

- **직접 데이터(Array)**: 새로운 상태 배열이 직접 전달됨.
- **업데이터 함수(Function)**: [(prevState) => newState](file:///c:/Users/Administrator/Downloads/chzzk-quality-ext/chatfilter.js#17-22) 형태의 함수가 전달됨.

**표준 필터링 로직 예시**:

```javascript
queue.dispatch = function(action) {
    if (typeof action === 'function') {
        const originalAction = action;
        action = (prevState) => {
            const newState = originalAction(prevState);
            // 필터링 규칙 적용 (예: 특정 키워드 메시지 제외)
            return newState.filter(msg => !shouldFilter(msg));
        };
    } else if (Array.isArray(action)) {
        action = action.filter(msg => !shouldFilter(msg));
    }
    return originalDispatch.apply(this, [action]);
};
```

## 4. 접근 방법 가이드 (Approach Strategy)

구현 에이전트는 다음 단계를 따라야 합니다.

### 1단계: 초기화 및 폴링

- 채팅 컨테이너가 나타날 때까지 주기적으로 검사합니다.
- 컨테이너 발견 시 리액트 Fiber 노드를 확보합니다.

### 2단계: 유효성 검증

- 찾은 컴포넌트의 10번째 훅이 실제로 메시지 배열을 담고 있는지 확인합니다 (`Array.isArray(hook.memoizedState)`).
- 컴포넌트 이름(`Mne`)보다는 훅의 인덱스와 데이터 형태를 기준으로 타겟팅하여 내구성을 확보합니다.

### 3단계: 가로채기 실행

- `dispatch`를 패치하여 필터링 함수를 주입합니다.
- 기존의 `MutationObserver` 방식보다 우선순위를 높게 설정하여 DOM 연산을 사전에 차단합니다.

### 4단계: 동적 재연결

- 치지직의 SPA 특성상 방송 페이지 이동 시 컴포넌트가 파괴되고 재생성됩니다.
- 컴포넌트가 재생성될 때마다(또는 DOM이 바뀔 때마다) 인터셉터를 재부착(Re-attach)하는 로직을 포함해야 합니다.

## 5. 모니터링해야 할 네이티브 동작 (Native Behaviors to Monitor)

- **채팅 기록 제한**: 치지직은 메시지 배열(Hook 10)을 200개로 제한합니다. 201번째 메시지가 들어오면 가장 오래된 메시지가 제거됩니다.
- **재렌더링**: Fiber 노드는 재활용됩니다. DOM 요소가 다시 생성될 경우(예: "일반 채팅"에서 "후원 전용"으로 전환 시), 인터셉터는 재부착되어야 합니다.
- **난독화**: `Mne`와 같은 컴포넌트 이름은 변경될 수 있습니다. `hookIndex`와 `stateShape`(`.profile.nickname` 확인)를 휴리스틱으로 사용하여 컴포넌트를 감지해야 합니다.