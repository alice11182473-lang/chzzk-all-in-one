import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import Browser from 'webextension-polyfill';
import { safeParseSettings, SettingsSchema } from './settings-schema';

// --- CONFIG & DATA ---
// 기본 스키마에서 boolean 속성들의 기본값을 추출
const defaultSettings = SettingsSchema.parse({});
const baseBooleanSettings: Record<string, boolean> = {};
Object.keys(defaultSettings).forEach(key => {
  if (typeof defaultSettings[key as keyof typeof defaultSettings] === 'boolean') {
    baseBooleanSettings[key] = defaultSettings[key as keyof typeof defaultSettings] as boolean;
  }
});
baseBooleanSettings.sharpnessEnabled = false;

type PresetConfigType = Record<string, boolean>;

const PRESET_CONFIG: Record<string, PresetConfigType> = {
  lite: {
    autoQuality: false,
    preferLowLatency: false,
    hoverPreviewEnabled: false,
    chatStampEnabled: true,
    chatEmojiCopyPasteEnabled: true,
    layoutCleanEnabled: false,
    // UI 숨김 위주로 클린하게
    hideStudioButton: true,
    hideCheeseButton: true,
    hideNotiButton: true,
    hideCheatKeyButton: true,
    hideHeaderTabsEnabled: true,
    hideHomeRecommendEnabled: true,
    hideStreamerShopEnabled: true,
    staticLogoEnabled: true,
  },
  recommended: {
    autoQuality: true,
    preferLowLatency: true,
    hoverPreviewEnabled: true,
    thumbnailPreviewEnabled: false,
    chatStampEnabled: true,
    liveNotificationEnabled: true,
    chatEmojiCopyPasteEnabled: true,
    volumeIndicatorEnabled: true,
    layoutCleanEnabled: true,
    followingRefreshEnabled: true,
    watchTimerEnabled: true,
    // 적당한 수준의 편의성 활성화
    hideStudioButton: false,
    hideCheeseButton: false,
    hideNotiButton: false,
  },
  full: {
    autoQuality: true,
    preferLowLatency: true,
    hoverPreviewEnabled: true,
    hoverPreviewVideoEnabled: true,
    thumbnailPreviewEnabled: false,
    chatStampEnabled: true,
    liveNotificationEnabled: true,
    chatEmojiCopyPasteEnabled: true,
    ambientEnabled: true,
    sharpnessEnabled: true,
    wideViewEnabled: true,
    screenshotEnabled: true,
    recorderEnabled: true,
    streamStatsEnabled: true,
    statsContextMenuEnabled: true,
    blindedRestoreEnabled: true,
    chatDeviceIconEnabled: true,
    followingRefreshEnabled: true,
    watchTimerEnabled: true,
    layoutCleanEnabled: true,
    // 모든 유용한 기능 켜기
  },
};

const WIZARD_STEPS = [
  {
    id: 'performance', title: '성능 및 플레이어', subtitle: '플레이어 화질, 지연시간, 기본 동작 설정',
    options: ['autoQuality', 'preferLowLatency', 'adaptiveLatencyEnabled', 'ambientEnabled', 'sharpnessEnabled', 'wideViewEnabled', 'playbackSpeedEnabled', 'volumeIndicatorEnabled', 'watchTimerEnabled']
  },
  {
    id: 'convenience', title: '사이드바 및 레이아웃', subtitle: '사이드바와 기본 레이아웃 확장 기능',
    options: ['hoverPreviewEnabled', 'hoverPreviewVideoEnabled', 'sidebarFoldersEnabled', 'sidebarResizeEnabled', 'leftChatEnabled', 'focusModeEnabled', 'followingRefreshEnabled', 'followingExpandEnabled', 'hideOfflineFollowing']
  },
  {
    id: 'chat', title: '채팅', subtitle: '채팅창 시각 효과 및 부가 기능',
    options: ['chatStampEnabled', 'chatLatencyDisplayEnabled', 'chatDeviceIconEnabled', 'chatEmojiCopyPasteEnabled', 'chatResizeEnabled', 'chatFilterEnabled', 'blindedRestoreEnabled', 'blindedAutoRestoreEnabled', 'hideChatNickname', 'hideChatBadge']
  },
  {
    id: 'tools', title: '도구 및 통계', subtitle: '녹화, 스크린샷, 채팅 수집 등 고급 도구',
    options: ['screenshotEnabled', 'recorderEnabled', 'streamStatsEnabled', 'statsContextMenuEnabled', 'chatCollectorEnabled', 'chatExportEnabled', 'powerClickEnabled']
  },
  {
    id: 'cleanup', title: 'UI 클린업 및 알림', subtitle: '불필요한 요소를 숨기고 알림을 관리합니다.',
    options: ['liveNotificationEnabled', 'liveAutoReloadEnabled', 'layoutCleanEnabled', 'hideStudioButton', 'hideCheeseButton', 'hideNotiButton', 'hideCheatKeyButton', 'staticLogoEnabled', 'hideHomeBannerEnabled', 'hideHomeRecommendEnabled', 'hideStreamerShopEnabled', 'rankingHideEnabled']
  }
];

const OPTION_META: Record<string, { label: string, desc: string }> = {
  // Performance
  autoQuality: { label: '자동 화질 최적화 고정', desc: '진입 시 최적의 고화질(1080p 등)로 자동 재생' },
  preferLowLatency: { label: '저지연 모드 선호', desc: '스트리밍 지연(딜레이) 최소화 모드 우선 적용' },
  adaptiveLatencyEnabled: { label: '적응형 지연시간', desc: '네트워크 상태에 따라 지연시간 자동 조절' },
  ambientEnabled: { label: '앰비언트 효과', desc: '플레이어 외곽에 영상 색상 반영 빛 번짐 효과' },
  sharpnessEnabled: { label: '선명한 화면 필터', desc: '영상 선명도 조절 및 색상 보정' },
  wideViewEnabled: { label: '와이드 뷰 모드', desc: '여백을 최소화하여 플레이어 확대' },
  playbackSpeedEnabled: { label: '재생 속도 조절', desc: 'VOD/생방송 재생 속도 조절 기능 활성화' },
  volumeIndicatorEnabled: { label: '볼륨 표시기', desc: '볼륨 조절 시 화면에 수치 표시' },
  watchTimerEnabled: { label: '시청 타이머', desc: '현재 방송 시청 시간 표시' },

  // Convenience
  hoverPreviewEnabled: { label: '마우스 오버 미리보기', desc: '사이드바/목록에서 마우스 오버 시 미니 방송 카드 노출' },
  hoverPreviewVideoEnabled: { label: '비디오 미리보기', desc: '미리보기 카드에 실제 영상 스트림 렌더링' },
  thumbnailPreviewEnabled: { label: '썸네일 미리보기', desc: '타임라인 마우스 오버 시 썸네일 노출' },
  sidebarFoldersEnabled: { label: '사이드바 폴더', desc: '팔로잉 목록을 폴더로 그룹화' },
  sidebarResizeEnabled: { label: '사이드바 크기 조절', desc: '마우스 드래그로 사이드바 너비 조절' },
  leftChatEnabled: { label: '좌측 채팅창', desc: '채팅창을 화면 좌측으로 이동' },
  focusModeEnabled: { label: '집중 모드', desc: '플레이어 외 모든 UI 요소를 어둡게 처리' },
  followingRefreshEnabled: { label: '팔로잉 자동 새로고침', desc: '좌측 사이드바 팔로잉 목록 자동 갱신' },
  followingExpandEnabled: { label: '팔로잉 기본 펼침', desc: '팔로잉 목록을 항상 펼쳐진 상태로 유지' },
  hideOfflineFollowing: { label: '오프라인 팔로잉 숨김', desc: '방송 중이 아닌 스트리머 숨김' },

  // Chat
  chatStampEnabled: { label: '채팅 시간 표시', desc: '메시지 전송 시간 출력' },
  chatLatencyDisplayEnabled: { label: '채팅 지연시간 표시', desc: '채팅창 하단에 현재 딜레이 표시' },
  chatDeviceIconEnabled: { label: '기기 아이콘 표시', desc: '작성자의 기기(PC/모바일) 아이콘 표시' },
  chatEmojiCopyPasteEnabled: { label: '이모지 간편 복사', desc: '이모지 클릭 시 클립보드로 복사' },
  chatResizeEnabled: { label: '채팅창 크기 조절', desc: '드래그로 채팅창 너비 조절' },
  chatFilterEnabled: { label: '채팅 필터링', desc: '지정된 키워드/유저의 채팅 숨김' },
  blindedRestoreEnabled: { label: '블라인드 복구 버튼', desc: '삭제된 채팅 내역 확인 기능' },
  blindedAutoRestoreEnabled: { label: '블라인드 자동 복구', desc: '삭제된 채팅을 자동으로 노출' },
  hideChatNickname: { label: '닉네임 숨김', desc: '채팅창 유저 닉네임 숨김' },
  hideChatBadge: { label: '배지 숨김', desc: '채팅창 유저 배지 숨김' },

  // Tools
  screenshotEnabled: { label: '스크린샷 기능', desc: '플레이어 내 화면 캡처 버튼 추가' },
  recorderEnabled: { label: '녹화 기능', desc: '플레이어 내 영상 녹화 버튼 추가' },
  streamStatsEnabled: { label: '방송 통계 표시', desc: '플레이어 내 스트리밍 통계 오버레이' },
  statsContextMenuEnabled: { label: '통계 우클릭 메뉴', desc: '우클릭 메뉴에 방송 통계 복사 추가' },
  chatCollectorEnabled: { label: '채팅 수집기', desc: '채팅 기록 수집 및 검색 기능' },
  chatExportEnabled: { label: '채팅 내보내기', desc: '채팅 내역 파일 저장 기능' },
  powerClickEnabled: { label: '파워클릭 (연타)', desc: '연속 클릭 매크로 지원' },

  // Cleanup
  liveNotificationEnabled: { label: '라이브 알림', desc: '스트리머 라이브 시작 시 브라우저 알림' },
  liveAutoReloadEnabled: { label: '라이브 자동 새로고침', desc: '오프라인 페이지에서 라이브 전환 시 새로고침' },
  layoutCleanEnabled: { label: '기본 레이아웃 클린업', desc: '불필요한 기본 UI 요소 자동 정리' },
  hideStudioButton: { label: '스튜디오 버튼 숨김', desc: '상단 스튜디오 바로가기 제거' },
  hideCheeseButton: { label: '치즈 버튼 숨김', desc: '상단 치즈 충전 팝업 버튼 제거' },
  hideNotiButton: { label: '알림 버튼 숨김', desc: '상단 종 모양 알림 버튼 제거' },
  hideCheatKeyButton: { label: '치트키 버튼 숨김', desc: '상단 치트키 레이아웃 버튼 제거' },
  staticLogoEnabled: { label: '정적 로고 고정', desc: '상단 로고 라이브 애니메이션 제거' },
  hideHomeBannerEnabled: { label: '홈 상단 배너 숨김', desc: '메인 홈 화면 대형 배너 제거' },
  hideHomeRecommendEnabled: { label: '홈 추천 숨김', desc: '홈 자동 추천 방송 리스트 제거' },
  hideStreamerShopEnabled: { label: '스트리머 숍 숨김', desc: '상품/숍 연동 영역 제거' },
  rankingHideEnabled: { label: '랭킹 숨김', desc: '사이드바 인기 랭킹 제거' }
};

// Fallback label generation for any missed keys
const getOptionMeta = (key: string) => {
  if (OPTION_META[key]) return OPTION_META[key];
  return { label: key, desc: '상세 설명 없음' };
}

// --- COMPONENTS ---

const ToggleSwitch = ({ active, onClick }: { active: boolean, onClick: () => void }) => (
  <div className={`cqc-switch ${active ? 'active' : ''}`} onClick={onClick}>
    <div className="cqc-switch-handle"></div>
  </div>
);

interface SetupWizardProps {
  onClose: () => void;
}

export const SetupWizardComponent: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const isFirefox = /firefox|zen/i.test(navigator.userAgent);
  const [currentStep, setCurrentStep] = useState(0);
  const [activePreset, setActivePreset] = useState('recommended');
  const [options, setOptions] = useState<Record<string, boolean>>({});
  const [baseSettings, setBaseSettings] = useState<Record<string, boolean>>({});
  const [isLoaded, setIsLoaded] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    Browser.storage.sync.get('settings').then(res => {
      const current = safeParseSettings(res.settings) as any;
      const booleans: Record<string, boolean> = {};
      Object.keys(current).forEach(key => {
        if (typeof current[key] === 'boolean') {
          booleans[key] = current[key];
        }
      });
      setBaseSettings(booleans);
      
      // Default to recommended preset on first open, merging with user's existing settings
      const initialOptions = { ...booleans, ...PRESET_CONFIG.recommended };
      if (isFirefox) initialOptions.sharpnessEnabled = false;
      setOptions(initialOptions);
      setIsLoaded(true);
    });
  }, []);

  const handlePresetSelect = (presetKey: string) => {
    setActivePreset(presetKey);
    const newOptions = { ...baseSettings, ...PRESET_CONFIG[presetKey] };
    if (isFirefox) newOptions.sharpnessEnabled = false;
    setOptions(newOptions);
  };

  const handleToggle = (key: string) => {
    setActivePreset('custom');
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleNext = () => setCurrentStep(prev => prev + 1);
  const handlePrev = () => setCurrentStep(prev => prev - 1);

  const handleApply = async (isSkip = false) => {
    setIsSaving(true);
    setErrorMsg(null);
    try {
      const { settings: currentSettings } = await Browser.storage.sync.get('settings');
      const validated = safeParseSettings(currentSettings) as any;

      if (!isSkip) {
        // Apply all boolean options dynamically
        Object.keys(options).forEach(key => {
          if (key !== 'sharpnessEnabled') {
            validated[key] = options[key];
          }
        });
      }

      // Special overrides
      validated.enabled = true;
      validated.setupCompleted = true;

      await Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: validated });
      
      if (!isSkip) {
        await Browser.storage.sync.set({ sharpnessEnabled: options.sharpnessEnabled });
      }

      onClose();
      window.location.reload();
    } catch (err) {
      console.error('[CQC:SetupWizard] Save failed:', err);
      setIsSaving(false);
      setErrorMsg('설정 저장 실패 - 다시 시도해주세요.');
    }
  };

  const renderStepContent = () => {
    if (!isLoaded) return null;

    if (currentStep === 0) {
      return (
        <div className="cqc-wizard-step" key="step0">
          <div className="cqc-setup-warning">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
              <line x1="12" y1="9" x2="12" y2="13"></line>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            <div>
              <strong>성능 주의 사항:</strong> 일부 옵션({isFirefox ? '앰비언트 효과 등' : '앰비언트, 선명한 화면 등'})은 실시간 그래픽/비디오 필터를 사용하므로 PC 성능에 따라 튕김 현상이 발생할 수 있습니다.
            </div>
          </div>
          <div className="cqc-setup-section-title">기본 프리셋 선택</div>
          <div className="cqc-preset-cards">
            <div className={`cqc-preset-card ${activePreset === 'lite' ? 'active' : ''}`} onClick={() => handlePresetSelect('lite')}>
              <span className="cqc-preset-icon">⚡</span>
              <span className="cqc-preset-name">순정 모드 (Lite)</span>
              <span className="cqc-preset-desc">치지직 기본 레이아웃<br />최소 편의만 제공</span>
            </div>
            <div className={`cqc-preset-card ${activePreset === 'recommended' ? 'active' : ''}`} onClick={() => handlePresetSelect('recommended')}>
              <span className="cqc-preset-icon">⚖️</span>
              <span className="cqc-preset-name">올인원 추천</span>
              <span className="cqc-preset-desc">화질, 저지연, 알림 등<br />필수 편의 활성화</span>
            </div>
            <div className={`cqc-preset-card ${activePreset === 'full' ? 'active' : ''}`} onClick={() => handlePresetSelect('full')}>
              <span className="cqc-preset-icon">✨</span>
              <span className="cqc-preset-name">풀 이펙트 (Full)</span>
              <span className="cqc-preset-desc">비주얼 효과 및 보정 필터<br />모든 기능 활성화</span>
            </div>
          </div>
        </div>
      );
    }

    const stepData = WIZARD_STEPS[currentStep - 1];
    return (
      <div className="cqc-wizard-step" key={`step${currentStep}`}>
        <div className="cqc-setup-section-title">{stepData.title}</div>
        <div style={{ fontSize: '12px', color: '#718096', marginBottom: '16px' }}>{stepData.subtitle}</div>
        <div className="cqc-detail-options">
          {stepData.options.map(key => {
            if (key === 'sharpnessEnabled' && isFirefox) return null;
            const meta = getOptionMeta(key);
            return (
              <div className="cqc-detail-item" key={key}>
                <div className="cqc-detail-info">
                  <span className="cqc-detail-label">{meta.label}</span>
                  <span className="cqc-detail-desc">{meta.desc}</span>
                </div>
                <ToggleSwitch active={!!options[key]} onClick={() => handleToggle(key)} />
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const totalSteps = WIZARD_STEPS.length;

  return (
    <div className="cqc-setup-overlay">
      <style>{`
        .cqc-setup-overlay {
          position: fixed !important; top: 0 !important; left: 0 !important; width: 100vw !important; height: 100vh !important;
          background: rgba(8, 9, 11, 0.9) !important; backdrop-filter: none !important; -webkit-backdrop-filter: none !important;
          z-index: 999999 !important; display: flex !important; align-items: center !important; justify-content: center !important;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        }
        .cqc-setup-card {
          width: 500px !important; max-height: 90vh !important; overflow-y: hidden !important;
          background: #111215 !important; border: 1px solid #262830 !important; border-radius: 16px !important;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6) !important; color: #f1f2f6 !important;
          display: flex !important; flex-direction: column !important;
          animation: cqc-setup-fade-in 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }
        @keyframes cqc-setup-fade-in {
          from { opacity: 0; transform: scale(0.96) translateY(8px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .cqc-setup-header { padding: 24px 24px 16px !important; border-bottom: 1px solid #1c1d22 !important; display: flex !important; flex-direction: column !important; position: relative !important; }
        .cqc-setup-title { font-size: 20px !important; font-weight: 800 !important; letter-spacing: -0.5px !important; color: #ffffff !important; background: linear-gradient(135deg, #00ffa3 0%, #00b8ff 100%) !important; -webkit-background-clip: text !important; -webkit-text-fill-color: transparent !important; }
        .cqc-setup-subtitle { font-size: 11px !important; font-weight: 600 !important; color: #626675 !important; margin-top: 4px !important; letter-spacing: 1px !important; text-transform: uppercase !important; }
        .cqc-step-indicator { position: absolute !important; right: 24px !important; top: 24px !important; font-size: 12px !important; font-weight: 700 !important; color: #626675 !important; }
        
        .cqc-setup-body { padding: 24px !important; display: flex !important; flex-direction: column !important; overflow-y: auto !important; position: relative !important; min-height: 340px !important; }
        .cqc-wizard-step { animation: step-slide-in 0.25s ease-out forwards !important; }
        @keyframes step-slide-in { from { opacity: 0; transform: translateX(10px); } to { opacity: 1; transform: translateX(0); } }
        
        .cqc-setup-warning { background: #1c1318 !important; border: 1px solid #ff464633 !important; border-radius: 8px !important; padding: 12px !important; display: flex !important; gap: 10px !important; font-size: 12px !important; line-height: 1.5 !important; color: #ff8585 !important; margin-bottom: 20px !important; }
        .cqc-setup-warning svg { flex-shrink: 0 !important; color: #ff4646 !important; }
        .cqc-setup-section-title { font-size: 15px !important; font-weight: 700 !important; color: #e2e8f0 !important; margin-bottom: 12px !important; }
        
        .cqc-preset-cards { display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 10px !important; }
        .cqc-preset-card { background: #16171b !important; border: 1px solid #262830 !important; border-radius: 10px !important; padding: 14px 10px !important; display: flex !important; flex-direction: column !important; align-items: center !important; text-align: center !important; cursor: pointer !important; transition: all 0.2s ease !important; }
        .cqc-preset-card:hover { background: #1c1d24 !important; border-color: #3b3e4a !important; }
        .cqc-preset-card.active { background: #131f1a !important; border-color: #00ffa3 !important; box-shadow: 0 0 12px rgba(0, 255, 163, 0.3) !important; }
        .cqc-preset-icon { font-size: 20px !important; margin-bottom: 6px !important; }
        .cqc-preset-name { font-size: 13px !important; font-weight: 700 !important; color: #ffffff !important; }
        .cqc-preset-desc { font-size: 10px !important; color: #718096 !important; margin-top: 4px !important; line-height: 1.3 !important; }
        .cqc-preset-card.active .cqc-preset-name { color: #00ffa3 !important; }
        
        .cqc-detail-options { display: flex !important; flex-direction: column !important; gap: 10px !important; }
        .cqc-detail-item { background: #16171b !important; border: 1px solid #202228 !important; border-radius: 10px !important; padding: 12px 14px !important; display: flex !important; align-items: center !important; justify-content: space-between !important; transition: all 0.2s ease !important; }
        .cqc-detail-item:hover { border-color: #2b2e37 !important; }
        .cqc-detail-info { display: flex !important; flex-direction: column !important; gap: 4px !important; flex: 1 !important; padding-right: 16px !important; }
        .cqc-detail-label { font-size: 13px !important; font-weight: 700 !important; color: #ffffff !important; }
        .cqc-detail-desc { font-size: 11px !important; color: #718096 !important; line-height: 1.4 !important; }
        
        .cqc-switch { width: 36px !important; height: 20px !important; background: #3b3e4a !important; border-radius: 20px !important; position: relative !important; cursor: pointer !important; transition: background 0.2s ease !important; flex-shrink: 0 !important; }
        .cqc-switch.active { background: #00ffa3 !important; }
        .cqc-switch-handle { width: 14px !important; height: 14px !important; background: #ffffff !important; border-radius: 50% !important; position: absolute !important; top: 3px !important; left: 3px !important; transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1) !important; }
        .cqc-switch.active .cqc-switch-handle { transform: translateX(16px) !important; }
        
        .cqc-setup-footer { padding: 16px 24px !important; border-top: 1px solid #1c1d22 !important; display: flex !important; justify-content: space-between !important; align-items: center !important; background: #111215 !important; }
        .cqc-btn { padding: 10px 16px !important; border-radius: 8px !important; font-size: 13px !important; font-weight: 700 !important; cursor: pointer !important; transition: all 0.2s ease !important; border: none !important; }
        .cqc-btn-text { background: transparent !important; color: #a0aec0 !important; }
        .cqc-btn-text:hover { color: #ffffff !important; background: #1c1d22 !important; }
        .cqc-btn-primary { background: #00ffa3 !important; color: #111215 !important; }
        .cqc-btn-primary:hover { background: #00e291 !important; }
        .cqc-btn-primary:disabled { background: #008253 !important; cursor: not-allowed !important; opacity: 0.7 !important; }
        .cqc-btn-outline { background: transparent !important; border: 1px solid #3b3e4a !important; color: #e2e8f0 !important; }
        .cqc-btn-outline:hover { background: #1c1d22 !important; border-color: #4b5563 !important; }
        .cqc-footer-right { display: flex !important; gap: 10px !important; }
      `}</style>

      <div className="cqc-setup-card">
        <div className="cqc-setup-header">
          <span className="cqc-setup-title">CHZZK ALL-IN-ONE</span>
          <span className="cqc-setup-subtitle">SETUP WIZARD</span>
          <div className="cqc-step-indicator">
            {currentStep === 0 ? 'Welcome' : `Step ${currentStep} of ${totalSteps}`}
          </div>
        </div>

        <div className="cqc-setup-body">
          {renderStepContent()}
        </div>

        <div className="cqc-setup-footer">
          {errorMsg && <div style={{ color: '#ff6b6b', fontSize: '12px', position: 'absolute', bottom: '60px', left: '24px' }}>{errorMsg}</div>}

          <div>
            {currentStep > 0 && (
              <button type="button" className="cqc-btn cqc-btn-text" onClick={handlePrev} disabled={isSaving}>
                이전
              </button>
            )}
          </div>

          <div className="cqc-footer-right">
            {currentStep < totalSteps ? (
              <>
                <button type="button" className="cqc-btn cqc-btn-outline" onClick={() => handleApply(true)} disabled={isSaving}>
                  건너뛰고 완료
                </button>
                <button type="button" className="cqc-btn cqc-btn-primary" onClick={handleNext} disabled={isSaving}>
                  {currentStep === 0 ? '세부 설정하기' : '다음'}
                </button>
              </>
            ) : (
              <button type="button" className="cqc-btn cqc-btn-primary" onClick={() => handleApply(false)} disabled={isSaving}>
                {isSaving ? '적용 중...' : '적용 완료 및 시작하기'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export class SetupWizard {
  static show() {
    if (document.querySelector('.cqc-setup-overlay')) return;

    const container = document.createElement('div');
    container.id = 'cqc-setup-wizard-root';
    document.body.appendChild(container);

    const root = createRoot(container);
    const handleClose = () => {
      root.unmount();
      container.remove();
    };

    root.render(<SetupWizardComponent onClose={handleClose} />);
  }
}
