import esbuild from 'esbuild';
import fs from 'fs/promises';
import { existsSync } from 'fs';
import path from 'path';

const isWatch = process.argv.includes('--watch');

interface BuildConfig {
    outDir: string;
    devDir: string;
    entries?: any[];
    staticAssets?: string[];
}

const BUILD_CONFIG: BuildConfig = {
    outDir: 'firefox-ext',
    devDir: 'firefox-ext-dev'
};

interface Manifest {
    background?: {
        service_worker?: string;
        scripts?: string[];
        type?: string;
    };
    content_scripts?: Array<{
        js?: string[];
        css?: string[];
    }>;
    web_accessible_resources?: Array<{
        resources?: string[];
    }>;
    action?: {
        default_popup?: string;
    };
    name?: string;
    browser_specific_settings?: any;
    [key: string]: any;
}

class FirefoxBuilder {
    private config: BuildConfig;
    private isWatch: boolean;
    private contexts: esbuild.BuildContext[];

    constructor(config: BuildConfig, watch: boolean = false) {
        this.config = config;
        this.isWatch = watch;
        this.contexts = [];
    }

    async ensureDir(dir: string): Promise<void> {
        if (!existsSync(dir)) {
            await fs.mkdir(dir, { recursive: true });
        }
    }

    async getManifestInfo(): Promise<{ entries: any[], staticAssets: string[] }> {
        if (!existsSync('manifest.json')) return { entries: [], staticAssets: [] };
        
        const content = await fs.readFile('manifest.json', 'utf8');
        const manifest: Manifest = JSON.parse(content);
        
        const entries: any[] = [];
        const staticAssets = new Set<string>(['icons']);
        
        if (manifest.background?.service_worker) {
            entries.push({ in: manifest.background.service_worker, out: manifest.background.service_worker });
        }
        
        if (manifest.content_scripts) {
            manifest.content_scripts.forEach(cs => {
                if (cs.js) {
                    cs.js.forEach(jsFile => {
                        if (jsFile.endsWith('.min.js')) {
                            staticAssets.add(jsFile);
                        } else {
                            entries.push({ in: jsFile, out: jsFile.replace(/\.ts$/, '.js') });
                        }
                    });
                }
                if (cs.css) {
                    cs.css.forEach(cssFile => staticAssets.add(cssFile));
                }
            });
        }
        
        if (manifest.web_accessible_resources) {
            manifest.web_accessible_resources.forEach(war => {
                if (war.resources) {
                    war.resources.forEach(res => {
                        if (res.endsWith('.js')) {
                            const tsFile = res.replace(/\.js$/, '.ts');
                            if (existsSync(tsFile)) {
                                const entry: any = { in: tsFile, out: res };
                                if (res === 'injected.js') entry.format = 'esm';
                                entries.push(entry);
                            } else if (existsSync(res)) {
                                const entry: any = { in: res, out: res };
                                if (res === 'injected.js') entry.format = 'esm';
                                entries.push(entry);
                            }
                        } else if (res.endsWith('.html') || res.endsWith('.css')) {
                            staticAssets.add(res);
                        }
                    });
                }
            });
        }
        
        if (manifest.action?.default_popup) {
            staticAssets.add(manifest.action.default_popup);
            const popupJs = manifest.action.default_popup.replace('.html', '.js');
            const popupTs = manifest.action.default_popup.replace('.html', '.ts');
            if (existsSync(popupTs)) {
                entries.push({ in: popupTs, out: popupJs });
            } else if (existsSync(popupJs)) {
                entries.push({ in: popupJs, out: popupJs });
            }
        }

        const uniqueEntries: any[] = [];
        const seenIn = new Set<string>();
        for (const entry of entries) {
            if (!seenIn.has(entry.in) && existsSync(entry.in)) {
                seenIn.add(entry.in);
                uniqueEntries.push(entry);
            }
        }

        return { 
            entries: uniqueEntries, 
            staticAssets: Array.from(staticAssets).filter(a => existsSync(a)) 
        };
    }

    async copy(src: string, dest: string): Promise<void> {
        if (!existsSync(src)) return;
        const stat = await fs.stat(src);
        if (stat.isDirectory()) {
            await this.ensureDir(dest);
            const children = await fs.readdir(src);
            await Promise.all(children.map(child => this.copy(path.join(src, child), path.join(dest, child))));
        } else {
            if (src.endsWith('.html')) {
                let content = await fs.readFile(src, 'utf8');
                content = content.replace(/src=(["'])([^"']*\.)tsx?\1/g, 'src=$1$2js$1');
                await fs.writeFile(dest, content);
            } else {
                await fs.copyFile(src, dest);
            }
        }
    }

    async transformManifest(targetDir: string = this.config.outDir, isDev: boolean = false): Promise<void> {
        if (!existsSync('manifest.json')) return;
        this.log('📄', `파이어폭스용 manifest.json 변환 중${isDev ? ' (Dev)' : ''}...`, 'dim');

        const content = await fs.readFile('manifest.json', 'utf8');
        const manifest: Manifest = JSON.parse(content);

        const firefoxManifest: Manifest = {
            ...manifest,
            name: isDev ? `${manifest.name} (FF Dev)` : `${manifest.name} (FF)`,
            background: {
                scripts: manifest.background?.service_worker ? [manifest.background.service_worker.replace('.ts', '.js')] : [],
                type: 'module'
            }
        };

        if (firefoxManifest.content_scripts) {
            firefoxManifest.content_scripts.forEach(cs => {
                if (cs.js) {
                    cs.js = cs.js.map(file => file.replace(/\.ts$/, '.js'));
                }
            });
        }

        if (firefoxManifest.web_accessible_resources) {
            firefoxManifest.web_accessible_resources.forEach(war => {
                if (war.resources) {
                    war.resources = war.resources.map(file => file.replace(/\.ts$/, '.js'));
                }
            });
        }

        const bundledContentCss = 'content.css';
        const bundledContentCssPath = path.join(this.config.outDir, bundledContentCss);
        
        if (existsSync(bundledContentCssPath)) {
            if (firefoxManifest.content_scripts && firefoxManifest.content_scripts.length > 0) {
                if (!firefoxManifest.content_scripts[0].css) {
                    firefoxManifest.content_scripts[0].css = [];
                }
                if (!firefoxManifest.content_scripts[0].css.includes(bundledContentCss)) {
                    firefoxManifest.content_scripts[0].css.push(bundledContentCss);
                    this.log('💉', `${bundledContentCss}를 manifest에 추가함`, 'cyan');
                }
            }
        }

        const bundledInjectedCss = 'injected.css';
        const bundledInjectedCssPath = path.join(this.config.outDir, bundledInjectedCss);
        if (existsSync(bundledInjectedCssPath)) {
            if (firefoxManifest.web_accessible_resources) {
                firefoxManifest.web_accessible_resources.forEach(war => {
                    if (war.resources && !war.resources.includes(bundledInjectedCss)) {
                        war.resources.push(bundledInjectedCss);
                        this.log('💉', `${bundledInjectedCss}를 web_accessible_resources에 추가함`, 'cyan');
                    }
                });
            }
        }

        const baseId = manifest.browser_specific_settings?.gecko?.id || "chzzk-quality-rework@ext";
        firefoxManifest.browser_specific_settings = {
            gecko: {
                id: isDev ? baseId.replace('@ext', '-dev@ext') : baseId,
                strict_min_version: "113.0",
                data_collection_permissions: manifest.browser_specific_settings?.gecko?.data_collection_permissions ?? {
                    marketing: false,
                    "product-improvement": false,
                    technical: false
                }
            }
        };

        if (firefoxManifest.background?.service_worker) {
            delete firefoxManifest.background.service_worker;
        }

        await this.ensureDir(targetDir);
        await fs.writeFile(
            path.join(targetDir, 'manifest.json'),
            JSON.stringify(firefoxManifest, null, 2)
        );
    }

    async syncAssets(targetDir: string = this.config.outDir): Promise<void> {
        this.log('📂', `자산을 ${targetDir}로 동기화 중...`, 'dim');

        if (!this.config.staticAssets) return;
        await Promise.all(this.config.staticAssets.map(asset => {
            if (existsSync(asset)) {
                return this.copy(asset, path.join(targetDir, asset));
            }
        }));
    }

    async transformCode(filePath: string): Promise<void> {
        if (!existsSync(filePath)) return;
        let content = await fs.readFile(filePath, 'utf8');

        const chromeRegex = /chrome\.(storage|runtime|tabs|declarativeNetRequest|windows|scripting|alarms|i18n|notifications|offscreen|permissions|action|idle|webRequest|contextMenus)/g;
        content = content.replace(chromeRegex, 'browser.$1');

        await fs.writeFile(filePath, content);
    }

    async syncToDev(): Promise<void> {
        if (!this.isWatch) return;
        this.log('🔄', 'firefox-ext-dev와 동기화 중...', 'magenta');

        await this.copy(this.config.outDir, this.config.devDir);
        await this.transformManifest(this.config.devDir, true);
    }

    getEsbuildOptions(entries: any[], format: 'iife' | 'esm' | 'cjs'): esbuild.BuildOptions {
        return {
            entryPoints: entries.map(e => e.in),
            bundle: true,
            minify: true,
            format: format,
            outdir: this.config.outDir,
            target: 'firefox109',
            define: { 'chrome': 'browser' },
            plugins: [{
                name: 'ff-transform',
                setup: (build) => {
                    build.onEnd(async (result) => {
                        if (result.errors.length === 0) {
                            await Promise.all(entries.map(async (entry) => {
                                // output file will have .js extension usually
                                const outPath = entry.out.replace(/\.ts$/, '.js');
                                await this.transformCode(path.join(this.config.outDir, outPath));
                                this.log('✅', `번들 완료: ${outPath}`, 'green');
                            }));
                            if (this.isWatch) await this.syncToDev();
                        }
                    });
                }
            }]
        };
    }

    async build(): Promise<void> {
        const { entries, staticAssets } = await this.getManifestInfo();
        this.config.entries = entries;
        this.config.staticAssets = staticAssets;

        await this.ensureDir(this.config.outDir);
        this.log('🚀', `파이어폭스 빌드 시작${this.isWatch ? ' (감시 모드)' : ''}...`, 'cyan');
        this.log('📦', `감지됨: 엔트리 ${entries.length}개, 자산 ${staticAssets.length}개`, 'magenta');

        const iifeEntries = entries.filter(e => !e.format || e.format === 'iife');
        const esmEntries = entries.filter(e => e.format === 'esm');

        const buildGroups = [
            { entries: iifeEntries, format: 'iife' as const },
            { entries: esmEntries, format: 'esm' as const }
        ].filter(g => g.entries.length > 0);

        for (const group of buildGroups) {
            const options = this.getEsbuildOptions(group.entries, group.format);
            if (this.isWatch) {
                const ctx = await esbuild.context(options);
                await ctx.watch();
                this.contexts.push(ctx);
            } else {
                await esbuild.build(options);
            }
        }

        await this.transformManifest();
        await this.syncAssets();
        
        if (this.isWatch) {
            await this.syncToDev();
            this.watchStaticAssets();
            this.log('✨', '파이어폭스 감시(Watch) 모드 활성화됨.', 'green');
        } else {
            this.log('✨', '파이어폭스 빌드 완료.', 'green');
            process.exit(0);
        }
    }

    log(emoji: string, message: string, color: string = 'reset'): void {
        const colors: Record<string, string> = {
            reset: "\x1b[0m",
            green: "\x1b[32m",
            cyan: "\x1b[36m",
            yellow: "\x1b[33m",
            red: "\x1b[31m",
            magenta: "\x1b[35m",
            dim: "\x1b[2m"
        };
        const time = new Date().toLocaleTimeString('ko-KR', { hour12: false });
        const colorCode = colors[color] || colors.reset;
        console.log(`${colors.dim}[${time}]${colors.reset} ${emoji} ${colorCode}${message}${colors.reset}`);
    }

    watchStaticAssets(): void {
        const watchFiles = [...(this.config.staticAssets || []), 'manifest.json'];
        let timeout: NodeJS.Timeout | null = null;

        const debouncedSync = () => {
            if (timeout) clearTimeout(timeout);
            timeout = setTimeout(async () => {
                this.log('📝', '정적 자산 동기화 실행 중...', 'yellow');
                await this.transformManifest();
                await this.syncAssets();
                await this.syncToDev();
            }, 200);
        };

        const { watch } = require('fs');
        watchFiles.forEach(file => {
            if (existsSync(file)) {
                require('fs').stat(file, (err: any, stat: any) => {
                    if (!err) {
                        watch(file, { recursive: stat.isDirectory() }, () => {
                            debouncedSync();
                        });
                    }
                });
            }
        });
    }
}

const builder = new FirefoxBuilder(BUILD_CONFIG, isWatch);
builder.build().catch((err: any) => {
    console.error('❌ Build failed:', err);
    process.exit(1);
});
