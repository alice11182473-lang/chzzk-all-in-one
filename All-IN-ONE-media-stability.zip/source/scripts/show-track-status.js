/**
 * Chzzk Player Track Status & Metrics Viewer
 * 
 * Copy and paste this script into Chrome/Firefox DevTools Console on Chzzk stream page.
 */
(function showChzzkTrackStatus() {
  const target = window.$0 || document.body;
  const pzpEl = target.closest?.('.pzp, [class*="pzp-pc"]') || document.querySelector('.pzp, [class*="pzp-pc"]');
  const videoEl = target.tagName === 'VIDEO' 
    ? target 
    : (pzpEl?.querySelector('video.webplayer-internal-video') || pzpEl?.querySelector('video') || document.querySelector('video.webplayer-internal-video') || document.querySelector('video'));
  
  if (!pzpEl && !videoEl) {
    console.error('[CQC Status] Chzzk player elements not found. Please select player element ($0) first.');
    return;
  }

  // 1. Extract React properties for Channel Info
  let channelName = '';
  let liveTitle = '';
  let category = '';
  const infoEl = document.querySelector('[class*="live_information_player__"], [class*="live_information_container_"]');
  if (infoEl) {
    const fiberKey = Object.keys(infoEl).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
    const fiber = fiberKey ? infoEl[fiberKey] : null;
    let curr = fiber;
    while (curr) {
      const props = curr.memoizedProps;
      if (props) {
        const c = props.channel || props.streamer || props.liveInfo || props;
        const live = props.liveInfo || props.live || {};
        if (c.channelName || c.nickname || props.channelName) {
          channelName = c.channelName || c.nickname || props.channelName;
          liveTitle = c.liveTitle || live.liveTitle || props.liveTitle || props.title || '';
          category = c.liveCategoryValue || live.liveCategoryValue || props.categoryName || '';
          break;
        }
      }
      curr = curr.return;
    }
  }

  // 2. Locate Vue component and core player instance
  let rootVue = pzpEl?.__vue__;
  if (!rootVue && videoEl) {
    let curr = videoEl.parentElement;
    while (curr && !rootVue) {
      if (curr.__vue__) {
        rootVue = curr.__vue__;
      }
      curr = curr.parentElement;
    }
  }

  function findCore(node, depth = 0) {
    if (!node || depth > 12) return null;
    if (typeof node.getVideoTracksList === 'function') return node;
    if (node.$children) {
      for (const child of node.$children) {
        const found = findCore(child, depth + 1);
        if (found) return found;
      }
    }
    return null;
  }

  const core = rootVue ? findCore(rootVue) : null;
  const store = rootVue?.$store?.state;
  const isLive = store?.onLive ?? /^\/live\//.test(location.pathname);

  // 3. Calculate latency and buffers
  let bufferLength = 0;
  let bufferedRanges = [];
  if (videoEl?.buffered?.length) {
    for (let i = 0; i < videoEl.buffered.length; i++) {
      const start = videoEl.buffered.start(i);
      const end = videoEl.buffered.end(i);
      bufferedRanges.push(`${start.toFixed(2)}s - ${end.toFixed(2)}s`);
      if (videoEl.currentTime >= start && videoEl.currentTime <= end) {
        bufferLength = end - videoEl.currentTime;
      }
    }
  }

  const seekableRanges = [];
  if (videoEl?.seekable?.length) {
    for (let i = 0; i < videoEl.seekable.length; i++) {
      seekableRanges.push(`${videoEl.seekable.start(i).toFixed(2)}s - ${videoEl.seekable.end(i).toFixed(2)}s`);
    }
  }

  const liveEdge = videoEl?.seekable?.length ? videoEl.seekable.end(videoEl.seekable.length - 1) : 0;
  const latency = liveEdge > 0 && videoEl ? (liveEdge - videoEl.currentTime) : -1;

  // 4. Detailed tracks info
  const rawTracks = (core && typeof core.getVideoTracksList === 'function'
    ? Object.values(core.getVideoTracksList() || {})
    : (Array.isArray(store?.videoTracks) ? store.videoTracks : Object.values(store?.videoTracks || {}))
  ).filter(t => t != null && typeof t.id === 'string' && t.id.trim() !== '');

  const tracksTable = rawTracks.map(t => ({
    'Track ID': t.id || '',
    'Quality': t.label || `${t.height}p`,
    'Width': t.width || 0,
    'Height': t.height || 0,
    'Bandwidth (Mbps)': t.bandwidth ? (t.bandwidth / 1000000).toFixed(2) : '0.00',
    'Selected': (t.selected || t._selected || (t.label && store?.quality === t.label)) ? '●' : '',
    'Low Latency': (t.id?.includes('lowlatency') || t.id?.includes('LL')) ? 'Yes' : 'No'
  }));

  // 5. Build summary
  const summary = {
    'Channel': channelName || 'Unknown',
    'Stream Title': liveTitle || 'Unknown',
    'Category': category || 'Unknown',
    'Stream Type': isLive ? 'Live Stream' : 'VOD / Clip',
    'Current Quality': store?.quality || 'Unknown',
    'Playback Rate': videoEl ? `${videoEl.playbackRate}x` : 'N/A',
    'Volume': videoEl ? `${Math.round(videoEl.volume * 100)}%` : 'N/A',
    'Muted': videoEl ? (videoEl.muted ? 'Yes' : 'No') : 'N/A',
    'Low Latency Mode': store?.lowLatencyEnabled ? 'Enabled' : 'Disabled',
    'Latency (Edge Diff)': latency >= 0 ? `${latency.toFixed(2)}s` : 'N/A',
    'Buffer Length': `${bufferLength.toFixed(2)}s`,
    'Buffered Segments': bufferedRanges.join(', ') || 'None',
    'Seekable Ranges': seekableRanges.join(', ') || 'None',
    'Current Time': videoEl ? `${videoEl.currentTime.toFixed(2)}s` : 'N/A',
    'Live Edge Time': liveEdge > 0 ? `${liveEdge.toFixed(2)}s` : 'N/A',
    'Dropped Frames': videoEl?.getVideoPlaybackQuality ? videoEl.getVideoPlaybackQuality().droppedVideoFrames : 'N/A',
    'Total Frames': videoEl?.getVideoPlaybackQuality ? videoEl.getVideoPlaybackQuality().totalVideoFrames : 'N/A'
  };

  // 6. Pretty Print output
  console.group('%c[CHZZK] Current Player Track & Status Report', 'color: #00ffa3; font-weight: bold; font-size: 14px; background-color: #111; padding: 4px 8px; border-radius: 4px;');
  console.log('%cStream Info:', 'color: #00d084; font-weight: bold;');
  console.table({
    'Channel': summary.Channel,
    'Stream Title': summary['Stream Title'],
    'Category': summary.Category,
    'Stream Type': summary['Stream Type']
  });

  console.log('%cPlayback Metrics:', 'color: #00d084; font-weight: bold;');
  console.table({
    'Current Quality': summary['Current Quality'],
    'Latency (Edge Diff)': summary['Latency (Edge Diff)'],
    'Buffer Length': summary['Buffer Length'],
    'Playback Rate': summary['Playback Rate'],
    'Volume': summary.Volume,
    'Muted': summary.Muted,
    'Dropped Frames': summary['Dropped Frames'],
    'Total Frames': summary['Total Frames']
  });

  console.log('%cVideo Tracks:', 'color: #00d084; font-weight: bold;');
  if (tracksTable.length > 0) {
    console.table(tracksTable);
  } else {
    console.log('No track data found in store.');
  }

  console.log('%cDetailed Time / Buffering Ranges:', 'color: #00d084; font-weight: bold;');
  console.log('Current Time:', summary['Current Time']);
  console.log('Live Edge Time:', summary['Live Edge Time']);
  console.log('Buffered Ranges:', bufferedRanges);
  console.log('Seekable Ranges:', seekableRanges);
  console.groupEnd();
})();
