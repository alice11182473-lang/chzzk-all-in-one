import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

interface PackageJson {
    version: string;
    [key: string]: any;
}

const packageJsonPath = path.resolve('package.json');
let pkg: PackageJson;

try {
    pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
} catch (e) {
    console.error('[Error] Failed to read package.json');
    process.exit(1);
}

const version = pkg.version;
const distPath = path.resolve('dist');
const pemPath = path.resolve('dist.pem');
const finalCrx = path.resolve('release', `ALLINONE-v${version}-chrome.crx`);

// Find Chrome Executable
const chromePaths = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe')
];

let chromePath = '';
for (const p of chromePaths) {
    if (fs.existsSync(p)) {
        chromePath = p;
        break;
    }
}

if (!chromePath) {
    console.error('[Error] Google Chrome executable not found. Please install Chrome.');
    process.exit(1);
}

if (!fs.existsSync(distPath)) {
    console.error('[Error] dist folder not found. Run "npm run build" first.');
    process.exit(1);
}

if (!fs.existsSync('release')) {
    fs.mkdirSync('release');
}

if (!fs.existsSync(pemPath)) {
    console.error('[Error] dist.pem private key not found in root directory.');
    process.exit(1);
}

console.log(`[Package:CRX] Packing extension with version v${version}...`);

try {
    // Chrome creates "dist.crx" in the parent folder of dist (which is root)
    const tempCrx = path.resolve('dist.crx');
    if (fs.existsSync(tempCrx)) {
        fs.unlinkSync(tempCrx);
    }
    if (fs.existsSync(finalCrx)) {
        fs.unlinkSync(finalCrx);
    }

    const cmd = `"${chromePath}" --pack-extension="${distPath}" --pack-extension-key="${pemPath}"`;
    execSync(cmd, { stdio: 'inherit' });

    if (fs.existsSync(tempCrx)) {
        fs.renameSync(tempCrx, finalCrx);
        console.log(`[Success] CRX created and signed: ${finalCrx}`);
    } else {
        console.error('[Error] Packaging finished but chrome-ext.crx was not found.');
        process.exit(1);
    }
} catch (err: any) {
    console.error('[Error] Failed to sign and package CRX:', err.message);
    process.exit(1);
}
