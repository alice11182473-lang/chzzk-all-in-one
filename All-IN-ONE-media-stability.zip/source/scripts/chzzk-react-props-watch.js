/*
 * CHZZK __reactProps watcher
 *
 * Paste into Chrome DevTools Console on chzzk.naver.com.
 *
 * This watches exactly the kind of data you get from:
 *   $0.__reactProps$xxxx
 *
 * No MutationObserver. It reads React props attached to selected CHZZK DOM
 * nodes and diffs the React element props tree.
 *
 * Usage:
 *   ChzzkPropsWatch.inspect($0)
 *   ChzzkPropsWatch.watch($0, 'chat-aside')
 *   ChzzkPropsWatch.watchSelector('aside#aside-chatting', 'chat-aside')
 *   ChzzkPropsWatch.watchChat()
 *   ChzzkPropsWatch.watchSelector('[class*="live_information_"]', 'live-info')
 *   ChzzkPropsWatch.start()
 *   ChzzkPropsWatch.export()
 *   ChzzkPropsWatch.stop()
 */
(function installChzzkPropsWatch() {
  if (window.ChzzkPropsWatch?.stop) window.ChzzkPropsWatch.stop();

  const config = {
    intervalMs: 500,
    maxDepth: 8,
    maxKeys: 120,
    maxRecords: 1000,
    verbose: true,
    printInternalValues: true,
    chatItemSelector: '[class*="chatting_list_item__"], [class*="chatting_message_item__"], [class*="live_chatting_list_item__"]',
    chatContainerSelector: 'aside#aside-chatting, aside[class*="live_chatting_container"], [class*="live_chatting_list_container"], [class*="live_chatting_list_wrapper"]',
    internalKeys: [
      'chatMessage',
      'message',
      'content',
      'profile',
      'nickname',
      'userIdHash',
      'displayBadgeList',
      'extras',
      'emojis',
      'blind',
      'manager',
      'subscription',
      'donation',
      'chatButtonHandler',
      'chatRuleButtonHandler',
      'cleanBotButtonHandler',
      'hideChatHandler',
      'closeAllMenus',
    ],
  };

  const state = {
    timer: 0,
    targets: [],
    lastById: new Map(),
    records: [],
    errors: [],
  };

  const now = () => new Date().toISOString();

  const push = (record) => {
    state.records.push({ at: now(), url: location.href, ...record });
    const overflow = state.records.length - config.maxRecords;
    if (overflow > 0) state.records.splice(0, overflow);
  };

  const isCqc = (el) => {
    if (!el) return false;

    // Body/layout can have CQC state classes, but CHZZK nodes below it are still
    // valid targets. Only reject nodes that are inside UI roots we created.
    const ownedRoot = el.closest?.(
      [
        '.cqc-playback-bar-react-root',
        '.cqc-volume-indicator-react-root',
        '.cqc-folder-header',
        '.cqc-fpop',
        '.cqc-toast',
        '#cqc-root',
      ].join(',')
    );
    if (ownedRoot) return true;

    const className = typeof el.className === 'string' ? el.className : '';
    const id = typeof el.id === 'string' ? el.id : '';
    return /^cqc-| cqc-/.test(className) || /^cqc-/.test(id);
  };

  const describeElement = (el) => ({
    tag: el?.tagName?.toLowerCase() || '',
    id: el?.id || '',
    className: typeof el?.className === 'string' ? el.className : '',
    text: (el?.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 120),
  });

  const reactTypeName = (type) => {
    if (typeof type === 'string') return type;
    if (typeof type === 'function') return type.displayName || type.name || 'anonymous';
    if (typeof type === 'symbol') return String(type);
    if (type && typeof type === 'object') {
      if (type.displayName || type.name) return type.displayName || type.name;
      if (type.type) return `memo(${reactTypeName(type.type)})`;
      return String(type.$$typeof || 'object');
    }
    return type == null ? null : String(type);
  };

  const getReactPropsKey = (el) => {
    if (!el) return null;
    for (const key in el) {
      if (key.startsWith('__reactProps$') || key.startsWith('__reactEvents$')) return key;
    }
    return null;
  };

  const getReactFiberKey = (el) => {
    if (!el) return null;
    for (const key in el) {
      if (key.startsWith('__reactFiber$') || key.startsWith('__reactInternalInstance$')) return key;
    }
    return null;
  };

  const readReactProps = (el) => {
    const propsKey = getReactPropsKey(el);
    if (propsKey) return { key: propsKey, props: el[propsKey] };

    const fiberKey = getReactFiberKey(el);
    const fiber = fiberKey ? el[fiberKey] : null;
    return {
      key: fiberKey ? `${fiberKey}.memoizedProps` : null,
      props: fiber?.memoizedProps || fiber?.return?.memoizedProps || null,
    };
  };

  const clone = (value, depth = 0, seen = new WeakSet()) => {
    if (value == null) return value;
    const t = typeof value;
    if (t === 'string' || t === 'number' || t === 'boolean') return value;
    if (t === 'bigint') return `${value}n`;
    if (t === 'symbol') return String(value);
    if (t === 'function') return `[Function ${value.name || 'anonymous'}]`;
    if (value instanceof Element) return describeElement(value);
    if (depth >= config.maxDepth) return `[MaxDepth ${Array.isArray(value) ? 'Array' : value.constructor?.name || 'Object'}]`;
    if (seen.has(value)) return '[Circular]';
    seen.add(value);

    if (Array.isArray(value)) {
      return value.slice(0, config.maxKeys).map((item) => clone(item, depth + 1, seen));
    }

    const isReactElement =
      value.$$typeof &&
      value.props !== undefined &&
      (value.type !== undefined || value.key !== undefined);

    if (isReactElement) {
      return {
        $$typeof: String(value.$$typeof),
        key: value.key ?? null,
        ref: value.ref ? '[ref]' : null,
        type: reactTypeName(value.type),
        name: value.props?.name,
        silent: value.props?.silent,
        props: clone(value.props, depth + 1, seen),
      };
    }

    const out = {};
    for (const key of Object.keys(value).slice(0, config.maxKeys)) {
      if (key === '_owner' || key === '_store' || key === 'stateNode') continue;
      try {
        out[key] = clone(value[key], depth + 1, seen);
      } catch (err) {
        out[key] = `[ReadError ${err?.message || err}]`;
      }
    }
    if (Object.keys(value).length > config.maxKeys) {
      out.__truncatedKeys = Object.keys(value).length - config.maxKeys;
    }
    return out;
  };

  const findInternalValues = (value, basePath = '$', out = [], seen = new WeakSet()) => {
    if (out.length >= 200 || value == null) return out;

    if (typeof value !== 'object') {
      return out;
    }
    if (seen.has(value)) return out;
    seen.add(value);

    const isLikelyChatMessage =
      value.profile &&
      (value.content !== undefined || value.message !== undefined || value.msg !== undefined || value.extras !== undefined);

    if (isLikelyChatMessage) {
      out.push({
        kind: 'chatMessage',
        path: basePath,
        value: clone(value),
        summary: summarizeChatMessage(value),
      });
    }

    for (const key of Object.keys(value).slice(0, config.maxKeys)) {
      if (key === '_owner' || key === '_store' || key === 'stateNode') continue;
      let child;
      try {
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (descriptor && typeof descriptor.get === 'function' && !('value' in descriptor)) {
          out.push({
            kind: 'getter',
            key,
            path: `${basePath}.${key}`,
            value: `[Getter ${key}]`,
          });
          continue;
        }
        child = value[key];
      } catch (err) {
        out.push({
          kind: 'read-error',
          key,
          path: `${basePath}.${key}`,
          value: `[ReadError ${err?.message || err}]`,
        });
        continue;
      }
      const matched = config.internalKeys.some((needle) => key.toLowerCase().includes(needle.toLowerCase()));
      const path = `${basePath}.${key}`;
      if (matched) {
        out.push({
          kind: 'key',
          key,
          path,
          value: clone(child),
        });
      }
      if (child && typeof child === 'object') {
        findInternalValues(child, path, out, seen);
      }
      if (out.length >= 200) break;
    }
    return out;
  };

  const summarizeChatMessage = (msg) => {
    const profile = msg?.profile || {};
    const content =
      typeof msg?.content === 'string'
        ? msg.content
        : typeof msg?.message === 'string'
          ? msg.message
          : typeof msg?.msg === 'string'
            ? msg.msg
            : '';
    return {
      nickname: profile.nickname || profile.nickName || profile.name || '',
      userIdHash: profile.userIdHash || profile.userId || '',
      role: profile.userRoleCode || profile.role || '',
      content,
      time: msg?.time || msg?.createdTime || msg?.messageTime || '',
      badges: Array.isArray(msg?.displayBadgeList) ? msg.displayBadgeList.map((badge) => badge?.type || badge?.name || badge).slice(0, 12) : [],
      extras: clone(msg?.extras, 0),
    };
  };

  const stable = (value) => {
    const seen = new WeakSet();
    const sort = (input) => {
      if (!input || typeof input !== 'object') return input;
      if (seen.has(input)) return '[Circular]';
      seen.add(input);
      if (Array.isArray(input)) return input.map(sort);
      const out = {};
      for (const key of Object.keys(input).sort()) out[key] = sort(input[key]);
      return out;
    };
    return JSON.stringify(sort(value));
  };

  const diff = (a, b, path = '', out = []) => {
    if (stable(a) === stable(b)) return out;
    if (!a || !b || typeof a !== 'object' || typeof b !== 'object') {
      out.push({ path: path || '$', before: a, after: b });
      return out;
    }
    const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
    for (const key of keys) {
      const p = path ? `${path}.${key}` : key;
      if (!(key in a)) out.push({ path: p, before: undefined, after: b[key] });
      else if (!(key in b)) out.push({ path: p, before: a[key], after: undefined });
      else diff(a[key], b[key], p, out);
      if (out.length >= 300) break;
    }
    return out;
  };

  const snapshotElement = (el) => {
    const { key, props } = readReactProps(el);
    const clonedProps = clone(props);
    return {
      element: describeElement(el),
      reactPropsKey: key,
      props: clonedProps,
      internalValues: findInternalValues(props),
    };
  };

  const inspect = (el = window.$0) => {
    if (!el || isCqc(el)) {
      console.warn('[ChzzkPropsWatch] target not found or CQC element', el);
      return null;
    }
    const result = snapshotElement(el);
    console.groupCollapsed('%c[ChzzkPropsWatch] inspect __reactProps', 'color:#2f8cff;font-weight:bold');
    console.log(result);
    console.groupEnd();
    return result;
  };

  const watch = (el = window.$0, label = '') => {
    if (!el || isCqc(el)) {
      console.warn('[ChzzkPropsWatch] cannot watch target', el);
      return null;
    }
    const id = label || `${describeElement(el).tag}#${describeElement(el).id || state.targets.length}`;
    const existing = state.targets.find((target) => target.id === id);
    if (existing) existing.el = el;
    else state.targets.push({ id, el, selector: null });
    const snap = snapshotElement(el);
    state.lastById.set(id, snap);
    console.log('[ChzzkPropsWatch] watching', id, snap);
    return snap;
  };

  const watchSelector = (selector, label = selector) => {
    const el = document.querySelector(selector);
    if (!el) {
      console.warn('[ChzzkPropsWatch] selector not found', selector);
      return null;
    }
    const snap = watch(el, label);
    const target = state.targets.find((item) => item.id === label);
    if (target) target.selector = selector;
    return snap;
  };

  const retargetSelectors = () => {
    for (const target of state.targets) {
      if (target.selector && (!target.el || !document.contains(target.el))) {
        const next = document.querySelector(target.selector);
        if (next && !isCqc(next)) target.el = next;
      }
    }
  };

  const tick = () => {
    retargetSelectors();
    for (const target of state.targets) {
      try {
        if (!target.el || !document.contains(target.el) || isCqc(target.el)) continue;
        const next = snapshotElement(target.el);
        const prev = state.lastById.get(target.id);
        const changes = prev ? diff(prev.props, next.props) : [];
        if (changes.length) {
          const record = {
            type: '__reactProps-change',
            id: target.id,
            element: next.element,
            reactPropsKey: next.reactPropsKey,
            changes,
            internalValues: next.internalValues,
            props: next.props,
          };
          push(record);
          if (config.verbose) {
            console.groupCollapsed(
              `%c[ChzzkPropsWatch] ${target.id} __reactProps changed (${changes.length})`,
              'color:#00d084;font-weight:bold'
            );
            console.table(changes.slice(0, 80).map((item) => ({
              path: item.path,
              before: typeof item.before === 'object' ? JSON.stringify(item.before).slice(0, 220) : item.before,
              after: typeof item.after === 'object' ? JSON.stringify(item.after).slice(0, 220) : item.after,
            })));
            console.log('raw changes', changes);
            if (config.printInternalValues) {
              console.log('internal values', next.internalValues);
              const chatValues = next.internalValues.filter((item) => item.kind === 'chatMessage');
              if (chatValues.length) {
                console.table(chatValues.map((item) => item.summary));
              }
            }
            console.log('raw __reactProps', next.props);
            console.groupEnd();
          }
        }
        state.lastById.set(target.id, next);
      } catch (err) {
        state.errors.push({ at: now(), id: target.id, message: err?.message || String(err), stack: err?.stack });
      }
    }
  };

  const start = () => {
    stop(false);
    tick();
    state.timer = window.setInterval(tick, config.intervalMs);
    console.log('[ChzzkPropsWatch] started', {
      intervalMs: config.intervalMs,
      targets: state.targets.map((target) => target.id),
    });
  };

  const stop = (log = true) => {
    if (state.timer) {
      window.clearInterval(state.timer);
      state.timer = 0;
    }
    if (log) console.log('[ChzzkPropsWatch] stopped');
  };

  const find = (needle) => {
    const q = String(needle).toLowerCase();
    const hits = [];
    const walk = (value, path, seen = new WeakSet()) => {
      if (hits.length >= 300 || value == null) return;
      if (typeof value !== 'object') {
        if (String(value).toLowerCase().includes(q)) hits.push({ path, value });
        return;
      }
      if (seen.has(value)) return;
      seen.add(value);
      for (const key of Object.keys(value)) {
        const p = path ? `${path}.${key}` : key;
        let child;
        try {
          const descriptor = Object.getOwnPropertyDescriptor(value, key);
          if (descriptor && typeof descriptor.get === 'function' && !('value' in descriptor)) {
            if (key.toLowerCase().includes(q)) hits.push({ path: p, value: `[Getter ${key}]` });
            continue;
          }
          child = value[key];
        } catch (err) {
          if (key.toLowerCase().includes(q)) hits.push({ path: p, value: `[ReadError ${err?.message || err}]` });
          continue;
        }
        if (key.toLowerCase().includes(q)) hits.push({ path: p, value: child });
        walk(child, p, seen);
      }
    };
    for (const record of state.records.slice(-100)) walk(record, 'record');
    for (const [id, snap] of state.lastById) walk(snap.props, `latest.${id}.props`);
    console.groupCollapsed(`%c[ChzzkPropsWatch] find "${needle}" (${hits.length})`, 'color:#2f8cff;font-weight:bold');
    console.log(hits);
    console.groupEnd();
    return hits;
  };

  const watchChat = (selector = config.chatItemSelector, labelPrefix = 'chat-item') => {
    const container = document.querySelector(config.chatContainerSelector) || document;
    const items = Array.from(container.querySelectorAll(selector)).filter((el) => !isCqc(el));
    if (!items.length) {
      console.warn('[ChzzkPropsWatch] chat items not found', { container, selector });
      return [];
    }

    const watched = items.slice(-20).map((el, index) => {
      const idFromText = (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 30);
      const id = `${labelPrefix}-${index}-${idFromText || 'empty'}`;
      watch(el, id);
      return id;
    });
    console.log('[ChzzkPropsWatch] watching chat items', watched);
    return watched;
  };

  const dumpChat = (selector = config.chatItemSelector) => {
    const container = document.querySelector(config.chatContainerSelector) || document;
    const rows = Array.from(container.querySelectorAll(selector))
      .filter((el) => !isCqc(el))
      .slice(-30)
      .map((el, index) => {
        const snap = snapshotElement(el);
        const chat = snap.internalValues.find((item) => item.kind === 'chatMessage');
        return {
          index,
          element: snap.element,
          reactPropsKey: snap.reactPropsKey,
          chat: chat?.summary || null,
          internalValues: snap.internalValues,
          props: snap.props,
        };
      });
    console.groupCollapsed(`%c[ChzzkPropsWatch] dumpChat (${rows.length})`, 'color:#2f8cff;font-weight:bold');
    console.table(rows.map((row) => ({ index: row.index, ...row.chat })));
    console.log(rows);
    console.groupEnd();
    return rows;
  };

  const exportData = () => {
    const data = {
      version: 1,
      exportedAt: now(),
      url: location.href,
      config,
      targets: state.targets.map(({ id, selector, el }) => ({ id, selector, element: describeElement(el) })),
      latest: Object.fromEntries(state.lastById.entries()),
      records: state.records,
      errors: state.errors,
    };
    console.log('[ChzzkPropsWatch] export data', data);
    try {
      copy(JSON.stringify(data, null, 2));
      console.log('[ChzzkPropsWatch] JSON copied to clipboard');
    } catch (_) {
      console.log('[ChzzkPropsWatch] copy unavailable. Use returned object.');
    }
    return data;
  };

  window.ChzzkPropsWatch = {
    config,
    state,
    inspect,
    watch,
    watchSelector,
    watchChat,
    dumpChat,
    start,
    stop,
    find,
    export: exportData,
  };

  console.log('[ChzzkPropsWatch] ready. Try: ChzzkPropsWatch.inspect($0); ChzzkPropsWatch.watch($0, "selected"); ChzzkPropsWatch.start();');
})();
