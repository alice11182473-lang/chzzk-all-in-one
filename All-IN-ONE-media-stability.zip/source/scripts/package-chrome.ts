import fs from 'fs';
import path from 'path';
// @ts-ignore
import bestzip from 'bestzip';

/**
 * @description 크롬 확장 프로그램 패키징 스크립트
 * dist 폴더의 내용물을 zip 파일로 압축합니다.
 */

interface PackageJson {
    version: string;
    [key: string]: any;
}

const packageJsonPath = path.resolve('package.json');
let pkg: PackageJson;

try {
    pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
} catch (e) {
    console.error('[Error] Failed to read or parse package.json');
    process.exit(1);
}

const version = pkg.version;
const destFileName = `ALLINONE-v${version}-chrome.zip`;
const dest = path.resolve('release', destFileName);

console.log(`[Package] Creating Chrome extension package v${version}...`);

if (!fs.existsSync('dist')) {
    console.error('[Error] dist folder not found. Run "npm run build" first.');
    process.exit(1);
}

if (!fs.existsSync('release')) {
    fs.mkdirSync('release');
}

// Remove existing zip if it exists
if (fs.existsSync(dest)) {
    try {
        fs.unlinkSync(dest);
    } catch (e) {
        console.warn(`[Warning] Failed to delete existing zip file: ${dest}`);
    }
}

bestzip({
    source: '*',
    destination: dest,
    cwd: path.resolve('dist')
}).then(() => {
    console.log(`[Success] Package created: ${dest}`);
}).catch((err: any) => {
    console.error('[Error] Packaging failed:', err);
    process.exit(1);
});
