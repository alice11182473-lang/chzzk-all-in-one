import fs from 'fs';
import path from 'path';

// Define the interface for the manifest to ensure type safety
interface Manifest {
    name: string;
    browser_specific_settings?: {
        gecko?: {
            id: string;
            [key: string]: any;
        };
        [key: string]: any;
    };
    [key: string]: any;
}

const srcDir = path.resolve('firefox-ext');
const destDir = path.resolve('firefox-ext-dev');
const manifestPath = path.join(destDir, 'manifest.json');

console.log('Clearing old dev build...');
if (fs.existsSync(destDir)) {
    fs.rmSync(destDir, { recursive: true, force: true });
}

console.log('Copying firefox-ext to firefox-ext-dev...');
// Using modern fs.cpSync instead of manual recursive copy
if (fs.existsSync(srcDir)) {
    fs.cpSync(srcDir, destDir, { recursive: true });
} else {
    console.error(`❌ Source directory not found: ${srcDir}`);
    process.exit(1);
}

console.log('Modifying manifest.json for Dev version...');
if (fs.existsSync(manifestPath)) {
    try {
        const manifestStr = fs.readFileSync(manifestPath, 'utf8');
        const manifest = JSON.parse(manifestStr) as Manifest;

        // Add (Dev) suffix to the extension name
        if (!manifest.name.includes('(Dev)')) {
            manifest.name = `${manifest.name} (Dev)`;
        }

        // Assign a specific ID for the dev version to prevent conflicts
        if (manifest.browser_specific_settings?.gecko?.id) {
            const geckoId = manifest.browser_specific_settings.gecko.id;
            if (!geckoId.includes('-dev')) {
                manifest.browser_specific_settings.gecko.id = geckoId.replace('@ext', '-dev@ext');
            }
        }

        fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 4) + '\n');
        console.log('✅ Updated firefox-ext-dev/manifest.json');
    } catch (err) {
        console.error('❌ Failed to parse or modify manifest.json:', err);
        process.exit(1);
    }
} else {
    console.error('❌ Failed to find manifest.json inside firefox-ext-dev!');
    process.exit(1);
}

console.log('Firefox Developer Edition setup complete.');
