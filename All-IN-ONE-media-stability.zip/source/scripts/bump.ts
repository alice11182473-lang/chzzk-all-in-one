import fs from 'fs';
import path from 'path';

interface PackageJson {
    version: string;
    scripts?: Record<string, string>;
    [key: string]: any;
}

interface Manifest {
    version: string;
    [key: string]: any;
}

const packageJsonPath = path.resolve('package.json');
const manifestChromePath = path.resolve('manifest.json');
const manifestFirefoxPath = path.resolve('firefox-ext/manifest.json');

// Read package.json
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8')) as PackageJson;
const oldVersion = packageJson.version;

// Bump patch version safely
const parts = oldVersion.split('.');
if (parts.length < 3) {
    console.error('❌ Invalid version format in package.json. Expected x.y.z');
    process.exit(1);
}
parts[parts.length - 1] = (parseInt(parts[parts.length - 1], 10) + 1).toString();
const newVersion = parts.join('.');

console.log(`[DRY RUN] Bumping version from ${oldVersion} to ${newVersion} ...`);

// Update package.json version and scripts
packageJson.version = newVersion;
if (packageJson.scripts && packageJson.scripts['package:chrome']) {
    packageJson.scripts['package:chrome'] = packageJson.scripts['package:chrome'].replace(oldVersion, newVersion);
}
// fs.writeFileSync(packageJsonPath, JSON.stringify(packageJson, null, 2) + '\n');
console.log('✅ (Skipped) Updated package.json');

// Update Chrome manifest
if (fs.existsSync(manifestChromePath)) {
    const manifestChrome = JSON.parse(fs.readFileSync(manifestChromePath, 'utf8')) as Manifest;
    manifestChrome.version = newVersion;
    // fs.writeFileSync(manifestChromePath, JSON.stringify(manifestChrome, null, 2) + '\n');
    console.log('✅ (Skipped) Updated manifest.json');
}

// Update Firefox manifest
if (fs.existsSync(manifestFirefoxPath)) {
    const manifestFirefox = JSON.parse(fs.readFileSync(manifestFirefoxPath, 'utf8')) as Manifest;
    manifestFirefox.version = newVersion;
    // fs.writeFileSync(manifestFirefoxPath, JSON.stringify(manifestFirefox, null, 4) + '\n');
    console.log('✅ (Skipped) Updated firefox-ext/manifest.json');
}
