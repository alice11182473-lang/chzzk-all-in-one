# 치지직 채팅(.aside-chatting) 리액트 데이터 추적 가이드 (초안)

이 가이드는 치지직 생방송 페이지의 채팅 영역(`.aside-chatting`)에서 리액트 내부 데이터(Fiber)를 추출하여 메시지 상세 정보 및 유저 메타데이터를 확인하는 방법을 설명합니다.

## 1. 대상 DOM 요소 및 셀렉터

채팅 영역은 다음과 같은 구조를 가집니다.

- **채팅 리스트 컨테이너**: `[class*="live_chatting_list_wrapper__"]`
- **개별 메시지 아이템 (div)**: `[class*="live_chatting_list_item__"]`
- **메시지 내용 요소**: `[class*="live_chatting_message_text__"]`

## 2. React Fiber 및 Props 구조

개별 메시지 요소의 Fiber 노드에서 `memoizedProps` (또는 `chatMessage` 객체)를 통해 데이터를 추출합니다.

```javascript
// 예시: 메시지 요소에서 데이터 추출
const messageEl = document.querySelector('[class*="live_chatting_list_item__"]');
const fiber = messageEl[Object.keys(messageEl).find(k => k.startsWith('__reactFiber$'))];
const chatData = fiber?.memoizedProps?.chatMessage || fiber?.return?.memoizedProps?.chatMessage;
```

## 3. 주요 속성 매핑 (chatMessage)

| 경로 | 설명 | 예시 |
| :--- | :--- | :--- |
| `profile.nickname` | 유저 닉네임 | `치지직유저` |
| `profile.userIdHash` | 유저 고유 해시 ID | `a1b2c3d4...` |
| `content` | 채팅 메시지 내용 | `안녕하세요!` |
| `time` | 전송 시각 (Timestamp) | `1710831234567` |
| `displayBadgeList` | 배지 목록 (배열) | `[{type:"SUBSCRIPTION", ...}]` |
| `extras.osType` | 접속 기기 정보 | `PC`, `AOS`, `IOS` |
| `extras.emojis` | 사용된 이모티콘 정보 | `{...}` |

### 상세 등급 확인 방법

- **구독자**: `displayBadgeList` 내에 `type: "SUBSCRIPTION"` 항목이 존재하거나, `profile.streamingProperty.subscription` 객체가 존재함.
- **후원자**: `displayBadgeList` 내에 `type: "DONATION"` 배지가 포함됨.
- **매니저/스트리머**: `profile.userRoleCode` 또는 배지 타입을 통해 확인 가능.

## 4. React Key 구조

채팅 메시지의 `key`는 중복을 방지하기 위해 다음과 같은 조합으로 생성됩니다.

- 형식: `{userIdHash}_{timestamp}_{uuid}`
- 예시: `a1b2c3d4..._1710831234567_f9a8`

## 5. 실시간 채팅 모니터링 코드 (콘솔용)

브라우저 콘솔에서 실행하여 유입되는 채팅의 내부 데이터를 출력할 수 있습니다.

```javascript
function monitorChat() {
    const chatList = document.querySelector('[class*="live_chatting_list_wrapper__"]');
    if (!chatList) return console.error('채팅 리스트를 찾을 수 없습니다.');

    const observer = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
            mutation.addedNodes.forEach(node => {
                if (node.nodeType !== 1) return;
                
                const fiberKey = Object.keys(node).find(k => k.startsWith('__reactFiber$'));
                const fiber = node[fiberKey];
                const msg = fiber?.memoizedProps?.chatMessage || fiber?.return?.memoizedProps?.chatMessage;

                if (msg) {
                    console.log(`[%c${msg.profile.nickname}%c] ${msg.content}`, 
                        'color: #00ffa3; font-weight: bold', 'color: inherit', {
                        userId: msg.profile.userIdHash,
                        badges: msg.displayBadgeList,
                        isSub: !!msg.profile.streamingProperty?.subscription,
                        time: new Date(msg.time).toLocaleTimeString()
                    });
                }
            });
        });
    });

    observer.observe(chatList, { childList: true });
    console.log('채팅 모니터링 시작...');
}

monitorChat();
```
