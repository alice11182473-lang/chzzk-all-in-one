// @ts-nocheck
/** @ts-check */
import { log as cqcLog, SELECTORS, REGEX, triggerReact } from './dom-utils';
import { updatePowerStatusUI } from './powerclick';

const log = (...a) => cqcLog('AdPopup', ...a);

/**
 * 광고 차단 감지 팝업을 React 핸들러로 dismiss합니다.
 * @param {Element} popup - 팝업 컨테이너 엘리먼트
 * @returns {boolean} dismiss 성공 여부
 */
export const dismissAdPopup = (popup) => {
    const buttons = Array.from(popup.querySelectorAll('button'));
    for (const btn of buttons) {
        const handled = triggerReact(
            /** @type {HTMLElement} */(btn),
            ['confirmHandler', 'onClick', 'onClickHandler', 'onConfirm', 'onClose', 'onDismiss']
        );
        if (handled) {
            log('[광고 팝업] React dismiss 성공 (버튼)');
            return true;
        }
    }

    const handled = triggerReact(
        /** @type {HTMLElement} */(popup),
        ['onClick', 'onClose', 'onDismiss', 'onConfirm']
    );
    if (handled) {
        log('[광고 팝업] React dismiss 성공 (컨테이너)');
        return true;
    }

    return false;
};

/**
 * 광고 차단 감지 팝업을 즉시 은폐하고 제거합니다.
 * @param {Element} popup - 팝업 컨테이너 엘리먼트
 * @param {any} settings
 * @param {Function} post
 */
export const handleAdPopupImmediate = (popup, settings, post) => {
    // 이미 처리 중인 팝업이 반복 처리되는 것을 방지
    if (/** @type {HTMLElement} */(popup).dataset.cqcDismissing) return;

    const text = popup.textContent ?? '';
    const isAdBlock = REGEX.AD_BLOCK.test(text);
    const isCheatKeyText = REGEX.CHEAT_KEY_MSG ? REGEX.CHEAT_KEY_MSG.test(text) : false;

    // 치트키 팝업/툴팁 여부 확인 (기존 클래스 및 사용자 제보 신규 클래스 포함)
    const isCheatKey = popup.classList.contains('popup_cheat_key_container__9cQgJ') ||
        !!popup.querySelector('.popup_cheat_key_button_close__poCih') ||
        popup.matches?.(SELECTORS.CHEAT_KEY_TOOLTIP_CONTAINER) ||
        !!popup.querySelector(SELECTORS.CHEAT_KEY_TOOLTIP_CLOSE_BTN) ||
        isCheatKeyText;

    // 옵션이 명시적으로 false가 아닌 한 기본적으로 true로 취급
    const autoAdSkip = settings?.autoAdSkip !== false;
    const layoutCleanEnabled = settings?.layoutCleanEnabled !== false;

    // 광고 스킵 또는 레이아웃 정리가 활성화된 경우에만 진행
    const shouldHandle = isAdBlock ? autoAdSkip : (isCheatKey && (autoAdSkip || layoutCleanEnabled));

    if (!shouldHandle) return;
    if (!isAdBlock && !isCheatKey) return;

    // 처리 시작 마커 설정
    /** @type {HTMLElement} */(popup).dataset.cqcDismissing = 'true';

    log(`[팝업 감지] ${isAdBlock ? '광고 차단' : '치트키'} 팝업 즉각 제거 시도`);

    /** @type {HTMLElement} */(popup).style.setProperty('display', 'none', 'important');
    /** @type {HTMLElement} */(popup).style.setProperty('visibility', 'hidden', 'important');
    /** @type {HTMLElement} */(popup).style.setProperty('opacity', '0', 'important');
    /** @type {HTMLElement} */(popup).style.setProperty('pointer-events', 'none', 'important');

    const tryDismiss = (attempt = 0) => {
        if (dismissAdPopup(popup)) {
            log(`[팝업 제거] 성공 (시도 #${attempt})`);
            if (isAdBlock) post('AD_POPUP_DISMISSED', null);
        } else if (attempt < 50) {
            setTimeout(() => tryDismiss(attempt + 1), 10);
        }
    };
    tryDismiss(0);
};

let toolbarDebounce = null;
const handleToolbarUpdate = (settings) => {
    if (toolbarDebounce) clearTimeout(toolbarDebounce);
    toolbarDebounce = setTimeout(() => {
        try {
            if (settings?.powerClickEnabled && typeof updatePowerStatusUI === 'function') updatePowerStatusUI(settings);
        } catch (e) { }
    }, 100);
};

/**
 * 광고 팝업 감시 시작
 * @param {any} settings
 * @param {Function} post
 */
export const initAdPopupWatch = (settings, post) => {
    // 1. 고속 MutationObserver (선택자 기반 우선 필터링)
    const observer = new MutationObserver((mutations) => {
        let shouldUpdateToolbar = false;
        const potentialPopups = new Set();

        for (const m of mutations) {
            for (const node of m.addedNodes) {
                if (node.nodeType !== 1) continue;
                const el = /** @type {HTMLElement} */(node);

                if (!shouldUpdateToolbar && (el.matches?.(SELECTORS.TOOLBAR_BOX) || el.querySelector?.(SELECTORS.TOOLBAR_BOX))) {
                    shouldUpdateToolbar = true;
                }

                // 텍스트(textContent) 추출 및 정규식 검사는 비용이 크므로 핸들러로 위임
                // 여기서는 가벼운 셀렉터 매칭만 수행하여 메모리/CPU 사용률 최소화
                if (el.matches?.(SELECTORS.AD_POPUP) || el.matches?.(SELECTORS.CHEAT_KEY_POPUP) || el.matches?.(SELECTORS.CHEAT_KEY_TOOLTIP_CONTAINER)) {
                    potentialPopups.add(el);
                } else if (el.querySelector) {
                    const inners = el.querySelectorAll(`${SELECTORS.AD_POPUP}, ${SELECTORS.CHEAT_KEY_POPUP}, ${SELECTORS.CHEAT_KEY_TOOLTIP_CONTAINER}`);
                    inners.forEach(inner => potentialPopups.add(inner));
                }
            }
        }

        if (shouldUpdateToolbar) handleToolbarUpdate(settings);
        potentialPopups.forEach(p => handleAdPopupImmediate(p, settings, post));
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // 2. 초기 1회 실행
    retryDismissAdPopup(settings, post);

    // 3. 놓친 팝업을 잡기 위한 백업 감시자 (주기적 폴링)
    // MutationObserver가 놓치는 경우를 대비하여 1.5초마다 가볍게 체크
    setInterval(() => {
        retryDismissAdPopup(settings, post);
    }, 1500);

    log('[팝업 감시] 고속 감시 및 백업 감시(Interval) 시작됨');
};

/**
 * 광고 팝업 제거 재시도
 * @param {any} settings
 * @param {Function} post
 */
export const retryDismissAdPopup = (settings, post) => {
    document.querySelectorAll(SELECTORS.AD_POPUP).forEach(p => handleAdPopupImmediate(p, settings, post));
    document.querySelectorAll(SELECTORS.CHEAT_KEY_POPUP).forEach(p => handleAdPopupImmediate(p, settings, post));
    document.querySelectorAll(SELECTORS.CHEAT_KEY_TOOLTIP_CONTAINER).forEach(p => handleAdPopupImmediate(p, settings, post));
};
