﻿using assembly PresentationFramework
using assembly PresentationCore
using assembly WindowsBase

[CmdletBinding()]
param(
    [string]$ZipPath
)

# 1. 어셈블리 로드
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
[System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression") | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null

$InstallDir = "$env:LOCALAPPDATA\chzzk-quality-ext"
$TempIconPath = "$env:TEMP\chzzk_icon128.png"

# UI 스크립트 스코프 변수 선언
$Form = $null
$LogoImage = $null
$StatusText = $null
$ProgressBar = $null
$ActionButton = $null
$InstallPanel = $null
$GuidePanel = $null
$GuideTitle = $null

# 2. 기능 함수 정의
function Write-Log([string]$msg) {
    # GUI 로그박스 제거로 인해 콘솔 디버그용으로만 출력
    Write-Host $msg
}

function Update-Progress([int]$value, [string]$status) {
    $ProgressBar.Value = $value
    $StatusText.Text = $status
    Write-Log "➜ $status"
}

function Set-ButtonState([string]$content, [string]$background, [string]$foreground) {
    $ActionButton.Content = $content
    $converter = New-Object System.Windows.Media.BrushConverter
    $ActionButton.Background = $converter.ConvertFromString($background)
    $ActionButton.Foreground = $converter.ConvertFromString($foreground)
    $ActionButton.IsEnabled = $true
}

# 파일 이름에서 버전 추출 및 버전에 의한 정렬 도우미 함수
function Get-VersionFromFileName([string]$fileName) {
    if ($fileName -match 'v?(\d+\.\d+\.\d+(?:\.\d+)?)') {
        try {
            return [System.Version]$Matches[1]
        } catch {}
    }
    return [System.Version]"0.0.0"
}

function Import-ZipIcon([string]$zipPath) {
    if (Test-Path $TempIconPath) { Remove-Item $TempIconPath -Force -ErrorAction SilentlyContinue }
    if ($zipPath -and (Test-Path $zipPath)) {
        try {
            $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
            $entry = $zip.Entries | Where-Object { $_.FullName -eq "icons/icon128.png" }
            if ($entry) {
                $entry.ExtractToFile($TempIconPath, $true)
            }
            $zip.Dispose()
        } catch {}
    }
    
    if (Test-Path $TempIconPath) {
        try {
            $uri = New-Object System.Uri $TempIconPath
            $bitmap = New-Object System.Windows.Media.Imaging.BitmapImage
            $bitmap.BeginInit()
            $bitmap.UriSource = $uri
            $bitmap.CacheOption = "OnLoad"
            $bitmap.EndInit()
            $LogoImage.Source = $bitmap
        } catch {}
    }
}

function Initialize-UI([string]$defaultZip) {
    [xml]$xamlText = @"
    <Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
            xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
            Title="치지직 올인원 설치기" Height="480" Width="500" 
            WindowStartupLocation="CenterScreen" ResizeMode="NoResize"
            Background="#141517" Foreground="White">
        <Grid Margin="20">
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <!-- 상단 제목 -->
            <TextBlock Grid.Row="0" Text="치지직 올인원" 
                       FontSize="18" FontWeight="Bold" Foreground="#00FFA3"
                       HorizontalAlignment="Center" Margin="0,0,0,15"/>

            <!-- 중앙 내용 전환 영역 -->
            <Grid Grid.Row="1" VerticalAlignment="Center">
                <!-- [1] 설치 진행 화면 -->
                <StackPanel Name="InstallPanel" Visibility="Visible">
                    <Image Name="LogoImage" Width="80" Height="80" 
                           Stretch="Uniform" HorizontalAlignment="Center" Margin="0,0,0,20"/>
                    <TextBlock Name="StatusText" Text="설치 준비 완료." 
                               FontSize="13" HorizontalAlignment="Center" Margin="0,0,0,10"/>
                    <ProgressBar Name="ProgressBar" Height="12" 
                                 Background="#25262B" Foreground="#00FFA3" BorderThickness="0" 
                                 Margin="0,0,0,15" Minimum="0" Maximum="100" Value="0"/>
                </StackPanel>

                <!-- [2] 설치 완료 가이드 화면 -->
                <StackPanel Name="GuidePanel" Visibility="Collapsed">
                    <Border Background="#1C1D20" CornerRadius="6" Padding="20">
                        <StackPanel>
                            <!-- 녹색 체크 마크 SVG 벡터 패스 -->
                            <Path Data="M 12 2 C 6.48 2 2 6.48 2 12 C 2 17.52 6.48 22 12 22 C 17.52 22 22 17.52 22 12 C 22 6.48 17.52 2 12 2 Z M 10 17 L 5 12 L 6.41 10.59 L 10 14.17 L 17.59 6.58 L 19 8 L 10 17 Z"
                                  Fill="#00FFA3" Height="48" Width="48" Stretch="Uniform" HorizontalAlignment="Center" Margin="0,0,0,15"/>

                            <TextBlock Name="GuideTitle" Text="설치가 완료되었습니다!" 
                                       FontSize="16" FontWeight="Bold" Foreground="#00FFA3" 
                                       HorizontalAlignment="Center" Margin="0,0,0,20"/>
                            
                            <TextBlock Text="[1] 처음 설치하는 경우" FontWeight="Bold" Foreground="White" FontSize="13" Margin="0,0,0,8"/>
                            <TextBlock Text="• 브라우저 주소창 입력: chrome://extensions (웨일/엣지도 동일)" Foreground="#CCCCCC" FontSize="12" Margin="10,0,0,5"/>
                            <TextBlock Text="• 우측 상단의 [개발자 모드] 토글 스위치를 활성화합니다." Foreground="#CCCCCC" FontSize="12" Margin="10,0,0,5"/>
                            <TextBlock Text="• 좌측 상단 [압축해제된 확장 프로그램 로드] 버튼을 누릅니다." Foreground="#CCCCCC" FontSize="12" Margin="10,0,0,5"/>
                            <TextBlock Text="• 폴더창 주소란에 붙여넣기(Ctrl+V) 한 뒤 [폴더 선택]을 완료합니다." Foreground="#CCCCCC" FontSize="12" Margin="10,0,0,20"/>

                            <TextBlock Text="[2] 업데이트하는 경우" FontWeight="Bold" Foreground="White" FontSize="13" Margin="0,0,0,8"/>
                            <TextBlock Text="• 최신 ZIP 파일을 설치기 폴더에 먼저 넣고 실행해야 적용됩니다." Foreground="#CCCCCC" FontSize="12" Margin="10,0,0,5"/>
                            <TextBlock Text="• 브라우저 확장 프로그램 페이지에서 카드의 [새로고침]을 클릭합니다." Foreground="#CCCCCC" FontSize="12" Margin="10,0,0,0"/>
                        </StackPanel>
                    </Border>
                </StackPanel>
            </Grid>

            <!-- 하단 버튼 -->
            <Button Name="ActionButton" Grid.Row="2" Content="설치 시작" Height="40"
                    Background="#00FFA3" Foreground="Black" FontWeight="Bold" FontSize="12"
                    BorderThickness="0" Cursor="Hand">
                <Button.Resources>
                    <Style TargetType="Border">
                        <Setter Property="CornerRadius" Value="4"/>
                    </Style>
                </Button.Resources>
            </Button>
        </Grid>
    </Window>
"@
    $reader = New-Object System.Xml.XmlNodeReader $xamlText
    
    # 지연 참조 형식 로드
    $xamlReaderType = [Type]"System.Windows.Markup.XamlReader"
    $script:Form = $xamlReaderType::Load($reader)

    # 컨트롤 바인딩
    $script:LogoImage = $Form.FindName("LogoImage")
    $script:StatusText = $Form.FindName("StatusText")
    $script:ProgressBar = $Form.FindName("ProgressBar")
    $script:ActionButton = $Form.FindName("ActionButton")
    $script:InstallPanel = $Form.FindName("InstallPanel")
    $script:GuidePanel = $Form.FindName("GuidePanel")
    $script:GuideTitle = $Form.FindName("GuideTitle")

    # 이벤트 연결
    $ActionButton.Add_Click({ On-ActionClicked })
    $Form.Add_SourceInitialized({ Start-InstallProcess -zipPath $defaultZip })
    $Form.Add_Closed({ Cleanup-Resources })
}

function Start-InstallProcess([string]$zipPath) {
    $ActionButton.IsEnabled = $false
    Write-Log "[시작] 치지직 퀄리티 확장 프로그램 설치를 시작합니다."

    $targetZip = $null
    if ($zipPath) {
        $targetZip = $zipPath
    } else {
        $zips = Get-ChildItem -Path $PSScriptRoot -Filter "*.zip"
        if ($zips.Count -gt 0) {
            # 파일명 버전 기준 정렬하여 최신 버전 선택
            $sortedZips = $zips | Sort-Object @{Expression={Get-VersionFromFileName $_.Name}} -Descending
            $targetZip = $sortedZips[0].FullName
        }
    }

    # 1단계: ZIP 파일 유효성 검증
    Update-Progress 10 "ZIP 압축 파일 탐색 중..."
    if (-not $targetZip -or -not (Test-Path $targetZip)) {
        Update-Progress 10 "오류: 폴더 내에 ZIP 파일이 존재하지 않습니다."
        Write-Log "[실패] ZIP 파일이 존재하지 않거나 경로가 잘못되었습니다."
        Set-ButtonState "오류 발생 (종료)" "Red" "White"
        return
    }
    Write-Log "사용할 ZIP: $(Split-Path $targetZip -Leaf)"

    Import-ZipIcon $targetZip

    # 2단계: 이전 폴더 제거
    Update-Progress 40 "이전 설치 파일 정리 중..."
    if (Test-Path $InstallDir) {
        try {
            Remove-Item -Path "$InstallDir\*" -Recurse -Force -ErrorAction Stop
            Write-Log "이전 파일 정리 성공."
        } catch {
            Update-Progress 40 "오류: 폴더가 브라우저에 의해 잠겨 있습니다."
            Write-Log "[오류] 폴더 점유 중. 브라우저(크롬, 웨일, 엣지 등)를 종료하고 다시 시도하세요."
            Set-ButtonState "오류 발생 (종료)" "Red" "White"
            return
        }
    } else {
        New-Item -Path $InstallDir -ItemType Directory -Force | Out-Null
        Write-Log "설치 디렉토리 생성 완료."
    }

    # 3단계: ZIP 압축 해제
    Update-Progress 70 "고정 설치 경로에 압축 해제 중..."
    try {
        Expand-Archive -Path $targetZip -DestinationPath $InstallDir -Force -ErrorAction Stop
        Write-Log "압축 해제 성공 -> $InstallDir"
    } catch {
        Update-Progress 70 "오류: 압축 해제에 실패했습니다."
        Write-Log "[실패] ZIP 파일 압축 해제 중 오류 발생."
        Set-ButtonState "오류 발생 (종료)" "Red" "White"
        return
    }

    # 4단계: 경로 복사
    Update-Progress 90 "설치 경로 클립보드 복사 중..."
    try {
        $InstallDir | Set-Clipboard
        Write-Log "설치 경로 클립보드 복사 완료."
    } catch {
        Write-Log "[경고] 클립보드 복사 실패."
    }

    # 설치된 manifest.json에서 실시간 버전 파싱
    $InstalledVersion = "알 수 없음"
    $ManifestPath = "$InstallDir\manifest.json"
    if (Test-Path $ManifestPath) {
        try {
            $manifest = Get-Content $ManifestPath -Encoding UTF8 -Raw | ConvertFrom-Json
            if ($manifest.version) {
                $InstalledVersion = "v" + $manifest.version
            }
        } catch {}
    }

    # 최종 완료 안내 및 뷰 전환
    Update-Progress 100 "설치가 성공적으로 완료되었습니다!"
    $GuideTitle.Text = "설치가 완료되었습니다! ($InstalledVersion)"
    
    # 패널 교체
    $InstallPanel.Visibility = "Collapsed"
    $GuidePanel.Visibility = "Visible"

    Set-ButtonState "완료 (탐색기 열고 종료)" "LimeGreen" "Black"
}

function On-ActionClicked {
    if ($ActionButton.Content -eq "설치 시작") {
        Start-InstallProcess -zipPath $ZipPath
    } elseif ($ActionButton.Content -eq "완료 (탐색기 열고 종료)") {
        explorer.exe $InstallDir
        $Form.Close()
    } else {
        $Form.Close()
    }
}

function Cleanup-Resources {
    if ($LogoImage -and $LogoImage.Source) {
        $LogoImage.Source = $null
    }
    if (Test-Path $TempIconPath) {
        Remove-Item $TempIconPath -Force -ErrorAction SilentlyContinue
    }
}

# 3. 메인 구동
try {
    Initialize-UI -defaultZip $ZipPath
    $Form.ShowDialog() | Out-Null
}
catch {
    Write-Host "❌ [오류 발생] 설치 실행 중 치명적인 에러가 발생했습니다:" -ForegroundColor Red
    Write-Host $_.ScriptStackTrace -ForegroundColor Yellow
    Write-Error $_
    
    # 에러 발생 시에만 창이 안 꺼지고 사용자 입력 대기
    if ($Host.Name -eq "ConsoleHost") {
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Gray
        Read-Host "오류가 발생하여 대기 중입니다. 엔터(Enter) 키를 누르면 종료됩니다"
    }
}
