export { initPlaybackBar, initPlayerUIHooks } from './src/modules/player/playback-bar/index.tsx';
