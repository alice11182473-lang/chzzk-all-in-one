// @ts-nocheck
/**
 * @fileoverview IndexedDB 스키마 버전 및 스토어 이름 공용 상수
 * DB 버전을 변경할 때 이 파일만 수정하면 모든 모듈에 반영됩니다.
 */

/** @type {string} */
export const DB_NAME = 'cqc-thumb-db';

/** @type {number} */
export const DB_VERSION = 7;

/** @type {Readonly<Record<string, string>>} */
export const STORE_NAMES = Object.freeze({
    THUMBNAILS: 'thumbnails',
    SETTINGS: 'settings',
    POWER_LOGS: 'power_logs',
    BLINDED: 'blinded_messages',
    COLLECTOR_CHATS: 'collector_chats',
});
