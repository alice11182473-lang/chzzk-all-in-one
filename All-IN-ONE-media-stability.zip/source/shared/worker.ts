// @ts-nocheck
/**
 * @fileoverview 단일 코어 블로킹을 우회하기 위한 백그라운드 워커 (Blob 기반 범용 모듈)
 *
 * Canvas ImageData(ArrayBuffer) 또는 ImageBitmap을 Base64(WebP)로 변환하는 작업을 오프로딩합니다.
 * Vite, esbuild 등 번들러 환경에 구애받지 않고 사용 가능하도록 Blob Worker 패턴을 적용하였습니다.
 */

const workerCode = `
self.onmessage = async (e) => {
    const { id, type, payload } = e.data;

    try {
        if (type === 'ENCODE_IMAGE_BITMAP') {
            const { bmp, time } = payload;
            const canvas = new OffscreenCanvas(bmp.width, bmp.height);
            const ctx = canvas.getContext('2d');
            if (!ctx) throw new Error('No 2d context for OffscreenCanvas');

            ctx.drawImage(bmp, 0, 0);
            bmp.close();

            const blob = await canvas.convertToBlob({ type: 'image/webp', quality: 0.4 });

            const reader = new FileReader();
            reader.onload = () => {
                self.postMessage({ id, status: 'success', dataUrl: reader.result, time });
            };
            reader.readAsDataURL(blob);

        } else if (type === 'ENCODE_IMAGE') {
            const { width, height, buffer, time } = payload;

            const canvas = new OffscreenCanvas(width, height);
            const ctx = canvas.getContext('2d');
            if (!ctx) throw new Error('No 2d context for OffscreenCanvas');

            const imageData = new ImageData(new Uint8ClampedArray(buffer), width, height);
            ctx.putImageData(imageData, 0, 0);

            const blob = await canvas.convertToBlob({ type: 'image/webp', quality: 0.4 });

            const reader = new FileReader();
            reader.onload = () => {
                self.postMessage({ id, status: 'success', dataUrl: reader.result, time });
            };
            reader.readAsDataURL(blob);
        }
    } catch (err) {
        self.postMessage({ id, status: 'error', error: err?.toString() });
    }
};
`;

let workerBlobUrl = '';

/**
 * ImageEncoder 워커 인스턴스를 생성하여 반환합니다.
 * @returns {Worker}
 */
export function createImageEncoderWorker() {
    if (!workerBlobUrl) {
        const blob = new Blob([workerCode], { type: 'application/javascript' });
        workerBlobUrl = URL.createObjectURL(blob);
    }
    return new Worker(workerBlobUrl);
}
