// @ts-nocheck
/**
 * @fileoverview 치지직 올인원 (Beta) — IndexedDB 래퍼
 *
 * 썸네일 데이터 메모리 누수를 방지하기 위해 IndexedDB에 Base64 이미지를 저장합니다.
 */
import { DB_NAME, DB_VERSION, STORE_NAMES } from './db-constants';

/**
 * 데이터베이스 관리를 위한 Singleton 클래스입니다.
 */
class DatabaseManager {
    /** @type {DatabaseManager | null} */
    static #instance = null;

    #dbName = DB_NAME;
    #dbVersion = DB_VERSION;
    #stores = { ...STORE_NAMES };
    #maxThumbCount = 300;
    #sessionId = Math.random().toString(36).substring(2, 15);

    /** @type {IDBDatabase | null} */
    #db = null;
    #isInit = false;
    /** @type {Promise<void> | null} */
    #initPromise = null;

    constructor() {
        if (DatabaseManager.#instance) {
            return DatabaseManager.#instance;
        }
        DatabaseManager.#instance = this;
    }

    /**
     * 클래스의 단일 인스턴스를 반환합니다.
     * @returns {DatabaseManager}
     */
    static getInstance() {
        if (!DatabaseManager.#instance) {
            DatabaseManager.#instance = new DatabaseManager();
        }
        return DatabaseManager.#instance;
    }

    /**
     * DB를 초기화합니다.
     * @param {boolean} [isRetry=false] - VersionError 발생 시 재시도 여부
     * @returns {Promise<void>}
     */
    async init(isRetry = false) {
        if (this.#isInit) return;
        if (this.#initPromise && !isRetry) return this.#initPromise;

        this.#initPromise = new Promise((resolve) => {
            try {
                const req = indexedDB.open(this.#dbName, this.#dbVersion);

                req.onupgradeneeded = (e) => {
                    // @ts-ignore
                    const database = e.target.result;
                    const stores = this.#stores;

                    if (e.oldVersion < 5) {
                        if (database.objectStoreNames.contains(stores.THUMBNAILS)) {
                            database.deleteObjectStore(stores.THUMBNAILS);
                        }
                    }

                    if (!database.objectStoreNames.contains(stores.THUMBNAILS)) {
                        const store = database.createObjectStore(stores.THUMBNAILS, { keyPath: 'id' });
                        store.createIndex('sessionId', 'sessionId', { unique: false });
                        store.createIndex('timestamp', 'timestamp', { unique: false });
                    }
                    if (!database.objectStoreNames.contains(stores.SETTINGS)) {
                        database.createObjectStore(stores.SETTINGS, { keyPath: 'key' });
                    }
                    if (!database.objectStoreNames.contains(stores.POWER_LOGS)) {
                        database.createObjectStore(stores.POWER_LOGS, { keyPath: 'id', autoIncrement: true });
                    }
                    // v6: 블라인드 메시지 원본 저장소
                    if (!database.objectStoreNames.contains(stores.BLINDED)) {
                        const bs = database.createObjectStore(stores.BLINDED, { keyPath: 'msgKey' });
                        bs.createIndex('timestamp', 'timestamp', { unique: false });
                    }
                    // v7: 모아보기 채팅 저장소
                    if (!database.objectStoreNames.contains(stores.COLLECTOR_CHATS)) {
                        const cs = database.createObjectStore(stores.COLLECTOR_CHATS, { keyPath: 'msgId' });
                        cs.createIndex('channelId', 'channelId', { unique: false });
                        cs.createIndex('time', 'time', { unique: false });
                    }
                };

                req.onsuccess = (e) => {
                    // @ts-ignore
                    const database = e.target.result;
                    this.#db = database;
                    this.#isInit = true;

                    // 다른 탭 등에서 DB 버전 변경(업그레이드) 시 연결 종료
                    if (database) {
                        database.onversionchange = () => {
                            database.close();
                            this.#db = null;
                            this.#isInit = false;
                            this.#initPromise = null;
                        };
                    }

                    resolve();
                };

                req.onblocked = (e) => {
                    console.warn('[CQC:DB] IndexedDB 초기화 블락됨 (다른 탭에서 기존 연결이 닫히지 않음)', e);
                };

                req.onerror = (e) => {
                    // @ts-ignore
                    const error = e.target.error;
                    console.error('[CQC:DB] IndexedDB 초기화 실패:', error?.name, error?.message, error);

                    this.#initPromise = null;

                    // VersionError인 경우 로컬 DB 버전 불일치가 의심되므로 삭제 후 재시도
                    if (error?.name === 'VersionError' && !isRetry) {
                        console.warn('[CQC:DB] VersionError 감지. 기존 데이터베이스 삭제 후 재시도합니다.');
                        try {
                            const deleteReq = indexedDB.deleteDatabase(this.#dbName);
                            deleteReq.onsuccess = () => {
                                console.log('[CQC:DB] 기존 데이터베이스 삭제 완료. 재초기화를 수행합니다.');
                                resolve(this.init(true));
                            };
                            deleteReq.onerror = (delErr) => {
                                console.error('[CQC:DB] 기존 데이터베이스 삭제 실패:', delErr);
                                resolve();
                            };
                            deleteReq.onblocked = () => {
                                console.warn('[CQC:DB] 기존 데이터베이스 삭제 블락됨. 다른 탭의 연결이 끊어질 때까지 대기합니다.');
                            };
                        } catch (delEx) {
                            console.error('[CQC:DB] 데이터베이스 삭제 중 예외 발생:', delEx);
                            resolve();
                        }
                    } else {
                        resolve();
                    }
                };
            } catch (ex) {
                console.error('[CQC:DB] IndexedDB open 예외 발생:', ex);
                this.#initPromise = null;
                resolve();
            }
        });

        return this.#initPromise;
    }

    /**
     * 내부적으로 DB 인스턴스를 확보합니다.
     * @returns {Promise<IDBDatabase | null>}
     */
    async #getDB() {
        if (!this.#db) await this.init();
        return this.#db;
    }

    /**
     * 썸네일을 IndexedDB에 저장합니다.
     * @param {number} time - 영상 시간 (초)
     * @param {string} dataUrl - 이미지 Base64 URL
     * @returns {Promise<void>}
     */
    async saveThumbnail(time, dataUrl) {
        const db = await this.#getDB();
        if (!db) return;
        const storeName = this.#stores.THUMBNAILS;
        const sessionId = this.#sessionId;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);

            store.put({ id: `${sessionId}_${time}`, sessionId, time, dataUrl, timestamp: Date.now() });

            const sessionIdx = store.index('sessionId');
            const countReq = sessionIdx.count(sessionId);
            countReq.onsuccess = () => {
                const count = countReq.result;
                if (count > this.#maxThumbCount) {
                    let toDelete = count - this.#maxThumbCount;
                    const cursorReq = sessionIdx.openCursor(sessionId);
                    cursorReq.onsuccess = (e) => {
                        // @ts-ignore
                        const cursor = e.target.result;
                        if (cursor && toDelete > 0) {
                            cursor.delete();
                            toDelete--;
                            cursor.continue();
                        }
                    };
                }
            };

            const globalCountReq = store.count();
            globalCountReq.onsuccess = () => {
                const globalCount = globalCountReq.result;
                const maxGlobalCount = this.#maxThumbCount * 5;
                if (globalCount > maxGlobalCount) {
                    let toDelete = globalCount - maxGlobalCount;
                    const timeIdx = store.index('timestamp');
                    const cursorReq = timeIdx.openCursor();
                    cursorReq.onsuccess = (e) => {
                        // @ts-ignore
                        const cursor = e.target.result;
                        if (cursor && toDelete > 0) {
                            cursor.delete();
                            toDelete--;
                            cursor.continue();
                        }
                    };
                }
            };

            tx.oncomplete = () => resolve();
        });
    }

    /**
     * 주어진 시간에 가장 가까운 썸네일을 가져옵니다.
     * @param {number} targetTime 탐색할 시간 (초 단위)
     * @returns {Promise<string | null>} 찾은 썸네일 DataURL 또는 실패시 null
     */
    async getClosestThumbnail(targetTime) {
        const db = await this.#getDB();
        if (!db) return null;
        const storeName = this.#stores.THUMBNAILS;
        const sessionId = this.#sessionId;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const sessionIdx = store.index('sessionId');

            /** @type {string | null} */
            let closestUrl = null;
            let minDiff = Infinity;

            const req = sessionIdx.openCursor(sessionId);
            req.onsuccess = (e) => {
                // @ts-ignore
                const cursor = e.target.result;
                if (cursor) {
                    const diff = Math.abs(cursor.value.time - targetTime);
                    if (diff < minDiff) {
                        minDiff = diff;
                        closestUrl = cursor.value.dataUrl;
                    }
                    cursor.continue();
                } else {
                    if (minDiff < 5) resolve(closestUrl);
                    else resolve(null);
                }
            };
            req.onerror = () => resolve(null);
        });
    }

    /**
     * 썸네일 데이터를 모두 삭제합니다.
     * @returns {Promise<void>}
     */
    async clearThumbnails() {
        const db = await this.#getDB();
        if (!db) return;
        const storeName = this.#stores.THUMBNAILS;
        const sessionId = this.#sessionId;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const sessionIdx = store.index('sessionId');

            const req = sessionIdx.openCursor(sessionId);
            req.onsuccess = (e) => {
                // @ts-ignore
                const cursor = e.target.result;
                if (cursor) {
                    cursor.delete();
                    cursor.continue();
                }
            };
            tx.oncomplete = () => resolve();
        });
    }

    /**
     * Key-Value 데이터를 읽어옵니다.
     * @param {string} key
     * @returns {Promise<any>}
     */
    async getKV(key) {
        const db = await this.#getDB();
        if (!db) return undefined;
        const storeName = this.#stores.SETTINGS;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readonly');
            const req = tx.objectStore(storeName).get(key);
            req.onsuccess = () => resolve(req.result?.value);
            req.onerror = () => resolve(undefined);
        });
    }

    /**
     * Key-Value 데이터를 저장합니다.
     * @param {string} key
     * @param {any} value
     * @returns {Promise<void>}
     */
    async setKV(key, value) {
        const db = await this.#getDB();
        if (!db) return;
        const storeName = this.#stores.SETTINGS;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readwrite');
            tx.objectStore(storeName).put({ key, value });
            tx.oncomplete = () => resolve();
        });
    }

    /**
     * 통나무 수집 기록을 저장합니다.
     * @param {object} data
     * @returns {Promise<void>}
     */
    async addPowerLog(data) {
        const db = await this.#getDB();
        if (!db) return;
        const storeName = this.#stores.POWER_LOGS;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            store.add({
                ...data,
                // @ts-ignore
                timestamp: data.timestamp || Date.now()
            });
            tx.oncomplete = () => resolve();
        });
    }

    /**
     * 최근 수집 기록들을 가져옵니다.
     * @param {number} limit 
     * @returns {Promise<any[]>}
     */
    async getPowerLogs(limit = 20) {
        const db = await this.#getDB();
        if (!db) return [];
        const storeName = this.#stores.POWER_LOGS;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            /** @type {any[]} */
            const logs = [];
            const req = store.openCursor(null, 'prev');
            req.onsuccess = (e) => {
                // @ts-ignore
                const cursor = e.target.result;
                if (cursor && logs.length < limit) {
                    logs.push(cursor.value);
                    cursor.continue();
                } else {
                    resolve(logs);
                }
            };
        });
    }
    /**
     * 모든 설정 키를 반환합니다.
     * @returns {Promise<any[]>}
     */
    async getAllKeys() {
        const db = await this.#getDB();
        if (!db) return [];
        const storeName = this.#stores.SETTINGS;

        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readonly');
            const req = tx.objectStore(storeName).getAllKeys();
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => resolve([]);
        });
    }

    /**
     * 블라인드 메시지 원본을 저장합니다.
     * @param {string} msgKey
     * @param {string} originalContent
     * @param {string} [nickname]
     * @returns {Promise<void>}
     */
    async saveBlindedMessage(msgKey, originalContent, nickname = '') {
        const db = await this.#getDB();
        if (!db) return;
        const storeName = this.#stores.BLINDED;
        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readwrite');
            tx.objectStore(storeName).put({ msgKey, originalContent, nickname, timestamp: Date.now() });
            tx.oncomplete = () => resolve();
            tx.onerror = () => resolve();
        });
    }

    /**
     * 블라인드 메시지 원본을 조회합니다.
     * @param {string} msgKey
     * @returns {Promise<{msgKey: string, originalContent: string, nickname: string, timestamp: number}|undefined>}
     */
    async getBlindedMessage(msgKey) {
        const db = await this.#getDB();
        if (!db) return undefined;
        const storeName = this.#stores.BLINDED;
        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readonly');
            const req = tx.objectStore(storeName).get(msgKey);
            req.onsuccess = () => resolve(req.result || undefined);
            req.onerror = () => resolve(undefined);
        });
    }

    /**
     * 오래된 블라인드 메시지를 정리합니다 (기본 24시간).
     * @param {number} [maxAgeMs=86400000]
     * @returns {Promise<number>}
     */
    async pruneBlindedMessages(maxAgeMs = 86400000) {
        const db = await this.#getDB();
        if (!db) return 0;
        const cutoff = Date.now() - maxAgeMs;
        const storeName = this.#stores.BLINDED;
        return new Promise((resolve) => {
            const tx = db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const idx = store.index('timestamp');
            const range = IDBKeyRange.upperBound(cutoff);
            let deleted = 0;
            const req = idx.openCursor(range);
            req.onsuccess = (e) => {
                // @ts-ignore
                const cursor = e.target.result;
                if (cursor) {
                    cursor.delete();
                    deleted++;
                    cursor.continue();
                }
            };
            tx.oncomplete = () => resolve(deleted);
            tx.onerror = () => resolve(deleted);
        });
    }

    /**
     * 모아보기 채팅 단건 저장 (백그라운드)
     */
    async addCollectorChat(chat) {
        if (!this.#db) await this.init();
        return new Promise((resolve, reject) => {
            try {
                const tx = this.#db.transaction([STORE_NAMES.COLLECTOR_CHATS], 'readwrite');
                const store = tx.objectStore(STORE_NAMES.COLLECTOR_CHATS);
                store.put(chat);
                tx.oncomplete = () => resolve(true);
                tx.onerror = (e) => reject(e);
            } catch (ex) {
                reject(ex);
            }
        });
    }

    /**
     * 특정 채널의 모아보기 채팅 전체 조회
     */
    async getCollectorChatsByChannel(channelId) {
        if (!this.#db) await this.init();
        return new Promise((resolve) => {
            try {
                const tx = this.#db.transaction([STORE_NAMES.COLLECTOR_CHATS], 'readonly');
                const store = tx.objectStore(STORE_NAMES.COLLECTOR_CHATS);
                const index = store.index('channelId');
                const req = index.getAll(channelId);
                req.onsuccess = () => {
                    const result = req.result || [];
                    result.sort((a, b) => a.time - b.time);
                    resolve(result);
                };
                req.onerror = () => resolve([]);
            } catch (ex) {
                resolve([]);
            }
        });
    }

    /**
     * 채널과 무관하게 만료 시간이 지난 모아보기 채팅 전부 삭제
     * retentionHours 값이 0 이하이면 무시 (또는 전체 삭제) - 여기선 만료 처리
     */
    async clearExpiredCollectorChats(retentionHours) {
        if (!this.#db) await this.init();
        if (typeof retentionHours !== 'number' || retentionHours <= 0) return;

        return new Promise((resolve) => {
            try {
                const expirationTime = Date.now() - (retentionHours * 3600 * 1000);
                const tx = this.#db.transaction([STORE_NAMES.COLLECTOR_CHATS], 'readwrite');
                const store = tx.objectStore(STORE_NAMES.COLLECTOR_CHATS);
                const index = store.index('time');
                const range = IDBKeyRange.upperBound(expirationTime);
                const req = index.openCursor(range);

                req.onsuccess = (e) => {
                    const cursor = e.target.result;
                    if (cursor) {
                        cursor.delete();
                        cursor.continue();
                    } else {
                        resolve(true); // 커서 끝남 (삭제 완료)
                    }
                };
                req.onerror = () => resolve(false);
            } catch (ex) {
                resolve(false);
            }
        });
    }

    /**
     * 특정 채널의 모든 채팅 삭제
     */
    async clearCollectorChatsByChannel(channelId) {
        if (!this.#db) await this.init();
        return new Promise((resolve) => {
            try {
                const tx = this.#db.transaction([STORE_NAMES.COLLECTOR_CHATS], 'readwrite');
                const store = tx.objectStore(STORE_NAMES.COLLECTOR_CHATS);
                const index = store.index('channelId');
                const req = index.openCursor(IDBKeyRange.only(channelId));

                req.onsuccess = (e) => {
                    const cursor = e.target.result;
                    if (cursor) {
                        cursor.delete();
                        cursor.continue();
                    } else {
                        resolve(true);
                    }
                };
                req.onerror = () => resolve(false);
            } catch (ex) {
                resolve(false);
            }
        });
    }
}

// 싱글톤 인스턴스 생성 및 내보내기
const dbManager = DatabaseManager.getInstance();

export const initDB = () => dbManager.init();
export const saveThumbnail = (/** @type {number} */ time, /** @type {string} */ url) => dbManager.saveThumbnail(time, url);
export const getClosestThumbnail = (/** @type {number} */ time) => dbManager.getClosestThumbnail(time);
export const clearThumbnails = () => dbManager.clearThumbnails();
export const getKV = (/** @type {string} */ key) => dbManager.getKV(key);
export const setKV = (/** @type {string} */ key, /** @type {any} */ value) => dbManager.setKV(key, value);
export const addPowerLog = (/** @type {any} */ data) => dbManager.addPowerLog(data);
export const getPowerLogs = (/** @type {number} */ limit) => dbManager.getPowerLogs(limit);
export const getAllKeys = () => dbManager.getAllKeys();

/**
 * 블라인드 메시지 원본을 저장합니다.
 * @param {string} msgKey
 * @param {string} originalContent
 * @param {string} [nickname]
 * @returns {Promise<void>}
 */
export const saveBlindedMessage = (msgKey, originalContent, nickname = '') => dbManager.saveBlindedMessage(msgKey, originalContent, nickname);

/**
 * 블라인드 메시지 원본을 조회합니다.
 * @param {string} msgKey
 * @returns {Promise<{msgKey: string, originalContent: string, nickname: string, timestamp: number}|undefined>}
 */
export const getBlindedMessage = (msgKey) => dbManager.getBlindedMessage(msgKey);

/**
 * 오래된 블라인드 메시지를 정리합니다.
 * @param {number} [maxAgeMs]
 * @returns {Promise<number>}
 */
export const pruneBlindedMessages = (maxAgeMs) => dbManager.pruneBlindedMessages(maxAgeMs);

export default dbManager;
