@echo off
title Chzzk Quality Installer

if "%~1" == "" (
    powershell.exe -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
) else (
    powershell.exe -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -ZipPath "%~1"
)
