// @ts-nocheck
import Hls from 'hls.js';
import { SELECTORS, REGEX, isHomePage } from './dom-utils';
import { getKV, setKV } from './shared/db';

const SVG_MUTE = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"></path><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>`;
const SVG_UNMUTE = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>`;

/**
 * 치지직 사이드바 팔로잉 목록의 실시간 방송 미리보기 클래스
 */
class HoverPreview {
    constructor() {
        this.enabled = true;
        this.thumbnailPreviewEnabled = false;
        this.videoEnabled = true;
        this.volume = 0;
        this.isMuted = true;
        this.card = null;
        /** @type {string|null} */
        this.currentChannelId = null;
        /** @type {Map<string, {data: any, ts: number}>} */
        this.cache = new Map();
        this.cacheTTL = 30000; // 30 seconds

        this.boundMouseOver = this.handleMouseOver.bind(this);
        this.boundMouseOut = this.handleMouseOut.bind(this);

        this.hlsInstance = null;
        this.showTimer = null;
        this.uptimeTimer = null;
        this.hoverPreviewDelay = 500;
    }

    /**
     * 설정을 업데이트하고 활성화 여부를 결정합니다.
     * @param {any} settings 
     */
    update(settings) {
        this.enabled = settings?.hoverPreviewEnabled !== false;
        this.thumbnailPreviewEnabled = false; // 본문 미리보기는 항상 비활성화
        this.videoEnabled = settings?.hoverPreviewVideoEnabled !== false;
        this.volume = settings?.hoverPreviewVolume ?? 0;
        this.hoverPreviewDelay = settings?.hoverPreviewDelay ?? 500;
        this.hoverPreviewVideoDelay = settings?.hoverPreviewVideoDelay ?? 1200;
        this.hoverCardSize = settings?.hoverCardSize ?? 440;
        this.interactive = settings?.hoverPreviewInteractive !== false;
        this.uptimeFormat = settings?.hoverPreviewUptimeFormat ?? 'hhmmss';
        if (this.enabled || this.thumbnailPreviewEnabled) {
            this.start();
        } else {
            this.stop();
        }
    }

    /**
     * 이벤트 리스너를 등록합니다.
     */
    start() {
        this.stop();
        if (!this.enabled && !this.thumbnailPreviewEnabled) return;
        document.addEventListener('mouseover', this.boundMouseOver);
        document.addEventListener('mouseout', this.boundMouseOut);
        // @ts-ignore
        window.cqcHoverPreview = this;
    }

    /**
     * 이벤트 리스너를 제거하고 카드를 숨깁니다.
     */
    stop() {
        document.removeEventListener('mouseover', this.boundMouseOver);
        document.removeEventListener('mouseout', this.boundMouseOut);
        if (this.showTimer) {
            clearTimeout(this.showTimer);
            this.showTimer = null;
        }
        this.hideCard();
    }

    /**
     * 미리보기 카드 요소를 생성합니다.
     * @returns {HTMLElement}
     */
    createCard() {
        const card = document.createElement('div');
        card.className = 'cqc-hover-card';
        card.innerHTML = `
      <a class="cqc-hover-card__link" href="/live/xxx">    
        <div class="cqc-hover-card__thumb-wrap">
          <video class="cqc-hover-card__video" muted playsinline></video>
          <img class="cqc-hover-card__thumb" />
          <div class="cqc-hover-card__watchparty-badge">같이보기+ 채널</div>
          <div class="cqc-hover-card__live-badge">LIVE</div>
          <span class="cqc-hover-card__viewers"></span>
          <button class="cqc-hover-card__vol-btn" title="음소거 토글"></button>
        </div>
        <div class="cqc-hover-card__body">
          <div class="cqc-hover-card__title"></div>
          <div class="cqc-hover-card__meta">
            <span class="cqc-hover-card__channel"></span>
            <div class="cqc-hover-card__tags">
              <span class="cqc-hover-card__uptime"></span>
              <span class="cqc-hover-card__category"></span>
            </div>
          </div>
        </div>
      </a>
    `;

        card.addEventListener('mouseenter', () => this.cancelHide());
        card.addEventListener('mouseleave', () => this.scheduleHide());
        card.addEventListener('click', (e) => {
            // @ts-ignore
            if (e.target.closest('.cqc-hover-card__vol-btn')) return;
            if (this.isSidebar) {
              e.preventDefault();
              e.stopPropagation();
              return;
            }
            if (e.ctrlKey || e.shiftKey) return;
            e.preventDefault?.();
            if (this.currentLink) {
                this.currentLink.click();
                this.hideCard();
            }
        });

        getKV('hoverPreviewMuted').then(v => { this.isMuted = v !== false; updateVolBtn(); });
        const volBtn = card.querySelector('.cqc-hover-card__vol-btn');
        const updateVolBtn = () => { if (volBtn) volBtn.innerHTML = this.isMuted ? SVG_MUTE : SVG_UNMUTE; };
        volBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            e.preventDefault();
            this.isMuted = !this.isMuted;
            await setKV('hoverPreviewMuted', this.isMuted);
            updateVolBtn();
            const video = card.querySelector('.cqc-hover-card__video');
            if (video) video.muted = this.isMuted;
        });

        document.body.appendChild(card);
        return card;
    }

    /**
     * 카드 요소를 가져오거나 새로 생성합니다.
     * @returns {HTMLElement}
     */
    getCard() {
        if (!this.card || !this.card.isConnected) {
            this.card = this.createCard();
        }
        return this.card;
    }

    /**
     * 마우스 오버 이벤트를 처리합니다.
     * @param {MouseEvent} e 
     */
    async handleMouseOver(e) {
        if (!this.enabled && !this.thumbnailPreviewEnabled) return;

        const link = this.findLiveLink(e.target);
        if (!link) return;

        const href = link.getAttribute('href');
        const channelId = this.extractChannelId(href);
        if (!channelId) return;

        const isSidebar = !!link.closest('#sidebar, aside, [class*="navigation_bar_container__"], [class*="aside_container__"]');
        this.isSidebar = isSidebar;
        
        let rectElement = link;
        if (!isSidebar) {
            const thumbArea = /** @type {HTMLElement} */ (e.target).closest('[class*="_thumbnail_"], [class*="thumbnail_"], [class*="_video_"], img');
            if (!thumbArea || !link.contains(thumbArea)) {
                return; // 썸네일 영역이 아니면 무시
            }
            if (thumbArea.className.includes('_is_live_')) {
                return; // _is_live_ 클래스가 붙은 썸네일 제외
            }
            rectElement = /** @type {HTMLElement} */ (thumbArea);
        }

        if (channelId === this.currentChannelId) {
            this.cancelHide();
            return;
        }

        this.cancelHide();
        if (this.showTimer) {
            clearTimeout(this.showTimer);
            this.showTimer = null;
        }

        this.currentChannelId = channelId;
        this.currentLink = link;
        this.currentRectElement = rectElement;

        const delay = isSidebar ? 0 : this.hoverPreviewDelay;
        if (delay > 0) {
            this.showTimer = setTimeout(() => {
                this.triggerShow(channelId, rectElement, isSidebar);
            }, delay);
        } else {
            this.triggerShow(channelId, rectElement, isSidebar);
        }
    }

    /**
     * 실제로 카드를 표시하는 트리거 함수입니다.
     * @param {string} channelId 
     * @param {HTMLElement} rectElement 
     * @param {boolean} isSidebar 
     */
    async triggerShow(channelId, rectElement, isSidebar) {
        if (!isSidebar || !this.currentLink || this.findLiveLink(this.currentLink) !== this.currentLink) { this.hideCard(); return; }
        if (this.currentChannelId !== channelId) return;

        // 네이티브 툴팁 강제 숨김
        const nativeTooltip = document.querySelector(SELECTORS.SIDEBAR_TOOLTIP);
        if (nativeTooltip) {
            nativeTooltip.style.display = 'none';
        }

        const rect = rectElement.getBoundingClientRect();
        this.showLoading(rect, isSidebar);

        const data = await this.fetchLiveDetail(channelId);
        if (data && this.currentChannelId === channelId) {
            // 데이터 로드 후 최신 위치 재계산
            const latestRect = this.currentRectElement ? this.currentRectElement.getBoundingClientRect() : rect;
            this.renderCard(data, latestRect, isSidebar);
            if (this.videoEnabled) {
                this.scheduleVideo(data);
            }
        } else if (!data && this.currentChannelId === channelId) {
            this.hideCard();
        }
    }

    /**
     * 마우스 아웃 이벤트를 처리합니다.
     * @param {MouseEvent} e 
     */
    handleMouseOut(e) {
        const link = this.findLiveLink(e.target);
        if (link) {
            // @ts-ignore
            if (e.relatedTarget?.closest?.('.cqc-hover-card')) return;
            if (this.showTimer) {
                clearTimeout(this.showTimer);
                this.showTimer = null;
            }
            this.scheduleHide();
        }
    }

    findLiveLink(target) {
        if (!(target instanceof HTMLElement)) return null;
        if (target.closest('[data-cqc-power-dashboard]')) return null;
        const link = target.closest(SELECTORS.LIVE_LINK);
        if (link) {
            // 메인 배너(최상단 캐러셀) 안의 썸네일은 이미 자체 재생/동작이 있으므로 제외
            if (link.closest(SELECTORS.HOME_RECOMMEND_CAROUSEL)) {
                return null;
            }

            // ── 사이드바 미리보기 (홈 설정과 독립적으로 동작) ──
            if (this.enabled && (link.closest('#sidebar, aside, [class*="navigation_bar_container__"], [class*="aside_container__"]'))) {
                return /** @type {HTMLElement} */ (link);
            }


        }
        return null;
    }

    /**
     * 추천 라이브/채널 섹션 내부인지 확인합니다.
     * @param {HTMLElement} link
     * @returns {boolean}
     */
    isRecommendSection(link) {
        const section = link.closest('section');
        if (!section) return false;

        // 헤더 텍스트 또는 클래스명 매칭
        const headers = section.querySelectorAll('h2, h3, h4, [class*="title"], [class*="header"]');
        for (let i = 0; i < headers.length; i++) {
            const txt = headers[i].textContent || '';
            if (txt.includes('추천')) {
                return true;
            }
        }

        if (section.className && /recommend|flick/i.test(section.className)) {
            return true;
        }

        return false;
    }

    /**
     * URL에서 채널 ID를 추출합니다.
     * @param {string | null} href 
     * @returns {string | null}
     */
    extractChannelId(href) {
        return href?.match(/\/live\/([a-f0-9]+)/)?.[1] || null;
    }

    /**
     * 채널의 라이브 정보를 가져옵니다 (캐시 지원).
     * @param {string} channelId 
     * @returns {Promise<any>}
     */
    async fetchLiveDetail(channelId) {
        const cached = this.cache.get(channelId);
        if (cached && (Date.now() - cached.ts < this.cacheTTL)) {
            return cached.data;
        }

        try {
            const resp = await fetch(`https://api.chzzk.naver.com/service/v3/channels/${channelId}/live-detail`, {
                credentials: 'include'
            });
            const json = await resp.json();
            if (json.code === 200 && json.content) {
                const data = json.content;
                this.cache.set(channelId, { data, ts: Date.now() });
                return data;
            }
        } catch (err) {
            console.error('[CQC:Hover] 정보 조회 실패:', err);
        }
        return null;
    }

    /**
     * 로딩 상태를 표시합니다.
     * @param {DOMRect} rect 
     * @param {boolean} [isSidebar=true]
     */
    showLoading(rect, isSidebar = true) {
        const card = this.getCard();
        /** @type {any} */ (card.querySelector('.cqc-hover-card__thumb')).style.display = 'none';
        /** @type {any} */ (card.querySelector('.cqc-hover-card__video')).classList.remove('is-playing');
        /** @type {any} */ (card.querySelector('.cqc-hover-card__title')).textContent = '불러오는 중...';
        card.classList.remove('cqc-hover-card--show');
        this.positionCard(card, rect, isSidebar);
    }

    /**
     * 같이보기 방송인지 확인합니다.
     * @param {any} data 
     * @returns {boolean}
     */
    isWatchParty(data) {
        if (!data) return false;
        return (data.watchPartyNo !== null && data.watchPartyNo !== undefined) ||
            (data.watchPartyType !== null && data.watchPartyType !== undefined);
    }

    /**
     * 유료 또는 제한된 스트림인지 확인합니다.
     * @param {any} data 
     * @returns {boolean}
     */
    isPaidOrRestricted(data) {
        if (!data) return false;
        if (data.paidProduct !== null && data.paidProduct !== undefined) return true;
        if (data.paidProductId) return true;
        if (data.watchPartyPaidProductId) return true;
        if (data.watchPartyTag === '2026북중미월드컵') return true;
        if (data.adParameter?.tag === 'worldcup') return true;
        return false;
    }

    /**
     * 카드를 렌더링하고 표시합니다.
     * @param {any} data 
     * @param {DOMRect} rect 
     * @param {boolean} [isSidebar=true]
     */
    renderCard(data, rect, isSidebar = true) {
        const card = this.getCard();
        const thumb = /** @type {HTMLImageElement} */ (card.querySelector('.cqc-hover-card__thumb'));

        const isWorldCup = data.watchPartyTag === '2026북중미월드컵' || data.adParameter?.tag === 'worldcup';
        const isPlus = data.watchPartyType === 'RS';

        if (data.liveImageUrl) {
            thumb.src = data.liveImageUrl.replace('{type}', '480');
            thumb.style.display = 'block';
            thumb.style.opacity = '1';
        }

        if (thumb) {
            if (isWorldCup && isPlus) {
                thumb.style.filter = 'brightness(0.3)';
            } else {
                thumb.style.filter = '';
            }
        }

        const link = /** @type {HTMLElement|null} */ (card.querySelector('.cqc-hover-card__link'));
        if (link && this.currentLink) {
          link.href = this.currentLink.getAttribute('href');
        }

        const wpBadge = /** @type {HTMLElement|null} */ (card.querySelector('.cqc-hover-card__watchparty-badge'));
        if (wpBadge) {
            if (isPlus) {
                wpBadge.style.textAlign = 'center';
                wpBadge.innerHTML = '같이보기+ 채널<br><span style="font-size: 0.45em; font-weight: 500; display: block; margin-top: 6px; opacity: 0.9; text-shadow: 0 1px 4px rgba(0,0,0,0.8); letter-spacing: -0.01em;">네이버 플러스 멤버십 회원이면<br>시청 가능!</span>';
                wpBadge.style.display = 'block';
            } else {
                wpBadge.style.display = 'none';
            }
        }

        const volBtn = /** @type {HTMLElement|null} */ (card.querySelector('.cqc-hover-card__vol-btn'));
        if (volBtn) {
            if (isWorldCup && isPlus) {
                volBtn.style.setProperty('display', 'none', 'important');
            } else {
                volBtn.style.removeProperty('display');
            }
        }

        /** @type {any} */ (card.querySelector('.cqc-hover-card__viewers')).textContent = `${(data.concurrentUserCount || 0).toLocaleString()}명 시청중`;
        /** @type {any} */ (card.querySelector('.cqc-hover-card__title')).textContent = data.liveTitle || '';
        /** @type {any} */ (card.querySelector('.cqc-hover-card__channel')).textContent = data.channel?.channelName || '';

        let categoryText = data.liveCategoryValue || '';
        /** @type {any} */ (card.querySelector('.cqc-hover-card__category')).textContent = categoryText;

        const uptimeEl = /** @type {HTMLElement|null} */ (card.querySelector('.cqc-hover-card__uptime'));
        if (uptimeEl) {
            if (this.uptimeTimer) {
                clearInterval(this.uptimeTimer);
                this.uptimeTimer = null;
            }
            if (data.openDate && this.uptimeFormat !== 'off') {
                uptimeEl.style.display = 'block';
                // openDate 형식: "2026-07-06 18:00:51" -> "2026/07/06 18:00:51" 변환 후 타임스탬프
                const openTimeMs = new Date(data.openDate.replace(/-/g, '/')).getTime();
                
                const updateUptime = () => {
                    if (!this.card?.classList.contains('cqc-hover-card--show')) return;
                    const diffSeconds = Math.floor((Date.now() - openTimeMs) / 1000);
                    if (diffSeconds < 0) return;
                    
                    const h = Math.floor(diffSeconds / 3600);
                    const m = Math.floor((diffSeconds % 3600) / 60);
                    const s = diffSeconds % 60;
                    
                    if (this.uptimeFormat === 'korean') {
                        uptimeEl.textContent = h > 0 ? `${h}시간 ${m}분 ${s}초` : `${m}분 ${s}초`;
                    } else if (this.uptimeFormat === 'hm') {
                        uptimeEl.textContent = h > 0 ? `${h}:${m.toString().padStart(2, '0')}` : `${m}분`;
                    } else {
                        // default: hhmmss
                        uptimeEl.textContent = h > 0 
                            ? `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}` 
                            : `${m}:${s.toString().padStart(2, '0')}`;
                    }
                };
                
                updateUptime();
                this.uptimeTimer = setInterval(updateUptime, 1000);
            } else {
                uptimeEl.style.display = 'none';
            }
        }

        this.positionCard(card, rect, isSidebar);
    }

    /**
     * 카드의 위치를 설정하고 표시합니다.
     * @param {HTMLElement} card 
     * @param {DOMRect} rect 
     * @param {boolean} [isSidebar=true]
     */
    positionCard(card, rect, isSidebar = true) {
        if (!isSidebar || !this.currentLink || this.findLiveLink(this.currentLink) !== this.currentLink) { this.hideCard(); return; }
        card.style.display = 'block';

        const cardWidth = this.hoverCardSize || 440;
        card.style.setProperty('--cqc-hover-card-width', `${cardWidth}px`);
        card.style.width = `var(--cqc-hover-card-width)`;
        
        const cardHeight = cardWidth * (9 / 16) + 70; // 썸네일 16:9 + 하단 텍스트

        // 썸네일이 화면 중앙 기준 어느 쪽에 있는지 판단
        const isRightSide = rect.left + (rect.width / 2) > window.innerWidth / 2;

        if (isRightSide) {
            // 화면 우측: 썸네일 왼쪽에 띄움
            let leftPos = rect.left - cardWidth - 16;
            card.style.left = `${Math.max(16, leftPos)}px`;
        } else {
            // 화면 좌측 (또는 사이드바): 썸네일 오른쪽에 띄움
            let leftPos = rect.right + 16;
            if (leftPos + cardWidth > window.innerWidth - 16) {
                leftPos = window.innerWidth - cardWidth - 16;
            }
            card.style.left = `${leftPos}px`;
        }

        // 수직 정렬: 썸네일과 수직 중앙 맞춤
        let topPos = rect.top + (rect.height / 2) - (cardHeight / 2);
        
        // 상/하단 뷰포트 오버플로우 방지
        topPos = Math.max(16, topPos);
        if (topPos + cardHeight > window.innerHeight - 16) {
            topPos = Math.max(16, window.innerHeight - cardHeight - 16);
        }

        card.style.top = `${topPos}px`;
        card.classList.remove('cqc-hover-card--popout');
        card.style.cursor = 'default';

        if (!isSidebar && !this.interactive) {
            card.style.pointerEvents = 'none';
        } else {
            card.style.pointerEvents = 'auto';
        }

        // 네이티브 툴팁 강제 숨김
        const nativeTooltip = document.querySelector(SELECTORS.SIDEBAR_TOOLTIP);
        if (nativeTooltip) {
            nativeTooltip.style.display = 'none';
        }

        requestAnimationFrame(() => {
            card.classList.add('cqc-hover-card--show');
            document.body.classList.add('cqc-hover-active');
        });
    }

    /**
     * 비디오 재생을 예약합니다.
     * @param {any} data 
     */
    scheduleVideo(data) {
        this.stopVideo();
        if (this.isPaidOrRestricted(data)) return;
        // 설정된 비디오 전환 지연 시간 대기 후 재생 (리소스 절약)
        this.videoTimer = setTimeout(() => this.playVideo(data), this.hoverPreviewVideoDelay ?? 1200);
    }

    /**
     * 비디오를 재생합니다.
     * @param {any} data 
     */
    async playVideo(data) {
        //console.log('[CQC:Hover:Debug] playVideo 시작, 데이터:', data);
        if (!this.enabled || !this.videoEnabled) {
            //console.log('[CQC:Hover:Debug] 기능 비활성화로 중단');
            return;
        }

        let playbackJson;
        try {
            playbackJson = JSON.parse(data.livePlaybackJson || '{}');
            //console.log('[CQC:Hover:Debug] Playback JSON 파싱 성공:', playbackJson);
        } catch (e) {
            //console.error('[CQC:Hover:Debug] Playback JSON 파싱 실패:', e);
            return;
        }

        const isFirefox = navigator.userAgent.toLowerCase().includes('firefox');
        //console.log('[CQC:Hover:Debug] 브라우저 식별, Firefox 여부:', isFirefox, 'userAgent:', navigator.userAgent);

        const mediaList = playbackJson.media || [];

        // 파이어폭스에서는 스트리밍 안정성을 위해 HLS를 우선 고려, 그 외는 LLHLS
        let preferredMedia;
        if (isFirefox) {
            preferredMedia = mediaList.find((/** @type {any} */ m) => m.mediaId === 'HLS') ||
                mediaList.find((/** @type {any} */ m) => m.mediaId === 'LLHLS');
        } else {
            preferredMedia = mediaList.find((/** @type {any} */ m) => m.mediaId === 'LLHLS') ||
                mediaList.find((/** @type {any} */ m) => m.mediaId === 'HLS');
        }

        if (!preferredMedia) {
            //console.log('[CQC:Hover:Debug] 선호 미디어(HLS/LLHLS)를 찾지 못함. 첫번째 미디어 선택 시도');
            preferredMedia = mediaList[0];
        } else {
            //console.log('[CQC:Hover:Debug] 선호 미디어 선택 완료:', preferredMedia.mediaId, preferredMedia);
        }

        if (!preferredMedia || !preferredMedia.path) {
            //console.error('[CQC:Hover:Debug] 유효한 재생 주소를 찾을 수 없음 (preferredMedia.path 누락)');
            return;
        }

        let hlsUrl = preferredMedia.path;
        //console.log('[CQC:Hover:Debug] 초기 추출된 hlsUrl:', hlsUrl);

        // 720p 트랙이 명시되어 있는지 확인 (치지직은 주로 720p로 미리보기 제공)
        const track720 = preferredMedia.encodingTrack?.find((/** @type {any} */ t) => t.encodingTrackId === '720p');
        if (track720 && track720.path) {
            hlsUrl = track720.path;
            //console.log('[CQC:Hover:Debug] 명시적인 720p 트랙 주소 적용:', hlsUrl);
        } else {
            //console.log('[CQC:Hover:Debug] 명시적인 720p 트랙이 없음. 기본 주소 유지');
        }

        const card = this.getCard();
        const video = /** @type {HTMLVideoElement} */ (card.querySelector('.cqc-hover-card__video'));

        // 비디오 속성 강제 설정 (정책 및 검은 화면 방지)
        video.muted = this.isMuted;
        video.volume = Math.max(0, Math.min(1, this.volume / 100));
        video.setAttribute('playsinline', 'true');
        video.setAttribute('autoplay', 'true');
        //console.log('[CQC:Hover:Debug] 비디오 요소 속성 설정 (muted, playsinline, autoplay)');

        // timeupdate 리스너를 통해 실제 첫 프레임이 렌더링되어 재생되는 시점에만 비디오를 노출 (암전 방지)
        if (video._cqcTimeUpdateHandler) {
            video.removeEventListener('timeupdate', video._cqcTimeUpdateHandler);
        }
        video._cqcTimeUpdateHandler = () => {
            if (video.currentTime > 0) {
                video.classList.add('is-playing');
                if (video._cqcTimeUpdateHandler) {
                    video.removeEventListener('timeupdate', video._cqcTimeUpdateHandler);
                    video._cqcTimeUpdateHandler = null;
                }
            }
        };
        video.addEventListener('timeupdate', video._cqcTimeUpdateHandler);

        // 기존 HLS 인스턴스 정리
        if (this.hlsInstance) {
            //console.log('[CQC:Hover:Debug] 기존 HLS 인스턴스 파괴');
            this.hlsInstance.destroy();
            this.hlsInstance = null;
        }

        // @ts-ignore
        const HlsClass = Hls;
        //console.log('[CQC:Hover:Debug] HlsClass 인스턴스 확인:', !!HlsClass);

        if (HlsClass && HlsClass.isSupported()) {
            //console.log('[CQC:Hover:Debug] Hls.js 지원 확인됨. HLS 인스턴스 생성 시작');
            const hlsConfig = {
                capLevelToPlayerSize: true,
                autoStartLoad: false, // 마스터 플레이리스트일 수 있으므로 매니페스트 파싱 후 시작
                enableWorker: true,
                lowLatencyMode: !isFirefox, // 파이어폭스는 저지연 모드 비활성화 (안정성 강화)
                xhrSetup: (/** @type {any} */ xhr) => {
                    // xhr.withCredentials = true; (CORS 정책 충돌로 인한 간헐적 재생 실패 방지)
                },
                // 버퍼 설정 완화 (브라우저 호환성 개선)
                maxBufferLength: 15,
                maxMaxBufferLength: 30,
                backBufferLength: 0
            };
            //console.log('[CQC:Hover:Debug] Hls.js 초기화 설정:', hlsConfig);

            this.hlsInstance = new HlsClass(hlsConfig);

            // @ts-ignore
            window.cqcGC?.track(this.hlsInstance, 'HlsInstance');

            // 1. 에러 리스너 우선 등록
            this.hlsInstance.on(HlsClass.Events.ERROR, (/** @type {any} */ event, /** @type {any} */ data) => {
                //console.error('[CQC:Hover:Debug] Hls.js 에러 발생:', data.type, data.details, data);
                if (data.fatal) {
                    if (data.type === HlsClass.ErrorTypes.NETWORK_ERROR) {
                        //console.error('[CQC:Hover:Debug] 치명적인 네트워크 에러, startLoad() 재시도');
                        this.hlsInstance.startLoad();
                    } else if (data.type === HlsClass.ErrorTypes.MEDIA_ERROR) {
                        //console.error('[CQC:Hover:Debug] 치명적인 미디어 에러, recoverMediaError() 시도');
                        this.hlsInstance.recoverMediaError();
                    } else {
                        //console.error('[CQC:Hover:Debug] 기타 치명적인 에러, HLS 인스턴스 파괴');
                        this.hlsInstance.destroy();
                    }
                }
            });

            // 2. 미디어 연결 시 처리
            this.hlsInstance.on(HlsClass.Events.MEDIA_ATTACHED, () => {
                //console.log('[CQC:Hover:Debug] MEDIA_ATTACHED 이벤트 발생, loadSource 호출:', hlsUrl);
                this.hlsInstance.loadSource(hlsUrl);
            });

            // 3. 매니페스트 파싱 시 처리
            this.hlsInstance.on(HlsClass.Events.MANIFEST_PARSED, (/** @type {any} */ event, /** @type {any} */ data) => {
                //console.log('[CQC:Hover:Debug] MANIFEST_PARSED 이벤트 발생:', data);
                const levels = this.hlsInstance.levels;
                //console.log('[CQC:Hover:Debug] 제공되는 레벨들:', levels);

                const level720 = levels.findIndex((/** @type {any} */ l) => l.height === 720);

                if (level720 !== -1) {
                    //console.log(`[CQC:Hover:Debug] 720p 레벨 찾음 (Index: ${level720}), 레벨 고정 시도`);
                    this.hlsInstance.currentLevel = level720;
                    this.hlsInstance.startLevel = level720;
                } else {
                    //console.log('[CQC:Hover:Debug] 720p 레벨을 찾을 수 없음, 기본 동작 사용');
                }

                // 레벨 설정 후 로딩 시작
                //console.log('[CQC:Hover:Debug] startLoad() 호출');
                this.hlsInstance.startLoad();

                video.play().then(() => {
                    //console.log('[CQC:Hover:Debug] 비디오 자동 재생 성공');
                }).catch(err => {
                    //console.warn('[CQC:Hover:Debug] 비디오 자동 재생 차단/실패:', err);
                });
            });

            // 4. 리스너 등록 후 최종적으로 attachMedia 호출
            //console.log('[CQC:Hover:Debug] 리스너 등록 완료, attachMedia 호출');
            this.hlsInstance.attachMedia(video);
        }
        else if (video.canPlayType('application/vnd.apple.mpegurl')) {
            //console.log('[CQC:Hover:Debug] 네이티브 HLS 지원 확인됨 (사파리 등), src 지정:', hlsUrl);
            video.src = hlsUrl;
            video.addEventListener('loadedmetadata', () => {
                //console.log('[CQC:Hover:Debug] 네이티브 HLS 메타데이터 로드됨, 재생 시도');
                video.play().catch(err => console.warn('[CQC:Hover:Debug] 네이티브 자동 재생 차단:', err));
            }, { once: true });
        } else {
            //console.error('[CQC:Hover:Debug] Hls.js 미지원 및 네이티브 HLS 미지원 브라우저');
        }
    }

    stopVideo() {
        //console.log('[CQC:Hover:Debug] stopVideo 호출됨');
        if (this.videoTimer) {
            clearTimeout(this.videoTimer);
            this.videoTimer = null;
        }
        if (this.hlsInstance) {
            //console.log('[CQC:Hover:Debug] hlsInstance 파괴');
            this.hlsInstance.destroy();
            this.hlsInstance = null;
        }
        if (this.card) {
            const video = /** @type {HTMLVideoElement} */ (this.card.querySelector('.cqc-hover-card__video'));
            if (video._cqcTimeUpdateHandler) {
                video.removeEventListener('timeupdate', video._cqcTimeUpdateHandler);
                video._cqcTimeUpdateHandler = null;
            }
            video.classList.remove('is-playing');
            video.removeAttribute('src');
            video.load();
        }
    }
    hideCard() {
        this.stopVideo();
        if (this.uptimeTimer) {
            clearInterval(this.uptimeTimer);
            this.uptimeTimer = null;
        }
        if (this.card) {
            this.card.classList.remove('cqc-hover-card--show');
            document.body.classList.remove('cqc-hover-active');
            setTimeout(() => {
                if (this.card && !this.card.classList.contains('cqc-hover-card--show')) {
                    this.card.style.display = 'none';
                }
            }, 250);
        }
        this.currentChannelId = null;
    }

    /**
     * 숨기기 타이머를 예약합니다.
     */
    scheduleHide() {
        this.cancelHide();
        this.hideTimer = setTimeout(() => this.hideCard(), 150);
    }

    /**
     * 숨기기 타이머를 취소합니다.
     */
    cancelHide() {
        if (this.hideTimer) {
            clearTimeout(this.hideTimer);
            this.hideTimer = null;
        }
    }
}

/** @type {HoverPreview|null} */
let instance = null;

/**
 * HoverPreview 기능을 초기화합니다.
 * @param {any} [settings]
 * @returns {HoverPreview}
 */
export const initHoverPreview = (settings = {}) => {
    if (!instance) instance = new HoverPreview();
    instance.update(settings);
    return instance;
};
