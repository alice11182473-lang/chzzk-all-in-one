// @ts-nocheck
/** @ts-check */
'use strict';

// ── CQC Network Interceptor (AdBlock) ──
(function () {

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  //  Route – 개별 URL 매칭 + 처리 규칙 정의
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  class Route {
    /**
     * @param {object} opts
     * @param {(url: string, method: string) => boolean} opts.match
     * @param {'block' | 'stub' | 'rewrite'} opts.action
     * @param {((data: any) => any) | undefined} opts.mutator  - rewrite 전용
     * @param {(() => any) | undefined} opts.stubBody          - stub 전용
     * @param {string} opts.label
     */
    constructor({ match, action, mutator, stubBody, label }) {
      this.match = match;
      this.action = action;
      this.mutator = mutator ?? null;
      this.stubBody = stubBody ?? null;
      this.label = label;
    }
  }

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  //  ResponseMutators – 응답 JSON 변조 로직 모음
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  class ResponseMutators {
    static pruneT(obj) {
      if (!obj?.content) return obj;
      const c = obj.content;
      delete c.videoAdScheduleId;
      for (const ab of c.adBreaks ?? [])
        for (const src of ab.adSources ?? [])
          delete src.withRemindAd;
      for (const ad of c.ads ?? []) {
        for (const ack of ad.eventTracking?.ackImpressions ?? [])
          delete ack.url;
        if (ad.adInfo) delete ad.adInfo.responseSize;
      }
      return obj;
    }

    static injectAdFree(obj) {
      if (obj?.content) obj.content.adFree = true;
      return obj;
    }

    static disableAdDisplay(obj) {
      const resp = obj?.content?.playerAdDisplayResponse;
      if (resp) { resp.preRoll = false; resp.midRoll = false; }
      return obj;
    }
  }

  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  //  NetworkInterceptor – Fetch & XHR 인터셉터 본체
  // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  class NetworkInterceptor {
    static BANNER_RE = /^https:\/\/nng-phinf\.pstatic\.net\/[A-Za-z]+\/[A-Za-z0-9._-]+\/Banner_[A-Za-z0-9_-]+\.[A-Za-z]+$/;
    static VETA_RE = /veta\.naver\.com\/(?:vas|gfp|call)/;

    #routes;
    #log;
    #xhrResponseDesc;
    #xhrResponseTextDesc;

    constructor() {
      this.#log = (..._args) => {};
      this.#xhrResponseDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'response');
      this.#xhrResponseTextDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'responseText');
      this.#routes = this.#buildRoutes();
    }

    // ── 라우트 정의 ──
    #buildRoutes() {
      return [
        // 배너 이미지 차단
        new Route({
          match: (url) => NetworkInterceptor.BANNER_RE.test(url),
          action: 'block',
          label: '배너 이미지 차단',
        }),
        // Veta OPTIONS 사전요청 차단
        new Route({
          match: (url, method) => method === 'OPTIONS' && NetworkInterceptor.VETA_RE.test(url),
          action: 'block',
          label: 'Veta OPTIONS 차단',
        }),
        // ad-polling → 빈 JSON 스텁
        new Route({
          match: (url) => url.includes('api.chzzk.naver.com/ad-polling/'),
          action: 'stub',
          stubBody: () => ({ code: 200, message: null, content: {} }),
          label: 'ad-polling 빈 응답',
        }),
        // service/t → 광고 필드 제거
        new Route({
          match: (url) => url.includes('api.chzzk.naver.com/service/t/'),
          action: 'rewrite',
          mutator: ResponseMutators.pruneT,
          label: 'chzzk/t 광고 필드 제거',
        }),
        // display-status → preRoll/midRoll 비활성화
        new Route({
          match: (url) => url.includes('/ad/display-status'),
          action: 'rewrite',
          mutator: ResponseMutators.disableAdDisplay,
          label: 'display-status 광고 비활성화',
        }),
        // my-info → adFree=true
        new Route({
          match: (url) => url.includes('my-info'),
          action: 'rewrite',
          mutator: ResponseMutators.injectAdFree,
          label: 'my-info adFree 주입',
        }),
      ];
    }

    // ── 라우트 매칭 ──
    #findRoute(url, method) {
      for (const route of this.#routes) {
        if (route.match(url, method)) return route;
      }
      return null;
    }

    // ── URL 추출 헬퍼 ──
    static extractFetchUrl(args) {
      const input = args[0];
      if (typeof input === 'string') return input;
      if (input instanceof URL) return input.href;
      return input?.url ?? '';
    }

    // ── Fetch 응답 재구성 헬퍼 ──
    async #rewriteFetchResponse(response, mutator, label) {
      try {
        const json = await response.clone().json();
        mutator(json);
        this.#log(`[네트워크] ${label}`, response.url);
        const res = new Response(JSON.stringify(json), {
          status: response.status,
          statusText: response.statusText,
          headers: response.headers,
        });
        Object.defineProperty(res, 'url', { value: response.url });
        return res;
      } catch (e) {
        this.#log(`[오류] ${label} 프록시 에러:`, e);
        return response;
      }
    }

    // ── Fetch Proxy 설치 ──
    #installFetchProxy() {
      const self = this;
      window.fetch = new Proxy(window.fetch, {
        apply(target, thisArg, args) {
          const url = NetworkInterceptor.extractFetchUrl(args);
          const method = (args[1]?.method ?? 'GET').toUpperCase();
          const route = self.#findRoute(url, method);

          if (!route) return Reflect.apply(target, thisArg, args);

          switch (route.action) {
            case 'block':
              self.#log(`[네트워크] ${route.label} (Fetch)`, url);
              throw new TypeError('요청 실패 (CQC 프록시에 의해 차단됨)');

            case 'stub': {
              const body = route.stubBody();
              return Promise.resolve(
                new Response(JSON.stringify(body), {
                  status: 200,
                  statusText: 'OK',
                  headers: { 'Content-Type': 'application/json' },
                }),
              );
            }

            case 'rewrite':
              return (async () => {
                const res = await Reflect.apply(target, thisArg, args);
                return self.#rewriteFetchResponse(res, route.mutator, route.label);
              })();
          }
        },
      });
    }

    // ── XHR 에러 발송 헬퍼 ──
    #abortXhr(xhr, label) {
      this.#log(`[네트워크] ${label}`);
      queueMicrotask(() => {
        xhr.dispatchEvent(new Event('error'));
        xhr.dispatchEvent(new Event('loadend'));
      });
    }

    // ── XHR Proxy 설치 ──
    #installXhrProxy() {
      const self = this;
      const nativeOpen = XMLHttpRequest.prototype.open;
      const nativeSend = XMLHttpRequest.prototype.send;

      // open → method/url 캡처
      XMLHttpRequest.prototype.open = new Proxy(nativeOpen, {
        apply(target, xhr, args) {
          xhr._cqcMethod = args[0];
          const rawUrl = args[1];
          xhr._cqcUrl = typeof rawUrl === 'string' ? rawUrl : (rawUrl instanceof URL ? rawUrl.href : '');
          return Reflect.apply(target, xhr, args);
        },
      });

      // send → 라우트 매칭 + 응답 변조
      XMLHttpRequest.prototype.send = new Proxy(nativeSend, {
        apply(target, xhr, args) {
          const url = xhr._cqcUrl ?? '';
          const method = (xhr._cqcMethod ?? 'GET').toUpperCase();
          const route = self.#findRoute(url, method);

          if (!route) return Reflect.apply(target, xhr, args);

          // block / stub(XHR에선 에러로 처리)
          if (route.action === 'block') {
            self.#abortXhr(xhr, `${route.label} (XHR)`);
            return;
          }

          if (route.action === 'stub' || route.action === 'rewrite') {
            // response / responseText getter 오버라이드 (인스턴스 레벨)
            Object.defineProperty(xhr, 'response', {
              get() { return this._cqcRes !== undefined ? this._cqcRes : self.#xhrResponseDesc.get.call(this); },
              configurable: true,
            });
            Object.defineProperty(xhr, 'responseText', {
              get() { return this._cqcResTxt !== undefined ? this._cqcResTxt : self.#xhrResponseTextDesc.get.call(this); },
              configurable: true,
            });

            xhr.addEventListener('readystatechange', function onDone() {
              if (xhr.readyState !== 4) return;
              try {
                let data;
                if (route.action === 'stub') {
                  data = route.stubBody();
                } else {
                  data = xhr.response;
                  if (typeof data === 'string') data = JSON.parse(data);
                  data = route.mutator(data);
                }
                xhr._cqcRes = data;
                xhr._cqcResTxt = JSON.stringify(data);
                self.#log(`[네트워크] ${route.label} (XHR)`, url);
              } catch { /* 파싱 불가 응답 무시 */ }
            });
          }

          return Reflect.apply(target, xhr, args);
        },
      });
    }

    // ── 진입점 ──
    install() {
      this.#installFetchProxy();
      this.#installXhrProxy();
    }
  }

  // ── 실행 ──
  new NetworkInterceptor().install();
})();
