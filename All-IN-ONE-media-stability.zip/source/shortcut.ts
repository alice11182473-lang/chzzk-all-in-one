// @ts-nocheck
import './src/utils/StorageBridge';
import Browser from 'webextension-polyfill';

/**
 * @param {string} s - CSS 선택자
 * @returns {any}
 */
const $ = (s) => document.querySelector(s);

/**
 * @param {string} s - CSS 선택자
 * @returns {any}
 */
const $$ = (s) => document.querySelectorAll(s);

/** @type {any} */
let cfg = null;

/**
 * 백그라운드 서비스 워커로 메시지를 전송합니다.
 * @param {string} type
 * @param {any} [payload]
 * @returns {Promise<any>}
 */
const msg = async (type, payload) => {
  try {
    return await Browser.runtime.sendMessage({ type, payload });
  } catch (err) {
    console.error(`[CQC:Shortcut] Message failed: ${type}`, err);
    return null;
  }
};

/**
 * @param {any} shortcut 
 * @returns {string}
 */
const formatShortcut = (shortcut) => {
  if (!shortcut) return '없음';
  const parts = [];
  if (shortcut.ctrl) parts.push('Ctrl');
  if (shortcut.shift) parts.push('Shift');
  if (shortcut.alt) parts.push('Alt');
  if (shortcut.meta) parts.push('Meta');

  let keyText = shortcut.key;
  if (keyText === ' ') keyText = 'Space';
  else if (keyText) keyText = keyText.toUpperCase();

  if (keyText) parts.push(keyText);
  return parts.join('+') || '없음';
};

const updateAllocatedKeys = () => {
  $$('.sc-key').forEach((/** @type {HTMLElement} */ keyEl) => {
    keyEl.classList.remove('allocated');
  });

  if (!cfg || !cfg.customShortcuts) return;

  const allocatedKeys = new Set();
  for (const shortcut of Object.values(cfg.customShortcuts)) {
    if (shortcut && shortcut.key) {
      allocatedKeys.add(shortcut.key.toLowerCase());
    }
  }

  $$('.sc-key').forEach((/** @type {HTMLElement} */ keyEl) => {
    const key = keyEl.dataset.key;
    if (key && allocatedKeys.has(key.toLowerCase())) {
      keyEl.classList.add('allocated');
    }
  });
};

const clearShortcut = (action) => {
  if (!cfg.customShortcuts) cfg.customShortcuts = {};
  cfg.customShortcuts[action] = null;
  save();
  renderShortcuts();
};

const renderShortcuts = () => {
  if (!cfg || !cfg.customShortcuts) return;
  for (const [action, shortcut] of Object.entries(cfg.customShortcuts)) {
    const el = $(`#sc-val-${action}`);
    if (el) {
      el.textContent = formatShortcut(shortcut);
    }
  }
  updateAllocatedKeys();
};

const save = () => {
  msg('SAVE_SETTINGS', cfg);
};

document.addEventListener('DOMContentLoaded', async () => {
  cfg = await msg('GET_SETTINGS');
  if (!cfg) {
    console.warn('[CQC:Shortcut] Settings not loaded, using defaults.');
    cfg = {};
  }
  const defaultShortcuts = {
    'screenshot': { key: 's', ctrl: true, shift: true, alt: false, meta: false },
    'record': { key: 'r', ctrl: true, shift: true, alt: false, meta: false },
    'stats': { key: 'd', ctrl: true, shift: true, alt: false, meta: false },
    'backward': { key: '[', ctrl: false, shift: false, alt: false, meta: false },
    'forward': { key: ']', ctrl: false, shift: false, alt: false, meta: false },
    'chatCollector': { key: 'k', ctrl: true, shift: true, alt: false, meta: false }
  };
  cfg.customShortcuts = { ...defaultShortcuts, ...(cfg.customShortcuts || {}) };
  renderShortcuts();
  shortcutBind();
});

const shortcutBind = () => {
  /** @type {string|null} */
  let currentAction = null;
  let currentCtrl = false;
  let currentShift = false;
  let currentAlt = false;

  const btnClose = $('#btn-close-shortcut-modal');

  const updateModifierButtons = () => {
    $('#sc-mod-ctrl')?.classList.toggle('active', currentCtrl);
    $('#sc-mod-shift')?.classList.toggle('active', currentShift);
    $('#sc-mod-alt')?.classList.toggle('active', currentAlt);
  };

  const updateActionButtons = () => {
    $$('.sc-action-btn').forEach((/** @type {HTMLElement} */ btn) => {
      btn.classList.toggle('active', btn.dataset.action === currentAction);
    });
  };

  const updateKeysReservedUI = () => {
    const hasMod = currentCtrl || currentShift || currentAlt;
    $$('.sc-key').forEach((/** @type {HTMLElement} */ keyEl) => {
      const key = keyEl.dataset.key;
      if (['f', 'm', ' ', 'j', 't'].includes(key || '')) {
        if (hasMod) {
          keyEl.classList.remove('reserved');
          keyEl.removeAttribute('title');
        } else {
          keyEl.classList.add('reserved');
          let title = '치지직 ';
          if (key === 'f') title += '전체화면';
          else if (key === 'm') title += '음소거';
          else if (key === ' ') title += '재생';
          else if (key === 'j') title += '되감기';
          else if (key === 't') title += '넓은 화면';
          title += ' 기본 키 (단독 할당 불가)';
          keyEl.setAttribute('title', title);
        }
      }
    });
  };

  if (btnClose) {
    btnClose.addEventListener('click', () => {
      window.close();
    });
  }

  $$('.sc-mod-btn').forEach((/** @type {HTMLElement} */ btn) => {
    btn.addEventListener('click', () => {
      const id = btn.id;
      if (id === 'sc-mod-ctrl') currentCtrl = !currentCtrl;
      else if (id === 'sc-mod-shift') currentShift = !currentShift;
      else if (id === 'sc-mod-alt') currentAlt = !currentAlt;
      updateModifierButtons();
      updateKeysReservedUI();
    });
  });

  $$('.sc-action-btn').forEach((/** @type {HTMLElement} */ btn) => {
    btn.addEventListener('click', () => {
      currentAction = btn.dataset.action ?? null;
      updateActionButtons();
      if (currentAction && cfg?.customShortcuts?.[currentAction]) {
        const shortcut = cfg.customShortcuts[currentAction];
        currentCtrl = !!shortcut.ctrl;
        currentShift = !!shortcut.shift;
        currentAlt = !!shortcut.alt;
        updateModifierButtons();
        updateKeysReservedUI();
      }
    });
  });

  $$('.sc-key').forEach((/** @type {HTMLElement} */ keyEl) => {
    keyEl.addEventListener('click', () => {
      if (!currentAction) {
        alert('설정할 액션을 먼저 선택해 주세요.');
        return;
      }
      const key = keyEl.dataset.key;
      if (!key) return;

      // 특수 기능/제어 키는 단독 단축키 지정에서 제외
      if (['control', 'shift', 'alt', 'meta', 'capslock', 'tab', 'backspace', 'enter', 'menu', 'esc'].includes(key)) {
        return;
      }

      const hasMod = currentCtrl || currentShift || currentAlt;
      if (['f', 'm', ' ', 'j', 't'].includes(key) && !hasMod) {
        alert(`'${key === ' ' ? 'Space' : key.toUpperCase()}' 키는 치지직 기본 단축키와 충돌합니다. 조합키(Ctrl, Shift, Alt)와 함께 설정하거나 다른 키를 선택해 주세요.`);
        return;
      }

      if (!cfg.customShortcuts) cfg.customShortcuts = {};
      cfg.customShortcuts[currentAction] = {
        key: key,
        ctrl: currentCtrl,
        shift: currentShift,
        alt: currentAlt,
        meta: false
      };
      save();
      renderShortcuts();
    });
  });

  document.addEventListener('keydown', (/** @type {KeyboardEvent} */ e) => {
    if (!currentAction) return;

    if (e.key === 'Escape') {
      window.close();
      return;
    }

    if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) {
      currentCtrl = e.ctrlKey;
      currentShift = e.shiftKey;
      currentAlt = e.altKey;
      updateModifierButtons();
      updateKeysReservedUI();
      return;
    }

    e.preventDefault();
    e.stopPropagation();

    const key = e.key.toLowerCase();

    // Delete/Backspace → 단축키 해제
    if (key === 'delete' || key === 'backspace') {
      clearShortcut(currentAction);
      const statusEl = $('#sc-status');
      if (statusEl) statusEl.textContent = `'${currentAction}' 단축키가 해제되었습니다.`;
      return;
    }

    if (['capslock', 'tab', 'enter', 'contextmenu'].includes(key)) {
      return;
    }
    const ctrl = e.ctrlKey;
    const shift = e.shiftKey;
    const alt = e.altKey;

    const hasMod = ctrl || shift || alt;
    if (['f', 'm', ' ', 'j', 't'].includes(key) && !hasMod) {
      alert(`'${key === ' ' ? 'Space' : key.toUpperCase()}' 키는 치지직 기본 단축키와 충돌합니다. 조합키(Ctrl, Shift, Alt)와 함께 설정하거나 다른 키를 선택해 주세요.`);
      return;
    }

    if (!cfg.customShortcuts) cfg.customShortcuts = {};
    cfg.customShortcuts[currentAction] = {
      key: key,
      ctrl: ctrl,
      shift: shift,
      alt: alt,
      meta: false
    };

    save();
    renderShortcuts();

    currentCtrl = ctrl;
    currentShift = shift;
    currentAlt = alt;
    updateModifierButtons();
    updateKeysReservedUI();
  }, true);
};

// 윈도우 크기 강제 고정 (540x620)
window.addEventListener('resize', () => {
  const targetW = 540;
  const targetH = 620;
  if (window.outerWidth !== targetW || window.outerHeight !== targetH) {
    try {
      window.resizeTo(targetW, targetH);
    } catch (e) {
      console.warn('[CQC:Shortcut] Failed to force resize windows:', e);
    }
  }
});
