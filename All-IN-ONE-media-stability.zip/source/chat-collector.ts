// @ts-nocheck
/** @ts-check */
import { SELECTORS, log, getChannelData, getFiberNode } from './dom-utils';
import dbManager from './shared/db';

function cqcCollectorMounts(selectors) {
  const root = document.querySelector(selectors.CHAT_ASIDE) ||
    document.querySelector('textarea[placeholder*="채팅"], pre[placeholder*="채팅"]')?.closest('aside');
  const scope = root || document;
  let header = scope.querySelector(selectors.CHAT_HEADER);
  if (!header && root) {
    // Locate the compact chat title row without relying on CSS build hashes.
    const title = [...root.querySelectorAll('h1,h2,h3,strong,span,div')].find(el =>
      el.children.length === 0 && el.textContent.trim() === '채팅');
    for (let el = title?.parentElement; el && el !== root; el = el.parentElement) {
      if (el.getBoundingClientRect().height > 100) break;
      if (el.querySelector('button')) { header = el; break; }
    }
  }
  let list = scope.querySelector(selectors.CHAT_LIST_WRAPPER_ALT);
  if (!list && root) {
    const nick = [...root.querySelectorAll('[class*="nickname"]')].find(el =>
      !el.closest('.cqc-collected-chat-panel'));
    for (let el = nick?.parentElement; el && el !== root; el = el.parentElement) {
      if (/auto|scroll/.test(getComputedStyle(el).overflowY)) { list = el; break; }
    }
  }
  return { root, header, list };
}
function cqcCollectorInsert(header, wrapper, reference) {
  // insertBefore requires a direct child; CHZZK may nest its menu button.
  let anchor = reference;
  while (anchor && anchor.parentElement !== header) anchor = anchor.parentElement;
  if (getComputedStyle(header).position === 'static') header.style.position = 'relative';
  header.insertBefore(wrapper, anchor || null);
}

/** @type {any} */
let localSettings = null;
/** @type {any} */
let localPost = null;

/** @type {any} */
let chatCollectorInterval = null;
/** @type {any} */
let loadingTimeout = null;

/**
 * 모아보기 헤더 버튼 상태(색상 및 라벨)를 갱신합니다.
 */
const updateCollectorButtonState = () => {
  const btn = document.querySelector('.cqc-collector-toggle-btn');
  if (!btn) return;

  const isActive = !!(window.cqcChatCollectorActive);
  const icon = btn.querySelector('.cqc-collector-icon');

  if (isActive) {
    btn.classList.add('cqc-active');
    btn.setAttribute('aria-label', '채팅 모아보기 (활성화됨)');
    if (icon) {
      // @ts-ignore
      icon.style.color = '#00ffa3';
      // @ts-ignore
      icon.style.filter = 'drop-shadow(0 0 4px rgba(0, 255, 163, 0.6))';
    }
  } else {
    btn.classList.remove('cqc-active');
    btn.setAttribute('aria-label', '채팅 모아보기 (비활성화됨)');
    if (icon) {
      // @ts-ignore
      icon.style.color = '';
      // @ts-ignore
      icon.style.filter = '';
    }
  }

  // 즉시 분리 패널 적용/제거
  const isSplitModeActive = isActive && localSettings?.chatCollectorSplitMode === true;
  if (isSplitModeActive) {
    ensureSplitPanel();
  } else {
    removeSplitPanel();
  }
};

/**
 * 버튼 위치(오프셋)를 동적으로 업데이트합니다.
 */
const updateHeaderButtonsLayout = () => {
  const isCollectorEnabled = localSettings?.chatCollectorIconEnabled !== false;
  const isExportEnabled = localSettings?.chatExportEnabled !== false;

  const collectorWrapper = document.querySelector('.cqc-collector-toggle-btn-wrapper');
  const exportWrapper = document.querySelector('.cqc-export-btn-wrapper');

  const isPopupChat = location.pathname.endsWith('/chat');

  if (isPopupChat) {
    // 팝업창인 경우 왼쪽 정렬
    let leftOffset = 12;
    if (collectorWrapper && isCollectorEnabled) {
      collectorWrapper.style.setProperty('right', 'auto', 'important');
      collectorWrapper.style.setProperty('left', `${leftOffset}px`, 'important');
      leftOffset += 36;
    }
    if (exportWrapper && isExportEnabled) {
      exportWrapper.style.setProperty('right', 'auto', 'important');
      exportWrapper.style.setProperty('left', `${leftOffset}px`, 'important');
      leftOffset += 36;
    }
  } else {
    // 본창인 경우 기존처럼 오른쪽 정렬
    let rightOffset = 36;
    if (collectorWrapper && isCollectorEnabled) {
      collectorWrapper.style.setProperty('left', 'auto', 'important');
      collectorWrapper.style.setProperty('right', `${rightOffset}px`, 'important');
      rightOffset += 36;
    }
    if (exportWrapper && isExportEnabled) {
      exportWrapper.style.setProperty('left', 'auto', 'important');
      exportWrapper.style.setProperty('right', `${rightOffset}px`, 'important');
      rightOffset += 36;
    }
  }
};

/**
 * 모아보기 분리 패널을 생성하고 DOM에 Sticky 레이어로 추가합니다.
 */
const ensureSplitPanel = () => {
  const chatWrapper = cqcCollectorMounts(SELECTORS).list;
  if (!chatWrapper || !chatWrapper.parentElement) return;

  if (document.querySelector('.cqc-collected-chat-panel')) return;

  // flex 자식으로서 찌그러질 수 있게 minHeight 0 보장
  (chatWrapper as HTMLElement).style.minHeight = '0';

  const panel = document.createElement('div');
  panel.className = 'cqc-collected-chat-panel';
  // 새로운 CSS 파일 없이 기존 채팅창과 일치하는 룩을 위해 background: inherit, 기존 border 디자인을 활용한 inline 스타일 적용 (형제 노드로 들어가므로 sticky 불필요)
  const savedHeight = localStorage.getItem('cqc_collected_panel_height') || '250px';
  panel.style.cssText = 'width:100%; box-sizing:border-box; display:flex; flex-direction:column; background:inherit; flex-shrink:0; overflow:hidden;';
  panel.style.height = savedHeight;

  const header = document.createElement('div');
  header.style.cssText = 'display:flex; justify-content:space-between; align-items:center; padding:6px 12px; font-size:11px; font-weight:700; color:rgba(255,255,255,0.5); background:rgba(0,0,0,0.15); border-bottom:1px solid rgba(255,255,255,0.05); user-select:none; width:100%; box-sizing:border-box;';
  header.innerHTML = `
    <span>모아보기 채팅</span>
    <span style="font-size:10px; cursor:pointer; opacity:0.7; font-weight:normal;" class="cqc-collected-chat-clear-btn">지우기</span>
  `;

  const list = document.createElement('div');
  list.className = 'cqc-collected-chat-list';
  // 기존 채팅창 여백과 동일하게 맞추기 위해 좌우 padding을 12px로 설정
  list.style.cssText = 'flex:1; width:100%; box-sizing:border-box; overflow-y:auto; padding:4px 12px; min-height:0;';

  const resizeHandle = document.createElement('div');
  resizeHandle.className = 'cqc-collected-chat-resize-handle';
  resizeHandle.style.cssText = 'width:100%; height:8px; cursor:ns-resize; border-bottom:2px dashed rgba(255,255,255,0.15); flex-shrink:0; background:transparent; transition:background 0.2s, border-color 0.2s; position:relative;';

  resizeHandle.addEventListener('mouseenter', () => {
    resizeHandle.style.borderBottomColor = 'rgba(0, 255, 163, 0.4)';
    resizeHandle.style.backgroundColor = 'rgba(0, 255, 163, 0.05)';
  });
  resizeHandle.addEventListener('mouseleave', () => {
    resizeHandle.style.borderBottomColor = 'rgba(255, 255, 255, 0.15)';
    resizeHandle.style.backgroundColor = 'transparent';
  });

  resizeHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const startY = e.clientY;
    const startHeight = panel.getBoundingClientRect().height;

    const onMouseMove = (moveEvent) => {
      const deltaY = moveEvent.clientY - startY;
      const newHeight = Math.max(120, Math.min(600, startHeight + deltaY));
      panel.style.height = `${newHeight}px`;
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      localStorage.setItem('cqc_collected_panel_height', `${panel.getBoundingClientRect().height}px`);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });

  panel.appendChild(header);
  panel.appendChild(list);
  panel.appendChild(resizeHandle);

  // 스크롤 영역 바로 위에 형제 노드로 배치
  chatWrapper.parentElement.insertBefore(panel, chatWrapper);

  // 지우기 버튼 이벤트 바인딩
  header.querySelector('.cqc-collected-chat-clear-btn')?.addEventListener('click', () => {
    saveCollectedChats([]);
    list.innerHTML = '';
  });

  // sessionStorage에서 초기 데이터 불러오기
  const chats = getCollectedChats();
  if (chats.length > 0) {
    list.innerHTML = chats.map(c => c.html).join('');
  }

  // 스크롤 하단 이동
  list.scrollTop = list.scrollHeight;
};

/**
 * 모아보기 분리 패널을 제거합니다.
 */
const removeSplitPanel = () => {
  const panel = document.querySelector('.cqc-collected-chat-panel');
  if (panel) {
    panel.remove();
  }
};

let inMemoryCollectorChats = [];
let currentChannelId = 'unknown';

/**
 * 초기화: 채널 로드 시 IndexedDB에서 기존 수집 채팅을 불러옴
 */
const initCollectorChats = async () => {
  const channel = getChannelData(document.body);
  currentChannelId = channel?.channelId || 'unknown';

  if (currentChannelId !== 'unknown') {
    // 만료 기일 읽기 (기본값 72시간, 0은 브라우저 종료 시 삭제)
    const retentionHours = localSettings?.chatCollectorRetentionHours ?? 72;
    
    if (retentionHours === 0) {
      // 0인 경우, 브라우저 세션(세션 쿠키) 단위로 초기화 확인
      if (!document.cookie.includes('cqc_chat_session=1')) {
        document.cookie = "cqc_chat_session=1; path=/";
        await dbManager.clearCollectorChatsByChannel(currentChannelId);
      }
    } else {
      // 지정된 기한 지난 채팅 정리
      await dbManager.clearExpiredCollectorChats(retentionHours);
    }

    // 해당 채널 채팅 불러오기
    inMemoryCollectorChats = await dbManager.getCollectorChatsByChannel(currentChannelId);
    
    // UI에 반영 (패널이 열려 있다면)
    const list = document.querySelector('.cqc-collected-chat-list');
    if (list && inMemoryCollectorChats.length > 0) {
      list.innerHTML = inMemoryCollectorChats.map(c => c.html).join('');
      list.scrollTop = list.scrollHeight;
    }
  }
};

const getCollectedChats = () => {
  return inMemoryCollectorChats;
};

const saveCollectedChats = (chats) => {
  // 전체 교체용 (초기화)
  inMemoryCollectorChats = chats;
  if (chats.length === 0) {
    dbManager.clearCollectorChatsByChannel(currentChannelId);
  }
};

/**
 * 분리 패널 리스트 레이어에 노드를 복제해 추가합니다.
 */
const appendMessageToSplitPanel = (el, msg) => {
  const msgId = msg ? (msg.messageId || `${msg.time}-${msg.profile?.nickname}-${msg.content}`) : null;
  if (!msgId || !msg) return;

  const chats = getCollectedChats();
  
  // 1. 중복 확인 (messageId 기반)
  if (chats.some((c) => c.msgId === msgId)) {
    return;
  }

  // 2. DOM 복제 및 HTML 추출
  const clone = el.cloneNode(true);
  clone.classList.add('cqc-collected-item');
  const html = clone.outerHTML;

  // 3. 배열에 추가 및 시간순 정렬
  const chatObj = { 
    msgId, 
    channelId: currentChannelId,
    time: msg.time || Date.now(), 
    html 
  };
  chats.push(chatObj);
  chats.sort((a, b) => a.time - b.time);

  // 4. 최대 200개 유지
  if (chats.length > 200) {
    chats.splice(0, chats.length - 200);
  }

  // 인메모리 배열 및 DB 저장 (비동기 처리)
  inMemoryCollectorChats = chats;
  dbManager.addCollectorChat(chatObj).catch(e => console.error(e));

  // 5. DOM 렌더링 (패널이 열려있을 때만)
  const list = document.querySelector('.cqc-collected-chat-list');
  if (list) {
    // 임시: 전체 렌더링 (가장 확실한 시간순 보장)
    list.innerHTML = chats.map(c => c.html).join('');
    // 스크롤 하단 자동 이동
    list.scrollTop = list.scrollHeight;
  }
};

// 전역 인젝션 메시지 브릿지 콜백
(window as any).cqcAddMessageToCollectedPanel = (el, msg) => {
  if (!window.cqcChatCollectorActive) return;

  const collectorRoles = localSettings?.chatCollectorRoles || ['streamer', 'manager'];
  const collectorUsers = (localSettings?.chatCollectorTargetUsers || []).map(u => u.toLowerCase().trim());

  const role = (msg.profile?.userRoleCode || '').toLowerCase();
  const nickname = (msg.profile?.nickname || '').toLowerCase().trim();
  const matchedRole = collectorRoles.some(cr => role.includes(cr));
  const matchedUser = collectorUsers.includes(nickname);

  let isDonation = false;
  if (collectorRoles.includes('donation')) {
    const payAmount = msg.extras?.payAmount ?? msg._cqcParsedExtras?.payAmount;
    if (typeof payAmount === 'number') {
      isDonation = true;
    }
  }

  if (matchedRole || matchedUser || isDonation) {
    appendMessageToSplitPanel(el, msg);
  }
};

/**
 * 채팅 기록을 TXT 파일로 다운로드합니다.
 */
const exportChatHistory = () => {
  try {
    const hooks = new Set();
    if (window.cqcCurrentChatHooks) {
      window.cqcCurrentChatHooks.forEach(h => hooks.add(h));
    }
    if (window.cqcCurrentChatHook) {
      hooks.add(window.cqcCurrentChatHook);
    }

    const messages = [];
    const seenIds = new Set();

    hooks.forEach(hook => {
      const list = hook.memoizedState;
      if (Array.isArray(list)) {
        list.forEach(msg => {
          if (!msg) return;
          if (msg.noticeType) return; // 공지사항 제외
          const msgId = msg.messageId || `${msg.time}-${msg.profile?.nickname}-${msg.content}`;
          if (!seenIds.has(msgId)) {
            seenIds.add(msgId);
            messages.push(msg);
          }
        });
      }
    });

    // 시간 순서 정렬
    messages.sort((a, b) => (Number(a.time) || 0) - (Number(b.time) || 0));

    if (messages.length === 0) {
      alert('내보낼 채팅 기록이 없습니다.');
      return;
    }

    // 포맷팅
    const lines = messages.map(msg => {
      const timeNum = Number(msg.time);
      let timeStr = '';
      if (!isNaN(timeNum)) {
        const d = new Date(timeNum);
        const hh = String(d.getHours()).padStart(2, '0');
        const mm = String(d.getMinutes()).padStart(2, '0');
        const ss = String(d.getSeconds()).padStart(2, '0');
        timeStr = `[${hh}:${mm}:${ss}] `;
      }
      let nickname = msg._cqcOriginalNickname || msg.profile?.nickname;
      if (!nickname) {
        if (msg.noticeType) {
          nickname = '공지';
        } else {
          nickname = '시스템';
        }
      }

      let content = msg.originalContent || msg.content || '';
      if (Array.isArray(content)) {
        content = content.map(item => {
          if (typeof item === 'string') return item;
          if (item && typeof item === 'object') {
            if (item.type === 'text') return item.value || '';
            if (item.type === 'emoji') return `{${item.name || '이모티콘'}}`;
          }
          return '';
        }).join('');
      } else if (typeof content === 'object') {
        content = JSON.stringify(content);
      } else {
        content = String(content);
      }

      return `${timeStr}${nickname}: ${content}`;
    });

    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;

    // 파일명 형식: chat_export_[스트리머]_[시간].txt
    const channel = getChannelData(document.body);
    const channelName = channel?.channelName || '';
    const channelNameSafe = channelName ? `${channelName.replace(/[\/\\?%*:|"<>\s]/g, '_')}_` : '';

    const now = new Date();
    const yyyy = now.getFullYear();
    const MM = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');

    link.download = `chat_export_${channelNameSafe}${yyyy}${MM}${dd}_${hh}${mm}${ss}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  } catch (err) {
    log('Injected', '채팅 내보내기 중 에러 발생:', err);
    alert('채팅 내보내기에 실패했습니다.');
  }
};

/**
 * 채팅 영역 헤더에 토글 버튼들을 주입합니다.
 */
const injectChatHeaderButtons = () => {
  try {
    // Panel mounting must not depend on the optional menu/header button.
    if (window.cqcChatCollectorActive && localSettings?.chatCollectorSplitMode === true) ensureSplitPanel();
    else removeSplitPanel();
    const headerContainer = cqcCollectorMounts(SELECTORS).header;
    if (!headerContainer) return;

    // 현재 채널 인식 후 모아보기 채팅 데이터 로드 (최초 1회 또는 채널 변경 시)
    const channel = getChannelData(document.body);
    const actualChannelId = channel?.channelId;
    if (actualChannelId && actualChannelId !== currentChannelId) {
      initCollectorChats().catch(e => console.error('Failed to init collector chats:', e));
    }

    // 더보기 메뉴 버튼을 탐색하여 그 부모(래퍼) 왼쪽에 배치
    const moreMenuBtn = headerContainer.querySelector(SELECTORS.CHAT_MORE_MENU_BTN);
    const moreMenuWrapper = moreMenuBtn?.parentElement || null;

    // 1. 모아보기 버튼
    const isCollectorIconEnabled = localSettings?.chatCollectorIconEnabled !== false;
    const existingCollectorWrapper = document.querySelector('.cqc-collector-toggle-btn-wrapper');

    if (isCollectorIconEnabled) {
      if (!existingCollectorWrapper) {
        const btnWrapper = document.createElement('div');
        btnWrapper.className = 'live_chatting_header_wrapper__GyePF cqc-collector-toggle-btn-wrapper';

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'live_chatting_header_button__t2pa1 cqc-collector-toggle-btn';
        button.setAttribute('aria-label', '채팅 모아보기');
        button.setAttribute('data-tooltip', '채팅 모아보기');

        button.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="cqc-collector-icon">
            <path d="M4 6H20M7 12H17M10 18H14" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `;

        button.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (typeof (/** @type {any} */(window)).cqcToggleChatCollector === 'function') {
            (/** @type {any} */(window)).cqcToggleChatCollector();
          }
        });

        btnWrapper.appendChild(button);
        cqcCollectorInsert(headerContainer, btnWrapper, moreMenuWrapper);
      }
      updateCollectorButtonState();
    } else {
      existingCollectorWrapper?.remove();
    }

    // 2. 내보내기 버튼
    const isExportEnabled = localSettings?.chatExportEnabled !== false;
    const existingExportWrapper = document.querySelector('.cqc-export-btn-wrapper');

    if (isExportEnabled) {
      if (!existingExportWrapper) {
        const btnWrapper = document.createElement('div');
        btnWrapper.className = 'live_chatting_header_wrapper__GyePF cqc-export-btn-wrapper';

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'live_chatting_header_button__t2pa1 cqc-export-btn';
        button.setAttribute('aria-label', '채팅 내보내기');
        button.setAttribute('data-tooltip', '채팅 내보내기 (TXT)');

        button.innerHTML = `
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="cqc-export-icon" style="color: currentColor;">
            <path d="M12 15V3m0 12l-4-4m4 4l4-4M4 17v1a2 2 0 002 2h12a2 2 0 002-2v-1" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        `;

        button.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          exportChatHistory();
        });

        btnWrapper.appendChild(button);
        cqcCollectorInsert(headerContainer, btnWrapper, moreMenuWrapper);
      }
    } else {
      existingExportWrapper?.remove();
    }

    // 3. 레이아웃 동적 갱신
    updateHeaderButtonsLayout();

    // 4. 모아보기 분리 패널 제어
    const isSplitModeActive = window.cqcChatCollectorActive && localSettings?.chatCollectorSplitMode === true;
    if (isSplitModeActive) {
      ensureSplitPanel();
    } else {
      removeSplitPanel();
    }

    // 전역 상태 갱신 바인딩 유지
    (/** @type {any} */(window)).cqcUpdateCollectorButtonState = updateCollectorButtonState;

  } catch (err) {
    log('Injected', '채팅 헤더 버튼 주입 중 에러 발생:', err);
  }
};

/**
 * @param {any} settings
 * @param {Function} post
 */
export const initChatCollector = (settings, post) => {
  localSettings = settings;
  localPost = post;

  (window as any).cqcUpdateChatCollectorSettings = (newSettings) => {
    localSettings = newSettings;
  };

  const isPopupChat = location.pathname.endsWith('/chat');
  if (isPopupChat) {
    document.body.classList.add('cqc-popup-chat');
    document.documentElement.style.setProperty('overflow', 'hidden', 'important');
    document.body.style.setProperty('overflow', 'hidden', 'important');
  }

  // 기존 인터벌 정리
  if (chatCollectorInterval) { clearInterval(chatCollectorInterval); chatCollectorInterval = null; }

  // 1초 간격으로 채팅 헤더 마운트 감지하여 버튼 주입
  chatCollectorInterval = setInterval(() => {
    injectChatHeaderButtons();
  }, 1000);

  // 최초 즉시 실행 시도
  injectChatHeaderButtons();
};

/**
 * 모듈 해제 시 생성된 리소스를 전부 정리합니다.
 */
export const cleanupChatCollector = () => {
  if (chatCollectorInterval) {
    clearInterval(chatCollectorInterval);
    chatCollectorInterval = null;
  }
  if (loadingTimeout) {
    clearTimeout(loadingTimeout);
    loadingTimeout = null;
  }
  // 헤더 버튼 및 래퍼 제거
  document.querySelector('.cqc-collector-toggle-btn-wrapper')?.remove();
  document.querySelector('.cqc-export-btn-wrapper')?.remove();
  // 분리 패널 제거
  removeSplitPanel();
  // 로딩 화면 제거
  document.querySelectorAll('.cqc-skeleton-wrapper').forEach(el => el.remove());

  delete (/** @type {any} */(window)).cqcUpdateCollectorButtonState;
};


/**
 * 채팅 모아보기 상태 변화에 따른 UI 피드백을 관리합니다.
 * 안내문 UI를 중앙에 로드하고 0.5초 후 해제합니다.
 */
export const updateChatCollectorUIState = () => {
  try {
    const isActive = !!(window.cqcChatCollectorActive);
    log('Injected', `채팅 모아보기 상태 업데이트: ${isActive ? '활성화' : '비활성화'}`);

    // 기존 타이머 클리어
    if (loadingTimeout) {
      clearTimeout(loadingTimeout);
      loadingTimeout = null;
    }

    // 기존 UI 제거
    document.querySelectorAll('.cqc-skeleton-wrapper').forEach(el => el.remove());

    const container = document.querySelector(SELECTORS.CHAT_LIST_CONTAINER);
    if (!container) return;

    // 안내문 래퍼 생성
    const wrapper = document.createElement('div');
    wrapper.className = 'cqc-skeleton-wrapper';

    // 부모 배경색 감지하여 자연스러운 오버레이 배경 지정
    const parentBg = window.getComputedStyle(container.parentElement || container).backgroundColor;
    if (parentBg && parentBg !== 'rgba(0, 0, 0, 0)' && parentBg !== 'transparent') {
      wrapper.style.backgroundColor = parentBg;
    } else {
      wrapper.style.backgroundColor = 'rgb(20, 21, 23)';
    }

    // 로딩 중 안내문 추가
    const notice = document.createElement('div');
    notice.className = 'cqc-skeleton-loading-text';

    // 로딩 SVG 아이콘 적용
    const svgIcon = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="cqc-loading-spinner" style="animation: cqc-spin 1s linear infinite;">
           <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/>
         </svg>`;

    const textSpan = document.createElement('span');
    textSpan.textContent = isActive ? '모아보기 필터링 적용 중...' : '전체 채팅 불러오는 중...';

    notice.innerHTML = svgIcon;
    notice.appendChild(textSpan);
    wrapper.appendChild(notice);

    // 화면 최상단 또는 적합한 위치에 삽입
    container.appendChild(wrapper);

    let isFinished = false;
    const fadeOutOverlay = () => {
      if (isFinished) return;
      isFinished = true;

      wrapper.style.transition = 'opacity 0.15s ease';
      wrapper.style.opacity = '0';
      setTimeout(() => {
        wrapper.remove();
      }, 150);
    };

    // 실시간 렌더링 완료 감지를 위한 MutationObserver 설정
    const observer = new MutationObserver((mutations) => {
      // 스켈레톤 팝업 외의 실제 채팅 컴포넌트(React) 변화가 감지되면 해제
      const isReactMutation = mutations.some(mutation => {
        const added = Array.from(mutation.addedNodes);
        const removed = Array.from(mutation.removedNodes);
        return added.concat(removed).some((node: any) => {
          return !(node.classList && node.classList.contains('cqc-skeleton-wrapper'));
        });
      });

      if (isReactMutation) {
        observer.disconnect();
        // 브라우저가 변경사항을 실제로 그릴 수 있도록 2프레임 대기 후 제거
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            fadeOutOverlay();
          });
        });
      }
    });

    observer.observe(container, { childList: true, subtree: true });

    // 안전 타임아웃 (800ms) - 아무 변화가 없거나 굳을 경우 대비
    loadingTimeout = setTimeout(() => {
      observer.disconnect();
      fadeOutOverlay();
      loadingTimeout = null;
    }, 800);

  } catch (err) {
    log('Injected', '채팅 모아보기 UI 상태 업데이트 에러:', err);
  }
};
