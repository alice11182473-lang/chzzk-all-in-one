// @ts-nocheck
/** @ts-check */
import {
    SELECTORS,
    getComponentFiber,
    getChannelData,
    log as baseLog
} from './dom-utils';

/**
 * @description 치지직 영상 리스트 커스텀 정렬 및 엔진 해킹 모듈
 */

const log = (...args) => baseLog('VideoSort', ...args);

/** 
 * 현재까지 분석된 핵심 Hook 인덱스
 * Chzzk 업데이트 시 변경될 수 있음
 */
const HOOK_INDICES = {
    RENDER_LIMIT: 7,
    GENERATOR: 31
};

/**
 * 모든 영상 카드를 강제로 생성합니다.
 * @param {any} fiber - Rft 컴포넌트의 Fiber 노드
 */
const overdriveList = (fiber) => {
    try {
        const hooks = [];
        let h = fiber.memoizedState;
        while (h) { hooks.push(h); h = h.next; }

        const limitHook = hooks[HOOK_INDICES.RENDER_LIMIT];
        const generatorHook = hooks[HOOK_INDICES.GENERATOR];

        if (!limitHook || !generatorHook) throw new Error('Hook을 찾을 수 없습니다.');

        // 원래 값 저장
        const originalLimit = limitHook.memoizedState;
        const originalBase = limitHook.baseState;

        // 1. 렌더링 제한 해제 (20 -> 1000)
        limitHook.memoizedState = 1000;
        limitHook.baseState = 1000;

        // 2. 카드 생성 엔진 가동
        const genFunc = Array.isArray(generatorHook.memoizedState) 
            ? generatorHook.memoizedState[0] 
            : generatorHook.memoizedState;

        if (typeof genFunc === 'function') {
            const fakeEntries = [{ isIntersecting: true, target: document.body }];
            // 엔진을 여러 번 호출하여 모든 데이터를 쏟아내게 함
            for (let i = 0; i < 3; i++) genFunc(fakeEntries);

            // 상태 복구 (React 충돌 방지)
            setTimeout(() => {
                try {
                    limitHook.memoizedState = originalLimit;
                    limitHook.baseState = originalBase;
                    log('엔진 상태 복구 완료');
                } catch (e) {
                    log('엔진 상태 복구 실패:', e);
                }
            }, 1000);

            return true;
        }
    } catch (e) {
        log('엔진 오버드라이브 실패:', e);
    }
    return false;
};

/**
 * 순차적 페이드-업 애니메이션과 함께 정렬을 수행합니다.
 * @param {boolean} desc - 시청자 많은 순 여부
 */
const sortWithStaggeredFade = async (desc) => {
    const container = document.querySelector(SELECTORS.VIDEO_LIST);
    if (!container) return;

    // container 내부의 비디오 아이템들만 수집하여 사이드바 등 외부 요소 유입 방지
    const itemEls = Array.from(container.querySelectorAll(SELECTORS.VIDEO_ITEM));
    if (itemEls.length === 0) return;

    // 1. 데이터 수집 및 정렬
    const items = itemEls.map(el => {
        const data = getChannelData(el);
        return { el, viewers: data?.viewers || 0 };
    });

    items.sort((a, b) => desc ? b.viewers - a.viewers : a.viewers - b.viewers);

    // 2. 애니메이션: 페이드 아웃
    itemEls.forEach(el => {
        // @ts-ignore
        el.style.transition = 'opacity 0.2s ease';
        // @ts-ignore
        el.style.opacity = '0';
    });

    await new Promise(r => setTimeout(r, 200));

    // 3. DOM 재배치
    const fragment = document.createDocumentFragment();
    items.forEach(item => {
        item.el.classList.add('cqc-item-hidden');
        // @ts-ignore
        item.el.style.opacity = '';
        fragment.appendChild(item.el);
    });
    container.appendChild(fragment);

    // 4. 애니메이션: 순차적 등장
    items.forEach((item, index) => {
        setTimeout(() => {
            item.el.classList.remove('cqc-item-hidden');
            item.el.classList.add('cqc-animate');
            setTimeout(() => item.el.classList.remove('cqc-animate'), 600);
        }, index * 20);
    });

    log(`정렬 완료: ${desc ? '많은' : '적은'} 순 (${items.length}개)`);
};

/**
 * 정렬 버튼들을 주입합니다.
 */
const injectSortButtons = () => {
    // lives 페이지(/lives, /lives/all 등)에서만 동작하도록 제한
    if (!location.pathname.startsWith('/lives')) {
        document.getElementById('CQC_SORT_DESC')?.remove();
        document.getElementById('CQC_SORT_ASC')?.remove();
        return;
    }

    // RECOMMEND 버튼의 부모 또는 lives 페이지 필터 영역의 tablist를 명시적으로 찾음
    const recommendBtn = document.getElementById('RECOMMEND');
    const tabList = recommendBtn 
        ? recommendBtn.parentElement 
        : (document.querySelector('div[class*="_filter_"] div[role="tablist"]') || document.querySelector(SELECTORS.TAB_LIST));
    if (!tabList) return;

    // 이벤트 위임을 사용하여 네이티브 버튼 클릭 감지
    if (!tabList.dataset.cqcSortBound) {
        // @ts-ignore
        tabList.dataset.cqcSortBound = 'true';
        tabList.addEventListener('click', (e) => {
            const target = /** @type {HTMLElement} */ (e.target);
            const btn = target.closest('button');
            if (btn && btn.id !== 'CQC_SORT_DESC' && btn.id !== 'CQC_SORT_ASC') {
                // 네이티브 버튼 클릭 시 커스텀 버튼 선택 해제
                document.getElementById('CQC_SORT_DESC')?.setAttribute('aria-selected', 'false');
                document.getElementById('CQC_SORT_ASC')?.setAttribute('aria-selected', 'false');
            }
        });
    }

    if (document.getElementById('CQC_SORT_DESC')) return;

    const sampleBtn = document.querySelector(`${SELECTORS.TAB_ITEM}[aria-selected="false"]`) || tabList.querySelector('button');
    if (!sampleBtn) return;

    const createBtn = (id, text, desc) => {
        const btn = /** @type {HTMLButtonElement} */(sampleBtn.cloneNode(true));
        btn.id = id;
        btn.innerText = text;
        btn.removeAttribute('aria-selected');
        btn.className = sampleBtn.className;
        
        // 원본 스타일 강제 주입
        const style = window.getComputedStyle(sampleBtn);
        btn.style.fontFamily = style.fontFamily;
        btn.style.fontSize = style.fontSize;
        btn.style.fontWeight = style.fontWeight;
        btn.style.marginLeft = '4px';

        btn.onclick = async (e) => {
            e.preventDefault();
            tabList.querySelectorAll('button').forEach(b => b.setAttribute('aria-selected', 'false'));
            btn.setAttribute('aria-selected', 'true');

            // 엔진 해킹 및 정렬
            const rft = getComponentFiber(document.querySelector(SELECTORS.VIDEO_LIST), 'Rft');
            if (rft && overdriveList(rft)) {
                await new Promise(res => setTimeout(res, 50));
                await sortWithStaggeredFade(desc);
                window.dispatchEvent(new Event('resize'));
            } else {
                log('엔진을 찾을 수 없어 기본 정렬만 시도합니다.');
                await sortWithStaggeredFade(desc);
            }
        };
        return btn;
    };

    tabList.appendChild(createBtn('CQC_SORT_DESC', '인원 많은 순', true));
    tabList.appendChild(createBtn('CQC_SORT_ASC', '인원 적은 순', false));
    log('커스텀 정렬 버튼 주입 완료');
};

/**
 * 영상 정렬 기능을 초기화합니다.
 * @param {any} settings 
 */
export const initCustomVideoSort = (settings) => {
    if (!settings?.customVideoSortEnabled) return;

    // 애니메이션 스타일 주입
    if (!document.getElementById('CQC_SORT_STYLE')) {
        const style = document.createElement('style');
        style.id = 'CQC_SORT_STYLE';
        style.textContent = `
            @keyframes cqcFadeUp {
                from { opacity: 0; transform: translateY(25px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .cqc-item-hidden { opacity: 0 !important; }
            .cqc-animate { animation: cqcFadeUp 0.5s ease forwards; }
        `;
        document.head.appendChild(style);
    }

    // 탭 리스트 로드 감제 및 주기적 주입
    setInterval(injectSortButtons, 2000);
};
