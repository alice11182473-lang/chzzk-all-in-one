import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import Browser from 'webextension-polyfill';

const ChatMultiView: React.FC = () => {
  const [channels, setChannels] = useState<any[]>([]);

  const loadChannels = useCallback(async () => {
    const res = await Browser.storage.local.get('mcChannels');
    setChannels(res.mcChannels || []);
  }, []);

  useEffect(() => {
    loadChannels();

    const listener = (changes: any, areaName: string) => {
      if (areaName === 'local' && changes.mcChannels) {
        setChannels(changes.mcChannels.newValue || []);
      }
    };

    Browser.storage.onChanged.addListener(listener);
    return () => Browser.storage.onChanged.removeListener(listener);
  }, []);

  const handleReload = useCallback(() => {
    loadChannels();
  }, [loadChannels]);

  const visibleChannels = useMemo(() => channels.slice(0, 6), [channels]);

  return (
    <>
      <div className="toolbar">
        <div className="toolbar__title">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          채팅 멀티뷰
          {channels.length > 0 && <span className="toolbar__count">({channels.length}/6)</span>}
        </div>
        <button className="toolbar__btn" onClick={handleReload} title="새로고침">↺ 새로고침</button>
      </div>

      {channels.length === 0 ? (
        <div className="empty" id="empty">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          팝업에서 채팅 채널을 추가해주세요
        </div>
      ) : (
        <div className="grid" id="grid" data-count={Math.min(channels.length, 6)}>
          {visibleChannels.map((channel, idx) => {
            const channelId = channel.id || channel;
            const channelTitle = channel.title || channelId;
            return (
              <div className="grid__item" key={channelId + idx}>
                <div className="grid__label">{channelTitle}</div>
                <iframe src={`https://chzzk.naver.com/live/${channelId}/chat`} />
              </div>
            );
          })}
        </div>
      )}
    </>
  );
};

const rootEl = document.getElementById('root');
if (rootEl) {
  const root = createRoot(rootEl);
  root.render(<ChatMultiView />);
}
