# 치지직 플레이어 정보(React) 및 비디오(Vue) 데이터 추적 가이드 (초안)

이 가이드는 치지직 생방송 페이지의 플레이어 상단 정보 영역(`.live_information_player__uFFcH`)과 실제 비디오 플레이어(`.pzp`)의 내부 데이터(React Props & Vue State)를 추출하는 방법을 설명합니다.

## 1. 플레이어 정보 영역 (React)

방송 제목, 카테고리, 스트리머 상세 정보 등을 관리하는 영역입니다.

- **대상 셀렉터**: `.live_information_player__uFFcH` (또는 주변의 정보 컨테이너)
- **주요 속성 매핑 (Fiber Props)**:

| 경로 | 설명 | 예시 |
| :--- | :--- | :--- |
| `channelInfo.channelName` | 스트리머 닉네임 | `I3eom` |
| `channelInfo.channelId` | 채널 고유 ID | `d57c10...` |
| `channelInfo.followerCount` | 팔로워 수 | `571` |
| `liveTitle` | 방송 제목 | `완미 정지 좀 풀어주세요..` |
| `liveCategoryValue` | 카테고리 명 | `카운터 스트라이크 2` |
| `concurrentUserCount` | 현재 시청자 수 | `4` |

```javascript
// 콘솔 확인 코드
const infoEl = document.querySelector('.live_information_player__uFFcH');
const fiber = infoEl[Object.keys(infoEl).find(k => k.startsWith('__reactFiber$'))];
console.log(fiber.memoizedProps);
```

---

## 2. 비디오 플레이어 영역 (Vue/PZP)

실제 영상 재생 상태, 화질, 비트레이트, 지연 시간 등을 관리하는 PZP 플레이어입니다.

- **대상 셀렉터**: `.pzp` (또는 `[class*="pzp-pc"]`)
- **데이터 접근**: 요소의 `__vue__` 속성 및 그 하위의 `$store.state`에 접근합니다.

### 주요 속성 매핑 (Vuex Store State)

| 경로 | 설명 | 예시 |
| :--- | :--- | :--- |
| `volume` | 현재 음량 (0.0 ~ 1.0) | `0.3` |
| `quality` | 현재 화질 설정 | `1080p` |
| `latency` | 지연 모드 상태 | `low-latency` |
| `lowLatencyEnabled` | 저지연 모드 활성화 여부 | `true` |
| `protocol` | 재생 프로토콜 | `live:` |
| `videoTracks` | 가용한 비디오 트랙 정보 | 비트레이트, FPS, 코덱 등 포함 |

### 상세 비트레이트 확인 방법

`videoTracks` 배열 내의 각 객체에서 `bandwidth` (bps 단위)를 확인할 수 있습니다.

- **1080p**: 약 `8,192,000` bps (8Mbps)
- **720p**: 약 `3,000,000` bps (3Mbps)

```javascript
// 콘솔 확인 코드
const playerEl = document.querySelector('.pzp');
const store = playerEl?.__vue__?.$store?.state;
if (store) {
    console.log({
        quality: store.quality,
        volume: store.volume,
        latency: store.latency,
        bitrate: store.videoTracks?.[0]?.bandwidth // 현재 트랙의 비트레이트
    });
}
```

---

## 3. 탐색(Seek) 및 지연 시간(Latency) 정보

라이브 방송의 현재 재생 시점과 지연 시간(레이턴시)을 파악하는 방법입니다.

### 주요 속성 매핑 (Vuex Store & Video Element)

| 항목 | 설명 | 추출 방법 |
| :--- | :--- | :--- |
| **라이브 여부** | 현재 방송이 라이브인지 | `store.onLive` (boolean) |
| **타임머신** | 과거 시점 탐색 가능 여부, true로 바꾸면 네이티브 타임머신을 사용할수 있으나 유료 상품이기에 false로 항상 둘것. | `store.timeMachine` (boolean) |
| **라이브 엣지** | 현재 방송의 가장 최신 시점 | `video.seekable.end(0)` |
| **현재 시점** | 현재 내가 보고 있는 시점 | `video.currentTime` |
| **지연 시간** | 실제 방송과의 시간 차이 | `video.seekable.end(0) - video.currentTime` |
| **버퍼 범위** | 미리 로드된 영상 구간 | `video.buffered` (TimeRanges) |

### 레이턴시 측정 및 자동 따라잡기(Sync) 팁
- **지연 시간 산출**: `seekable.end`와 `currentTime`의 차이가 곧 레이턴시(초 단위)입니다. 치지직 저지연 모드에서는 보통 **2~5초** 사이를 유지합니다.
- **의도치 않은 지연(7초 이상) 발생 시**: 네트워크 불안정 등으로 인해 버퍼링이 발생하여 지연 시간이 **7초** 이상으로 벌어질 경우, 자동으로 라이브 최전방으로 이동시키는 로직이 유용합니다.

```javascript
// 7초 이상 지연 시 자동 따라잡기 로직
const catchUpLive = (video, threshold = 7) => {
    const liveEdge = video.seekable.length ? video.seekable.end(0) : 0;
    const latency = liveEdge - video.currentTime;

    // 사용자가 과거 시점을 보고 있는 게 아니라면 (예: 배속이 1이고, 최근에 수동 탐색 안 함)
    // 7초 이상 차이 날 때 라이브 엣지 2초 전으로 점프
    if (latency > threshold) {
        console.log(`[CQC] 지연 시간(${latency.toFixed(1)}s) 감지. 라이브로 이동합니다.`);
        video.currentTime = liveEdge - 2; // 안전을 위해 2초 전으로 이동
    }
};

// 주기적으로 체크 (예: 2초마다)
const video = document.querySelector('video');
if (video) {
    setInterval(() => catchUpLive(video), 2000);
}
```
