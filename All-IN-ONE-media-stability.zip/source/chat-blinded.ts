// @ts-nocheck
/**
 * @fileoverview 블라인드된 채팅 메시지 원본 복구 및 관리 모듈
 */
import { getReactProps, getFiberNode, SELECTORS, log as cqcLog } from './dom-utils';

const log = (...args) => cqcLog('BlindedChat', ...args);

class BlindedMessageManager {
    #settings = { enabled: true, blindedRestoreEnabled: true, blindedAutoRestoreEnabled: false };
    #observer = null;
    #hoverStyleId = 'cqc-blinded-hover-style';
    #globalMouseHandler = null;
    #memoryCache = new Map();
    #MAX_CACHE_SIZE = 2000;
    #activeContainer = null;
    #mountIntervalId = null;

    async init(settings) {
        if (settings) this.#settings = settings;

        // 이미 실행 중이면 정리 후 재설정
        this.cleanup();

        if (this.#settings.enabled === false || this.#settings.blindedRestoreEnabled === false) {
            return;
        }

        this.#injectHoverStyle();
        this.#startObserver();
        this.#addHoverListeners();

        log('BlindedMessageManager initialized');
    }

    #injectHoverStyle() {
        if (document.getElementById(this.#hoverStyleId)) return;
        const style = document.createElement('style');
        style.id = this.#hoverStyleId;
        style.textContent = `
            .cqc-blinded-target {
                cursor: help !important;
                transition: background-color 0.2s ease;
            }
            .cqc-blinded-target:hover {
                background-color: rgba(255, 170, 0, 0.08) !important;
            }
            .cqc-blinded-restored {
                color: var(--Content-Neutral-Cool-Stronger, #ffaa00) !important;
                font-style: italic;
            }
            .cqc-blinded-restored::before {
                content: '[원본] ';
                font-size: 0.8em;
                font-weight: bold;
            }
        `;
        document.head.appendChild(style);
    }

    #startObserver() {
        this.#stopObserverOnly();

        const attachToContainer = () => {
            const container = document.querySelector(SELECTORS.CHAT_LIST_CONTAINER);
            if (!container) {
                if (this.#activeContainer) {
                    this.#stopObserverOnly();
                }
                return;
            }
            if (this.#activeContainer === container) return;

            this.#stopObserverOnly();
            this.#activeContainer = container;

            this.#observer = new MutationObserver((mutations) => {
                if (!this.#settings.blindedRestoreEnabled) return;
                for (const m of mutations) {
                    if (m.type === 'attributes') {
                        const el = /** @type {HTMLElement} */(m.target);
                        if (el.nodeType === 1) {
                            if (el.matches?.(SELECTORS.CHAT_BLINDED_CONTAINER) || el.querySelector?.(SELECTORS.CHAT_BLINDED_CONTAINER)) {
                                this.#checkBlinded(el);
                            }
                        }
                        continue;
                    }

                    for (const node of m.addedNodes) {
                        if (node.nodeType !== 1) continue;
                        const el = /** @type {HTMLElement} */(node);

                        // 새 메시지 도착 시 감지
                        if (el.matches?.(SELECTORS.CHAT_ITEM)) {
                            this.#captureOriginalContent(el);
                            this.#checkBlinded(el);
                        } else {
                            const inner = el.querySelector?.(SELECTORS.CHAT_ITEM);
                            if (inner) {
                                this.#captureOriginalContent(/** @type {HTMLElement} */(inner));
                                this.#checkBlinded(/** @type {HTMLElement} */(inner));
                            }
                        }
                    }
                }
            });

            this.#observer.observe(container, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['class']
            });

            // 초기 스캔
            container.querySelectorAll(SELECTORS.CHAT_ITEM).forEach(el => {
                this.#captureOriginalContent(/** @type {HTMLElement} */(el));
                this.#checkBlinded(/** @type {HTMLElement} */(el));
            });
            log('BlindedChat attached to container directly');
        };

        // 1.5초 간격으로 채팅 컨테이너 마운트 감지하여 감시 적용
        this.#mountIntervalId = window.setInterval(attachToContainer, 1500);
        attachToContainer();
    }

    #stopObserverOnly() {
        if (this.#observer) {
            this.#observer.disconnect();
            this.#observer = null;
        }
        this.#activeContainer = null;
    }

    /**
     * 메시지 엘리먼트에서 원본 내용을 추출하여 메모리에 저장합니다.
     * @param {HTMLElement} el 
     */
    async #captureOriginalContent(el) {
        const props = getReactProps(el);
        const chatMessage = props?.chatMessage || props?.children?.props?.chatMessage;

        if (chatMessage && chatMessage.key) {
            let contentToSave = chatMessage.originalContent || chatMessage.content;
            if (!contentToSave) return;

            // 배열이면 텍스트 추출
            if (Array.isArray(contentToSave)) {
                contentToSave = contentToSave.map(item => {
                    if (typeof item === 'string') return item;
                    if (item && typeof item === 'object') {
                        if (item.type === 'text') return item.value || '';
                        if (item.type === 'emoji') return `{${item.name || '이모티콘'}}`;
                    }
                    return '';
                }).join('');
            }

            const contentStr = String(contentToSave);
            const isBlinded = contentStr.includes('블라인드') || contentStr.includes('클린봇');
            
            if (!isBlinded) {
                const key = chatMessage.key;
                this.#memoryCache.set(key, contentStr);
                if (this.#memoryCache.size > this.#MAX_CACHE_SIZE) {
                    const firstKey = this.#memoryCache.keys().next().value;
                    this.#memoryCache.delete(firstKey);
                }
            }
        }
    }

    /**
     * 엘리먼트 또는 상위 트리에서 채팅 고유 키를 찾습니다.
     * @param {HTMLElement} el 
     * @returns {string|null}
     */
    #findChatKey(el) {
        let fiber = getFiberNode(el);
        while (fiber) {
            // 1. chatMessage.key (표준)
            if (fiber.memoizedProps?.chatMessage?.key) return fiber.memoizedProps.chatMessage.key;

            // 2. fiber.key (React 리스트 키 - 새로고침 후에도 유지됨)
            if (typeof fiber.key === 'string' && fiber.key.includes('_')) return fiber.key;

            // 3. props.key
            if (typeof fiber.memoizedProps?.key === 'string' && fiber.memoizedProps.key.includes('_')) return fiber.memoizedProps.key;

            fiber = fiber.return;
        }

        // 4. 마지막 수단: CHAT_ITEM 찾아서 재시도
        const item = el.closest(SELECTORS.CHAT_ITEM);
        if (item && item !== el) return this.#findChatKey(/** @type {HTMLElement} */(item));

        return null;
    }

    /**
     * 블라인드 처리된 메시지인지 확인하고 호버 이벤트를 부착합니다.
     * @param {HTMLElement} el 
     */
    #checkBlinded(el) {
        const containers = Array.from(el.querySelectorAll?.(SELECTORS.CHAT_BLINDED_CONTAINER) || []);
        const targets = el.matches?.(SELECTORS.CHAT_BLINDED_CONTAINER) ? [el, ...containers] : containers;
        
        const parentTarget = el.closest?.(SELECTORS.CHAT_BLINDED_CONTAINER);
        if (parentTarget && !targets.includes(parentTarget)) {
            targets.push(parentTarget);
        }

        targets.forEach(target => {
            const textEl = target.querySelector(SELECTORS.CHAT_MESSAGE_TEXT);
            if (textEl && (textEl.textContent?.includes('블라인드') || textEl.textContent?.includes('클린봇'))) {
                this.#prepareRestore(/** @type {HTMLElement} */(target));
            }
        });
    }

    /**
     * - 블라인드 메시지에 호버 핸들러를 등록합니다.
     * @param {HTMLElement} container 
     */
    #prepareRestore(container) {
        if (container.dataset.cqcBlindedHandled) return;
        container.dataset.cqcBlindedHandled = 'true';

        const textEl = container.querySelector(SELECTORS.CHAT_MESSAGE_TEXT);
        if (!textEl) return;

        const originalBlindedText = textEl.textContent;
        let isRestored = false;

        const onEnter = async () => {
            if (isRestored) return;

            // 1. 우선 현재 DOM의 React Props에서 직접 원본 텍스트 추출 시도
            const item = container.closest(SELECTORS.CHAT_ITEM);
            if (item) {
                const props = getReactProps(/** @type {HTMLElement} */(item));
                const chatMessage = props?.chatMessage || props?.children?.props?.chatMessage;
                if (chatMessage) {
                    let dirtyText = chatMessage.originalContent || chatMessage.content;
                    if (Array.isArray(dirtyText)) {
                        dirtyText = dirtyText.map(i => {
                            if (typeof i === 'string') return i;
                            if (i && typeof i === 'object') {
                                if (i.type === 'text') return i.value || '';
                                if (i.type === 'emoji') return `{${i.name || '이모티콘'}}`;
                            }
                            return '';
                        }).join('');
                    }
                    const contentStr = String(dirtyText);
                    // 실제 원본 텍스트가 맞는지 확인 (클린봇 안내문구가 아님)
                    if (contentStr && !contentStr.includes('클린봇이 부적절한') && !contentStr.includes('메시지가 블라인드')) {
                        textEl.textContent = contentStr;
                        textEl.classList.add('cqc-blinded-restored');
                        isRestored = true;
                        return;
                    }
                }
            }

            // 2. DOM에서 원본을 찾을 수 없는 경우 (치지직 서버가 지웠거나 덮어쓴 경우) 캐시에서 폴백
            const key = this.#findChatKey(container);
            if (key) {
                const original = this.#memoryCache.get(key) || null;
                if (original) {
                    textEl.textContent = typeof original === 'string' ? original : JSON.stringify(original);
                    textEl.classList.add('cqc-blinded-restored');
                    isRestored = true;
                    return;
                }
            }

            textEl.title = '원본 내용을 찾을 수 없습니다. (새로고침 전 저장되지 않음)';
        };

        const onLeave = () => {
            if (!isRestored) return;
            textEl.textContent = originalBlindedText;
            textEl.classList.remove('cqc-blinded-restored');
            isRestored = false;
        };

        if (this.#settings.blindedAutoRestoreEnabled) {
            onEnter();
        } else {
            container.classList.add('cqc-blinded-target');
            container.addEventListener('mouseenter', onEnter);
            container.addEventListener('mouseleave', onLeave);
        }
    }

    #addHoverListeners() {
        if (this.#globalMouseHandler) return;

        this.#globalMouseHandler = (e) => {
            if (!this.#settings.blindedRestoreEnabled) return;
            const target = /** @type {HTMLElement} */(e.target);
            const container = target.closest(SELECTORS.CHAT_BLINDED_CONTAINER);
            if (container) {
                this.#prepareRestore(/** @type {HTMLElement} */(container));
            }
        };

        // MutationObserver 외에 이벤트 위임 방식으로도 처리 (안전장치)
        document.addEventListener('mouseover', this.#globalMouseHandler, { capture: true, passive: true });
    }

    cleanup() {
        this.#stopObserverOnly();
        if (this.#mountIntervalId) {
            clearInterval(this.#mountIntervalId);
            this.#mountIntervalId = null;
        }
        if (this.#globalMouseHandler) {
            document.removeEventListener('mouseover', this.#globalMouseHandler, { capture: true });
            this.#globalMouseHandler = null;
        }
        document.getElementById(this.#hoverStyleId)?.remove();

        this.#memoryCache.clear();

        // 데이터셋 플래그 정리 (재활성화 시 대응)
        document.querySelectorAll('[data-cqc-blinded-handled]').forEach(el => {
            delete (/** @type {HTMLElement} */(el).dataset.cqcBlindedHandled);
            el.classList.remove('cqc-blinded-target');
        });
    }
}

export const blindedChatManager = new BlindedMessageManager();
export const initBlindedChat = (settings) => blindedChatManager.init(settings);
export const cleanupBlindedChat = () => blindedChatManager.cleanup();
