// @ts-nocheck
import Browser from "webextension-polyfill";
import { SELECTORS } from './dom-utils';

export const initMultiview = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    if (!urlParams.has('multiview')) return;

    console.log('[CQC] Starting Multiview Engine 2.0');

    const mode = urlParams.get('multiview'); // 'true' (video) or 'chat'

    /** @type {any} */
    const data = await Browser.storage.local.get({ mvChannels: [], mcChannels: [], mvWideEnabled: true });

    const channels = mode === 'chat' ? (data.mcChannels || []) : data.mvChannels;

    if (!channels || channels.length === 0) {
        alert('멀티뷰 채널이 구성되지 않았습니다. 제어판에서 채널을 추가해주세요.');
        return;
    }

    // 문서 구조 초기화 (React SPA 개입 원천 차단)
    window.stop();
    document.documentElement.style.background = '#000';
    document.body.innerHTML = '';
    document.body.style.cssText = 'margin:0; padding:0; background:#000; overflow:hidden !important; cursor:default;';

    const count = channels.length;
    let gridStyle = '';

    // 유연한 그리드 전략 (최대 6개 대응)
    if (count === 1) {
        gridStyle = 'grid-template-columns: 1fr; grid-template-rows: 1fr;';
    } else if (count === 2) {
        gridStyle = 'grid-template-columns: 1fr 1fr; grid-template-rows: 1fr;';
    } else if (count <= 4) {
        gridStyle = 'grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr;';
    } else {
        // 5~6개: 3열 2행
        gridStyle = 'grid-template-columns: 1fr 1fr 1fr; grid-template-rows: 1fr 1fr;';
    }

    const container = document.createElement('div');
    container.id = 'cqc-mv-container';
    container.style.cssText = `
        display: grid !important;
        width: 100vw !important;
        height: 100vh !important;
        gap: 6px !important;
        background: #0a0a0a !important;
        padding: 6px !important;
        box-sizing: border-box !important;
        ${gridStyle}
    `;

    const wideParam = '&wide=1';

    channels.forEach((ch) => {
        const item = document.createElement('div');
        item.className = 'cqc-mv-item';
        item.style.cssText = `
            position: relative !important;
            background: #000 !important;
            width: 100% !important;
            height: 100% !important;
            overflow: hidden !important;
            border-radius: 12px !important;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.8) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            box-sizing: border-box !important;
        `;

        if (mode === 'chat') {
            const label = document.createElement('div');
            label.style.cssText = 'position:absolute; top:8px; left:12px; font-size:11px; font-weight:700; color:rgba(255,255,255,0.4); z-index:10; pointer-events:none;';
            label.textContent = ch.title || ch.id;
            item.appendChild(label);
        }

        const iframe = document.createElement('iframe');
        // 모드에 따라 URL 결정
        if (mode === 'chat') {
            iframe.src = `https://chzzk.naver.com/live/${ch.id}/chat?mv_iframe=1`;
        } else {
            iframe.src = `https://chzzk.naver.com/live/${ch.id}?mv_iframe=1${wideParam}`;
        }

        iframe.allow = "autoplay; fullscreen; picture-in-picture";
        iframe.sandbox = "allow-scripts allow-same-origin allow-forms allow-popups";
        iframe.style.cssText = "width:100% !important; height:100% !important; border:none !important; display:block !important;";

        item.appendChild(iframe);
        container.appendChild(item);
    });

    document.body.appendChild(container);

    // 치지직 SPA의 자동 요소 생성을 차단하기 위한 상시 감시
    const cleanup = () => {
        const allowedIds = ['cqc-mv-container'];
        for (const el of Array.from(document.body.children)) {
            if (!allowedIds.includes(el.id) && el.tagName !== 'SCRIPT' && el.tagName !== 'STYLE') {
                el.remove();
            }
        }
    };

    setInterval(cleanup, 500);
    // MutationObserver를 통한 즉각 대응 추가
    const observer = new MutationObserver(cleanup);
    observer.observe(document.body, { childList: true });
};

/**
 * iframe 내부에서 동작할 최적화 로직
 */
export const handleMultiviewIframe = () => {
    const urlParams = new URLSearchParams(window.location.search);
    if (!urlParams.has('mv_iframe')) return;

    document.body.classList.add('cqc-is-mv-iframe');
    document.body.classList.add('cqc-mv-wide-forced');

    // SPA(React) 환경에 맞추어 DOM 속성 직접 변경 대신 최상위 CSS를 주입
    const style = document.createElement('style');
    style.id = 'cqc-mv-iframe-style';
    style.textContent = `
        ${SELECTORS.PLAYER} {
            z-index: 1 !important;
            background: #000 !important;
        }
        ${SELECTORS.MULTIVIEW_IFRAME_HIDES} {
            display: none !important;
        }
        ${SELECTORS.MULTIVIEW_IFRAME_LAYOUT} {
            padding: 0 !important;
            margin: 0 !important;
            width: 100% !important;
            height: 100% !important;
            max-width: none !important;
            min-width: 0 !important;
        }
    `;
    document.head.appendChild(style);

    // 팝업/토스트 강제 제거 (광고 안내 등)
    const removePopups = () => {
        const popups = document.querySelectorAll(SELECTORS.MULTIVIEW_IFRAME_POPUPS);
        popups.forEach(p => {
            const confirmBtn = p.querySelector('button');
            if (confirmBtn) /** @type {HTMLElement} */ (confirmBtn).click();
            else /** @type {HTMLElement} */ (p).remove();
        });
    };

    setInterval(removePopups, 2000);
    window.addEventListener('load', removePopups);
};
