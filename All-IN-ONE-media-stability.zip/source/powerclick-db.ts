// @ts-nocheck
/**
 * @fileoverview IndexedDB 기반의 파워 클릭 로컬 데이터베이스 캡슐화 모듈
 */
import { DB_NAME, DB_VERSION, STORE_NAMES } from './shared/db-constants';

const KV_STORE = STORE_NAMES.SETTINGS;
const POWER_LOG_STORE = STORE_NAMES.POWER_LOGS;

export class PowerDB {
    #dbInstance = null;
    #isInitialized = false;

    async init(isRetry = false) {
        if (this.#isInitialized && this.#dbInstance) return true;
        return new Promise((resolve) => {
            try {
                const req = indexedDB.open(DB_NAME, DB_VERSION);
                req.onupgradeneeded = (e) => {
                    const db = e.target.result;
                    if (e.oldVersion < 5) {
                        if (db.objectStoreNames.contains('thumbnails')) {
                            db.deleteObjectStore('thumbnails');
                        }
                    }
                    if (!db.objectStoreNames.contains('thumbnails')) {
                        const store = db.createObjectStore('thumbnails', { keyPath: 'id' });
                        store.createIndex('sessionId', 'sessionId', { unique: false });
                        store.createIndex('timestamp', 'timestamp', { unique: false });
                    }
                    if (!db.objectStoreNames.contains(KV_STORE)) {
                        db.createObjectStore(KV_STORE, { keyPath: 'key' });
                    }
                    if (!db.objectStoreNames.contains(POWER_LOG_STORE)) {
                        db.createObjectStore(POWER_LOG_STORE, { keyPath: 'id', autoIncrement: true });
                    }
                    // v6: 블라인드 메시지 원본 저장소
                    if (!db.objectStoreNames.contains(STORE_NAMES.BLINDED)) {
                        const bs = db.createObjectStore(STORE_NAMES.BLINDED, { keyPath: 'msgKey' });
                        bs.createIndex('timestamp', 'timestamp', { unique: false });
                    }
                };
                req.onsuccess = (e) => {
                    this.#dbInstance = e.target.result;
                    this.#isInitialized = true;

                    // DB 버전 변경 시 연결 해제 (다른 탭에서 업그레이드 발생 대비)
                    this.#dbInstance.onversionchange = () => {
                        this.#dbInstance.close();
                        this.#dbInstance = null;
                        this.#isInitialized = false;
                    };
                    this.#dbInstance.onclose = () => {
                        this.#dbInstance = null;
                        this.#isInitialized = false;
                    };

                    this.#cleanupOldBlindedMessages();
                    resolve(true);
                };
                req.onblocked = (e) => {
                    console.warn('[CQC:PowerDB] IndexedDB 초기화 블락됨 (다른 탭에서 기존 연결이 닫히지 않음)', e);
                };
                req.onerror = (e) => {
                    const error = e.target?.error;
                    console.error('[CQC:PowerDB] IndexedDB 초기화 실패:', error?.name, error?.message, error);
                    this.#isInitialized = false;

                    // VersionError인 경우 로컬 DB 버전 불일치가 의심되므로 삭제 후 재시도
                    if (error?.name === 'VersionError' && !isRetry) {
                        console.warn('[CQC:PowerDB] VersionError 감지. 기존 데이터베이스 삭제 후 재시도합니다.');
                        try {
                            const deleteReq = indexedDB.deleteDatabase(DB_NAME);
                            deleteReq.onsuccess = () => {
                                console.log('[CQC:PowerDB] 기존 데이터베이스 삭제 완료. 재초기화를 수행합니다.');
                                resolve(this.init(true));
                            };
                            deleteReq.onerror = (delErr) => {
                                console.error('[CQC:PowerDB] 기존 데이터베이스 삭제 실패:', delErr);
                                resolve(false);
                            };
                            deleteReq.onblocked = () => {
                                console.warn('[CQC:PowerDB] 기존 데이터베이스 삭제 블락됨. 다른 탭의 연결이 끊어질 때까지 대기합니다.');
                            };
                        } catch (delEx) {
                            console.error('[CQC:PowerDB] 데이터베이스 삭제 중 예외 발생:', delEx);
                            resolve(false);
                        }
                    } else {
                        resolve(false);
                    }
                };
            } catch (ex) {
                console.error('[CQC:PowerDB] IndexedDB open 예외 발생:', ex);
                this.#isInitialized = false;
                resolve(false);
            }
        });
    }

    /**
     * 오래된 블라인드 메시지를 정리합니다 (24시간 기준)
     */
    async #cleanupOldBlindedMessages() {
        if (!this.#dbInstance) return;
        try {
            const tx = this.#dbInstance.transaction(STORE_NAMES.BLINDED, 'readwrite');
            const store = tx.objectStore(STORE_NAMES.BLINDED);
            const index = store.index('timestamp');
            const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
            const range = IDBKeyRange.upperBound(oneDayAgo);
            const req = index.openCursor(range);
            req.onsuccess = (e) => {
                const cursor = e.target.result;
                if (cursor) {
                    cursor.delete();
                    cursor.continue();
                }
            };
        } catch (e) { /* ignore */ }
    }

    async getKV(key) {
        await this.init();
        if (!this.#dbInstance) return undefined;
        return new Promise((resolve) => {
            try {
                const tx = this.#dbInstance.transaction(KV_STORE, 'readonly');
                const req = tx.objectStore(KV_STORE).get(key);
                req.onsuccess = () => resolve(req.result?.value);
                req.onerror = () => resolve(undefined);
            } catch (e) { resolve(undefined); }
        });
    }

    async setKV(key, value) {
        await this.init();
        if (!this.#dbInstance) return false;
        return new Promise((resolve) => {
            try {
                const tx = this.#dbInstance.transaction(KV_STORE, 'readwrite');
                const req = tx.objectStore(KV_STORE).put({ key, value });
                req.onsuccess = () => resolve(true);
                req.onerror = () => resolve(false);
            } catch (e) { resolve(false); }
        });
    }

    async getAllKeys() {
        await this.init();
        if (!this.#dbInstance) return [];
        return new Promise((resolve) => {
            const tx = this.#dbInstance.transaction(KV_STORE, 'readonly');
            const req = tx.objectStore(KV_STORE).getAllKeys();
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => resolve([]);
        });
    }

    async getPowerChannels() {
        const allKeys = await this.getAllKeys();
        const metaKeys = allKeys.filter(k => String(k).startsWith('channel_meta_'));
        const channels = [];

        for (const key of metaKeys) {
            const meta = await this.getKV(key);
            if (meta && meta.channelId) {
                const count = await this.getKV('power_count_' + meta.channelId);
                channels.push({
                    channelId: meta.channelId,
                    channelName: meta.channelName || meta.channelId,
                    channelImageUrl: meta.channelImageUrl || '',
                    count: typeof count === 'number' ? count : 0,
                    syncTs: meta.syncTs || 0
                });
            }
        }
        return channels;
    }

    async resetPowerChannels(channelIds = 'all') {
        if (channelIds === 'all') {
            const allKeys = await this.getAllKeys();
            const powerKeys = allKeys.filter(k => String(k).startsWith('power_count_'));
            for (const key of powerKeys) {
                await this.setKV(key, 0);
            }
            await this.setKV('total_power_count', 0);
        } else if (Array.isArray(channelIds)) {
            for (const chId of channelIds) {
                await this.setKV('power_count_' + chId, 0);
            }
            const allKeys = await this.getAllKeys();
            const powerKeys = allKeys.filter(k => String(k).startsWith('power_count_'));
            let total = 0;
            for (const key of powerKeys) {
                const v = await this.getKV(key);
                if (typeof v === 'number') total += v;
            }
            await this.setKV('total_power_count', total);
        }
    }

    async getPowerLogs(limit = 100) {
        await this.init();
        if (!this.#dbInstance) return [];
        return new Promise((resolve) => {
            try {
                const tx = this.#dbInstance.transaction(POWER_LOG_STORE, 'readonly');
                const store = tx.objectStore(POWER_LOG_STORE);
                const logs = [];
                const req = store.openCursor(null, 'prev');
                req.onsuccess = (e) => {
                    const cursor = e.target.result;
                    if (cursor && logs.length < limit) {
                        logs.push(cursor.value);
                        cursor.continue();
                    } else {
                        resolve(logs);
                    }
                };
                req.onerror = () => resolve([]);
            } catch (e) { resolve([]); }
        });
    }

    async addPowerLog(data) {
        await this.init();
        if (!this.#dbInstance) return;
        return new Promise((resolve) => {
            try {
                const tx = this.#dbInstance.transaction(POWER_LOG_STORE, 'readwrite');
                const store = tx.objectStore(POWER_LOG_STORE);
                store.add({ ...data, timestamp: data.timestamp || Date.now() });
                tx.oncomplete = () => resolve(undefined);
                tx.onerror = () => resolve(undefined);
            } catch (e) { resolve(undefined); }
        });
    }

    async saveBlindedMessage(msgKey, originalContent) {
        await this.init();
        if (!this.#dbInstance) return false;
        return new Promise((resolve) => {
            try {
                const tx = this.#dbInstance.transaction(STORE_NAMES.BLINDED, 'readwrite');
                const store = tx.objectStore(STORE_NAMES.BLINDED);
                const req = store.put({
                    msgKey,
                    originalContent,
                    timestamp: Date.now()
                });
                req.onsuccess = () => resolve(true);
                req.onerror = () => resolve(false);
            } catch (e) { resolve(false); }
        });
    }

    async getBlindedMessage(msgKey) {
        await this.init();
        if (!this.#dbInstance) return null;
        return new Promise((resolve) => {
            try {
                const tx = this.#dbInstance.transaction(STORE_NAMES.BLINDED, 'readonly');
                const store = tx.objectStore(STORE_NAMES.BLINDED);
                const req = store.get(msgKey);
                req.onsuccess = () => resolve(req.result?.originalContent || null);
                req.onerror = () => resolve(null);
            } catch (e) { resolve(null); }
        });
    }
}

export const powerDB = new PowerDB();
