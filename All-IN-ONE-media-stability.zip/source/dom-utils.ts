export {
    CACHE_TTL,
    NESTED_KEYS,
    REGEX,
    isShortcutMatched,
    DEFAULT_SETTINGS
} from './src/utils/Constants';
export type { ShortcutConfig } from './src/utils/Constants';

export {
    DEFAULT_SELECTORS,
    SelectorRegistry
} from './src/utils/SelectorRegistry';
export type { SelectorKey } from './src/utils/SelectorRegistry';

export {
    ChzzkPageDetector,
    isLivePage,
    isVideoPage,
    isClipPage,
    isHomePage,
    isPlayerPage,
    isSidebarCollapsed,
    isLargeMode
} from './src/utils/ChzzkPageDetector';

export {
    ReactFiberExplorer,
    getFiberNode,
    getComponentFiber,
    getReactProps,
    getReactStore,
    triggerReact,
    setReactInputValue
} from './src/utils/ReactFiberExplorer';
export type { FiberNode } from './src/utils/ReactFiberExplorer';

export {
    ChannelDataExtractor,
    getChannelProps,
    getChannelData
} from './src/utils/ChannelDataExtractor';
export type { ChannelData } from './src/utils/ChannelDataExtractor';

export {
    ToastController,
    showToast
} from './src/utils/ToastController';

export {
    ConsoleLogger,
    log
} from './src/utils/ConsoleLogger';

import { SelectorRegistry } from './src/utils/SelectorRegistry';
export const SELECTORS = SelectorRegistry.getInstance().getProxy();
export const initSelectors = (overrides?: Record<string, string>): void => SelectorRegistry.getInstance().init(overrides);
