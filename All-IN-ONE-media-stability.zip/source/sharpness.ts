// @ts-nocheck
/** 활성화 여부 저장 키 */
const STORAGE_KEY_ENABLED = 'sharpnessEnabled';
/** 강도 저장 키 */
const STORAGE_KEY_INTENSITY = 'sharpnessIntensity';
/** 모드 저장 키 */
const STORAGE_KEY_MODE = 'sharpnessMode';
/** 커스텀 설정 저장 키 */
const STORAGE_KEY_CUSTOM = 'sharpnessCustom';
/** 기본 필터 ID */
const FILTER_ID_DEFAULT = 'sharp_default';
/** 자연스러운 필터 ID */
const FILTER_ID_NATURAL = 'sharp_natural';
/** 커스텀 필터 ID */
const FILTER_ID_CUSTOM = 'sharp_custom';
/** SVG 컨테이너 ID */
const SVG_ID = 'sharpnessSVGContainer';
/** 스타일 엘리먼트 ID */
const STYLE_ID = 'sharpnessStyle';
/** 설정 메뉴 선택자 */
const MENU_SELECTOR = '.pzp-pc__settings';
/** 기본 커스텀 필터 값 */
const DEFAULT_CUSTOM = { saturate: 1.0, brightness: 1.0, contrast: 1.0 };

import Browser from 'webextension-polyfill';
import { isPlayerPage } from './dom-utils';

/**
 * 선명도 설정을 제거합니다.
 */
const clearSharpness = () => {
  document.getElementById(SVG_ID)?.remove();
  document.getElementById(STYLE_ID)?.remove();
};

/**
 * 저장소에서 값을 가져옵니다.
 * @param {string} key 
 * @param {any} defaultVal 
 * @returns {Promise<any>}
 */
const getValue = async (key, defaultVal) => {
  const result = /** @type {any} */ (await Browser.storage.sync.get({ [key]: defaultVal }));
  return result[key];
};

/**
 * 저장소에 값을 설정합니다.
 * @param {string} key 
 * @param {any} val 
 * @returns {Promise<void>}
 */
const setValue = async (key, val) => {
  await Browser.storage.sync.set({ [key]: val });
};

/**
 * 로그를 출력합니다.
 * @param  {...any} a 
 */
const log = (...a) => { };

/**
 * 선명도 필터 클래스
 */
export class SharpnessFilter extends EventTarget {
  #enabled = false;
  #intensity = 1;
  #mode = 'default';
  #custom = { ...DEFAULT_CUSTOM };
  /** @type {HTMLElement} */
  #svg;
  /** @type {HTMLStyleElement} */
  #style;
  /** @type {any} */
  controls = null;

  constructor() {
    super();
    this.#svg = this.#createSVG();
    this.#style = this.#createStyle();
    this.#style.media = 'none';
  }

  get enabled() { return this.#enabled; }
  get intensity() { return this.#intensity; }
  get mode() { return this.#mode; }

  /**
   * 필터 SVG 엘리먼트를 생성합니다.
   * @returns {HTMLElement}
   */
  #createSVG() {
    const div = document.createElement('div');
    div.id = SVG_ID;
    div.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" style="position:absolute;width:0;height:0;">
          <defs>
            <filter id="${FILTER_ID_DEFAULT}">
              <feConvolveMatrix order="3" divisor="1" kernelMatrix="" />
            </filter>
            <filter id="${FILTER_ID_NATURAL}">
              <feConvolveMatrix order="3" divisor="1" kernelMatrix="" />
              <feColorMatrix type="saturate" values="1.2" />
            </filter>
            <filter id="${FILTER_ID_CUSTOM}">
              <feConvolveMatrix order="3" divisor="1" kernelMatrix="" />
              <feColorMatrix type="saturate" values="1" />
              <feComponentTransfer>
                <feFuncR type="linear" slope="1" intercept="0" />
                <feFuncG type="linear" slope="1" intercept="0" />
                <feFuncB type="linear" slope="1" intercept="0" />
              </feComponentTransfer>
            </filter>
          </defs>
        </svg>`;
    return div;
  }

  /**
   * 필터 스타일 엘리먼트를 생성합니다.
   * @returns {HTMLStyleElement}
   */
  #createStyle() {
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
        :is(.pzp, .chzzk_player) video, video.webplayer-internal-video {
          filter: url(#${FILTER_ID_DEFAULT}) !important;
        }
        .sharp-slider {
          accent-color: var(--sharp-accent, #00f889);
        }
      `;
    return style;
  }

  /**
   * 필터 행렬을 업데이트합니다.
   */
  #updateFilterMatrix() {
    const k = 1 + Math.max(0, Math.min(5, this.#intensity)) * 0.25;
    const off = -((k - 1) / 4);
    const matrix = `0 ${off} 0 ${off} ${k} ${off} 0 ${off} 0`;
    this.#svg.querySelectorAll('feConvolveMatrix').forEach(elem => {
      elem.setAttribute('kernelMatrix', matrix);
    });
  }

  /**
   * 커스텀 필터 파라미터를 업데이트합니다.
   */
  #updateCustomFilter() {
    const f = this.#svg.querySelector(`#${FILTER_ID_CUSTOM}`);
    if (!f) return;
    const { saturate, brightness, contrast } = this.#custom;
    f.querySelector('feColorMatrix')?.setAttribute('values', String(saturate));
    const slope = contrast;
    const intercept = (brightness - 1) * 0.5 + (1 - contrast) * 0.5;
    f.querySelectorAll('feFuncR, feFuncG, feFuncB').forEach(fn => {
      fn.setAttribute('slope', String(slope));
      fn.setAttribute('intercept', String(intercept));
    });
  }

  /**
   * 현재 모드에 따른 필터 ID를 가져옵니다.
   * @returns {string}
   */
  #getFilterId() {
    if (this.#mode === 'natural') return FILTER_ID_NATURAL;
    if (this.#mode === 'custom') return FILTER_ID_CUSTOM;
    return FILTER_ID_DEFAULT;
  }

  /**
   * 스타일 시트에 정보를 반영합니다.
   */
  #applyModeToStyle() {
    const filterId = this.#getFilterId();
    this.#style.textContent = `
        :is(.pzp, .chzzk_player) video, video.webplayer-internal-video {
          filter: url(#${filterId}) !important;
        }
        .sharp-slider {
          accent-color: var(--sharp-accent, #00f889);
        }
      `;
    this.#style.media = this.#enabled && this.extensionEnabled !== false ? 'all' : 'none';
    if (this.#mode === 'custom') this.#updateCustomFilter();
  }

  /**
   * 필터를 초기화합니다.
   */
  init = async () => {
    clearSharpness();
    document.body.append(this.#svg);
    document.head.append(this.#style);
    await this.syncSettings();
    if (!this.storageListener) {
      this.storageListener = (changes, area) => {
        if (area === 'sync' && ['sharpnessEnabled','sharpnessIntensity','sharpnessMode','sharpnessCustom','settings'].some(key => key in changes)) this.syncSettings();
      };
      Browser.storage.onChanged.addListener(this.storageListener);
    }
    const menu = document.querySelector(MENU_SELECTOR);
    if (menu instanceof HTMLElement) {
      this.addMenuControls(menu);
    }
    if (this.controls) this.refreshControls();
    this.dispatchEvent(new Event('initialized'));
    log('초기화 완료', { enabled: this.#enabled, intensity: this.#intensity, mode: this.#mode });
  };

  /**
   * 필터를 활성화합니다.
   * @param {boolean} [persist=true] 
   */
  syncSettings = async () => {
    const token = this.syncToken = (this.syncToken || 0) + 1;
    const data = await Browser.storage.sync.get({sharpnessEnabled:false,sharpnessIntensity:1,sharpnessMode:'default',sharpnessCustom:DEFAULT_CUSTOM,settings:{enabled:true}});
    if (token !== this.syncToken) return;
    this.#enabled = !!data.sharpnessEnabled;
    this.#intensity = Number.isFinite(Number(data.sharpnessIntensity)) ? Number(data.sharpnessIntensity) : 1;
    this.#mode = ['default','natural','custom'].includes(data.sharpnessMode) ? data.sharpnessMode : 'default';
    this.#custom = {...DEFAULT_CUSTOM,...data.sharpnessCustom};
    this.extensionEnabled = data.settings?.enabled !== false;
    this.#updateFilterMatrix();this.#applyModeToStyle();this.refreshControls();
  };

  enable = (persist = true) => {
    this.#enabled = true;
    if (persist) setValue(STORAGE_KEY_ENABLED, true);
    this.#applyModeToStyle();
    this.refreshControls();
  };

  /**
   * 필터를 비활성화합니다.
   * @param {boolean} [persist=true] 
   */
  disable = (persist = true) => {
    this.#enabled = false;
    if (persist) setValue(STORAGE_KEY_ENABLED, false);
    this.#applyModeToStyle();
    this.refreshControls();
  };

  /** 필터 상태를 토글합니다. */
  toggle = () => {
    this.enabled ? this.disable() : this.enable();
  };

  /**
   * 필터 강도를 설정합니다.
   * @param {number} v 
   */
  setIntensity = (v) => {
    this.#intensity = v;
    this.#updateFilterMatrix();
    setValue(STORAGE_KEY_INTENSITY, v);
    this.refreshControls();
  };

  /**
   * 필터 모드를 설정합니다.
   * @param {string} m 
   */
  setMode = (m) => {
    if (m !== 'default' && m !== 'natural' && m !== 'custom') return;
    this.#mode = m;
    this.#applyModeToStyle();
    setValue(STORAGE_KEY_MODE, m);
    this.#toggleCustomUI();
  };

  /**
   * 커스텀 필터 파라미터를 설정합니다.
   * @param {string} key 
   * @param {number} val 
   */
  setCustomParam = (/** @type {string} */ key, val) => {
    /** @type {any} */
    const c = this.#custom;
    c[key] = val;
    this.#updateCustomFilter();
    setValue(STORAGE_KEY_CUSTOM, { ...this.#custom });
  };

  /** 커스텀 UI를 토글합니다. */
  #toggleCustomUI() {
    const panel = document.querySelector('.cqc-custom-filter-panel');
    if (panel instanceof HTMLElement) panel.style.display = this.#mode === 'custom' ? 'flex' : 'none';
  }

  /**
   * 컨트롤 엘리먼트들을 등록합니다.
   * @param {any} controls 
   */
  registerControls = ({ wrapper, checkbox, slider, label, select }) => {
    this.controls = { wrapper, checkbox, slider, label, select };
    this.refreshControls();
  };

  /** 컨트롤 상태를 새로고침합니다. */
  refreshControls = () => {
    if (!this.controls) return;
    const { wrapper, checkbox, slider, label, select } = this.controls;
    checkbox.checked = this.enabled;
    wrapper.setAttribute('aria-checked', String(this.enabled));
    slider.style.accentColor = this.enabled ? '#00f889' : 'gray';
    slider.value = this.intensity;
    slider.setAttribute('aria-valuenow', this.intensity.toFixed(1));
    slider.setAttribute('aria-valuetext', `강도 ${this.intensity.toFixed(1)} 배`);
    label.textContent = `(${this.intensity.toFixed(1)}x 배)`;
    select.value = this.mode;
  };

  /** 테스트 패턴을 그립니다. */
  drawTestPattern = () => {
    const c = /** @type {HTMLCanvasElement|null} */(document.getElementById('sharp-test-canvas'));
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const { width: w, height: h } = c;
    ctx.clearRect(0, 0, w, h);
    ctx.strokeStyle = '#888';
    ctx.lineWidth = 1;
    for (let x = 0; x <= w; x += 10) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    }
    for (let y = 0; y <= h; y += 10) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    ctx.strokeStyle = '#444';
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(w, h); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(w, 0); ctx.lineTo(0, h); ctx.stroke();
  };

  /**
   * 메뉴에 컨트롤을 추가합니다.
   * @param {HTMLElement} menu 
   */
  addMenuControls = (menu) => {
    if (menu.querySelector('.cqc-sharp-menu')) return;

    const NATIVE_FILTER_SELECTOR = '.pzp-pc-setting-intro-filter';
    let nativeItem = menu.querySelector(NATIVE_FILTER_SELECTOR);
    /** @type {any} */
    let container;

    if (nativeItem) {
      container = nativeItem.cloneNode(false);
      container.classList.add('cqc-sharp-menu');
      nativeItem.replaceWith(container);
      log('기존 선명한 화면 항목 발견 — 대체');
    } else {
      container = document.createElement('div');
      container.className = 'pzp-ui-setting-home-item cqc-sharp-menu';
      container.setAttribute('role', 'menuitem');
      container.tabIndex = 0;
      menu.append(container);
      log('기존 선명한 화면 항목 없음 — 새로 추가');
    }

    const filterId = this.#getFilterId();
    const c = this.#custom;
    const customDisplay = this.#mode === 'custom' ? 'flex' : 'none';
    container.innerHTML = `
        <div class="pzp-ui-setting-home-item__top">
          <div class="pzp-ui-setting-home-item__left">
            <span class="pzp-ui-setting-home-item__label">선명한 화면</span>
          </div>
          <div class="pzp-ui-setting-home-item__right">
            <div role="switch" class="pzp-ui-toggle sharp-toggle-wrapper"
                 aria-label="샤프닝 필터 토글"
                 aria-checked="${this.enabled}" tabindex="0">
              <input type="checkbox" class="pzp-ui-toggle__checkbox sharp-toggle" tabindex="-1">
              <div class="pzp-ui-toggle__handle"></div>
            </div>
          </div>
        </div>
        <div class="pzp-ui-setting-home-item__bottom" style="padding:8px;display:flex;flex-direction:column;gap:8px;">
          <div style="display:flex;align-items:center;gap:8px;">
            <label for="sharp-filter-select" class="visually-hidden">필터 선택</label>
            <select id="sharp-filter-select" style="flex:1;padding:4px 6px;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:5px;color:#e0e0e0;font-size:11px;outline:none;cursor:pointer;">
              <option value="default" style="background:#141517; color:#e0e0e0;">기본 필터</option>
              <option value="natural" style="background:#141517; color:#e0e0e0;">색상 보정 필터</option>
              <option value="custom" style="background:#141517; color:#e0e0e0;">커스텀 필터</option>
            </select>
          </div>
          <div style="display:flex;align-items:center;gap:8px;">
            <label for="sharp-slider" class="visually-hidden">강도 조절</label>
            <input id="sharp-slider" type="range" min="1" max="3" step="0.1" class="sharp-slider"
                   aria-valuemin="1" aria-valuemax="3">
            <span id="sharp-intensity-label"></span>
          </div>
          <div class="cqc-custom-filter-panel" style="display:${customDisplay};flex-direction:column;gap:6px;padding-top:4px;border-top:1px solid rgba(255,255,255,0.08);">
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="min-width:40px;font-size:11px;color:#aaa;">채도</span>
              <input type="range" min="0" max="2" step="0.05" value="${c.saturate}" class="cqc-custom-saturate" style="flex:1;accent-color:#00f889;">
              <span class="cqc-custom-saturate-val" style="min-width:32px;text-align:right;font-size:11px;color:#aaa;">${c.saturate.toFixed(2)}</span>
            </div>
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="min-width:40px;font-size:11px;color:#aaa;">밝기</span>
              <input type="range" min="0.5" max="1.5" step="0.05" value="${c.brightness}" class="cqc-custom-brightness" style="flex:1;accent-color:#00f889;">
              <span class="cqc-custom-brightness-val" style="min-width:32px;text-align:right;font-size:11px;color:#aaa;">${c.brightness.toFixed(2)}</span>
            </div>
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="min-width:40px;font-size:11px;color:#aaa;">대비</span>
              <input type="range" min="0.5" max="1.5" step="0.05" value="${c.contrast}" class="cqc-custom-contrast" style="flex:1;accent-color:#00f889;">
              <span class="cqc-custom-contrast-val" style="min-width:32px;text-align:right;font-size:11px;color:#aaa;">${c.contrast.toFixed(2)}</span>
            </div>
            <button class="cqc-custom-reset" style="align-self:flex-end;padding:2px 10px;font-size:10px;color:#aaa;background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.1);border-radius:4px;cursor:pointer;">초기화</button>
          </div>
          <div style="display:flex;gap:8px;">
            <canvas id="sharp-test-canvas" width="100" height="100"
              style="border:1px solid #ccc;filter:url(#${filterId});"></canvas>
            <img id="sharp-example-image"
                 src="https://images.unsplash.com/photo-1596854372745-0906a0593bca?q=80&w=2080"
                 alt="예시 이미지" width="100" height="100"
                 style="border:1px solid #ccc;filter:url(#${filterId});display:block;vertical-align:top;">
          </div>
        </div>`;

    const wrapper = container.querySelector('.sharp-toggle-wrapper');
    const checkbox = container.querySelector('.sharp-toggle');
    const slider = container.querySelector('#sharp-slider');
    const label = container.querySelector('#sharp-intensity-label');
    const select = container.querySelector('#sharp-filter-select');

    checkbox.checked = this.enabled;
    wrapper.setAttribute('aria-checked', String(this.enabled));
    slider.value = this.intensity;
    label.textContent = `(${this.intensity.toFixed(1)}x 배)`;
    select.value = this.mode;

    container.addEventListener('click', (/** @type {any} */ e) => { e.stopPropagation(); });
    container.addEventListener('mousedown', (/** @type {any} */ e) => { e.stopPropagation(); });
    container.addEventListener('mouseup', (/** @type {any} */ e) => { e.stopPropagation(); });
    container.addEventListener('pointerdown', (/** @type {any} */ e) => { e.stopPropagation(); });
    container.addEventListener('pointerup', (/** @type {any} */ e) => { e.stopPropagation(); });

    wrapper.addEventListener('click', () => { this.toggle(); });

    wrapper.addEventListener('keydown', (/** @type {any} */ e) => {
      if (['Enter', ' '].includes(e.key)) {
        e.preventDefault();
        this.toggle();
      }
    });

    slider.addEventListener('input', (/** @type {any} */ e) => {
      // @ts-ignore
      const v = parseFloat(e.target.value);
      this.setIntensity(v);
      this.drawTestPattern();
    });

    slider.addEventListener('keydown', (/** @type {any} */ e) => {
      if (!this.enabled) return;
      let v = this.intensity;
      if (['ArrowRight', 'ArrowUp'].includes(e.key)) v = Math.min(v + 0.1, 3);
      else if (['ArrowLeft', 'ArrowDown'].includes(e.key)) v = Math.max(v - 0.1, 1);
      else return;
      e.preventDefault();
      this.setIntensity(v);
      slider.value = v;
      this.drawTestPattern();
    });

    select.addEventListener('change', (/** @type {any} */ e) => {
      // @ts-ignore
      const newMode = e.target.value;
      this.setMode(newMode);
      this.drawTestPattern();
      const flip = this.#getFilterId();
      const canvas = document.getElementById('sharp-test-canvas');
      const img = document.getElementById('sharp-example-image');
      if (canvas) canvas.style.filter = `url(#${flip})`;
      if (img) img.style.filter = `url(#${flip})`;
    });

    const bindCustom = (/** @type {string} */ cls, /** @type {string} */ param) => {
      const input = container.querySelector(`.cqc-custom-${cls}`);
      const valSpan = container.querySelector(`.cqc-custom-${cls}-val`);
      if (!input) return;
      input.addEventListener('input', (/** @type {any} */ e) => {
        // @ts-ignore
        const v = parseFloat(e.target.value);
        this.setCustomParam(param, v);
        if (valSpan) valSpan.textContent = v.toFixed(2);
        const fid = this.#getFilterId();
        const cv = document.getElementById('sharp-test-canvas');
        const im = document.getElementById('sharp-example-image');
        if (cv) cv.style.filter = `url(#${fid})`;
        if (im) im.style.filter = `url(#${fid})`;
      });
    };
    bindCustom('saturate', 'saturate');
    bindCustom('brightness', 'brightness');
    bindCustom('contrast', 'contrast');

    const resetBtn = container.querySelector('.cqc-custom-reset');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        this.#custom = { ...DEFAULT_CUSTOM };
        this.#updateCustomFilter();
        setValue(STORAGE_KEY_CUSTOM, { ...this.#custom });
        container.querySelector('.cqc-custom-saturate').value = DEFAULT_CUSTOM.saturate;
        container.querySelector('.cqc-custom-brightness').value = DEFAULT_CUSTOM.brightness;
        container.querySelector('.cqc-custom-contrast').value = DEFAULT_CUSTOM.contrast;
        container.querySelector('.cqc-custom-saturate-val').textContent = DEFAULT_CUSTOM.saturate.toFixed(2);
        container.querySelector('.cqc-custom-brightness-val').textContent = DEFAULT_CUSTOM.brightness.toFixed(2);
        container.querySelector('.cqc-custom-contrast-val').textContent = DEFAULT_CUSTOM.contrast.toFixed(2);
      });
    }

    this.registerControls({ wrapper, checkbox, slider, label, select });
    this.drawTestPattern();
    log('메뉴 컨트롤 추가 완료');
  };

  /** 메뉴 감시를 시작합니다. */
  observeMenus = () => {
    const trySetup = () => {
      const menu = document.querySelector(MENU_SELECTOR);
      if (menu instanceof HTMLElement) {
        this.addMenuControls(menu);
      }
    };
    trySetup();
    // MutationObserver 대신 1.5초 주기 interval을 돌며 메뉴 유무를 확인합니다.
    // 메뉴 설정 창이 열렸을 때만 추가 렌더링을 진행하도록 가벼운 폴링을 구성합니다.
    window.setInterval(trySetup, 1500);
  };
}

/**
 * 선명도 모듈 초기화
 */
let sharpnessInstance;
export function initSharpness() {
  if (sharpnessInstance) return sharpnessInstance;
  const sharpness = sharpnessInstance = new SharpnessFilter();
  sharpness.init();
  sharpness.observeMenus();
}
