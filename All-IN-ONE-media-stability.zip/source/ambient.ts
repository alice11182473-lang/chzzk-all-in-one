// @ts-nocheck
import Browser from 'webextension-polyfill';
import { isLargeMode, SELECTORS } from './dom-utils';

/** 앰비언트 컬러 샘플링 간격 (ms) — 느릴수록 오로라처럼 부드럽게 */
const AMBIENT_UPDATE_INTERVAL = 2000;

/**
 * 앰비언트 배경 효과 관리 클래스
 */
class AmbientManager {
    static _instance: AmbientManager | null = null;

    _enabled: boolean = true;
    _isRunning: boolean = false;
    _rafId: number | null = null;
    _lastUpdateTime: number = 0;
    _isVideoVisible: boolean = true;

    _canvasA: HTMLCanvasElement | null = null;
    _canvasB: HTMLCanvasElement | null = null;
    _ctxA: CanvasRenderingContext2D | null = null;
    _ctxB: CanvasRenderingContext2D | null = null;
    _frontIsA: boolean = true;

    _container: HTMLElement | null = null;
    _video: HTMLVideoElement | null = null;
    _loopId: number | null = null;
    _observer: IntersectionObserver | null = null;
    _playListener: (() => void) | null = null;
    _pauseListener: (() => void) | null = null;

    constructor() {
        if (AmbientManager._instance) return AmbientManager._instance;
        AmbientManager._instance = this;
        this._initEvents();
    }

    static getInstance(): AmbientManager {
        if (!AmbientManager._instance) AmbientManager._instance = new AmbientManager();
        return AmbientManager._instance;
    }

    _initEvents(): void {
        const onStateChange = () => {
            if (this._isContextValid()) this.tryInject();
        };
        window.addEventListener('resize', onStateChange);
        document.addEventListener('fullscreenchange', onStateChange);
        document.addEventListener('webkitfullscreenchange', onStateChange);

        document.addEventListener('click', (e: MouseEvent) => {
            const target = e.target as HTMLElement | null;
            if (target && typeof target.closest === 'function') {
                if (target.closest(SELECTORS.VIEW_MODE_BTN)) {
                    setTimeout(onStateChange, 50);
                    setTimeout(onStateChange, 300);
                }
            }
        });

        document.addEventListener('keydown', (e: KeyboardEvent) => {
            const target = e.target as HTMLElement | null;
            if (target) {
                const tagName = target.tagName || '';
                const isEditable = (target as any).isContentEditable || false;
                if (tagName === 'INPUT' || tagName === 'TEXTAREA' || isEditable) return;
            }

            const key = e.key.toLowerCase();
            if (key === 't' || key === 'j') {
                setTimeout(onStateChange, 50);
                setTimeout(onStateChange, 300);
            }
        });
    }

    _isContextValid(): boolean {
        return !!(typeof Browser !== 'undefined' && Browser.runtime?.id);
    }

    init(): void {
        if (!this._isContextValid()) return;

        try {
            Browser.storage.sync.get('settings').then((items: any) => {
                if (!this._isContextValid()) return;
                const data = items;
                const enabled = data?.settings?.ambientEnabled ?? true;
                this.updateSettings({ ambientEnabled: enabled });
            }).catch(e => console.error('[CQC:Ambient] Storage get error:', e));

            Browser.storage.onChanged.addListener((changes: any, area: string) => {
                if (area === 'sync' && changes.settings && this._isContextValid()) {
                    const newValue = changes.settings.newValue;
                    const enabled = newValue?.ambientEnabled ?? true;
                    this.updateSettings({ ambientEnabled: enabled });
                }
            });
        } catch (e) {
            console.error('[CQC:Ambient] Storage error:', e);
        }
    }

    updateSettings(settings: any): void {
        const wasEnabled = this._enabled;
        this._enabled = settings.ambientEnabled ?? true;

        if (this._enabled) {
            if (!wasEnabled) this._startLoop();
            this.tryInject();
        } else {
            this._stopLoop();
            this.cleanup(false);
        }
    }

    _startLoop(): void {
        this._stopLoop();
        this._loopId = window.setInterval(() => {
            if (!this._isContextValid()) {
                this._stopLoop();
                return;
            }
            const isLive = location.pathname.startsWith('/live/') && location.pathname.length > 6;
            if (isLive) this.tryInject();
            else this.cleanup(true);
        }, 1000);
    }

    _stopLoop(): void {
        if (this._loopId) {
            clearInterval(this._loopId);
            this._loopId = null;
        }
    }

    _createLayer(): HTMLElement {
        this._container = document.createElement('div');
        if (this._container) {
            this._container.className = 'cqc-ambient-container';
        }

        const makeCanvas = (): HTMLCanvasElement => {
            const c = document.createElement('canvas');
            c.className = 'cqc-ambient-canvas';
            c.width = 16;
            c.height = 9;
            // @ts-ignore
            window.cqcGC?.track(c, 'Canvas');
            return c;
        };

        this._canvasA = makeCanvas();
        if (this._canvasA) {
            this._ctxA = this._canvasA.getContext('2d', { alpha: false });
            this._canvasA.style.opacity = '1';
        }
        this._canvasB = makeCanvas();
        if (this._canvasB) {
            this._ctxB = this._canvasB.getContext('2d', { alpha: false });
            this._canvasB.style.opacity = '0';
        }

        this._frontIsA = true;

        if (this._container) {
            if (this._canvasA) this._container.appendChild(this._canvasA);
            if (this._canvasB) this._container.appendChild(this._canvasB);
            this._container.style.opacity = '0';
        }
        return this._container as HTMLElement;
    }

    tryInject(): void {
        if (!this._enabled || !this._isContextValid()) return;

        const isLive = location.pathname.startsWith('/live/') && location.pathname.length > 6;
        const isMain = window.self === window.top;
        const isMV = location.search.includes('mv_iframe=1');

        if (!isLive || !isMain || isMV) {
            this.cleanup(true);
            return;
        }

        const pzp = document.querySelector(SELECTORS.PLAYER_CONTAINER);
        const video = pzp?.querySelector('video') as HTMLVideoElement | null;

        if (!pzp || !video) return;

        const isDetached = this._container && !this._container.isConnected;
        if ((this._video && this._video !== video) || isDetached) {
            this.cleanup(true);
        }

        const isLarge = isLargeMode();
        const vContainer = document.querySelector(SELECTORS.LIVE_VIDEO_CONTAINER) as HTMLElement | null;

        if (isLarge) {
            if (this._container) this._container.style.display = 'none';
            this._isVideoVisible = false;
            if (vContainer) vContainer.style.setProperty('overflow', 'hidden', 'important');
        } else {
            if (this._container) this._container.style.display = 'block';
            this._isVideoVisible = true;
            if (vContainer) vContainer.style.removeProperty('overflow');
        }

        const parent = pzp.parentElement;
        if (parent && !parent.querySelector(':scope > .cqc-ambient-container')) {
            if (this._container) this._container.remove();
            const layer = this._createLayer();
            if (window.getComputedStyle(parent).position === 'static') {
                parent.style.position = 'relative';
            }
            parent.insertBefore(layer, pzp);
            document.body.classList.add('cqc-ambient-active');
        }

        if (this._video !== video) {
            this._video = video;
            this._bindVideoEvents(video);
            this._initObserver(video);
        }

        if (this._enabled && this._isVideoVisible && !video.paused && !video.ended) {
            if (!this._isRunning) {
                this._isRunning = true;
                this._scheduleNext();
            }
        }
    }

    _bindVideoEvents(video: HTMLVideoElement): void {
        this._unbindVideoEvents();
        
        this._playListener = () => {
            if (this._enabled && this._isVideoVisible && !this._isRunning) {
                this._isRunning = true;
                this._scheduleNext();
            }
        };
        this._pauseListener = () => {
            this._isRunning = false;
            if (this._rafId) {
                if (this._video && 'cancelVideoFrameCallback' in HTMLVideoElement.prototype) {
                    // @ts-ignore
                    this._video.cancelVideoFrameCallback(this._rafId);
                } else {
                    cancelAnimationFrame(this._rafId);
                }
                this._rafId = null;
            }
        };

        video.addEventListener('play', this._playListener);
        video.addEventListener('pause', this._pauseListener);
        video.addEventListener('ended', this._pauseListener);
    }

    _unbindVideoEvents(): void {
        if (this._video) {
            if (this._playListener) this._video.removeEventListener('play', this._playListener);
            if (this._pauseListener) {
                this._video.removeEventListener('pause', this._pauseListener);
                this._video.removeEventListener('ended', this._pauseListener);
            }
        }
        this._playListener = null;
        this._pauseListener = null;
    }

    _initObserver(video: HTMLVideoElement): void {
        if (this._observer) {
            this._observer.disconnect();
        }
        this._observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                const isLarge = isLargeMode();
                if (this._container) {
                    this._container.style.display = isLarge ? 'none' : 'block';
                }
                this._isVideoVisible = entry.isIntersecting && !isLarge;
                
                const vContainer = document.querySelector(SELECTORS.LIVE_VIDEO_CONTAINER) as HTMLElement | null;
                if (vContainer) {
                    if (isLarge) vContainer.style.setProperty('overflow', 'hidden', 'important');
                    else vContainer.style.removeProperty('overflow');
                }

                if (this._isVideoVisible && video && !video.paused && !video.ended) {
                    if (!this._isRunning) {
                        this._isRunning = true;
                        this._scheduleNext();
                    }
                } else {
                    this._isRunning = false;
                }
            });
        }, { threshold: 0 });
        this._observer.observe(video);
    }

    _scheduleNext(): void {
        if (!this._video || !this._isRunning || !this._isVideoVisible || this._video.paused || this._video.ended) {
            this._isRunning = false;
            return;
        }
        if ('requestVideoFrameCallback' in HTMLVideoElement.prototype) {
            // @ts-ignore
            this._rafId = this._video.requestVideoFrameCallback((t: number) => this._update(t));
        } else {
            this._rafId = requestAnimationFrame((t: number) => this._update(t));
        }
    }

    _update(timestamp: number): void {
        if (!this._enabled || !this._video || !this._canvasA || !this._canvasB || !this._ctxA || !this._ctxB) {
            this._isRunning = false;
            if (this._container) this._container.style.opacity = '0';
            return;
        }

        if (!this._isVideoVisible || this._video.paused || this._video.ended || this._video.readyState < 2) {
            if (this._container) this._container.style.opacity = '0';
            this._isRunning = false;
            return;
        }

        const now = performance.now();
        if (this._lastUpdateTime === 0 || now - this._lastUpdateTime >= AMBIENT_UPDATE_INTERVAL) {
            try {
                const backCtx = this._frontIsA ? this._ctxB : this._ctxA;
                const frontCanvas = this._frontIsA ? this._canvasA : this._canvasB;
                const backCanvas = this._frontIsA ? this._canvasB : this._canvasA;

                if (backCtx) backCtx.drawImage(this._video, 0, 0, 16, 9);
                if (backCanvas) backCanvas.style.opacity = '1';
                if (frontCanvas) frontCanvas.style.opacity = '0';
                this._frontIsA = !this._frontIsA;

                if (this._container) this._container.style.opacity = '1';
            } catch (e) {
                if (this._container) this._container.style.opacity = '0';
            }
            this._lastUpdateTime = now;
        }

        this._scheduleNext();
    }

    cleanup(isTemp: boolean = false): void {
        if (!isTemp) this._enabled = false;
        this._isRunning = false;

        this._unbindVideoEvents();

        if (this._rafId) {
            if (this._video && 'cancelVideoFrameCallback' in HTMLVideoElement.prototype) {
                // @ts-ignore
                this._video.cancelVideoFrameCallback(this._rafId);
            } else {
                cancelAnimationFrame(this._rafId);
            }
            this._rafId = null;
        }

        if (this._observer) {
            this._observer.disconnect();
            this._observer = null;
        }

        if (this._container) {
            this._container.remove();
            this._container = null;
            this._canvasA = null; this._ctxA = null;
            this._canvasB = null; this._ctxB = null;
        }

        document.body?.classList.remove('cqc-ambient-active');
        const vContainer = document.querySelector(SELECTORS.LIVE_VIDEO_CONTAINER) as HTMLElement | null;
        if (vContainer) vContainer.style.removeProperty('overflow');

        this._video = null;
    }
}

const manager = AmbientManager.getInstance();

export const initAmbient = (): void => {
    if (manager) manager.init();
};
export const tryInjectAmbient = (): void => {
    if (manager) manager.tryInject();
};
export const cleanupAmbient = (isTemp) => {
    if (manager) manager.cleanup(isTemp);
};
/** @param {any} settings */
export const updateAmbientSettings = (settings) => {
    if (manager) manager.updateSettings(settings);
};
