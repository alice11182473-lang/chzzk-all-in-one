// @ts-nocheck
import { getReactProps, getFiberNode, SELECTORS, ConsoleLogger } from './dom-utils';

/**
 * PC/모바일 디바이스 아이콘 SVG 정의
 */
const SVG_PC = `<svg class="cqc-device-icon cqc-device-icon--pc" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="1.5" y="2" width="13" height="9" rx="1.5"/><line x1="5.5" y1="14" x2="10.5" y2="14"/><line x1="8" y1="11" x2="8" y2="14"/></svg>`;

const SVG_ANDROID = `<svg class="cqc-device-icon cqc-device-icon--android" viewBox="780 0 220 158.588" fill="none"><path fill="currentColor" d="M999.254 149.56c-.086-.546-.17-1.086-.261-1.626a132.867 132.867 0 0 0-2.034-9.928 133.566 133.566 0 0 0-11.303-29.985 135.285 135.285 0 0 0-9.738-15.887 134.237 134.237 0 0 0-14.709-17.325 134.646 134.646 0 0 0-23.677-18.77c.052-.084.095-.175.147-.26 2.692-4.651 5.392-9.297 8.084-13.948l7.897-13.623c1.896-3.26 3.787-6.525 5.67-9.785a12.276 12.276 0 0 0 .69-10.93 12.163 12.163 0 0 0-5.027-5.771 12.353 12.353 0 0 0-5.218-1.678 12.471 12.471 0 0 0-2.311.02 12.237 12.237 0 0 0-9.349 6.044c-1.891 3.259-3.782 6.525-5.67 9.784l-7.897 13.624c-2.692 4.651-5.392 9.296-8.084 13.948-.294.507-.591 1.015-.884 1.529-.409-.163-.813-.326-1.222-.482-14.843-5.66-30.948-8.756-47.782-8.756-.46 0-.916 0-1.38.006-14.967.15-29.347 2.752-42.763 7.423-1.55.54-3.085 1.113-4.607 1.711-.274-.474-.555-.95-.825-1.424-2.692-4.652-5.392-9.297-8.084-13.949l-7.897-13.623a4140.11 4140.11 0 0 1-5.67-9.785A12.234 12.234 0 0 0 783.69.05c-1.832.157-3.62.723-5.222 1.68a12.214 12.214 0 0 0-4.25 4.235 12.045 12.045 0 0 0-.773 1.535 12.31 12.31 0 0 0-.38 8.536c.27.82.618 1.62 1.066 2.394 1.895 3.26 3.786 6.525 5.67 9.784 2.636 4.542 5.269 9.083 7.901 13.624 2.692 4.651 5.388 9.296 8.08 13.948.02.039.048.078.068.117a134.67 134.67 0 0 0-15.475 11.21 135.198 135.198 0 0 0-23.142 25.034 133.16 133.16 0 0 0-9.737 15.887 133.682 133.682 0 0 0-11.303 29.985 136.29 136.29 0 0 0-2.034 9.928c-.091.54-.175 1.086-.258 1.626a130.315 130.315 0 0 0-.769 5.875H1000a136.2 136.2 0 0 0-.765-5.875z"/><path fill="#202124" d="M935.982 118.54c5.34-3.555 6.117-11.78 1.732-18.37-4.38-6.59-12.262-9.05-17.599-5.495-5.34 3.555-6.117 11.78-1.732 18.369 4.38 6.59 12.262 9.05 17.599 5.495zM814.983 113.067c4.385-6.59 3.608-14.814-1.732-18.369-5.34-3.555-13.219-1.095-17.604 5.495-4.38 6.59-3.603 14.814 1.733 18.369 5.34 3.555 13.222 1.095 17.603-5.495z"/></svg>`;

const SVG_APPLE = `<svg class="cqc-device-icon cqc-device-icon--apple" viewBox="0 0 406.5899048 500" fill="currentColor"><path d="M393.794 170.505c-2.88 2.24-54.063 30.71-54.063 95.01 0 74.216 64.94 100.448 66.859 101.088-.32 1.92-10.237 35.828-34.23 71.017-21.112 30.71-43.825 61.74-77.734 61.74s-42.867-20.153-81.894-20.153c-38.388 0-51.823 20.793-82.854 20.793s-52.783-28.79-77.735-63.66C23.353 395.074 0 331.414 0 270.633c0-96.929 63.02-148.752 125.4-148.752 32.95 0 60.46 21.753 81.254 21.753 19.514 0 50.224-23.033 87.972-23.033 14.395 0 65.579 1.28 99.168 49.904zm-184.58-55.342c-2.56 0-5.12-.32-6.719-.64-.32-1.28-.96-5.118-.96-8.957 0-25.911 13.116-51.503 27.512-67.818C246.96 16.635 277.35.96 302.303 0c.64 2.88.96 6.398.96 9.917 0 25.592-10.877 51.183-26.232 69.738-16.634 20.473-45.105 35.508-67.818 35.508z"/></svg>`;

const DEVICE_DATA_ATTR = 'data-cqc-device-icon';

/**
 * 채팅 디바이스 아이콘 초기화
 */
export const initChatDeviceIcon = (settings: any, observer: any) => {
  ConsoleLogger.log('info', 'Chat', '[ChatDeviceIcon] 초기화 시작');

  const getOsType = (chatMessage: any): string => {
    if (!chatMessage) return '';

    // 1) 직접 osType 필드
    let os = (chatMessage.osType || '').toUpperCase();

    // 2) originalExtras에서 추출
    if (!os && chatMessage.originalExtras) {
      try {
        const extras = typeof chatMessage.originalExtras === 'string'
          ? JSON.parse(chatMessage.originalExtras)
          : chatMessage.originalExtras;
        if (extras.osType) os = extras.osType.toUpperCase();
      } catch (e) { /* ignore */ }
    }

    // WEB → PC 통일
    if (os === 'WEB') os = 'PC';
    return os;
  };

  const getSvgForOS = (os: string): string => {
    if (os === 'PC') return SVG_PC;
    if (os === 'AOS' || os === 'ANDROID') return SVG_ANDROID;
    if (os === 'IOS' || os === 'APPLE') return SVG_APPLE;
    return '';
  };

  /** @param {HTMLElement} el - CHAT_MESSAGE/CHAT_ITEM 요소 */
  const applyDeviceIcon = (el: HTMLElement) => {
    if (!settings?.chatDeviceIconEnabled) return;

    let chatMessage = getReactProps(el)?.chatMessage;
    if (!chatMessage) {
      let fiber = getFiberNode(el);
      for (let i = 0; i < 5 && fiber; i++) {
        if (fiber.memoizedProps?.chatMessage) {
          chatMessage = fiber.memoizedProps.chatMessage;
          break;
        }
        fiber = fiber.return;
      }
    }

    if (!chatMessage) return;

    const os = getOsType(chatMessage);
    if (!os) return;

    const svg = getSvgForOS(os);
    if (!svg) return;

    const item = el.closest(SELECTORS.CHAT_ITEM_CONTAINER);
    if (item && (item.querySelector(SELECTORS.CHAT_DONATION) || item.matches(SELECTORS.CHAT_DONATION))) {
      return;
    }

    const existingIcon = item
      ? item.querySelector('.cqc-device-icon')
      : el.querySelector('.cqc-device-icon');

    if (existingIcon) {
      // 이미 같은 OS 아이콘이면 스킵
      if (existingIcon.getAttribute('data-os') === os) return;
      existingIcon.parentElement?.remove();
    }

    el.setAttribute(DEVICE_DATA_ATTR, 'true');

    const wrapper = document.createElement('span');
    wrapper.className = 'cqc-device-icon-wrapper';
    wrapper.innerHTML = svg;
    wrapper.title = os === 'PC' ? 'PC' : os === 'AOS' ? 'Android' : os === 'IOS' ? 'iOS' : os;

    const svgEl = wrapper.querySelector('svg');
    if (svgEl) svgEl.setAttribute('data-os', os);

    const stampEl = item?.querySelector('.cqc-stamp');
    const nickBtn = item?.querySelector(SELECTORS.CHAT_NICKNAME);

    // 타임스탬프가 있다면 그 왼쪽에 삽입, 없으면 닉네임 왼쪽에 삽입
    if (stampEl?.parentElement) {
      stampEl.parentElement.insertBefore(wrapper, stampEl);
    } else if (nickBtn?.parentElement) {
      nickBtn.parentElement.insertBefore(wrapper, nickBtn);
    } else if (item) {
      item.prepend(wrapper);
    } else {
      el.prepend(wrapper);
    }
  };

  const removeAllIcons = () => {
    document.querySelectorAll('.cqc-device-icon-wrapper').forEach(el => el.remove());
    document.querySelectorAll(`[${DEVICE_DATA_ATTR}]`).forEach(el => el.removeAttribute(DEVICE_DATA_ATTR));
  };

  const initialCheck = () => {
    if (!settings?.chatDeviceIconEnabled) {
      removeAllIcons();
      return;
    }
    document.querySelectorAll(SELECTORS.CHAT_MESSAGE).forEach(el => {
      applyDeviceIcon(el as HTMLElement);
    });
  };

  const retrigger = () => {
    initialCheck();
  };

  // 뮤테이션 폭주를 프레임당 1회 스캔으로 합쳐 깜빡임/리플로우 방지
  let scanRaf = 0;
  const scheduleScan = () => {
    if (scanRaf) return;
    scanRaf = requestAnimationFrame(() => {
      scanRaf = 0;
      initialCheck();
    });
  };

  // 스타일 주입
  const STYLE_ID = 'cqc-chat-device-icon-style';
  if (!document.getElementById(STYLE_ID)) {
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .cqc-device-icon-wrapper {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-right: 4px;
        flex-shrink: 0;
        vertical-align: middle;
        opacity: 0.55;
        transition: opacity 0.15s;
        /* 채팅 폰트 크기 연동 (em 단위 사용) */
        font-size: 1.05em;
        width: 1em;
        height: 1em;
      }
      .cqc-device-icon-wrapper:hover {
        opacity: 1;
      }
      .cqc-device-icon {
        display: block;
        width: 100%;
        height: 100%;
      }
      .cqc-device-icon--pc {
        color: #6bb5ff;
      }
      .cqc-device-icon--android {
        color: #a4c639;
      }
      .cqc-device-icon--apple {
        color: #d1d5db;
      }
    `;
    document.head.appendChild(style);
  }

  let pollerHandle: any = null;
  let containerObserver: MutationObserver | null = null;

  if (observer) {
    pollerHandle = observer.poller.waitFor(
      'chatDeviceIconContainerWait',
      SELECTORS.CHAT_CONTAINER,
      (container: HTMLElement) => {
        ConsoleLogger.log('info', 'Chat', '[ChatDeviceIcon] 채팅 컨테이너 감지. MutationObserver 가동');
        initialCheck();

        if (containerObserver) {
          containerObserver.disconnect();
          containerObserver = null;
        }

        containerObserver = new MutationObserver(() => {
          if (!settings?.chatDeviceIconEnabled) return;
          scheduleScan();
        });

        containerObserver.observe(container, { childList: true, subtree: true });
      },
      { interval: 500, persistent: true }
    );
  }

  initialCheck();            // 토글-온 시 즉시 반영 (poller 틱 지연 제거)
  setTimeout(initialCheck, 1000);

  return {
    retrigger,
    cleanup: () => {
      ConsoleLogger.log('info', 'Chat', '[ChatDeviceIcon] 리소스 정리 진행');
      if (pollerHandle) {
        pollerHandle.stop();
        pollerHandle = null;
      }
      if (containerObserver) {
        containerObserver.disconnect();
        containerObserver = null;
      }
      if (scanRaf) {
        cancelAnimationFrame(scanRaf);
        scanRaf = 0;
      }
      removeAllIcons();
      const styleEl = document.getElementById(STYLE_ID);
      if (styleEl) styleEl.remove();
    }
  };
};
