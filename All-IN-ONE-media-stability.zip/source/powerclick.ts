import { observePowerRewards } from './compatibility/power-observer.js';
import { installPowerDashboard } from './compatibility/power-dashboard.js';
// @ts-nocheck
/**
 * @fileoverview 통나무 파밍(Power Click) 메인 컨트롤러 모듈 (Entry Point)
 */

import { triggerReact, getChannelData, SELECTORS, REGEX, log as cqcLog, getFiberNode } from './dom-utils';
import { powerDB } from './powerclick-db';
import { powerUI } from './powerclick-ui';

installPowerDashboard({db: powerDB, ui: powerUI, getChannel: getChannelData});

const log = (...args) => cqcLog('PowerManager', ...args);

class PowerManager {
    #powerCount = 0;
    #currentChannelId = '';
    #powerInterval = null;
    #navRetryTimer = null;
    #settings = { enabled: true, powerClickEnabled: true };
    #lastUrl = location.href;

    async init(settings) {
        if (settings) this.#settings = settings;

        await powerDB.init();
        await this.#checkDailyReset();

        if (this.#powerInterval) return;

        const onActivityChange = () => this.updateUI();
        window.addEventListener('cqc-power-activity-change', onActivityChange);
        this.stopPowerActivityListener = () => window.removeEventListener('cqc-power-activity-change', onActivityChange);

        document.addEventListener('visibilitychange', () => this.updateUI());
        window.addEventListener('focus', () => this.updateUI());
        window.addEventListener('blur', () => this.updateUI());
        window.addEventListener('click', () => this.updateUI(), { capture: true, passive: true });

        // 재생은 표시 조건일 뿐 적립 확인 근거로 사용하지 않습니다.
        document.addEventListener('play', (e) => {
            if (e.target && (e.target as Element).tagName === 'VIDEO' && this.#isPlayerPage()) {
                this.updateUI();
            }
        }, true);

        document.addEventListener('pause', (e) => {
            if (e.target && (e.target as Element).tagName === 'VIDEO' && this.#isPlayerPage()) {
                this.updateUI();
            }
        }, true);

        // 초기 채널 데이터 로드
        const channel = getChannelData(document.body);
        if (channel?.channelId) {
            this.#currentChannelId = channel.channelId;
            const storedCount = await powerDB.getKV('power_count_' + this.#currentChannelId);
            if (typeof storedCount === 'number') this.#powerCount = storedCount;
        }
        this.updateUI();

        this.stopPowerObserver?.();
        this.stopPowerObserver = observePowerRewards(() => this.collectAvailablePower());
        log('자동 통나무 파밍 감지 루프 시작 (3초 간격)');
        this.#powerInterval = setInterval(async () => {
            // SPA 라우팅 대응
            if (location.href !== this.#lastUrl) {
                this.#lastUrl = location.href;
                this.#currentChannelId = '';
                this.#powerCount = 0;
                powerUI.removeUI();
                this.#scheduleNavRetry();
            }

            if (!this.#settings.enabled || !this.#settings.powerClickEnabled) return;

            // 1. 현재 채널 식별
            const urlMatch = location.pathname.match(/^\/(live|video)\/([a-z0-9_]+)/i);
            const curChannel = getChannelData(document.body);
            const chId = urlMatch?.[2] || curChannel?.channelId || '';

            // 2. DB 카운트 동기화 (Race Condition 방지)
            if (chId && chId !== this.#currentChannelId) {
                this.#currentChannelId = chId;
                const storedCount = await powerDB.getKV('power_count_' + chId);
                this.#powerCount = typeof storedCount === 'number' ? storedCount : 0;
            } else if (this.#currentChannelId) {
                const storedCount = await powerDB.getKV('power_count_' + this.#currentChannelId);
                if (typeof storedCount === 'number') {
                    if (storedCount === 0) this.#powerCount = 0;
                    else if (storedCount > this.#powerCount) this.#powerCount = storedCount;
                }
            }

            // 3. 통나무 파밍 버튼 탐색 및 자동 클릭
            const btns = Array.from(document.querySelectorAll('button:not([data-cqc-clicked])'));
            for (const btn of btns) {
                if (REGEX.POWER_MSG.test(btn.textContent || '')) {
                    this.#clickPowerButton(/** @type {HTMLButtonElement} */(btn));
                }
            }
            this.updateUI();

        }, 3000);
    }

    collectAvailablePower() {
        if (!this.#settings.enabled || !this.#settings.powerClickEnabled || !this.#isPlayerPage()) return;
        for (const btn of document.querySelectorAll('button:not([data-cqc-clicked])')) {
            if (REGEX.POWER_MSG.test(btn.textContent || '')) this.#clickPowerButton(btn);
        }
    }

    async #clickPowerButton(btn) {
        if (!btn || btn.dataset.cqcClicked || btn.disabled) return;

        // 1. 클릭 시점의 채널 정보를 즉시 캡처 (데이터 유실 방지)
        const channel = getChannelData(document.body);
        const urlMatch = location.pathname.match(/^\/(live|video)\/([a-z0-9_]+)/i);
        const capturedChId = urlMatch?.[2] || channel?.channelId || this.#currentChannelId;
        let capturedChName = channel?.channelName;
        
        // 1-1. React props에서 이름을 가져오지 못했을 경우, 세부 정보 컨테이너에서 React 구조를 파싱하여 폴백
        if (!capturedChName || capturedChName === 'unknown') {
            const fallbackEl = document.querySelector(SELECTORS.LIVE_INFO_DETAILS);
            if (fallbackEl) {
                const fiber = getFiberNode(fallbackEl);
                const ci = fiber?.memoizedProps?.children?.props?.channelInformation;
                if (ci?.channelName) {
                    capturedChName = ci.channelName;
                }
            }
        }
        
        capturedChName = capturedChName || 'unknown';
        const capturedChImg = channel?.channelImageUrl || '';

        if (!capturedChId || capturedChId === 'unknown') {
            log('채널 식별 불가로 클릭 처리 중단 (채널 ID 누락)');
            return;
        }

        let amount = 1;
        const match = btn.textContent?.match(REGEX.AMOUNT_MSG);
        if (match) amount = parseInt(match[1], 10);

        // 2. 물리적/React 클릭 트리거
        // onPointerDown 등의 핸들러에서 매칭이 멈춰 실제 API 요청(onClick)이 호출되지 않는 버그 수정
        btn.dataset.cqcClicked = 'true';
        const reactClicked = triggerReact(btn, 'onClick');
        if (!reactClicked) {
            triggerReact(btn, 'onPointerDown');
            btn.click();
        }

        btn.dataset.cqcClicked = 'true';
        
        // 3. 메모리 카운트 선반영 및 UI 즉시 업데이트
        this.#powerCount += amount;
        this.updateUI();

        // 4. DB 업데이트 (비동기 처리)
        try {
            await powerDB.addPowerLog({
                amount,
                channelId: capturedChId,
                channelName: capturedChName,
                channelImageUrl: capturedChImg,
                url: location.href,
                timestamp: Date.now()
            });

            // 전체 카운트 누적
            const globalCount = (await powerDB.getKV('total_power_count') || 0) + amount;
            await powerDB.setKV('total_power_count', globalCount);

            // 채널별 카운트 누적
            const channelKey = 'power_count_' + capturedChId;
            const currentStored = await powerDB.getKV(channelKey) || 0;
            const newCount = currentStored + amount;
            await powerDB.setKV(channelKey, newCount);
            
            // 메모리 카운트 최종 동기화 (다른 탭 등에서의 변화 반영)
            if (capturedChId === this.#currentChannelId) {
                this.#powerCount = newCount;
            }

            // 채널 메타데이터 갱신 (목록 표시용)
            const official = await powerUI.getOfficialPower(capturedChId);
            await powerDB.setKV('channel_meta_' + capturedChId, {
                channelId: capturedChId,
                channelName: capturedChName,
                channelImageUrl: capturedChImg,
                officialAmount: official,
                syncTs: Date.now()
            });

            log(`벌목 성공: ${capturedChName} (+${amount})`);
        } catch (e) {
            log('벌목 데이터 저장 중 오류:', e);
        }

        // 5. 즉시 툴팁 UI 갱신 시도 (최근 획득 내역 업데이트)
        try {
            const tooltip = document.querySelector('.cqc-power-tooltip.is-show');
            if (tooltip) {
                const isSticky = tooltip.classList.contains('is-sticky');
                powerUI.renderPowerTooltip(tooltip, isSticky, capturedChId);
            }
        } catch (e) { }

        setTimeout(() => { if (document.contains(btn)) delete btn.dataset.cqcClicked; }, 1000);
    }

    #scheduleNavRetry() {
        if (!this.#settings.enabled || !this.#settings.powerClickEnabled) return;
        if (this.#navRetryTimer) clearInterval(this.#navRetryTimer);
        let retryCount = 0;
        
        this.#navRetryTimer = setInterval(() => {
            retryCount++;
            if (retryCount > 20) {
                clearInterval(this.#navRetryTimer);
                this.#navRetryTimer = null;
                return;
            }
            
            const hasVideoContainer = !!document.querySelector(SELECTORS.VIDEO_INFO_DATA);
            const hasToolbar = !!document.querySelector(SELECTORS.TOOLBAR_BOX);
            
            if (hasVideoContainer || hasToolbar) {
                this.updateUI();
            }
            
            if (document.getElementById('cqc-power-status') && document.getElementById('cqc-power-status-toolbar')) {
                clearInterval(this.#navRetryTimer);
                this.#navRetryTimer = null;
            }
        }, 500);
    }

    async #checkDailyReset() {
        try {
            const resetHours = this.#settings?.powerCountResetHours ?? 24;
            if (resetHours <= 0) return;

            const lastReset = await powerDB.getKV('power_last_reset_ts');
            const now = Date.now();

            if (!lastReset || now - lastReset >= resetHours * 60 * 60 * 1000) {
                log(`${resetHours}시간 경과, 파워 카운트 초기화 실행`);
                await powerDB.resetPowerChannels('all');
                await powerDB.setKV('power_last_reset_ts', now);
                this.#powerCount = 0;
            }
        } catch (e) {
            log('파워 리셋 타이머 체크 중 에러:', e);
        }
    }

    #isPlayerPage() {
        // live, video 페이지 중 /chat 경로가 아닌 경우에만 플레이어 페이지로 간주
        const path = location.pathname;
        const isBasicPlayer = /^\/(live|video)\/([a-z0-9_]+)/i.test(path);
        const isChatPage = path.endsWith('/chat');
        return isBasicPlayer && !isChatPage;
    }

    updateUI(currentSettings) {
        if (currentSettings) this.#settings = currentSettings;

        // 0. 페이지 유효성 확인 (live, video 페이지에서만 노출)
        if (!this.#isPlayerPage()) {
            window.__cqcPowerActivity?.updatePlayback({enabled: false});
            powerUI.removeUI();
            const isFocusMode = !!this.#settings.focusModeEnabled;
            const event = new CustomEvent('cqc-power-update', {
                detail: {
                    totalCount: 0,
                    powerCount: 0,
                    isFarming: false,
                    isFocusMode: isFocusMode,
                    isPowerEnabled: !!this.#settings.powerClickEnabled
                }
            });
            window.dispatchEvent(event);
            return;
        }

        const isPowerEnabled = this.#settings.enabled && this.#settings.powerClickEnabled;
        const isFocusMode = !!this.#settings.focusModeEnabled;
        
        // 한 채널을 즉시 예상 표시하고 서버 시청 적립 알림으로 보정합니다.
        const video = document.querySelector('video');
        const isPlaying = video && !video.paused && !video.ended;
        const liveChannelId = location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1] || '';
        window.__cqcPowerActivity?.updatePlayback({channelId: liveChannelId, playing: !!isPlaying, enabled: !!isPowerEnabled});
        const isFarming = !!(isPowerEnabled && isPlaying && window.__cqcPowerActivity?.isFarming(liveChannelId));
        
        powerUI.renderStatus(this.#powerCount, isPowerEnabled, this.#currentChannelId, isFarming, isFocusMode);
    }

    cleanup() {
        window.__cqcPowerActivity?.updatePlayback({enabled: false});
        this.stopPowerActivityListener?.();
        this.stopPowerActivityListener = null;
        this.stopPowerObserver?.();
        this.stopPowerObserver = null;
        if (this.#powerInterval) clearInterval(this.#powerInterval);
        if (this.#navRetryTimer) clearInterval(this.#navRetryTimer);
        this.#powerInterval = null;
        this.#navRetryTimer = null;
        powerUI.removeUI();
        log('모든 타이머 및 UI 요소 초기화 완료');
    }
}

const manager = new PowerManager();

// --------------------------------------------------------
// 호환성을 위한 Export 목록 (injected.js 에서 사용)
// --------------------------------------------------------

export const getKV = (key) => powerDB.getKV(key);
export const setKV = (key, value) => powerDB.setKV(key, value);
export const getPowerChannels = () => powerDB.getPowerChannels();
export const resetPowerChannels = (ids) => powerDB.resetPowerChannels(ids);

export const updatePowerStatusUI = (settings) => manager.updateUI(settings);
export const initPowerClick = (settings) => manager.init(settings);
export const cleanupPowerClick = () => manager.cleanup();
export const reinitPowerClickUI = () => manager.updateUI();
