// @ts-nocheck
// @ts-check
/** GC 모니터 — 메모리 성장 감지 + 세대별 객체 에이징 */

const PREFIX = '[CQC-GC]';
const STYLE = 'color:#7c3aed;font-weight:bold';
const _log = (/** @type {any[]} */ ...a) => console.log(`%c${PREFIX}`, STYLE, ...a);
const _warn = (/** @type {any[]} */ ...a) => console.warn(`%c${PREFIX}`, STYLE, ...a);

const TENURE_THRESHOLD = 3;
const DEFAULT_CONFIG = {
    sampleIntervalMs: 30_000,
    gcIntervalMs: 120_000,
    windowSize: 5,
};

const _fmt = (/** @type {number|null} */ bytes) => {
    if (bytes == null) return 'N/A';
    return bytes >= 1_048_576
        ? `${(bytes / 1_048_576).toFixed(2)} MB`
        : `${(bytes / 1024).toFixed(1)} KB`;
};

class GCMonitor {
    /** @type {number[]} */
    _samples = [];
    /** @type {Map<number, {weakRef: WeakRef<object>, label: string, gcCount: number, createdAt: number}>} */
    _tracked = new Map();
    /** @type {FinalizationRegistry<{label: string, id: number}>|null} */
    _registry = null;
    /** @type {number|null} */
    _sampleIntervalId = null;
    /** @type {number|null} */
    _gcIntervalId = null;
    _nextId = 0;
    _gcCallCount = 0;
    /** @type {typeof DEFAULT_CONFIG} */
    _config;

    /** @param {Partial<typeof DEFAULT_CONFIG>} config */
    constructor(config) {
        this._config = { ...DEFAULT_CONFIG, ...config };

        if (typeof FinalizationRegistry !== 'undefined') {
            this._registry = new FinalizationRegistry(({ label, id }) => {
                const entry = this._tracked.get(id);
                const survived = entry?.gcCount ?? '?';
                const lived = entry ? `${Date.now() - entry.createdAt}ms` : '?';
                _log(`✓ collected: ${label} #${id} — survived ${survived} GC cycles, lived ${lived}`);
                this._tracked.delete(id);
            });
        }
    }

    start() {
        if (this._sampleIntervalId !== null) return;
        this._sample();
        this._sampleIntervalId = window.setInterval(() => this._sample(), this._config.sampleIntervalMs);

        let gcTick = 0;
        const gcEvery = Math.round(this._config.gcIntervalMs / this._config.sampleIntervalMs);
        this._gcIntervalId = window.setInterval(() => {
            gcTick++;
            if (gcTick >= gcEvery) {
                gcTick = 0;
                this._tryGC('auto');
            }
        }, this._config.sampleIntervalMs);

        _log('started — gc available:', typeof window.gc === 'function');
    }

    stop() {
        if (this._sampleIntervalId !== null) clearInterval(this._sampleIntervalId);
        if (this._gcIntervalId !== null) clearInterval(this._gcIntervalId);
        this._sampleIntervalId = null;
        this._gcIntervalId = null;
    }

    /**
     * 객체를 추적 등록. GC 후 살아남을 때마다 gcCount 증가.
     * @param {object} obj
     * @param {string} label
     */
    track(obj, label) {
        if (typeof obj !== 'object' && typeof obj !== 'function') return;
        if (typeof WeakRef === 'undefined') return;
        const id = this._nextId++;
        this._tracked.set(id, {
            weakRef: new WeakRef(obj),
            label,
            gcCount: 0,
            createdAt: Date.now(),
        });
        this._registry?.register(obj, { label, id });
    }

    /** @returns {number|null} */
    _sampleHeap() {
        // @ts-ignore — performance.memory는 Chrome 전용
        return performance.memory ? performance.memory.usedJSHeapSize : null;
    }

    _isGrowing() {
        const win = this._samples.slice(-this._config.windowSize);
        if (win.length < this._config.windowSize) return false;
        for (let i = 1; i < win.length; i++) {
            if (win[i] <= win[i - 1]) return false;
        }
        return true;
    }

    /** @param {string} reason */
    _tryGC(reason) {
        const before = this._sampleHeap();
        if (typeof window.gc === 'function') {
            window.gc();
            this._gcCallCount++;
        }
        const after = this._sampleHeap();
        if (before !== null && after !== null) {
            const freed = before - after;
            _log(`[${reason}] GC: ${_fmt(before)} → ${_fmt(after)} (freed ${_fmt(freed)})`);
        }
        this._afterGC();
    }

    _afterGC() {
        for (const [id, entry] of this._tracked) {
            if (entry.weakRef.deref() === undefined) {
                this._tracked.delete(id);
            } else {
                entry.gcCount++;
                if (entry.gcCount === TENURE_THRESHOLD) {
                    _warn(`⚠ Old Generation 의심: ${entry.label} #${id} — ${entry.gcCount}번 GC 생존 (${_fmt(Date.now() - entry.createdAt)} 경과)`);
                }
            }
        }
    }

    _sample() {
        const heap = this._sampleHeap();
        if (heap !== null) {
            this._samples.push(heap);
            if (this._samples.length > this._config.windowSize + 2) this._samples.shift();
        }
        if (this._isGrowing()) {
            _warn(`메모리 성장 감지: 최근 ${this._config.windowSize}회 연속 증가 — 현재 ${_fmt(heap)}`);
        }
    }

    report() {
        _log('=== GC Monitor Report ===');
        // @ts-ignore
        if (performance.memory) {
            // @ts-ignore
            const m = performance.memory;
            _log(`힙: used=${_fmt(m.usedJSHeapSize)} / total=${_fmt(m.totalJSHeapSize)} / limit=${_fmt(m.jsHeapSizeLimit)}`);
        } else {
            _log('performance.memory 없음 (Firefox 또는 지원 안 됨)');
        }
        _log(`window.gc 사용 가능: ${typeof window.gc === 'function'} | GC 호출 횟수: ${this._gcCallCount}`);
        _log(`힙 샘플 (최근 ${this._samples.length}개):`, this._samples.map(_fmt).join(' → '));
        _log(`성장 중: ${this._isGrowing()}`);

        if (this._tracked.size === 0) {
            _log('추적 중인 객체 없음');
        } else {
            _log(`추적 객체 (${this._tracked.size}개):`);
            for (const [id, e] of this._tracked) {
                const alive = e.weakRef.deref() !== undefined;
                const age = `${Date.now() - e.createdAt}ms`;
                _log(`  ${e.label} #${id}: alive=${alive}, gcCount=${e.gcCount}, age=${age}`);
            }
        }
        _log('=========================');
    }

    status() {
        return {
            gcAvailable: typeof window.gc === 'function',
            gcCallCount: this._gcCallCount,
            heapUsed: this._sampleHeap(),
            isGrowing: this._isGrowing(),
            samples: [...this._samples],
            trackedCount: this._tracked.size,
        };
    }
}

/** @type {GCMonitor|null} */
let _singleton = null;

/** @param {Partial<typeof DEFAULT_CONFIG>} [config] */
export function initGCMonitor(config = {}) {
    if (_singleton) _singleton.stop();
    _singleton = new GCMonitor(config);
    _singleton.start();

    // @ts-ignore
    window.cqcGC = {
        report: () => _singleton?.report(),
        forceGC: () => _singleton?._tryGC('manual'),
        status: () => _singleton?.status(),
        track: (/** @type {object} */ obj, /** @type {string} */ label) => _singleton?.track(obj, label),
        stop: () => _singleton?.stop(),
        start: () => _singleton?.start(),
    };

    return _singleton;
}
