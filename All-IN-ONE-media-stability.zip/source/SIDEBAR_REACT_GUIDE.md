# 치지직 사이드바 리액트 데이터 추적 가이드

이 가이드는 치지직 사이드바의 리액트 내부 데이터(Fiber)를 추적하여 채널 정보 및 리액트 키를 추출하는 방법을 설명합니다. 별도의 API 호출 없이 페이지 내 이미 존재하는 데이터를 활용할 수 있습니다.

## 1. 대상 DOM 요소 및 셀렉터

사이드바의 팔로잉/추천 채널 리스트 항목은 다음과 같은 구조를 가집니다.

- **섹션 셀렉터**: `[class^="navigation_bar_section__"]`
- **아이템 셀렉터 (li)**: `li[data-channel-id]` 또는 섹션 내의 `li` 요소들
- **링크 셀렉터 (a)**: `a[href^="/live/"]`

## 2. React Fiber 접근 방법

DOM 요소에 연결된 React 내부 속성(`__reactFiber$`)을 통해 데이터에 접근합니다.

```javascript
/**
 * 특정 엘리먼트의 React Fiber 노드를 가져옵니다.
 * @param {HTMLElement} el 
 */
function getFiber(el) {
    const key = Object.keys(el).find(k => k.startsWith('__reactFiber$'));
    return key ? el[key] : null;
}
```

## 3. 주요 속성 매핑 (memoizedProps)

Fiber 노드의 `memoizedProps` (또는 부모 노드의 props)에서 다음 정보를 확인할 수 있습니다.

| 속성명 | 설명 | 예시 |
| :--- | :--- | :--- |
| `channelId` | 채널 고유 ID (해시) | `458f6ec20b03...` |
| `channelName` | 스트리머 이름 | `서새봄냥` |
| `liveTitle` | 현재 방송 제목 | `와우 한밤...` |
| `concurrentUserCount` | 실시간 시청자 수 | `2092` |
| `liveCategoryValue` | 방송 카테고리 | `World of Warcraft` |
| `openLive` | 라이브 여부 | `true` / `false` |
| `channelImageUrl` | 채널 프로필 이미지 URL | `https://...` |

## 4. React Key 구조

- **팔로잉/추천 목록**: 보통 리스트 내 인덱스 숫자가 문자열로 저장됩니다 (예: `"0"`, `"1"`).
- **카테고리/태그**: 해당 아이템의 영문 이름이나 고유 명칭이 키로 사용됩니다.

## 5. 실시간 추적 코드 (콘솔용)

브라우저 개발자 도구(F12) 콘솔에서 아래 코드를 실행하여 데이터를 확인할 수 있습니다.

```javascript
function trackSidebar() {
    const items = document.querySelectorAll('aside li');
    const results = [];

    items.forEach(li => {
        const fiber = li[Object.keys(li).find(k => k.startsWith('__reactFiber$'))];
        if (!fiber) return;

        // props 탐색 (필요시 return을 타고 올라감)
        let props = fiber.memoizedProps;
        if (!props?.channelId && fiber.return) {
            props = fiber.return.memoizedProps;
        }

        if (props?.channelId) {
            results.push({
                key: fiber.key,
                name: props.channelName,
                viewers: props.concurrentUserCount,
                category: props.liveCategoryValue,
                isLive: props.openLive,
                title: props.liveTitle
            });
        }
    });

    console.table(results);
}

// 실행
trackSidebar();
```
