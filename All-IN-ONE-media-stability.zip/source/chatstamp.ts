// @ts-nocheck
/** @ts-check */
import { getReactProps, getFiberNode, SELECTORS, ConsoleLogger } from './dom-utils';
import dayjs from 'dayjs';

/**
 * 채팅 타임스탬프 초기화
 * @param {any} settings 현재 설정
 * @returns {Function} retrigger 함수
 */
export const initChatStamp = (settings, observer) => {
  const STAMP_DATA_ATTR = 'data-cqc-stamped';
  ConsoleLogger.log('info', 'Chat', '[ChatStamp] 초기화 시작');

  const formatRelativeTime = (timeNum) => {
    const diff = Date.now() - timeNum;
    const secs = Math.floor(diff / 1000);
    if (secs < 60) return `${Math.max(0, secs)}초 전`;
    const mins = Math.floor(secs / 60);
    if (mins < 60) {
      const remSecs = secs % 60;
      return remSecs > 0 ? `${mins}분 ${remSecs}초 전` : `${mins}분 전`;
    }
    const hours = Math.floor(mins / 60);
    if (hours < 24) {
      const remMins = mins % 60;
      return remMins > 0 ? `${hours}시간 ${remMins}분 전` : `${hours}시간 전`;
    }
    const days = Math.floor(hours / 24);
    return `${days}일 전`;
  };

  /** @param {HTMLElement} el */
  const applyNativeStamp = (el) => {
    if (!settings?.chatStampEnabled) return;

    let chatMessage = getReactProps(el)?.chatMessage;
    if (!chatMessage) {
      let fiber = getFiberNode(el);
      for (let i = 0; i < 5 && fiber; i++) {
        if (fiber.memoizedProps?.chatMessage) {
          chatMessage = fiber.memoizedProps.chatMessage;
          break;
        }
        fiber = fiber.return;
      }
    }

    if (chatMessage && chatMessage.time) {
      const timeNum = Number(chatMessage.time);
      if (isNaN(timeNum)) return;

      const item = el.closest(SELECTORS.CHAT_ITEM_CONTAINER);
      if (item && (item.querySelector(SELECTORS.CHAT_DONATION) || item.matches(SELECTORS.CHAT_DONATION))) {
        return;
      }

      const existingStamp = item ? item.querySelector('.cqc-stamp') : el.querySelector('.cqc-stamp');

      if (existingStamp) {
        if (existingStamp.dataset.time === String(timeNum)) {
          return;
        }
        existingStamp.remove();
      }

      el.setAttribute(STAMP_DATA_ATTR, 'true');

      let stampStr = '';
      if (settings.chatStampFormat === 'relative') {
        stampStr = formatRelativeTime(timeNum);
      } else {
        const d = dayjs(timeNum);
        const format = settings.chatStampFormat || 'hh:mm:ss';
        const dayjsFormat = format === 'hh:mm' ? 'HH:mm' : 'HH:mm:ss';
        stampStr = d.format(dayjsFormat);
      }

      const stamp = document.createElement('span');
      stamp.className = 'cqc-stamp';
      stamp.dataset.time = String(timeNum);
      stamp.textContent = stampStr;

      let fontSize = '10px';
      if (settings.chatStampSizeLinked) {
        const baseSize = settings.chatFontSize || 14;
        fontSize = `${baseSize}px`;
      } else {
        fontSize = settings.chatStampSize ? `${settings.chatStampSize}px` : '10px';
      }

      stamp.style.cssText = `font-size:${fontSize}; color:#888; margin-right:4px; flex-shrink:0; white-space:nowrap; user-select:none;`;

      const nickBtn = item?.querySelector(SELECTORS.CHAT_NICKNAME);

      if (nickBtn?.parentElement) {
        nickBtn.parentElement.insertBefore(stamp, nickBtn);
      } else if (item) {
        item.prepend(stamp);
      } else {
        el.prepend(stamp);
      }
    }
  };

  const updateExistingStamps = () => {
    const stamps = document.querySelectorAll('.cqc-stamp');
    if (!settings?.chatStampEnabled) {
      stamps.forEach(s => s.remove());
      document.querySelectorAll(`[${STAMP_DATA_ATTR}]`).forEach(el => el.removeAttribute(STAMP_DATA_ATTR));
      return;
    }

    stamps.forEach(stamp => {
      // @ts-ignore
      const time = stamp.dataset.time;
      if (time) {
        const timeNum = Number(time);
        if (settings.chatStampFormat === 'relative') {
          stamp.textContent = formatRelativeTime(timeNum);
        } else {
          const d = dayjs(timeNum);
          const format = settings.chatStampFormat || 'hh:mm:ss';
          const dayjsFormat = format === 'hh:mm' ? 'HH:mm' : 'HH:mm:ss';
          stamp.textContent = d.format(dayjsFormat);
        }
      }

      let fontSize = '10px';
      if (settings.chatStampSizeLinked) {
        const baseSize = settings.chatFontSize || 14;
        fontSize = `${baseSize}px`;
      } else {
        fontSize = settings.chatStampSize ? `${settings.chatStampSize}px` : '10px';
      }
      // @ts-ignore
      stamp.style.fontSize = fontSize;
    });
  };

  const initialCheck = () => {
    if (!settings?.chatStampEnabled) return;
    document.querySelectorAll(SELECTORS.CHAT_MESSAGE).forEach(el => {
      applyNativeStamp(/** @type {HTMLElement} */(el));
    });
  };

  const retrigger = () => {
    initialCheck();
  };

  let pollerHandle = null;
  let containerObserver = null;

  // 2. 컨테이너 감지 시 로컬 MutationObserver 기동 (리렌더링 및 가상화 스크롤 대응)
  if (observer) {
    pollerHandle = observer.poller.waitFor(
      'chatStampContainerWait',
      SELECTORS.CHAT_CONTAINER,
      (container) => {
        ConsoleLogger.log('info', 'Chat', '[ChatStamp] 채팅 컨테이너 감지. 로컬 MutationObserver 가동');
        initialCheck();

        if (containerObserver) {
          containerObserver.disconnect();
          containerObserver = null;
        }

        containerObserver = new MutationObserver(() => {
          if (!settings?.chatStampEnabled) return;
          initialCheck();
        });

        containerObserver.observe(container, { childList: true, subtree: true });
      },
      { interval: 500, persistent: true }
    );
  }

  // 3. 상대 시간 업데이트 주기
  const relativeTimeIntervalId = setInterval(() => {
    if (settings?.chatStampEnabled && settings?.chatStampFormat === 'relative') {
      updateExistingStamps();
    }
  }, 1000);

  setTimeout(initialCheck, 1000);

  return {
    retrigger,
    cleanup: () => {
      ConsoleLogger.log('info', 'Chat', '[ChatStamp] 리소스 정리 진행');
      if (pollerHandle) {
        pollerHandle.stop();
        pollerHandle = null;
      }
      if (containerObserver) {
        containerObserver.disconnect();
        containerObserver = null;
      }
      if (relativeTimeIntervalId) {
        clearInterval(relativeTimeIntervalId);
      }
      delete (window as any).cqcOnNewMessagesReceived;
    }
  };
};
