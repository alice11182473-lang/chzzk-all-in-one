// @ts-nocheck
/**
 * @fileoverview 파워 클릭 UI 렌더링 모듈 (CSS 분리 및 클래스 기반 리팩토링)
 */

import { SELECTORS, getChannelData, isLargeMode, log as cqcLog } from './dom-utils';
import { powerDB } from './powerclick-db';
import './powerclick.css';
import { clsx } from 'clsx';

const log = (...args) => cqcLog('PowerUI', ...args);

const POWER_STATUS_ID = 'cqc-power-status';
const POWER_STATUS_TOOLBAR_ID = 'cqc-power-status-toolbar';
const POWER_STATUS_OVERLAY_ID = 'cqc-power-status-overlay';

export class PowerUI {
    #isUpdating = false;

    async renderStatus(powerCount, isPowerEnabled, currentChannelId, isFarming = true, isFocusMode = false) {
        if (isFocusMode) {
            this.removeUI();
            window.dispatchEvent(new CustomEvent('cqc-power-update', {
                detail: { totalCount: 0, powerCount: 0, isFarming: false, isFocusMode: true, isPowerEnabled }
            }));
            return;
        }
        if (!isPowerEnabled) {
            window.dispatchEvent(new CustomEvent('cqc-power-update', {
                detail: { totalCount: 0, powerCount: 0, isFarming: false, isFocusMode, isPowerEnabled: false }
            }));
            return;
        }
        if (this.#isUpdating) return;
        this.#isUpdating = true;

        try {
            const totalCount = await powerDB.getKV('total_power_count') || 0;
            const statusText = isFarming ? '벌목 중' : '벌목 대기 중';
            const statusClass = isFarming ? 'is-farming' : 'is-idle';
            const textValue = `통나무 ${powerCount}개 <span class="cqc-power-status-text ${statusClass}">${statusText}</span>`;
            const textTotal = `통나무 ${totalCount}개 <span class="cqc-power-status-text ${statusClass}">${statusText}</span>`;
            
            const svgIcon = `
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 20 21" style="vertical-align:middle;">
                    <mask id="mask_power" width="20" height="21" x="0" y="0" maskUnits="userSpaceOnUse" style="mask-type: alpha;">
                        <path fill="#000" d="M5 9.418c.46 0 .833.746.833 1.666 0 .92-.373 1.667-.833 1.667-.46 0-.833-.746-.833-1.667 0-.92.373-1.666.833-1.666Z"></path>
                        <path fill="#000" fill-rule="evenodd" d="M8.493 3.293c.372 0 .717.184.925.485l.08.137.94 1.878h4.747c1.072 0 1.885.786 2.39 1.711.52.953.819 2.22.819 3.58 0 1.361-.3 2.628-.82 3.58-.504.926-1.317 1.712-2.389 1.712H5c-1.071 0-1.885-.786-2.39-1.712-.519-.952-.818-2.219-.818-3.58 0-1.36.3-2.627.819-3.58C3.115 6.58 3.929 5.793 5 5.793h1.77l-.435-.872A1.125 1.125 0 0 1 7.34 3.293h1.153ZM5 7.209c-.31 0-.746.24-1.146.973-.385.707-.646 1.732-.646 2.902 0 1.17.26 2.196.646 2.902.4.733.836.974 1.146.974.31 0 .746-.24 1.146-.974.385-.706.646-1.731.646-2.902 0-1.17-.26-2.195-.646-2.902C5.746 7.45 5.31 7.21 5 7.21Zm2.214 0c.062.096.12.195.175.295.185.338.34.716.466 1.123h1.312l.072.003a.708.708 0 0 1 0 1.41l-.072.003h-1.02a9.034 9.034 0 0 1 .01 2h6.426l.073.003a.708.708 0 0 1 0 1.41l-.073.003H7.88c-.13.439-.294.845-.49 1.205-.055.1-.114.2-.176.296h7.971c.31 0 .746-.24 1.146-.974.386-.706.646-1.731.646-2.902 0-.363-.027-.711-.073-1.041H12a.708.708 0 0 1 0-1.416h4.537a4.256 4.256 0 0 0-.206-.445c-.4-.733-.836-.973-1.146-.973H7.214Zm1.14-1.416h.5l-.542-1.084h-.5l.542 1.084Z" clip-rule="evenodd"></path>
                    </mask>
                    <g mask="url(#mask_power)"><path fill="currentColor" d="M0 .25h20v20H0z"></path></g>
                </svg>`;

            const badgeCls = clsx('cqc-power-badge', 'cqc-power-status', {
                'is-farming': isFarming
            });
            const toolbarCls = clsx('toolbar_item__w9Z7l', 'cqc-power-status-toolbar', {
                'is-farming': isFarming
            });

            // 1. 영상 상단 뱃지
            const videoContainer = document.querySelector(SELECTORS.VIDEO_INFO_DATA);
            if (videoContainer) {
                let el = document.getElementById(POWER_STATUS_ID);
                if (!el) {
                    el = document.createElement('span');
                    el.id = POWER_STATUS_ID;
                    el.className = badgeCls;
                    el.innerHTML = `${svgIcon}<span class="cqc-power-count">${textValue}</span>`;
                    
                    const row = videoContainer.closest(SELECTORS.CHANNEL_INFO_ROW);
                    const info = row?.querySelector('[class*="_information_"]');
                    if (info) {
                        info.after(el);
                    } else {
                        videoContainer.before(el);
                    }
                } else {
                    el.className = badgeCls;
                    const span = el.querySelector('.cqc-power-count');
                    if (span && span.innerHTML !== textValue) span.innerHTML = textValue;
                }
            }

            // 2. 우상단 툴바 뱃지 (React ToolbarArea로 이관됨. CustomEvent 디스패치 완료)
            window.dispatchEvent(new CustomEvent('cqc-power-update', {
                detail: {
                    totalCount,
                    powerCount,
                    isFarming,
                    isFocusMode,
                    isPowerEnabled
                }
            }));

            // 3. 넓은 화면 모드 비디오 오버레이 뱃지
            const largeModeActive = isLargeMode();
            const playerContainer = document.querySelector(SELECTORS.PLAYER);
            if (largeModeActive && playerContainer) {
                const overlayCls = clsx('cqc-power-overlay', statusClass);
                let overlayEl = document.getElementById(POWER_STATUS_OVERLAY_ID);
                if (!overlayEl) {
                    overlayEl = document.createElement('div');
                    overlayEl.id = POWER_STATUS_OVERLAY_ID;
                    overlayEl.className = overlayCls;
                    overlayEl.innerHTML = `${svgIcon}<span class="cqc-power-count">${textValue}</span>`;
                    playerContainer.appendChild(overlayEl);
                } else {
                    overlayEl.className = overlayCls;
                    const span = overlayEl.querySelector('.cqc-power-count');
                    if (span && span.innerHTML !== textValue) span.innerHTML = textValue;
                }
            } else {
                document.getElementById(POWER_STATUS_OVERLAY_ID)?.remove();
            }
        } finally {
            setTimeout(() => { this.#isUpdating = false; }, 50);
        }
    }

    attachTooltipEvents(container, currentChannelId) {
        let tooltip = container.querySelector('.cqc-power-tooltip');
        if (!tooltip) {
            tooltip = document.createElement('div');
            tooltip.className = 'cqc-power-tooltip';
            tooltip.innerHTML = `
                <div class="cqc-power-tooltip-header"><div class="cqc-power-tooltip-title">통나무 획득 내역</div></div>
                <div class="cqc-power-list"><div style="text-align:center;padding:20px;color:#888;font-size:12px;">로딩 중...</div></div>
            `;
            container.appendChild(tooltip);

            let longHoverTimer = null;
            let isSticky = false;

            container.addEventListener('mouseenter', async () => {
                if (isSticky) return;
                tooltip.classList.add('is-show');
                await this.renderPowerTooltip(tooltip, false, currentChannelId);

                longHoverTimer = setTimeout(async () => {
                    isSticky = true;
                    tooltip.classList.add('is-sticky');
                    await this.renderPowerTooltip(tooltip, true, currentChannelId);
                }, 2500);
            });

            container.addEventListener('mouseleave', () => {
                if (isSticky) return;
                if (longHoverTimer) {
                    clearTimeout(longHoverTimer);
                    longHoverTimer = null;
                }
                tooltip.classList.remove('is-show');
            });

            tooltip.addEventListener('click', (e) => {
                const closeBtn = e.target.closest('.cqc-power-tooltip-close');
                if (closeBtn) {
                    tooltip.classList.remove('is-show', 'is-sticky');
                    isSticky = false;
                    e.stopPropagation();
                }
            });
        }
    }

    async renderPowerTooltip(tooltip, isFull = false, currentChannelId) {
        const listEl = tooltip.querySelector('.cqc-power-list');
        const titleEl = tooltip.querySelector('.cqc-power-tooltip-title');
        const headerEl = tooltip.querySelector('.cqc-power-tooltip-header');
        if (!listEl) return;

        let closeBtn = tooltip.querySelector('.cqc-power-tooltip-close');

        if (isFull) {
            log('전체 보유 내역 모드 렌더링 시작 (롱호버)');
            if (titleEl) titleEl.textContent = '모든 채널 통나무 보유량';

            if (!closeBtn && headerEl) {
                const btn = document.createElement('button');
                btn.className = 'cqc-power-tooltip-close';
                btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 3.5L3.5 10.5M3.5 3.5L10.5 10.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                headerEl.appendChild(btn);
            }

            listEl.innerHTML = `
                <div class="cqc-skeleton-item">
                    <div class="cqc-skeleton cqc-skeleton-avatar"></div>
                    <div class="cqc-skeleton-texts">
                        <div class="cqc-skeleton cqc-skeleton-text"></div>
                        <div class="cqc-skeleton cqc-skeleton-text short"></div>
                    </div>
                </div>
                <div class="cqc-skeleton-item">
                    <div class="cqc-skeleton cqc-skeleton-avatar"></div>
                    <div class="cqc-skeleton-texts">
                        <div class="cqc-skeleton cqc-skeleton-text" style="width:50%"></div>
                        <div class="cqc-skeleton cqc-skeleton-text short" style="width:30%"></div>
                    </div>
                </div>
            `;

            const [officialBalances] = await Promise.all([
                this.getAllBalances(),
                powerDB.init().catch(() => { })
            ]);

            const items = [];
            const localMetas = new Map();

            try {
                const allKeys = await powerDB.getAllKeys();
                const metaKeys = allKeys.filter(k => String(k).startsWith('channel_meta_'));
                for (const key of metaKeys) {
                    const meta = await powerDB.getKV(key);
                    if (meta && meta.channelId) localMetas.set(meta.channelId, meta);
                }
            } catch (e) { }

            if (officialBalances && Array.isArray(officialBalances)) {
                for (const bal of officialBalances) {
                    const meta = localMetas.get(bal.channelId);
                    items.push({
                        channelId: bal.channelId,
                        channelName: bal.channelName || meta?.channelName || 'unknown',
                        channelImageUrl: bal.channelImageUrl || meta?.channelImageUrl || '',
                        count: bal.amount ?? 0,
                        syncTs: meta?.syncTs || 0
                    });
                }
            } else {
                for (const [chId, meta] of localMetas) {
                    const count = await powerDB.getKV('power_count_' + chId) || 0;
                    if (count > 0) items.push({ ...meta, count });
                }
            }

            items.sort((a, b) => b.count - a.count || (b.syncTs || 0) - (a.syncTs || 0));

            let html = '';
            for (const item of items) {
                if (item.count <= 0) continue;
                const channelUrl = `/live/${item.channelId}`;
                html += `
                    <a href="${channelUrl}" class="cqc-power-item" target="_blank">
                        <img src="${item.channelImageUrl || 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_v2.png'}" 
                             class="cqc-power-item-img" referrerpolicy="no-referrer" loading="lazy"
                             onerror="this.src='https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_v2.png'">
                        <div class="cqc-power-item-info">
                            <div class="cqc-power-item-name">${item.channelName}</div>
                            <div class="cqc-power-item-time">${item.count}개 보유 중</div>
                        </div>
                    </a>
                `;
            }
            listEl.innerHTML = html || '<div style="text-align:center;padding:20px;color:#888;font-size:12px;">보유 중인 통나무가 없습니다.</div>';
            return;
        }

        if (closeBtn) closeBtn.remove();
        if (titleEl) titleEl.textContent = '최근 획득 내역';
        const logs = await powerDB.getPowerLogs(100);
        if (logs.length === 0) {
            listEl.innerHTML = '<div style="text-align:center;padding:20px;color:#888;font-size:12px;">아직 내역이 없습니다.</div>';
            return;
        }

        const channel = getChannelData(document.body);
        const chId = channel?.channelId || currentChannelId;

        let officialAmount = null;
        if (chId) {
            const meta = await powerDB.getKV('channel_meta_' + chId);
            officialAmount = meta?.officialAmount ?? null;
            const syncTs = meta?.syncTs || 0;

            if (officialAmount === null || (Date.now() - syncTs > 60000)) {
                const freshAmount = await this.getOfficialPower(chId);
                if (freshAmount !== null) {
                    officialAmount = freshAmount;
                    await powerDB.setKV('channel_meta_' + chId, {
                        channelId: chId,
                        channelName: channel?.channelName || 'unknown',
                        channelImageUrl: channel?.channelImageUrl || '',
                        officialAmount: officialAmount,
                        syncTs: Date.now()
                    });
                }
            }
        }

        const formatRel = (ts) => {
            const diff = Date.now() - ts;
            if (diff < 60000) return '방금 전';
            const min = Math.floor(diff / 60000);
            if (min < 60) return `${min}분 전`;
            const hr = Math.floor(min / 60);
            if (hr < 24) return `${hr}시간 전`;
            const day = Math.floor(hr / 24);
            return `${day}일 전`;
        };

        const map = new Map();
        for (const log of logs) {
            const key = log.channelId && log.channelId !== 'unknown' ? log.channelId : log.channelName;
            if (!map.has(key)) {
                map.set(key, { name: log.channelName, img: log.channelImageUrl, logs: [], id: log.channelId });
            }
            const d = map.get(key);
            d.logs.push(log);
            if (!d.img && log.channelImageUrl) d.img = log.channelImageUrl;
            if (d.name === 'unknown' && log.channelName !== 'unknown') d.name = log.channelName;
            if (!d.id && log.channelId && log.channelId !== 'unknown') d.id = log.channelId;
        }

        let html = '';
        if (officialAmount !== null) {
            html += `
                <div class="cqc-power-item official-balance">
                    <div class="cqc-power-item-info">
                        <div class="cqc-power-item-name" style="color:#00ffa3;">현재 방송국 공식 보유 통나무</div>
                        <div class="cqc-power-item-time">치지직 연동 데이터</div>
                    </div>
                    <div class="cqc-power-item-count">${officialAmount}</div>
                </div>
                <div style="height:1px; background:rgba(255,255,255,0.04); margin:4px 0 8px 0;"></div>
            `;
        }

        for (const d of map.values()) {
            const channelUrl = d.id && d.id !== 'unknown' ? `/live/${d.id}` : '#';
            const collectedCount = d.id ? await powerDB.getKV('power_count_' + d.id) || 0 : 0;
            if (collectedCount <= 0) continue;
            const lastLogTs = d.logs.reduce((max, l) => Math.max(max, l.timestamp || 0), 0);

            html += `
                <a href="${channelUrl}" class="cqc-power-item" ${channelUrl !== '#' ? 'target="_blank"' : ''}>
                    <img src="${d.img || 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_v2.png'}" 
                         class="cqc-power-item-img" referrerpolicy="no-referrer" loading="lazy"
                         onerror="this.src='https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_v2.png'">
                    <div class="cqc-power-item-info">
                        <div class="cqc-power-item-name">${d.name}</div>
                        <div class="cqc-power-item-time">${formatRel(lastLogTs)}</div>
                    </div>
                    <div class="cqc-power-item-count">${collectedCount}</div>
                </a>
            `;
        }
        listEl.innerHTML = html;
    }

    async getAllBalances() {
        try {
            log('전체 보유 내역 API 요청 시작...');
            const res = await fetch('https://api.chzzk.naver.com/service/v1/log-power/balances', {
                credentials: 'include'
            });
            if (!res.ok) {
                log('전체 보유 내역 API 요청 실패:', res.status);
                return null;
            }
            const json = await res.json();
            log('전체 보유 내역 API 응답 수신 성공:', json?.content?.data?.length || 0, '개 채널');
            return json?.content?.data ?? null;
        } catch (e) {
            log('전체 보유 내역 API 요청 오류:', e);
            return null;
        }
    }

    async getOfficialPower(chId) {
        if (!chId || chId === 'unknown') return null;
        try {
            const res = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${chId}/log-power`, {
                credentials: 'include'
            });
            const json = await res.json();
            return json?.content?.amount ?? null;
        } catch (e) {
            return null;
        }
    }

    removeUI() {
        document.getElementById(POWER_STATUS_ID)?.remove();
        document.getElementById(POWER_STATUS_TOOLBAR_ID)?.remove();
        document.getElementById(POWER_STATUS_OVERLAY_ID)?.remove();
    }
}

export const powerUI = new PowerUI();
