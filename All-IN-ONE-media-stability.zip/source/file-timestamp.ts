// @ts-nocheck
/**
 * 파일명에 사용할 타임스탬프를 포맷합니다.
 * @param {string} [format='dash'] - 포맷 종류: dash | dot | korean | date-only | unix
 * @param {string} [timezone='local'] - 시간대: local | utc
 * @returns {string} 파일명에 안전한 타임스탬프 문자열
 */
export const formatFileTimestamp = (format, timezone) => {
  const now = new Date();
  const useUTC = timezone === 'utc';

  const Y = useUTC ? now.getUTCFullYear() : now.getFullYear();
  const M = String(useUTC ? now.getUTCMonth() + 1 : now.getMonth() + 1).padStart(2, '0');
  const D = String(useUTC ? now.getUTCDate() : now.getDate()).padStart(2, '0');
  const h = String(useUTC ? now.getUTCHours() : now.getHours()).padStart(2, '0');
  const m = String(useUTC ? now.getUTCMinutes() : now.getMinutes()).padStart(2, '0');
  const s = String(useUTC ? now.getUTCSeconds() : now.getSeconds()).padStart(2, '0');

  const suffix = useUTC ? '_UTC' : '';

  switch (format) {
    case 'dot':
      return `${Y}.${M}.${D}_${h}.${m}.${s}${suffix}`;
    case 'korean':
      return `${Y}년${M}월${D}일_${h}시${m}분${s}초${suffix}`;
    case 'date-only':
      return `${Y}-${M}-${D}${suffix}`;
    case 'unix':
      return String(Math.floor(now.getTime() / 1000));
    case 'dash':
    default:
      return `${Y}-${M}-${D}_${h}-${m}-${s}${suffix}`;
  }
};
