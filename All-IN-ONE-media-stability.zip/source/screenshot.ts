// @ts-nocheck
import { log as cqcLog, SELECTORS, showToast, isPlayerPage } from './dom-utils';
import { formatFileTimestamp } from './file-timestamp';

/**
 * 로그 출력용 로컬 헬퍼
 * @param {...any} args
 */
const log = (...args) => cqcLog('Screenshot', ...args);

let currentSettings = null;

export const updateScreenshotSettings = (settings) => {
    currentSettings = settings;
};

const SETTING_BTN_SELECTOR = '.pzp-pc-setting-button';

/**
 * 비디오 엘리먼트를 찾습니다.
 * @returns {HTMLVideoElement|null}
 */
const findVideo = () =>
    (document.querySelector('video.webplayer-internal-video')) ??
    (document.querySelector('video'));

/**
 * 현재 화면을 캡처하여 저장합니다.
 */
export const capture = () => {
    const video = findVideo();
    if (!video || video.readyState < 2) {
        return;
    }

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx?.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(async (blob) => {
        if (!blob) return;
        const action = currentSettings?.screenshotAction ?? 'save';
        if (action === 'clipboard') {
            try {
                const item = new ClipboardItem({ 'image/png': blob });
                await navigator.clipboard.write([item]);
                showToast('<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffa3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px;margin-right:4px;"><rect x="2" y="6" width="20" height="14" rx="2"/><circle cx="12" cy="13" r="4"/></svg> 클립보드에 복사됨');
            } catch (err) {
                log('클립보드 복사 실패:', err);
                showToast('<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px;margin-right:4px;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> 클립보드 복사 실패');
            }
        } else {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const ts = formatFileTimestamp(currentSettings?.fileTimestampFormat, currentSettings?.fileTimestampTimezone);
            a.download = `chzzk_${ts}.png`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            showToast('<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffa3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px;margin-right:4px;"><rect x="2" y="6" width="20" height="14" rx="2"/><circle cx="12" cy="13" r="4"/></svg> 스크린샷 저장됨');
        }
    }, 'image/png');
};

const isShortcutMatched = (e, shortcut) => {
  if (!shortcut) return false;
  const eventKey = e.key.toLowerCase();
  const targetKey = shortcut.key.toLowerCase();
  
  return eventKey === targetKey &&
         !!e.ctrlKey === !!shortcut.ctrl &&
         !!e.shiftKey === !!shortcut.shift &&
         !!e.altKey === !!shortcut.alt &&
         !!e.metaKey === !!shortcut.meta;
};

const formatShortcut = (shortcut) => {
  if (!shortcut) return '없음';
  const parts = [];
  if (shortcut.ctrl) parts.push('Ctrl');
  if (shortcut.shift) parts.push('Shift');
  if (shortcut.alt) parts.push('Alt');
  if (shortcut.meta) parts.push('Meta');
  
  let keyText = shortcut.key;
  if (keyText === ' ') keyText = 'Space';
  else if (keyText) keyText = keyText.toUpperCase();
  
  if (keyText) parts.push(keyText);
  return parts.join('+') || '없음';
};

document.addEventListener('keydown', (/** @type {any} */ e) => {
    if (currentSettings?.screenshotEnabled === false) return;
    const shortcut = currentSettings?.customShortcuts?.screenshot;
    if (shortcut && isShortcutMatched(e, shortcut)) {
        if (isPlayerPage()) {
            e.preventDefault();
            capture();
        }
    }
});

/**
 * 플레이어 바에 스크린샷 버튼을 추가합니다.
 * @param {Element} bar 
 */
const addPlayerButton = (bar) => {
    if (bar.querySelector('#cqc-screenshot-btn')) return;

    const shortcut = currentSettings?.customShortcuts?.screenshot;
    const btn = document.createElement('button');
    btn.id = 'cqc-screenshot-btn';
    btn.className = 'pzp-button pzp-pc-ui-button';
    btn.setAttribute('aria-label', '스크린샷');
    btn.innerHTML = `
      <span class="pzp-button__tooltip pzp-button__tooltip--top">스크린샷 (${formatShortcut(shortcut)})</span>
      <span class="pzp-ui-icon">
        <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" class="pzp-ui-icon__svg">
          <rect x="8" y="12" width="20" height="14" rx="2" stroke="white" stroke-width="1.7" fill="none"/>
          <circle cx="18" cy="19" r="4" stroke="white" stroke-width="1.7" fill="none"/>
          <circle cx="18" cy="19" r="1.5" fill="white"/>
          <rect x="13" y="10" width="10" height="3" rx="1" fill="white" opacity="0.6"/>
        </svg>
      </span>`;

    btn.addEventListener('click', (/** @type {any} */ e) => {
        e.preventDefault();
        e.stopPropagation();
        capture();
    });

    const settingBtn = bar.querySelector(SETTING_BTN_SELECTOR);
    if (settingBtn && settingBtn.parentElement) {
        settingBtn.parentElement.insertBefore(btn, settingBtn);
    } else {
        bar.appendChild(btn);
    }
};

/**
 * 감시를 시작합니다.
 */
const observe = () => {
    const tryAdd = () => {
        const bar = document.querySelector(SELECTORS.PLAYER_CONTROL_BAR_RIGHT);
        if (bar) addPlayerButton(bar);
    };
    tryAdd();
    // DOM 변화 감지 대신 2초 간격으로 UI 삽입 여부를 확인합니다.
    window.setInterval(tryAdd, 2000);
};

/**
 * 스크린샷 모듈 초기화
 */
export function initScreenshot() {
    observe();
    log('모듈 초기화됨');
}
