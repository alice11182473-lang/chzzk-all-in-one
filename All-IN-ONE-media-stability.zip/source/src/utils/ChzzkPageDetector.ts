import { SelectorRegistry } from './SelectorRegistry';

export class ChzzkPageDetector {
    static isLive(): boolean {
        return /^\/live\/[^/]+\/?$/.test(location.pathname);
    }
    static isVideo(): boolean {
        return /^\/video\/[^/]+\/?$/.test(location.pathname);
    }
    static isClip(): boolean {
        return /^\/clips\/[^/]+\/?$/.test(location.pathname);
    }
    static isHome(): boolean {
        return location.pathname === '/' || location.pathname === '/home';
    }
    static isPlayerPage(): boolean {
        return ChzzkPageDetector.isLive() || ChzzkPageDetector.isVideo() || ChzzkPageDetector.isClip();
    }
    static isSidebarCollapsed(): boolean {
        const sel = SelectorRegistry.getInstance().getProxy();
        const btn = document.querySelector(sel.SIDEBAR_TOGGLE_BTN);
        if (btn) return btn.getAttribute('aria-expanded') === 'false';
        const sidebar = document.querySelector(sel.SIDEBAR_ASIDE);
        if (sidebar) return sidebar.getAttribute('aria-expanded') === 'false' || !sidebar.classList.contains('is_expanded');
        return false;
    }
    static isLargeMode(): boolean {
        const sel = SelectorRegistry.getInstance().getProxy();
        const playerLayout = document.querySelector(sel.PLAYER_LAYOUT) || document.querySelector(sel.PLAYER_CONTAINER);
        const hasLargeClass = playerLayout ? playerLayout.classList.contains('is_large') : false;
        if (hasLargeClass) return true;

        const player = document.querySelector(sel.PLAYER_PC) || document.querySelector(sel.PLAYER);
        if (player && (player.classList.contains('pzp-pc-viewmode-wide') || player.classList.contains('pzp-viewmode-wide') || player.classList.contains('pzp-pc--viewmode-wide'))) {
            return true;
        }

        const viewModeBtn = document.querySelector(sel.VIEW_MODE_BTN);
        if (viewModeBtn) {
            const ariaLabel = viewModeBtn.getAttribute('aria-label') || '';
            const title = viewModeBtn.getAttribute('title') || '';
            if (ariaLabel.includes('좁은') || title.includes('좁은')) {
                return true;
            }
        }
        return false;
    }
}

export const isLivePage = (): boolean => ChzzkPageDetector.isLive();
export const isVideoPage = (): boolean => ChzzkPageDetector.isVideo();
export const isClipPage = (): boolean => ChzzkPageDetector.isClip();
export const isHomePage = (): boolean => ChzzkPageDetector.isHome();
export const isPlayerPage = (): boolean => ChzzkPageDetector.isPlayerPage();
export const isSidebarCollapsed = (): boolean => ChzzkPageDetector.isSidebarCollapsed();
export const isLargeMode = (): boolean => ChzzkPageDetector.isLargeMode();
