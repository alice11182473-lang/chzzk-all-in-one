/** 캐시 유지 시간 (ms) */
export const CACHE_TTL = 300;

/** 중첩 객체 탐색 키 목록 */
export const NESTED_KEYS = [
    'item', 'channel', 'liveInfo', 'streamer', 'data', 'info',
    'channelData', 'channelInfo', 'liveChannel', 'profile', 'channelDetail', 'content'
] as const;

export const REGEX = {
    PLAYER_URL: /\/(live|video|clips)\/[a-z0-9_]+/i,
    AD_BLOCK_MSG: /광고\s*차단\s*프로그램.*사용\s*중/i,
    POWER_MSG: /통나무\s*파워.*배달\s*완료/i,
    AMOUNT_MSG: /(\d+)\s*받기/,
    CHAT_MSG_STAMP: /^\[\d{1,2}:\d{2}\]$/,
    AD_BLOCK: /광고\s*차단\s*프로그램.*사용\s*중/i,
    PLAYER_ROUTE: /^\/(live|video|clips)\/[^/]+/,
    CHEAT_KEY_MSG: /광고\s*방해없이\s*영상을\s*시청하고\s*싶으신가요/
} as const;

export interface ShortcutConfig {
    key: string;
    ctrl?: boolean;
    shift?: boolean;
    alt?: boolean;
    meta?: boolean;
}

export const isShortcutMatched = (e: KeyboardEvent, shortcut: ShortcutConfig | null): boolean => {
    if (!shortcut) return false;
    const eventKey = e.key.toLowerCase();
    const targetKey = shortcut.key.toLowerCase();

    return eventKey === targetKey &&
        !!e.ctrlKey === !!shortcut.ctrl &&
        !!e.shiftKey === !!shortcut.shift &&
        !!e.altKey === !!shortcut.alt &&
        !!e.metaKey === !!shortcut.meta;
};

export const DEFAULT_SETTINGS = {
    enabled: true,
    autoAdSkip: true,
    autoQuality: false,
    preferredQuality: 1080,
    preferLowLatency: false,
    targetLatency: 0,
    chaserMode: 'gradual',
    adaptiveLatencyEnabled: false,
    autoReapplyOnRerender: false,
    showNotification: false,
    layoutCleanEnabled: false,
    ambientEnabled: false,
    powerClickEnabled: false,
    followingRefreshEnabled: false,
    followingExpandEnabled: false,
    hideInstallPopupEnabled: false,
    hoverPreviewEnabled: false,
    thumbnailPreviewEnabled: false,
    hideOfflineFollowing: false,
    streamStatsEnabled: false,
    screenshotEnabled: false,
    screenshotAction: 'save',
    recorderEnabled: false,
    watchTimerEnabled: false,
    sidebarFoldersEnabled: false,
    sidebarResizeEnabled: false,
    chatResizeEnabled: false,
    customFont: '',
    customFontImport: '',
    wideViewEnabled: false,
    chatStampEnabled: false,
    chatStampFormat: 'hh:mm:ss',
    chatStampSize: 10,
    chatStampSizeLinked: false,
    chatFontSize: 0,
    playbackSpeedEnabled: false,
    chatCollectorEnabled: false,
    chatCollectorTargetUsers: [] as string[],
    chatCollectorRoles: ['streamer', 'manager'] as string[],
    chatCollectorPosition: null as string | null,
    chatCollectorRetentionHours: 72,
    focusModeEnabled: false,
    customFontWeight: 400,
    sidebarOfflineFoldEnabled: false,
    offlineGroupCollapsed: false,
    staticLogoEnabled: false,
    layoutCleanupKeywords: ['인기 카테고리', '방송 일정', '파트너', '서비스 바로가기'],
    liveNotificationEnabled: false,
    liveAutoReloadEnabled: false,
    liveNotificationInterval: 3,
    chatFilterEnabled: false,
    chatFilterKeywords: [] as { text: string; isRegex: boolean }[],
    chatFilterUsers: [] as { user: string; channelId: string; channelName?: string }[],
    chatEmojiMacros: [] as { keyword: string, emojiId: string, emojiUrl: string }[],
    chatFilterRoles: [] as string[],
    chatFilterOS: [] as string[],
    chatFilterMode: 'blur',
    discoveredRoles: ['STREAMER', 'MANAGER', 'SUBSCRIBER', 'FAN'] as string[],
    discoveredOS: ['PC', 'AOS', 'IOS'] as string[],
    chatFilterEmojis: [] as string[],
    chatDeviceIconEnabled: false,
    hoverPreviewVideoEnabled: false,
    hoverPreviewHomeEnabled: false,
    hoverPreviewRecommendEnabled: false,
    hoverPreviewDelay: 500,
    customVideoSortEnabled: false,
    gcMonitorEnabled: false,
    volumeIndicatorEnabled: false,
    blindedRestoreEnabled: false,
    discoveredHeaderTabs: [] as string[],
    hiddenHeaderTabs: [] as string[],
} as const;
