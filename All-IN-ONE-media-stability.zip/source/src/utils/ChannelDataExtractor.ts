import { SelectorRegistry } from './SelectorRegistry';
import { ReactFiberExplorer, FiberNode } from './ReactFiberExplorer';
import { CACHE_TTL, NESTED_KEYS } from './Constants';

export interface ChannelData {
    channelId?: string;
    channelName?: string;
    channelImageUrl?: string;
    isLive: boolean;
    liveTitle: string;
    viewers: number;
    category: string;
    thumbnailUrl: string;
}

export class ChannelDataExtractor {
    private static dataCache = new WeakMap<HTMLElement, { data: ChannelData; ts: number }>();

    static extractChannelProps(obj: Record<string, any>, id?: string, depth: number = 0, visited: Set<Record<string, any>> = new Set()): Record<string, any> | null {
        if (!obj || typeof obj !== 'object' || depth > 12 || visited.has(obj)) return null;
        visited.add(obj);

        const hasLiveInfo = (o: any) => !!(o && (o.openLive !== undefined || o.liveInfo || o.live || o.liveId || o.onLive || o.liveStatus));
        const currentId = obj.channelId || obj.channel?.channelId;
        const isTargetMatch = id ? (currentId === id) : !!(obj.channelName || obj.nickname || obj.channel?.channelName);
        const hasName = (o: any) => !!(o.channelName || o.nickname || o.name || o.channel?.channelName);

        if (isTargetMatch && hasName(obj)) {
            return obj;
        }

        const hotKeys = ['props', 'children', 'channel'];
        for (const k of hotKeys) {
            const val = Reflect.get(obj, k);
            if (val) {
                const res = ChannelDataExtractor.extractChannelProps(val, id, depth + 1, visited);
                if (res) {
                    if (hasLiveInfo(obj)) return obj;
                    return res;
                }
            }
        }

        if (Array.isArray(obj)) {
            for (let i = 0; i < obj.length; i++) {
                const res = ChannelDataExtractor.extractChannelProps(Reflect.get(obj, i), id, depth + 1, visited);
                if (res) return res;
            }
        }

        const metaKeys = ['liveInfo', 'streamer', ...NESTED_KEYS];
        for (const k of metaKeys) {
            const val = Reflect.get(obj, k);
            if (val && !visited.has(val)) {
                const res = ChannelDataExtractor.extractChannelProps(val, id, depth + 1, visited);
                if (res) return res;
            }
        }
        return null;
    }

    static getProps(el: HTMLElement, maxDepth: number = 30): Record<string, any> | null {
        if (!el) return null;
        const id = el.dataset?.channelId;
        const sel = SelectorRegistry.getInstance().getProxy();
        const checked = new Set<Record<string, any>>();

        // 1. DOM 노드의 React Props (__reactProps$) 우선 탐색
        const directProps = ReactFiberExplorer.getReactProps(el);
        if (directProps && !checked.has(directProps)) {
            checked.add(directProps);
            const result = ChannelDataExtractor.extractChannelProps(directProps, id, 0, new Set());
            if (result) return result;
        }

        // 2. Fiber 체인 탐색
        let curr = ReactFiberExplorer.getFiberNode(el);
        for (let i = 0; curr && i < maxDepth; i++) {
            const props = curr.memoizedProps;
            if (props && !checked.has(props)) {
                checked.add(props);
                const result = ChannelDataExtractor.extractChannelProps(props, id, 0, new Set());
                if (result) return result;
            }
            curr = curr.return;
        }

        const row = el.querySelector(sel.CHANNEL_INFO_ROW) as HTMLElement | null;
        if (row) {
            const rProps = ReactFiberExplorer.getReactProps(row);
            if (rProps && !checked.has(rProps)) {
                checked.add(rProps);
                const res = ChannelDataExtractor.extractChannelProps(rProps, id, 0, new Set());
                if (res) return res;
            }
        }

        const node = ReactFiberExplorer.getFiberNode(el);
        const findInFiberTree = (n: FiberNode | null, depth: number): Record<string, any> | null => {
            if (!n || depth <= 0) return null;
            let c = n.child;
            while (c) {
                const cp = c.memoizedProps;
                if (cp && !checked.has(cp)) {
                    const res = ChannelDataExtractor.extractChannelProps(cp, id, 0, new Set());
                    if (res) return res;
                }
                const nested = findInFiberTree(c, depth - 1);
                if (nested) return nested;
                c = c.sibling;
            }
            return null;
        };

        const fiberResult = findInFiberTree(node, 10);
        if (fiberResult) return fiberResult;

        const targets = el.querySelectorAll(`a, .item_link, img, [class*="thumbnail"], ${sel.VIDEO_INFORMATION}`);
        for (let i = 0; i < targets.length; i++) {
            const child = targets.item(i) as HTMLElement;
            const cNode = ReactFiberExplorer.getFiberNode(child);
            const cProps = cNode?.memoizedProps;
            if (cProps && !checked.has(cProps)) {
                const result = ChannelDataExtractor.extractChannelProps(cProps, id, 0, new Set());
                if (result) {
                    return result;
                }
            }
        }

        return null;
    }

    static getData(el: HTMLElement): ChannelData | null {
        if (!el) return null;

        const cached = ChannelDataExtractor.dataCache.get(el);
        if (cached && (Date.now() - cached.ts < CACHE_TTL)) return cached.data;

        let p = ChannelDataExtractor.getProps(el);
        if (!p) {
            const sel = SelectorRegistry.getInstance().getProxy();
            const row = document.querySelector(sel.CHANNEL_INFO_ROW) as HTMLElement | null;
            if (row) p = ChannelDataExtractor.getProps(row);
        }
        if (!p) return null;

        const c = p.channel || p.streamer || p.liveInfo || p;
        const live = p.liveInfo || p.live || {};

        const isLive = !!(
            c.openLive ||
            c.onLive ||
            c.liveStatus === 'OPEN' ||
            p.live === true ||
            p.isLive === true ||
            p.openLive === true ||
            (p.streamer && p.streamer.openLive) ||
            (live.status === 'OPEN' || live.status === 'LIVE' || live.liveId)
        );

        const finalData: ChannelData = {
            channelId: c.channelId || p.channelId || el.dataset?.channelId,
            channelName: c.channelName || c.nickname || c.name || p.nickname || p.channelName,
            channelImageUrl: c.channelImageUrl || c.profileImageUrl || c.image || p.profileImageUrl,
            isLive: isLive,
            liveTitle: (c.liveTitle || live.liveTitle || p.liveTitle || p.title || '').trim(),
            viewers: c.concurrentUserCount || live.concurrentUserCount || p.concurrentUserCount || p.userCount || p.viewerCount || 0,
            category: c.liveCategoryValue || live.liveCategoryValue || p.categoryName || '',
            thumbnailUrl: c.liveImageUrl || live.liveImageUrl || p.liveImageUrl || p.thumbnailImageUrl || '',
        };

        ChannelDataExtractor.dataCache.set(el, { data: finalData, ts: Date.now() });
        return finalData;
    }
}

export const getChannelProps = (el: HTMLElement, maxDepth?: number): Record<string, any> | null => ChannelDataExtractor.getProps(el, maxDepth);
export const getChannelData = (el: HTMLElement): ChannelData | null => ChannelDataExtractor.getData(el);
