export interface FiberNode {
    type?: any;
    child: FiberNode | null;
    sibling: FiberNode | null;
    return: FiberNode | null;
    memoizedProps: Record<string, any> | null;
}

export class ReactFiberExplorer {
    private static fiberKeyCache = new WeakMap<HTMLElement, string>();
    private static propsKeyCache = new WeakMap<HTMLElement, string>();

    static getFiberNode(el: HTMLElement): FiberNode | null {
        if (!el) return null;
        let key = ReactFiberExplorer.fiberKeyCache.get(el);
        if (!key) {
            for (const k in el) {
                if (k[0] === '_' && k[1] === '_' && (k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'))) {
                    key = k;
                    ReactFiberExplorer.fiberKeyCache.set(el, key);
                    break;
                }
            }
        }
        return key ? (el as any)[key] as FiberNode : null;
    }

    static getComponentFiber(el: HTMLElement, name: string): FiberNode | null {
        let curr = ReactFiberExplorer.getFiberNode(el);
        while (curr) {
            const type = curr.type;
            if (typeof type === 'function' && (type.name === name || (type as any).displayName?.includes(name))) {
                return curr;
            }
            if (typeof type === 'object' && type !== null && (type.name === name || type.displayName?.includes(name))) {
                return curr;
            }
            curr = curr.return;
        }
        return null;
    }

    static getReactProps(el: HTMLElement): Record<string, any> | null {
        if (!el) return null;
        let key = ReactFiberExplorer.propsKeyCache.get(el);
        if (!key) {
            for (const k in el) {
                if (k[0] === '_' && k[1] === '_' && (k.startsWith('__reactProps$') || k.startsWith('__reactEvents$'))) {
                    key = k;
                    ReactFiberExplorer.propsKeyCache.set(el, key);
                    break;
                }
            }
        }
        if (key) {
            return (el as any)[key] ?? null;
        }
        const node = ReactFiberExplorer.getFiberNode(el);
        return node?.memoizedProps ?? node?.return?.memoizedProps ?? null;
    }

    static getReactStore(el: HTMLElement): any {
        if (!el) return null;
        if ((el as any).$store) return (el as any).$store;
        if ((el as any).player?.$store) return (el as any).player.$store;

        const fiber = ReactFiberExplorer.getFiberNode(el);
        if (!fiber) return null;

        const props = fiber.memoizedProps;
        if (props?.store) return props.store;
        if (props?.children?.props?.store) return props.children.props.store;

        let curr = fiber.return;
        for (let i = 0; curr && i < 10; i++) {
            const p = curr.memoizedProps;
            if (p?.store) return p.store;
            if (p?.value?.store) return p.value.store;
            curr = curr.return;
        }
        return null;
    }

    static triggerReact(el: HTMLElement, handlerNames: string | string[] = ['onClick', 'onPointerDown', 'onClickHandler']): boolean {
        if (!el) return false;
        const names = Array.isArray(handlerNames) ? handlerNames : [handlerNames];

        let eventType = 'click';
        if (names.includes('onPointerDown') || names.includes('onPointerDownHandler')) {
            eventType = 'pointerdown';
        } else if (names.includes('onMouseDown')) {
            eventType = 'mousedown';
        }

        const ev = new MouseEvent(eventType, {
            bubbles: true,
            cancelable: true,
            view: window
        });

        let fiber = ReactFiberExplorer.getFiberNode(el);
        for (let depth = 0; fiber && depth < 5; depth++) {
            const props = fiber.memoizedProps;
            if (props) {
                for (const name of names) {
                    const handler = Reflect.get(props, name);
                    if (typeof handler === 'function') {
                        handler({
                            isTrusted: true,
                            nativeEvent: ev,
                            preventDefault: () => { ev.preventDefault(); },
                            stopPropagation: () => { ev.stopPropagation(); },
                            stopImmediatePropagation: () => { ev.stopImmediatePropagation(); },
                        });
                        return true;
                    }
                }
            }
            fiber = fiber.return;
        }

        el.dispatchEvent(ev);
        return false;
    }

    static setReactInputValue(el: HTMLInputElement | HTMLTextAreaElement, value: string): boolean {
        if (!el) return false;
        
        const prototype = Object.getPrototypeOf(el);
        const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
        const setter = descriptor?.set;
        
        if (setter) {
            setter.call(el, value);
        } else {
            el.value = value;
        }
        
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
    }
}

export const getFiberNode = (el: HTMLElement): FiberNode | null => ReactFiberExplorer.getFiberNode(el);
export const getComponentFiber = (el: HTMLElement, name: string): FiberNode | null => ReactFiberExplorer.getComponentFiber(el, name);
export const getReactProps = (el: HTMLElement): Record<string, any> | null => ReactFiberExplorer.getReactProps(el);
export const getReactStore = (el: HTMLElement): any => ReactFiberExplorer.getReactStore(el);
export const triggerReact = (el: HTMLElement, handlerNames?: string | string[]): boolean => ReactFiberExplorer.triggerReact(el, handlerNames);
export const setReactInputValue = (el: HTMLInputElement | HTMLTextAreaElement, value: string): boolean => ReactFiberExplorer.setReactInputValue(el, value);

