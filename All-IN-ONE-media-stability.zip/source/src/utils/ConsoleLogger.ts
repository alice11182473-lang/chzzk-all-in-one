export class ConsoleLogger {
    static readonly gradients = {
        'Content': 'linear-gradient(135deg, #0284c7, #06b6d4)',
        'PlaybackBar': 'linear-gradient(135deg, #ea580c, #eab308)',
        'Injected': 'linear-gradient(135deg, #b91c1c, #ec4899)',
        'Sidebar': 'linear-gradient(135deg, #4f46e5, #06b6d4)',
        'Player': 'linear-gradient(135deg, #7c3aed, #a855f7)',
        'Chat': 'linear-gradient(135deg, #2563eb, #3b82f6)',
        'Error': 'linear-gradient(135deg, #dc2626, #f87171)',
        'System': 'linear-gradient(135deg, #4b5563, #9ca3af)',
        'StateObserver': 'linear-gradient(135deg, #059669, #34d399)'
    } as const;

    static log(level: 'info' | 'warn' | 'error' | 'group' | 'groupCollapsed', mod: keyof typeof ConsoleLogger.gradients | string, text: string, data?: any): void {
        const gradient = ConsoleLogger.gradients[mod as keyof typeof ConsoleLogger.gradients] || 'linear-gradient(135deg, #4f46e5, #06b6d4)';
        const badgeStyle = `background: ${gradient}; color: #fff; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 10px; margin-right: 6px; text-shadow: 0 1px 2px rgba(0,0,0,0.3); box-shadow: 0 1px 3px rgba(0,0,0,0.2);`;
        const textStyle = `color: #e2e8f0; font-weight: bold;`;

        if (level === 'group' || level === 'groupCollapsed' || (data && typeof data === 'object')) {
            const startGroup = level === 'groupCollapsed' ? console.groupCollapsed : console.group;
            startGroup.call(console, `%c[CQC:${mod}]%c ${text}`, badgeStyle, textStyle);
            if (data !== undefined) {
                if (Array.isArray(data)) {
                    console.table(data);
                } else if (data instanceof Error) {
                    console.error(data);
                } else {
                    console.dir(data);
                }
            }
            console.groupEnd();
        } else if (level === 'error') {
            console.error(`%c[CQC:${mod}]%c ${text}`, badgeStyle, 'color: #ef4444; font-weight: bold;', data !== undefined ? data : '');
        } else if (level === 'warn') {
            console.warn(`%c[CQC:${mod}]%c ${text}`, badgeStyle, 'color: #eab308; font-weight: bold;', data !== undefined ? data : '');
        } else {
            if (data !== undefined) {
                console.log(`%c[CQC:${mod}]%c ${text}`, badgeStyle, textStyle, data);
            } else {
                console.log(`%c[CQC:${mod}]%c ${text}`, badgeStyle, textStyle);
            }
        }
    }
}

export const log = (mod: string, ...args: any[]): void => {
    if (args.length > 0) {
        const text = typeof args[0] === 'string' ? args[0] : 'Data Log';
        const data = args.length > 1 ? args[1] : (typeof args[0] === 'string' ? undefined : args[0]);
        ConsoleLogger.log('info', mod, text, data);
    } else {
        ConsoleLogger.log('info', mod, 'Empty Log');
    }
};
