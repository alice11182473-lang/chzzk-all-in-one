export const DEFAULT_SELECTORS = {
    AD_POPUP: ':is(div[class^="popup_container"], div[class*="_modal_"], div[class*="_popup_"])',
    CHANNEL_INFO_ROW: ':is([class*="video_information_row__"], [class*="_row_"])',
    CHANNEL_NAME_LINK: ':is([class*="video_information_link__"], [class*="_link_"])',
    CHANNEL_TAB_ITEM: ':is(.tab_item__8mCoC, [class*="_tab_item_"], [class*="_item_2b57p_"], button[role="tab"])',
    CHANNEL_TAB_LIST: ':is(div.tab_list__05SjP.channel_area__n-4MZ, div[class*="_list_2b57p_"], div[role="tablist"])',
    CHAT_ASIDE: ':is(aside#aside-chatting, aside[class*="live_chatting_container"], [class*="_chatting_container_"])',
    // 뱃지 1개를 감싼 아이콘 래퍼 (뱃지 선택 유지 시 이 래퍼째 숨겨 빈칸 제거). 치지직 빌드 해시 의존 → 깨지면 여기만 갱신.
    CHAT_BADGE_ICON: '[class*="_icon_o04z9_"]',
    // 한 메시지의 뱃지 전체를 담는 리스트 래퍼 (유지 뱃지가 없으면 통째로 숨겨 닉네임 정렬 어긋남 방지).
    CHAT_BADGE_WRAPPER: '[class*="_wrapper_o04z9_"]',
    CHAT_CONTAINER: ':is([class*="chatting_list_wrapper__"], [class*="_wrapper_sg7hy_"], div[role="log"])',
    CHAT_BLINDED_CONTAINER: ':is([class*="live_chatting_message_is_hidden"], [class*="_is_hidden_"])',
    CHAT_DONATION: ':is([class*="chatting_donation_message_container"], [class*="_donation_"], [class*="is_donation__"], [class*="donation_alarm__"], [class*="y6h6c"])',
    CHAT_FOLD_BTN: 'button[aria-label="채팅 접기"]',
    CHAT_HEADER: ':is([class*="live_chatting_header_container"], [class*="_container_mb8xy_"], [class*="_header_container_"])',
    CHAT_ITEM: ':is([class*="chatting_message_item__"], [class*="chatting_list_item__"], [class*="_item_"])',
    CHAT_ITEM_CONTAINER: ':is([class*="chatting_message_container"], [class*="chatting_message_item"], [class*="chatting_list_item__"], [class*="_item_"])',
    CHAT_INPUT: ':is([class*="live_chatting_input_input"], [class*="_input_"]:is(textarea, input, pre), textarea[placeholder*="채팅"], pre[placeholder*="채팅"])',
    CHAT_INPUT_BOX: ':is([class*="live_chatting_input_container"], div:has(> textarea[placeholder*="채팅"]), div:has(> input[placeholder*="채팅"]))',
    CHAT_PROFILE_BTN: ':is([class*="live_chatting_input_setting_button"], button[class*="setting_button"], button:has(> [class*="profile"] img))',
    CHAT_LIST_CONTAINER: ':is([class*="live_chatting_list_container"], [class*="_container_sg7hy_"], div[role="log"] > div)',
    CHAT_LIST_WRAPPER_ALT: ':is([class*="live_chatting_list_wrapper"], [class*="_wrapper_sg7hy_"], div[role="log"])',
    CHAT_MESSAGE: ':is([class*="chatting_message_text__"], div[class*="_chatting_message_"] > span[class*="_text_"], p[class*="_text_"])',
    CHAT_MESSAGE_TEXT: ':is([class*="live_chatting_message_text"], div[class*="_chatting_message_"] > span[class*="_text_"], p[class*="_text_"])',
    CHAT_MORE_MENU_BTN: 'button[aria-label="더보기 메뉴"]',
    CHAT_NICKNAME: ':is([class*="chatting_message_nickname"], button[class*="nickname"], [class*="_nickname_"])',
    CHAT_PROFILE_INFO: ':is(button[class*="live_chatting_popup_profile_information"], button[class*="_profile_information_"])',
    CHAT_PROFILE_POPUP: ':is([class*="live_chatting_popup_profile_container"], [class*="_profile_container_"])',
    CHEAT_KEY_BTN: 'a[href*="profile#cheat_key"]',
    CHEAT_KEY_CLOSE_BTN: ':is([class*="popup_cheat_key_button_close"], [class*="_button_close_"])',
    CHEAT_KEY_POPUP: ':is([class*="popup_cheat_key_container"], [class*="_popup_cheat_key_container_"])',
    CHEAT_KEY_TOOLTIP_CLOSE_BTN: ':is([class*="cheat_key_tooltip_button_close"], [class*="_tooltip_"] [class*="_button_close_"])',
    CHEAT_KEY_TOOLTIP_CONTAINER: ':is([class*="cheat_key_tooltip_container"], [class*="_tooltip_container_"])',
    CHEESE_BTN: 'a[href*="profile#cash"]',
    CONTEXT_MENU_LIST: '.pzp-contextmenu-pane__list',
    CONTEXT_MENU_PANE: '.pzp-contextmenu-pane.pzp-pc-contextmenu-pane.pzp-pc__contextmenu-pane',
    CONTEXT_MENU_ITEM_CLASS: 'pzp-ui-contextmenu-item pzp-contextmenu-pane__list-item',
    CONTEXT_MENU_ITEM_BTN_CLASS: 'pzp-ui-contextmenu-item__button',
    FOLLOWING_ANCHOR: ':is(a.navigator_link__ioXNN[href="/following"], a[class*="_link_"][href="/following"], a[href="/following"])',
    HOME_BANNER: ':is(.top_banner_container__Nk\\+98, section[class*="_container_gftsh_"], section:has(.flicking-camera))',
    HOME_MID_BANNER: 'section:has(> a[class*="_container_"] > div[class*="_wrapper_"])',
    HOME_RECOMMEND_CAROUSEL: ':is(section:has(> div[class*="_item_"]), section:has(> div[style*="transform: translate"]))',
    LAYOUT_BODY: ':is(#layout-body, div[class*="layout_body"], main[class*="_container_"], [class*="_layout_body_"])',
    LIVE_INFO_CONTAINER: ':is([class*="live_information_container_"], [class*="simple_live_information_container_"])',
    LIVE_INFO_DETAILS: ':is([class*="live_information_details_"], [class*="_details_"])',
    LIVE_INFO_LAYER: ':is(div[class*="live_information_video_layer"], div[class*="_video_layer_"], div[class*="_wrapper_"])',
    LIVE_LINK: 'a[href^="/live/"]',
    LIVE_PLAYER_ALT: ':is([class*="live_information_player__"], [class*="_player_"])',
    LIVE_VIDEO_CONTAINER: ':is([class*="live_information_video_container__"], [class*="_video_container_"], [class*="_video_area_"], [class*="_player_"])',
    LOGO_IMG: ':is([class*="navigation_bar_logo__"], h1[class*="_logo_"], strong[class*="_logo_"]) img',
    MORE_BTN: ':is(button[class*="more_button__"], button[class*="_more_button_"])',
    MULTIVIEW_IFRAME_HIDES: ':is([class^="header_container__"], [class*="_header_container_"]):not(#sidebar *), :is([class^="navigation_container__"], [class*="_navigation_container_"]), :is(aside[class^="aside_container__"], aside[class*="_container_1vdxf_"]), :is([class^="live_information_content__"], [class*="_content_"]):not([class*="chatting"]), :is([class^="video_information_container__"], [class*="_video_information_"]), :is([class^="channel_information_area__"], [class*="_information_area_"]), :is([class^="live_information_info__"], [class*="_information_info_"]), :is([class^="live_information_player_header__"], [class*="_player_header_"]), :is([class^="live_chatting_ranking_container__"], [class*="_ranking_container_"]), :is([class^="od_notification_container__"], [class*="_od_notification_"])',
    MULTIVIEW_IFRAME_LAYOUT: 'div[class*="layout_body"], :is(div[class^="live_layout_container__"], div[class*="_layout_container_"]), :is(div[class^="live_layout_section__"], div[class*="_layout_section_"]), :is(div[class^="live_layout_player__"], div[class*="_layout_player_"])',
    MULTIVIEW_IFRAME_POPUPS: ':is(div[class^="popup_container"], div[class*="_popup_container_"]), :is(div[class^="toast_container"], div[class*="_toast_container_"]), [class*="notification_container"]',
    NATIVE_PROGRESS_SLIDER: '.pzp-pc-progress-slider',
    NATIVE_SLIDER_TOOLTIP: '.pzp-pc-ui-slider-tooltip, .pzp-pc__slider-tooltip, [class*="slider-tooltip"], .pzp-seeking-preview',
    NATIVE_SLIDER_TOOLTIP_TIME: '.pzp-pc-ui-slider-tooltip-time, .pzp-pc__slider-tooltip-time, [class*="slider-tooltip-time"], .pzp-seeking-preview__time',
    NATIVE_SLIDER_WRAP: ':is([class*="slider_wrap__"], button[class*="_wrap_"])',
    NAV_ITEM: ':is([class*="navigation_bar_item__"], li[class*="_item_"])',
    NAV_SECTION: ':is([class*="navigation_bar_section__"], nav[class*="_section_"])',
    NAV_TITLE: ':is([class*="navigation_bar_title__"], [class*="_title_"])',
    NOTI_BTN: 'button:has(svg path[d^="M14.009"]), button:has(svg path[d^="m22.81"])',
    PLAYER: '.pzp',
    PLAYER_BOTTOM: '.pzp-pc__bottom, div:has(> :is([class*="slider_wrap__"], button[class*="_wrap_"]))',
    PLAYER_BUTTON_TOOLTIP: '.pzp-button__tooltip',
    PLAYER_CONTAINER: '.pzp, div.chzzk_player',
    PLAYER_CONTROL_BAR: '.pzp-pc__bottom-buttons-left, div:has(> button[class*="play_button"])',
    PLAYER_CONTROL_BAR_RIGHT: '.pzp-pc__bottom-buttons-right, .pzp-pc-bottom-buttons-right, div:has(> .pzp-pc-setting-button, > .pzp-ui-setting-button, > button[aria-label="설정"], > button[aria-label="화질"])',
    PLAYER_FULLSCREEN_BTN: 'button[class*="fullscreen-button"], .pzp-pc-fullscreen-button, button[class*="fullscreen"], button[aria-label="전체화면"]',
    PLAYER_LAYOUT: '#live_player_layout',
    PLAYER_LIVE_INDICATOR: '.pzp-pc--live',
    PLAYER_PC: '.pzp-pc',
    PLAYER_QUALITY_ITEM: '.pzp-ui-setting-quality-item',
    PLAYER_SETTING_BTN: '.pzp-pc-setting-button, .pzp-ui-setting-button',
    PLAYER_QUALITY_ITEM_PREFIX: '.pzp-ui-setting-quality-item__prefix',
    PLAYER_TIME_DISPLAY: '.pzp-vod-time, .pzp-pc-vod-time, .pzp-pc__vod-time, .pzp-pc__live-time, .pzp-pc__bottom-time, .pzp-vod-time__current-time, .pzp-pc__live-time__current, .pzp-pc__bottom-time__current, [role="timer"]',
    PLAYER_VOLUME_CONTROL: '.pzp-pc__volume-control, .pzp-pc-volume-control, [class*="volume_control"], .pzp-pc-volume-control__seekbar, [class*="volume_slider"], [class*="volume_active"]',
    EVENT_BANNER: 'div[class*="_container_55vbw_"], div[class*="_is_scrolled_"]:has([class*="_wrapper_"]):has([class*="_is_expanded_"]), div[class*="_is_scrolled_"]:has([class*="_is_collapsed_"])',
    RS_BANNER: ':is([class*="rs_banner_container__"], [class*="_rs_banner_"])',
    SETTINGS_MENU: '.pzp-pc__settings',
    SIDEBAR_ASIDE: ':is(aside#sidebar, aside[class*="aside_container"], [class*="_wrapper_1vdxf_"])',
    SIDEBAR_CONTAINER: '#sidebar',
    SIDEBAR_NAV_SECTION: 'nav[class*="section"]',
    SIDEBAR_NAV_TITLE: '[class*="title"]',
    SIDEBAR_ASIDE_WRAPPER: ':is([class*="aside_wrapper__"], [class*="_wrapper_1vdxf_"])',
    SIDEBAR_BANNER: ':is(a[class*="aside_banner"], a[class*="_banner_1vdxf_"], a[role="banner"])',
    SIDEBAR_CONTENT: ':is([class*="aside_content__"], [class*="_content_"])',
    SIDEBAR_ITEM: 'li',
    SIDEBAR_NAV_ITEM: ':is([class*="navigator_item__"], [class*="_item_1lz65_"])',
    SIDEBAR_NAV_NAME: ':is([class*="navigator_name__"], [class*="_name_"])',
    SIDEBAR_NAV_COUNT: ':is([class*="navigator_count__"], [class*="_count_"])',
    SIDEBAR_LIVE_INDICATOR: ':is([class*="live_indicator"], [class*="viewer_count"], [class*="viewer_num"], [class*="state_live"], [class*="navigator_is_live__"], [class*="_is_live_"])',
    SIDEBAR_LIST_CONTAINER: 'ul, div[class*="list_container"]',
    SIDEBAR_MENU_LINK: ':is(a[class*="navigation_bar_menu__"], a[class*="_menu_q99ll_"], a[class*="_menu_"])',
    SIDEBAR_NAV_LINK: ':is(a[href^="/live/"], a[class*="navigator_item_link__"], a[class*="_item_link_"]:not([href^="/category"]))',
    SIDEBAR_OBSERVER_SPINNER: 'div[class*="observer"], div[class*="spinner"], ul ~ div',
    SIDEBAR_REFRESH_BTN: ':is(button[aria-label="새로고침"], .navigator_icon_refresh__spksG, [class*="_icon_refresh_"])',
    SIDEBAR_TOGGLE_BTN: 'button[aria-controls="navigation"]',
    SIDEBAR_TOOLTIP: '[class*="_tooltip_1lz65_"]',
    STREAMER_SHOP: ':is(.streamer_shop_container__e2TdU, [class*="_shop_container_"])',
    STUDIO_BUTTON: ':is([class*="toolbar_studio_button__"], a[class*="_studio_button_"])',
    TAB_ITEM: ':is(.button_tab_item__PmbXE, [class*="_item_fdy08_"], button[role="tab"])',
    TAB_LIST: ':is(.button_tab_list__zvBju, [class*="_list_fdy08_"], div[role="tablist"])',
    THEME_BTN: 'button:has(svg path[d*="8.377"])',
    TOOLBAR_BOX: ':is([class*="toolbar_section"] [class*="toolbar_box"]:last-child, [class*="_section_sp9wj_"] [class*="_box_"]:last-child)',
    TOOLBAR_BOX_ALT: ':is([class*="toolbar_box__"], [class*="_box_sp9wj_"])',
    TOOLBAR_ITEM: ':is([class*="toolbar_item__"], [class*="_item_sp9wj_"])',
    TOOLBAR_PROFILE_BTN: ':is([class*="toolbar_profile_button"], [class*="_profile_button_sp9wj_"])',
    TOPIC_TAB_CONTAINER: ':is([class*="topic_tab_container__"], [class*="_container_w2qby_"], div:has(> nav[aria-label="주제 탭"]))',
    TOPIC_TAB_ELEMENTS: ':is(li, a[class*="topic_tab_banner__"], a[class*="_banner_w2qby_"])',
    TOPIC_TAB_LIST: ':is([class*="topic_tab_list__"], [class*="_list_w2qby_"])',
    VIDEO_INFO_DATA: ':is([class*="video_information_data"], [class*="_row_"] > [class*="_data_"], [class*="_data_"]:has(> [class*="_count_"])):not([data-testid^="donation-board"]):not([class*="_marquee_"] *)',
    VIDEO_INFORMATION: ':is([class*="video_information_data"], [class*="_row_"] > [class*="_data_"], [class*="_data_"]:has(> [class*="_count_"])):not([data-testid^="donation-board"]):not([class*="_marquee_"] *)',
    VIDEO_ITEM: ':is([class*="navigation_component_item__"], li:has(a[href^="/live/"]))',
    VIDEO_LIST: ':is([class*="navigation_component_list__"], ul[class*="_list_tsisc_"])',
    VIEW_MODE_BTN: '.pzp-pc-viewmode-button, .pzp-viewmode-button, [class*="pzp-viewmode-button"]',
    PLAYER_WIDE_CLASS_PC: 'pzp-pc-viewmode-wide',
    PLAYER_WIDE_CLASS: 'pzp-viewmode-wide',
    VOD_RECOMMEND: ':is(div[class*="vod_recommend_container"], div[class*="_recommend_container_"])',
    VIEW_MODE_DEFAULT_LABEL: '기본 화면',
    VIEW_MODE_NARROW_LABEL: '좁은 화면',
    VIEW_MODE_WIDE_LABEL: '넓은 화면',
    VIEW_MODE_FULL_EXIT_LABEL: '전체 화면 종료'
} as const;

export type SelectorKey = keyof typeof DEFAULT_SELECTORS;

export class SelectorRegistry {
    private static instance: SelectorRegistry | null = null;
    private selectors: Record<string, string>;
    private proxy: Record<string, string>;

    static getInstance(): SelectorRegistry {
        if (!SelectorRegistry.instance) {
            SelectorRegistry.instance = new SelectorRegistry();
        }
        return SelectorRegistry.instance;
    }

    constructor() {
        this.selectors = { ...DEFAULT_SELECTORS };
        this.proxy = new Proxy(this.selectors, {
            get: (target, prop: string) => {
                return target[prop] || '';
            }
        });
    }

    init(overrides?: Record<string, string>): void {
        if (overrides) {
            Object.assign(this.selectors, overrides);
        }
    }

    get(key: string): string {
        return this.selectors[key] || '';
    }

    getAll(): Record<string, string> {
        return this.selectors;
    }

    getProxy(): Record<string, string> {
        return this.proxy;
    }
}
