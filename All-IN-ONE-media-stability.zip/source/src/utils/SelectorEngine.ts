import { ReactFiberExplorer, SELECTORS } from '../../dom-utils';

export function getStableClassPrefix(className: string): string | null {
    if (!className) return null;
    const classes = className.split(/\s+/).filter(Boolean);
    const prefixes = classes.map(c => {
        const parts = c.split('__');
        if (parts.length > 1 && parts[0]) {
            return parts[0];
        }
        if (!c.includes(':') && !c.includes('.') && c.length > 2) {
            return c;
        }
        return null;
    }).filter(Boolean);

    if (prefixes.length === 0) return null;
    return prefixes.map(p => `[class*="${p}__"]`).join('');
}

export function getFiberComponentPath(el: HTMLElement): string[] {
    const path: string[] = [];
    let curr = ReactFiberExplorer.getFiberNode(el);
    while (curr) {
        const name = curr.type?.name || curr.type?.displayName;
        if (name && typeof name === 'string' && !path.includes(name)) {
            path.push(name);
        }
        curr = curr.return;
    }
    return path;
}

export function testSelector(selector: string): number {
    try {
        return document.querySelectorAll(selector).length;
    } catch (e) {
        return 0;
    }
}

export function findMatchingSelectorKey(el: HTMLElement): string | null {
    for (const [key, selector] of Object.entries(SELECTORS)) {
        if (!selector) continue;
        try {
            if (el.matches(selector)) {
                return key;
            }
        } catch (e) {
            // invalid selector 무시
        }
    }
    return null;
}

export interface SelectorCandidate {
    selector: string;
    strategy: string;
    matches: number;
}

export function generateRobustSelector(el: HTMLElement): SelectorCandidate[] {
    const candidates: SelectorCandidate[] = [];

    const addCandidate = (selector: string, strategy: string) => {
        if (!selector) return;
        if (candidates.some(c => c.selector === selector)) return;
        const matches = testSelector(selector);
        candidates.push({ selector, strategy, matches });
    };

    // 1. ID 기반 (자동생성되거나 임시 ID인지 대략 필터링)
    if (el.id && !/^(react-|__)/.test(el.id)) {
        addCandidate(`#${el.id}`, 'ID');
    }

    // 2. Data Attribute & Aria Label 기반
    const priorityAttrs = ['data-testid', 'data-component', 'aria-label', 'role', 'name'];
    for (const attr of priorityAttrs) {
        const val = el.getAttribute(attr);
        if (val) {
            addCandidate(`[${attr}="${val}"]`, `Attribute: ${attr}`);
            addCandidate(`${el.tagName.toLowerCase()}[${attr}="${val}"]`, `Tag + Attribute: ${attr}`);
        }
    }

    // 3. Link href
    if (el.tagName.toLowerCase() === 'a') {
        const href = el.getAttribute('href');
        if (href && href.length > 1 && !href.startsWith('javascript:')) {
            addCandidate(`a[href="${href}"]`, 'Link href');
            if (href.startsWith('/live/')) {
                addCandidate('a[href^="/live/"]', 'Live link prefix');
            }
        }
    }

    // 4. CSS Module 클래스 기반
    const className = el.className;
    if (className && typeof className === 'string') {
        const stableClass = getStableClassPrefix(className);
        if (stableClass) {
            addCandidate(stableClass, 'CSS Module Class');
            addCandidate(`${el.tagName.toLowerCase()}${stableClass}`, 'Tag + CSS Module Class');
        }
    }

    // 5. React Fiber 기반 컴포넌트 정보 결합
    const fiberPath = getFiberComponentPath(el);
    if (fiberPath.length > 0) {
        const className = el.className;
        if (className && typeof className === 'string') {
            const stableClass = getStableClassPrefix(className);
            if (stableClass) {
                let parent = el.parentElement;
                let depth = 1;
                while (parent && depth <= 3) {
                    const parentClass = parent.className;
                    if (parentClass && typeof parentClass === 'string') {
                        const parentStable = getStableClassPrefix(parentClass);
                        if (parentStable) {
                            addCandidate(`${parentStable} ${stableClass}`, `Parent Context (Depth ${depth})`);
                            break;
                        }
                    }
                    parent = parent.parentElement;
                    depth++;
                }
            }
        }
    }

    // 6. 단순 태그명
    addCandidate(el.tagName.toLowerCase(), 'Tag name');

    // 정렬: matches 가 1인 것이 최우선, 그 후 매칭 수 오름차순
    candidates.sort((a, b) => {
        if (a.matches === 1 && b.matches !== 1) return -1;
        if (a.matches !== 1 && b.matches === 1) return 1;
        return a.matches - b.matches;
    });

    return candidates;
}
