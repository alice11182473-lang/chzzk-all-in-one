import { SelectorRegistry } from './SelectorRegistry';

export class ToastController {
    static show(text: string, parent: HTMLElement | null = null): void {
        document.querySelector('.cqc-toast')?.remove();
        const t = document.createElement('div');
        t.className = 'cqc-toast';
        t.insertAdjacentHTML('beforeend', text);
        const sel = SelectorRegistry.getInstance().getProxy();
        const target = parent ?? document.querySelector(sel.PLAYER) ?? document.body;
        target.appendChild(t);
        requestAnimationFrame(() => t.classList.add('cqc-toast--show'));
        setTimeout(() => {
            t.classList.remove('cqc-toast--show');
            setTimeout(() => t.remove(), 200);
        }, 2000);
    }
}

export const showToast = (text: string, parent: HTMLElement | null = null): void => ToastController.show(text, parent);
