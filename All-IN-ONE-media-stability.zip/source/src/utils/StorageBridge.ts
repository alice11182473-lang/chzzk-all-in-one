import Browser from 'webextension-polyfill';

// Keep the original sync reference before redirection
const originalSync = Browser.storage.sync;

// Redirect Browser.storage.sync to Browser.storage.local
try {
  // @ts-ignore
  Object.defineProperty(Browser.storage, 'sync', {
    value: Browser.storage.local,
    writable: true,
    configurable: true
  });
} catch (e) {
  // @ts-ignore
  Browser.storage.sync = Browser.storage.local;
}

/**
 * Migrates existing settings from chrome.storage.sync to chrome.storage.local.
 * Only runs in background.js where it can execute asynchronously on startup.
 */
export const runMigration = async (): Promise<void> => {
  if (!originalSync) return;
  const migratedKey = '__cqc_migrated_to_local_v2';
  
  try {
    const localRes = await Browser.storage.local.get(migratedKey);
    if (localRes && localRes[migratedKey]) {
      console.log('[CQC:StorageBridge] Storage already migrated.');
      return;
    }
    
    // Load all data from original sync storage
    const allSyncData = await originalSync.get(null);
    
    if (allSyncData && Object.keys(allSyncData).length > 0) {
      // Save all data to local storage
      await Browser.storage.local.set(allSyncData);
      console.log('[CQC:StorageBridge] Successfully migrated sync storage to local storage');
    }
    
    // Mark migration as complete
    await Browser.storage.local.set({ [migratedKey]: true });
  } catch (err) {
    console.error('[CQC:StorageBridge] Migration failed:', err);
  }
};
