import React, { useState } from 'react';
import Browser from 'webextension-polyfill';
import { safeParseSettings } from '../../../settings-schema';

interface SetupWizardProps {
  onClose: () => void;
}

export const SetupWizard: React.FC<SetupWizardProps> = ({ onClose }) => {
  const isFirefox = /firefox|zen/i.test(navigator.userAgent);

  const [activePreset, setActivePreset] = useState<string>('balanced');

  const [options, setOptions] = useState({
    ambientEnabled: true,
    sharpnessEnabled: false,
    gridBypassEnabled: true,
    hoverPreviewEnabled: true,
    playbackBarEnabled: true,
    layoutCleanEnabled: true,
    chatStampEnabled: false,
  });

  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const presetConfig: Record<string, typeof options> = {
    performance: {
      ambientEnabled: false,
      sharpnessEnabled: false,
      gridBypassEnabled: true,
      hoverPreviewEnabled: false,
      playbackBarEnabled: true,
      layoutCleanEnabled: true,
      chatStampEnabled: false,
    },
    balanced: {
      ambientEnabled: true,
      sharpnessEnabled: false,
      gridBypassEnabled: true,
      hoverPreviewEnabled: true,
      playbackBarEnabled: true,
      layoutCleanEnabled: true,
      chatStampEnabled: false,
    },
    visual: {
      ambientEnabled: true,
      sharpnessEnabled: !isFirefox,
      gridBypassEnabled: true,
      hoverPreviewEnabled: true,
      playbackBarEnabled: true,
      layoutCleanEnabled: true,
      chatStampEnabled: true,
    },
  };

  const handlePresetSelect = (preset: string) => {
    setActivePreset(preset);
    setOptions(presetConfig[preset]);
  };

  const handleToggle = (key: keyof typeof options) => {
    setActivePreset('custom');
    setOptions((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleApply = async () => {
    setIsSaving(true);
    setErrorMsg(null);
    try {
      const { settings: currentSettings } = await Browser.storage.sync.get('settings');
      const validated = safeParseSettings(currentSettings);

      // 마법사 옵션 적용
      Object.assign(validated, options);

      // hoverPreviewVideoEnabled 하위 옵션 처리
      if (options.hoverPreviewEnabled) {
        if (activePreset === 'visual') {
          validated.hoverPreviewVideoEnabled = true;
        } else if (activePreset === 'performance') {
          validated.hoverPreviewVideoEnabled = false;
        }
      } else {
        validated.hoverPreviewVideoEnabled = false;
      }

      // 설정 완료로 표시
      validated.setupCompleted = true;

      // 백그라운드 메시지 라우팅을 통해 저장
      await Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: validated });

      onClose();
      window.location.reload();
    } catch (err) {
      console.error('[CQC:SetupWizard] Save failed:', err);
      setIsSaving(false);
      setErrorMsg('설정 저장 실패 - 다시 시도해주세요.');
    }
  };

  return (
    <div className="cqc-setup-overlay">
      <div className="cqc-setup-card">
        <div className="cqc-setup-header">
          <span className="cqc-setup-title">CHZZK ALL-IN-ONE</span>
          <span className="cqc-setup-subtitle">WELCOME PRESET</span>
        </div>
        <div className="cqc-setup-body">
          <div className="cqc-setup-warning">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
              <line x1="12" y1="9" x2="12" y2="13"></line>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            <div>
              <strong>성능 주의 사항:</strong> 일부 옵션({isFirefox ? '앰비언트 효과 등' : '앰비언트, 선명한 화면 등'})은 실시간 그래픽/비디오 필터를 사용하므로 CPU/GPU 사용량이 증가할 수 있습니다. 고사양 게임과 병행 시 튕김 현상이 발생하면 <strong>성능 우선</strong> 모드를 권장합니다.
            </div>
          </div>

          <div>
            <div className="cqc-setup-section-title">Step 1. 프리셋 선택</div>
            <div className="cqc-preset-cards">
              <div
                className={`cqc-preset-card ${activePreset === 'performance' ? 'active' : ''}`}
                onClick={() => handlePresetSelect('performance')}
              >
                <span className="cqc-preset-icon">⚡</span>
                <span className="cqc-preset-name">성능 우선</span>
                <span className="cqc-preset-desc">저사양 환경 추천<br />GPU 부하 최소화</span>
              </div>
              <div
                className={`cqc-preset-card ${activePreset === 'balanced' ? 'active' : ''}`}
                onClick={() => handlePresetSelect('balanced')}
              >
                <span className="cqc-preset-icon">⚖️</span>
                <span className="cqc-preset-name">밸런스</span>
                <span className="cqc-preset-desc">부담 없는 사양<br />균형 잡힌 경험</span>
              </div>
              <div
                className={`cqc-preset-card ${activePreset === 'visual' ? 'active' : ''}`}
                onClick={() => handlePresetSelect('visual')}
              >
                <span className="cqc-preset-icon">✨</span>
                <span className="cqc-preset-name">비주얼 우선</span>
                <span className="cqc-preset-desc">최고의 화질 경험<br />모든 효과 활성화</span>
              </div>
            </div>
          </div>

          <div>
            <div className="cqc-setup-section-title">Step 2. 세부 옵션 커스텀</div>
            <div className="cqc-detail-options">

              {/* 앰비언트 라이트 */}
              <div className="cqc-detail-item">
                <div className="cqc-detail-info">
                  <div className="cqc-detail-label-wrap">
                    <span className="cqc-detail-label">앰비언트 효과</span>
                    <span className="cqc-detail-badge">GPU 연산</span>
                  </div>
                  <span className="cqc-detail-desc">플레이어 외곽에 영상 색상 반영 빛 번짐 효과</span>
                </div>
                <div
                  className={`cqc-switch ${options.ambientEnabled ? 'active' : ''}`}
                  onClick={() => handleToggle('ambientEnabled')}
                ></div>
              </div>

              {/* 선명한 화면 필터 (Firefox 미노출) */}
              {!isFirefox && (
                <div className="cqc-detail-item">
                  <div className="cqc-detail-info">
                    <div className="cqc-detail-label-wrap">
                      <span className="cqc-detail-label">선명한 화면 필터</span>
                      <span className="cqc-detail-badge">GPU 연산</span>
                    </div>
                    <span className="cqc-detail-desc">실시간 영상 선명도 조절 및 색상 보정 필터</span>
                  </div>
                  <div
                    className={`cqc-switch ${options.sharpnessEnabled ? 'active' : ''}`}
                    onClick={() => handleToggle('sharpnessEnabled')}
                  ></div>
                </div>
              )}

              {/* 그리드 우회 */}
              <div className="cqc-detail-item">
                <div className="cqc-detail-info">
                  <div className="cqc-detail-label-wrap">
                    <span className="cqc-detail-label">그리드 우회 사용</span>
                  </div>
                  <span className="cqc-detail-desc">그리드 프로그램 설치 없이 1080p 고화질 시청 우회</span>
                </div>
                <div
                  className={`cqc-switch ${options.gridBypassEnabled ? 'active' : ''}`}
                  onClick={() => handleToggle('gridBypassEnabled')}
                ></div>
              </div>

              {/* 마우스 오버 미리보기 */}
              <div className="cqc-detail-item">
                <div className="cqc-detail-info">
                  <div className="cqc-detail-label-wrap">
                    <span className="cqc-detail-label">사이드바 마우스 오버 미리보기</span>
                  </div>
                  <span className="cqc-detail-desc">팔로잉 목록 마우스 오버 시 미니 방송 카드 노출</span>
                </div>
                <div
                  className={`cqc-switch ${options.hoverPreviewEnabled ? 'active' : ''}`}
                  onClick={() => handleToggle('hoverPreviewEnabled')}
                ></div>
              </div>

              {/* 플레이어 바 */}
              <div className="cqc-detail-item">
                <div className="cqc-detail-info">
                  <div className="cqc-detail-label-wrap">
                    <span className="cqc-detail-label">플레이어 바</span>
                  </div>
                  <span className="cqc-detail-desc">영상 플레이어 하단에 지연 시간 및 재생 정보 표시</span>
                </div>
                <div
                  className={`cqc-switch ${options.playbackBarEnabled ? 'active' : ''}`}
                  onClick={() => handleToggle('playbackBarEnabled')}
                ></div>
              </div>

              {/* 레이아웃 청소 */}
              <div className="cqc-detail-item">
                <div className="cqc-detail-info">
                  <div className="cqc-detail-label-wrap">
                    <span className="cqc-detail-label">레이아웃 청소 및 광고 제거</span>
                  </div>
                  <span className="cqc-detail-desc">사이드바 불필요 메뉴 제거 및 그리드 설치 유도 차단</span>
                </div>
                <div
                  className={`cqc-switch ${options.layoutCleanEnabled ? 'active' : ''}`}
                  onClick={() => handleToggle('layoutCleanEnabled')}
                ></div>
              </div>

              {/* 채팅 시간 표시 */}
              <div className="cqc-detail-item">
                <div className="cqc-detail-info">
                  <div className="cqc-detail-label-wrap">
                    <span className="cqc-detail-label">채팅 시간 표시 (타임스탬프)</span>
                  </div>
                  <span className="cqc-detail-desc">채팅창 개별 메시지에 전송된 시간 출력</span>
                </div>
                <div
                  className={`cqc-switch ${options.chatStampEnabled ? 'active' : ''}`}
                  onClick={() => handleToggle('chatStampEnabled')}
                ></div>
              </div>

            </div>
          </div>
        </div>
        <div className="cqc-setup-footer">
          {errorMsg && <div style={{ color: '#ff6b6b', fontSize: '12px', marginBottom: '8px', textAlign: 'center' }}>{errorMsg}</div>}
          <button
            type="button"
            className="cqc-apply-btn"
            onClick={handleApply}
            disabled={isSaving}
          >
            {isSaving ? '적용 중...' : '적용 완료 및 시작하기'}
          </button>
        </div>
      </div>
    </div>
  );
};
