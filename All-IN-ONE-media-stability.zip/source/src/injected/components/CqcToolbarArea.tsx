import React, { useState, useEffect, useRef } from 'react';
import { powerDB } from '../../../powerclick-db';
import { getChannelData } from '../../../dom-utils';

interface NoticeFeed {
    feed: {
        feedId: number;
        title: string;
        createdDate: string;
        repImageUrl?: string;
    };
}

interface PowerLog {
    channelId: string;
    channelName: string;
    channelImageUrl?: string;
    timestamp: number;
    amount: number;
}

interface ChannelMeta {
    channelId: string;
    channelName: string;
    channelImageUrl: string;
    officialAmount: number | null;
    syncTs: number;
}

interface PowerUpdateDetail {
    totalCount: number;
    powerCount: number;
    isFarming: boolean;
    isFocusMode: boolean;
    isPowerEnabled: boolean;
}

const IS_FIREFOX = navigator.userAgent.toLowerCase().includes('firefox');

export const CqcToolbarArea: React.FC<{ settings: any }> = ({ settings }) => {
    // 공지사항 관련 상태
    const [noticeIconEnabled, setNoticeIconEnabled] = useState(
        IS_FIREFOX ? false : (settings?.noticeIconEnabled ?? true)
    );
    const [isNoticeOpen, setIsNoticeOpen] = useState(false);
    const [notices, setNotices] = useState<NoticeFeed[]>([]);
    const [isNoticeLoading, setIsNoticeLoading] = useState(false);
    const [noticeError, setNoticeError] = useState<string | null>(null);
    const noticeRef = useRef<HTMLDivElement>(null);

    // 통나무(PowerClick) 관련 상태
    const [powerState, setPowerState] = useState<PowerUpdateDetail>({
        totalCount: 0,
        powerCount: 0,
        isFarming: false,
        isFocusMode: settings?.focusModeEnabled ?? false,
        isPowerEnabled: settings?.powerClickEnabled ?? true
    });
    const [isTooltipOpen, setIsTooltipOpen] = useState(false);
    const [isTooltipSticky, setIsTooltipSticky] = useState(false);
    const [tooltipItems, setTooltipItems] = useState<any[]>([]);
    const [isTooltipLoading, setIsTooltipLoading] = useState(false);
    const [officialAmount, setOfficialAmount] = useState<number | null>(null);

    const powerRef = useRef<HTMLDivElement>(null);
    const longHoverTimerRef = useRef<NodeJS.Timeout | null>(null);

    useEffect(() => {
        setNoticeIconEnabled(IS_FIREFOX ? false : (settings?.noticeIconEnabled ?? true));
        setPowerState(prev => ({
            ...prev,
            isFocusMode: settings?.focusModeEnabled ?? false,
            isPowerEnabled: settings?.powerClickEnabled ?? true
        }));
    }, [settings]);

    // 이벤트 리스너 등록 (통나무 개수 실시간 수신)
    useEffect(() => {
        const handlePowerUpdate = (e: Event) => {
            const customEvent = e as CustomEvent<PowerUpdateDetail>;
            if (customEvent.detail) {
                setPowerState(customEvent.detail);
            }
        };

        window.addEventListener('cqc-power-update', handlePowerUpdate);
        return () => {
            window.removeEventListener('cqc-power-update', handlePowerUpdate);
        };
    }, []);

    // 외부 클릭 시 모달 및 툴팁 닫기
    useEffect(() => {
        const handleOutsideClick = (e: MouseEvent) => {
            const target = e.target as HTMLElement;
            if (isNoticeOpen && noticeRef.current && !noticeRef.current.contains(target)) {
                setIsNoticeOpen(false);
            }
            if (isTooltipSticky && powerRef.current && !powerRef.current.contains(target)) {
                setIsTooltipOpen(false);
                setIsTooltipSticky(false);
            }
        };

        document.addEventListener('click', handleOutsideClick);
        return () => {
            document.removeEventListener('click', handleOutsideClick);
        };
    }, [isNoticeOpen, isTooltipSticky]);

    // 공지사항 가져오기
    const fetchNotices = async () => {
        setIsNoticeLoading(true);
        setNoticeError(null);
        try {
            const res = await new Promise<any>((resolve) => {
                const id = Math.random();
                const handler = (e: MessageEvent) => {
                    if (e.source !== window || e.data?.direction !== 'CQC_TO_INJECTED') return;
                    const { type, id: resId, payload } = e.data;
                    if (type === 'RESPONSE' && resId === id) {
                        window.removeEventListener('message', handler);
                        resolve(payload);
                    }
                };
                window.addEventListener('message', handler);
                window.postMessage({ direction: 'CQC_TO_CONTENT', id, type: 'CHZZK_FETCH_NOTICES' }, '*');
                
                setTimeout(() => {
                    window.removeEventListener('message', handler);
                    resolve({ success: false, error: '시간 초과로 공지사항을 불러오지 못했습니다.' });
                }, 3000);
            });

            if (res && res.success && res.data && res.data.feeds) {
                setNotices(res.data.feeds);
            } else {
                throw new Error(res?.error || '데이터를 불러올 수 없습니다.');
            }
        } catch (err: any) {
            setNoticeError(err.message || '공지사항을 불러오는데 실패했습니다.');
        } finally {
            setIsNoticeLoading(false);
        }
    };

    const handleNoticeClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (isNoticeOpen) {
            setIsNoticeOpen(false);
        } else {
            setIsNoticeOpen(true);
            fetchNotices();
        }
    };

    // 통나무 획득 정보 렌더링
    const fetchPowerTooltipData = async (isStickyMode: boolean) => {
        setIsTooltipLoading(true);
        const channel = getChannelData(document.body);
        const currentChannelId = channel?.channelId;

        // 공식 통나무 양 로드
        if (currentChannelId) {
            try {
                const meta = await powerDB.getKV('channel_meta_' + currentChannelId) as ChannelMeta | undefined;
                let offAmt = meta?.officialAmount ?? null;
                const syncTs = meta?.syncTs || 0;

                if (offAmt === null || (Date.now() - syncTs > 60000)) {
                    const res = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${currentChannelId}/log-power`, {
                        credentials: 'include'
                    });
                    const json = await res.json();
                    const freshAmount = json?.content?.amount ?? null;
                    if (freshAmount !== null) {
                        offAmt = freshAmount;
                        await powerDB.setKV('channel_meta_' + currentChannelId, {
                            channelId: currentChannelId,
                            channelName: channel?.channelName || 'unknown',
                            channelImageUrl: channel?.channelImageUrl || '',
                            officialAmount: offAmt,
                            syncTs: Date.now()
                        });
                    }
                }
                setOfficialAmount(offAmt);
            } catch (err) {
                setOfficialAmount(null);
            }
        } else {
            setOfficialAmount(null);
        }

        if (isStickyMode) {
            // 모든 채널 보유량 로드
            try {
                const res = await fetch('https://api.chzzk.naver.com/service/v1/log-power/balances', {
                    credentials: 'include'
                });
                const json = await res.json();
                const officialBalances = json?.content?.data ?? null;

                const items: any[] = [];
                const localMetas = new Map<string, any>();

                try {
                    const allKeys = await powerDB.getAllKeys() as string[];
                    const metaKeys = allKeys.filter(k => String(k).startsWith('channel_meta_'));
                    for (const key of metaKeys) {
                        const meta = await powerDB.getKV(key) as ChannelMeta | undefined;
                        if (meta && meta.channelId) localMetas.set(meta.channelId, meta);
                    }
                } catch (e) { }

                if (officialBalances && Array.isArray(officialBalances)) {
                    for (const bal of officialBalances) {
                        const meta = localMetas.get(bal.channelId);
                        items.push({
                            channelId: bal.channelId,
                            channelName: bal.channelName || meta?.channelName || 'unknown',
                            channelImageUrl: bal.channelImageUrl || meta?.channelImageUrl || '',
                            count: bal.amount ?? 0,
                            syncTs: meta?.syncTs || 0
                        });
                    }
                } else {
                    for (const [chId, meta] of localMetas.entries()) {
                        const count = (await powerDB.getKV('power_count_' + chId) as number) || 0;
                        if (count > 0) items.push({ ...meta, count });
                    }
                }

                items.sort((a, b) => b.count - a.count || (b.syncTs || 0) - (a.syncTs || 0));
                setTooltipItems(items);
            } catch (err) {
                setTooltipItems([]);
            }
        } else {
            // 최근 획득 내역 로드
            try {
                const logs = await powerDB.getPowerLogs(100) as PowerLog[];
                const map = new Map<string, any>();
                for (const log of logs) {
                    const key = log.channelId && log.channelId !== 'unknown' ? log.channelId : log.channelName;
                    if (!map.has(key)) {
                        map.set(key, { name: log.channelName, img: log.channelImageUrl, logs: [], id: log.channelId });
                    }
                    const d = map.get(key);
                    d.logs.push(log);
                    if (!d.img && log.channelImageUrl) d.img = log.channelImageUrl;
                    if (d.name === 'unknown' && log.channelName !== 'unknown') d.name = log.channelName;
                }

                const items: any[] = [];
                for (const d of map.values()) {
                    const collectedCount = d.id ? (await powerDB.getKV('power_count_' + d.id) as number) || 0 : 0;
                    if (collectedCount <= 0) continue;
                    const lastLogTs = d.logs.reduce((max: number, l: any) => Math.max(max, l.timestamp || 0), 0);
                    items.push({
                        channelId: d.id,
                        channelName: d.name,
                        channelImageUrl: d.img,
                        count: collectedCount,
                        lastLogTs
                    });
                }
                setTooltipItems(items);
            } catch (err) {
                setTooltipItems([]);
            }
        }
        setIsTooltipLoading(false);
    };

    const handlePowerMouseEnter = () => {
        if (isTooltipSticky) return;
        setIsTooltipOpen(true);
        fetchPowerTooltipData(false);

        longHoverTimerRef.current = setTimeout(() => {
            setIsTooltipSticky(true);
            fetchPowerTooltipData(true);
        }, 2500);
    };

    const handlePowerMouseLeave = () => {
        if (isTooltipSticky) return;
        if (longHoverTimerRef.current) {
            clearTimeout(longHoverTimerRef.current);
            longHoverTimerRef.current = null;
        }
        setIsTooltipOpen(false);
    };

    const handleCloseTooltip = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsTooltipOpen(false);
        setIsTooltipSticky(false);
        if (longHoverTimerRef.current) {
            clearTimeout(longHoverTimerRef.current);
            longHoverTimerRef.current = null;
        }
    };

    const formatRelTime = (ts: number) => {
        const diff = Date.now() - ts;
        if (diff < 60000) return '방금 전';
        const min = Math.floor(diff / 60000);
        if (min < 60) return `${min}분 전`;
        const hr = Math.floor(min / 60);
        if (hr < 24) return `${hr}시간 전`;
        const day = Math.floor(hr / 24);
        return `${day}일 전`;
    };

    const svgIcon = (
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="none" viewBox="0 0 20 21" style={{ verticalAlign: 'middle', marginRight: '4px' }}>
            <mask id="mask_power_react" width="20" height="21" x="0" y="0" maskUnits="userSpaceOnUse" style={{ maskType: 'alpha' }}>
                <path fill="#000" d="M5 9.418c.46 0 .833.746.833 1.666 0 .92-.373 1.667-.833 1.667-.46 0-.833-.746-.833-1.667 0-.92.373-1.666.833-1.666Z"></path>
                <path fill="#000" fillRule="evenodd" d="M8.493 3.293c.372 0 .717.184.925.485l.08.137.94 1.878h4.747c1.072 0 1.885.786 2.39 1.711.52.953.819 2.22.819 3.58 0 1.361-.3 2.628-.82 3.58-.504.926-1.317 1.712-2.389 1.712H5c-1.071 0-1.885-.786-2.39-1.712-.519-.952-.818-2.219-.818-3.58 0-1.36.3-2.627.819-3.58C3.115 6.58 3.929 5.793 5 5.793h1.77l-.435-.872A1.125 1.125 0 0 1 7.34 3.293h1.153ZM5 7.209c-.31 0-.746.24-1.146.973-.385.707-.646 1.732-.646 2.902 0 1.17.26 2.196.646 2.902.4.733.836.974 1.146.974.31 0 .746-.24 1.146-.974.385-.706.646-1.731.646-2.902 0-1.17-.26-2.195-.646-2.902C5.746 7.45 5.31 7.21 5 7.21Zm2.214 0c.062.096.12.195.175.295.185.338.34.716.466 1.123h1.312l.072.003a.708.708 0 0 1 0 1.41l-.072.003h-1.02a9.034 9.034 0 0 1 .01 2h6.426l.073.003a.708.708 0 0 1 0 1.41l-.073.003H7.88c-.13.439-.294.845-.49 1.205-.055.1-.114.2-.176.296h7.971c.31 0 .746-.24 1.146-.974.386-.706.646-1.731.646-2.902 0-.363-.027-.711-.073-1.041H12a.708.708 0 0 1 0-1.416h4.537a4.256 4.256 0 0 0-.206-.445c-.4-.733-.836-.973-1.146-.973H7.214Zm1.14-1.416h.5l-.542-1.084h-.5l.542 1.084Z" clip-rule="evenodd"></path>
            </mask>
            <g mask="url(#mask_power_react)"><path fill="currentColor" d="M0 .25h20v20H0z"></path></g>
        </svg>
    );

    const statusText = powerState.isFarming ? '벌목 중' : '벌목 대기 중';
    const statusClass = powerState.isFarming ? 'is-farming' : 'is-idle';

    return (
        <div className="cqc-toolbar-react-area" style={{ display: 'flex', alignItems: 'center' }}>
            {/* 1. 공지사항 아이콘 */}
            {noticeIconEnabled && (
                <div className="cqc-notice-icon-wrapper" ref={noticeRef} title="치지직 공지사항" style={{ display: 'flex', alignItems: 'center', marginRight: '8px', cursor: 'pointer', position: 'relative' }}>
                    <button className="cqc-notice-btn" onClick={handleNoticeClick} style={{ background: 'transparent', border: 'none', padding: '8px', cursor: 'pointer', color: 'var(--color-content-1, #fff)', display: 'flex', alignItems: 'center', justifyContent: 'center', borderRadius: '50%' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <line x1="10" y1="9" x2="8" y2="9"></line>
                        </svg>
                    </button>

                    {/* 공지사항 모달 */}
                    {isNoticeOpen && (
                        <div className="cqc-notice-modal cqc-glass-modal" style={{ position: 'absolute', top: '45px', right: '0px', left: 'auto', zIndex: 1000 }}>
                            <div className="cqc-notice-header">
                                <h3 style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                        <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                                        <polyline points="14 2 14 8 20 8"></polyline>
                                        <line x1="16" y1="13" x2="8" y2="13"></line>
                                        <line x1="16" y1="17" x2="8" y2="17"></line>
                                        <line x1="10" y1="9" x2="8" y2="9"></line>
                                    </svg>
                                    치지직 공지사항
                                </h3>
                                <button className="cqc-notice-close" onClick={() => setIsNoticeOpen(false)}>
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12"></path></svg>
                                </button>
                            </div>
                            <div className="cqc-notice-content">
                                {isNoticeLoading && (
                                    <div className="cqc-notice-loading">
                                        <svg className="cqc-spin" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path></svg>
                                        불러오는 중...
                                    </div>
                                )}
                                {noticeError && (
                                    <div className="cqc-notice-error">{noticeError}</div>
                                )}
                                {!isNoticeLoading && !noticeError && notices.length === 0 && (
                                    <div className="cqc-notice-empty">공지사항이 없습니다.</div>
                                )}
                                {!isNoticeLoading && !noticeError && notices.map((item, idx) => {
                                    const feed = item.feed;
                                    let dateStr = feed.createdDate;
                                    let date = dateStr;
                                    let isNew = false;
                                    if (dateStr && dateStr.length >= 8) {
                                        const year = parseInt(dateStr.substring(0, 4));
                                        const month = parseInt(dateStr.substring(4, 6)) - 1;
                                        const day = parseInt(dateStr.substring(6, 8));
                                        date = `${dateStr.substring(0, 4)}.${dateStr.substring(4, 6)}.${dateStr.substring(6, 8)}`;
                                        
                                        const feedDate = new Date(year, month, day);
                                        const now = new Date();
                                        const diffTime = Math.abs(now.getTime() - feedDate.getTime());
                                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                                        isNew = diffDays < 3;
                                    }
                                    return (
                                        <a key={feed.feedId || idx} href={`https://game.naver.com/lounge/chzzk/board/detail/${feed.feedId}`} target="_blank" rel="noreferrer" className="cqc-notice-item">
                                            <div className="cqc-notice-item-text">
                                                <div className="cqc-notice-title">
                                                    {isNew && <span className="cqc-notice-badge">N</span>}
                                                    {feed.title}
                                                </div>
                                                <div className="cqc-notice-date">{date}</div>
                                            </div>
                                            {feed.repImageUrl && (
                                                <div className="cqc-notice-thumb">
                                                    <img src={feed.repImageUrl} alt="thumbnail" />
                                                </div>
                                            )}
                                        </a>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* 2. 통나무 개수 버튼 */}
            {!powerState.isFocusMode && powerState.isPowerEnabled && (
                <div className={`toolbar_item__w9Z7l cqc-power-status-toolbar ${powerState.isFarming ? 'is-farming' : ''}`} ref={powerRef} onMouseEnter={handlePowerMouseEnter} onMouseLeave={handlePowerMouseLeave} style={{ display: 'flex', alignItems: 'center', marginRight: '8px', position: 'relative', cursor: 'pointer' }}>
                    <div className="cqc-power-toolbar-inner" style={{ display: 'flex', alignItems: 'center' }}>
                        {svgIcon}
                        <span className="cqc-power-count">
                            {`통나무 ${powerState.totalCount}개 `}
                            <span className={`cqc-power-status-text ${statusClass}`}>{statusText}</span>
                        </span>
                    </div>

                    {/* 통나무 획득 내역 툴팁 */}
                    {isTooltipOpen && (
                        <div className={`cqc-power-tooltip is-show ${isTooltipSticky ? 'is-sticky' : ''}`} style={{ pointerEvents: 'auto' }}>
                            <div className="cqc-power-tooltip-header">
                                <div className="cqc-power-tooltip-title">
                                    {isTooltipSticky ? '모든 채널 통나무 보유량' : '최근 획득 내역'}
                                </div>
                                {isTooltipSticky && (
                                    <button className="cqc-power-tooltip-close" onClick={handleCloseTooltip}>
                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M10.5 3.5L3.5 10.5M3.5 3.5L10.5 10.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
                                        </svg>
                                    </button>
                                )}
                            </div>
                            <div className="cqc-power-list">
                                {officialAmount !== null && !isTooltipSticky && (
                                    <>
                                        <div className="cqc-power-item official-balance">
                                            <div className="cqc-power-item-info">
                                                <div className="cqc-power-item-name" style={{ color: '#00ffa3' }}>현재 방송국 공식 보유 통나무</div>
                                                <div className="cqc-power-item-time">치지직 연동 데이터</div>
                                            </div>
                                            <div className="cqc-power-item-count">{officialAmount}</div>
                                        </div>
                                        <div style={{ height: '1px', background: 'rgba(255,255,255,0.04)', margin: '4px 0 8px 0' }} />
                                    </>
                                )}

                                {isTooltipLoading && (
                                    <div className="cqc-skeleton-item" style={{ padding: '10px' }}>
                                        <div className="cqc-skeleton cqc-skeleton-avatar"></div>
                                        <div className="cqc-skeleton-texts">
                                            <div className="cqc-skeleton cqc-skeleton-text"></div>
                                            <div className="cqc-skeleton cqc-skeleton-text short"></div>
                                        </div>
                                    </div>
                                )}

                                {!isTooltipLoading && tooltipItems.length === 0 && (
                                    <div style={{ textAlign: 'center', padding: '20px', color: '#888', fontSize: '12px' }}>
                                        보유 중인 통나무가 없습니다.
                                    </div>
                                )}

                                {!isTooltipLoading && tooltipItems.map((item, idx) => {
                                    const channelUrl = item.channelId && item.channelId !== 'unknown' ? `/live/${item.channelId}` : '#';
                                    return (
                                        <a key={item.channelId || idx} href={channelUrl} className="cqc-power-item" target={channelUrl !== '#' ? '_blank' : undefined} rel="noreferrer" onClick={(e) => channelUrl === '#' && e.preventDefault()}>
                                            <img src={item.channelImageUrl || 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_v2.png'} className="cqc-power-item-img" referrerPolicy="no-referrer" loading="lazy" onError={(e) => { e.currentTarget.src = 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_v2.png'; }} />
                                            <div className="cqc-power-item-info">
                                                <div className="cqc-power-item-name">{item.channelName}</div>
                                                <div className="cqc-power-item-time">
                                                    {isTooltipSticky ? `${item.count}개 보유 중` : formatRelTime(item.lastLogTs)}
                                                </div>
                                            </div>
                                            {!isTooltipSticky && <div className="cqc-power-item-count">{item.count}</div>}
                                        </a>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};
