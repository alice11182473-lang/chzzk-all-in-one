// @ts-nocheck
/**
 * ReactStateObserver — MutationObserver 대체 통합 React 상태 감시 시스템
 *
 * 관심사 분리:
 *   JotaiStoreWatcher    — Jotai Store의 Atom 구독(sub)
 *   ReactHookInterceptor — React useState/useReducer dispatch 가로채기
 *   DomPresencePoller     — MutationObserver 대신 경량 setInterval 폴링
 *   ReactStateObserver   — 위 3개를 통합 관리하는 Facade
 */
import { ConsoleLogger } from '../../utils/ConsoleLogger';
import { ReactFiberExplorer } from '../../utils/ReactFiberExplorer';

const MOD = 'StateObserver';

// ─── 공통 타입 ──────────────────────────────────────────────

export interface Unsubscribe {
  (): void;
}

export interface JotaiStore {
  get: (atom: any) => any;
  set: (atom: any, ...args: any[]) => any;
  sub: (atom: any, callback: () => void) => Unsubscribe;
  dev4_get_mounted_atoms?: () => Iterable<any>;
  dev4_get_internal_weak_map?: () => any;
}

export interface HookInterceptResult {
  hookIndex: number;
  element: HTMLElement;
  unintercept: Unsubscribe;
}

export interface PollerHandle {
  id: string;
  stop: Unsubscribe;
}

// ─── 1. JotaiStoreWatcher ───────────────────────────────────

export class JotaiStoreWatcher {
  private store: JotaiStore | null = null;
  private subscriptions = new Map<string, Unsubscribe>();
  private storeSource: string = 'unknown';

  /** Fiber 트리를 상위로 탐색하여 Jotai Store를 획득 */
  findStore(startElement: HTMLElement): JotaiStore | null {
    const fiber = ReactFiberExplorer.getFiberNode(startElement);
    if (!fiber) {
      ConsoleLogger.log('warn', MOD, '[JotaiWatcher] React Fiber를 찾을 수 없습니다', { element: startElement.tagName });
      return null;
    }

    const visited = new Set<any>();
    let found: JotaiStore | null = null;

    const scan = (node: any) => {
      if (!node || visited.has(node) || found) return;
      visited.add(node);

      const fields = ['memoizedProps', 'memoizedState', 'pendingProps', 'updateQueue'];
      for (const f of fields) {
        try {
          const val = node[f];
          if (!val || typeof val !== 'object') continue;

          if (this.isJotaiStore(val)) { found = val; return; }
          if (val.value && this.isJotaiStore(val.value)) { found = val.value; return; }
          if (val.store && this.isJotaiStore(val.store)) { found = val.store; return; }
        } catch (e) { /* skip */ }
      }

      if (node.return) scan(node.return);
      if (node.child) scan(node.child);
      if (node.sibling) scan(node.sibling);
    };

    scan(fiber);

    if (found) {
      this.store = found;
      this.storeSource = startElement.className || startElement.id || startElement.tagName;
      const atomCount = this.getMountedAtomCount();
      ConsoleLogger.log('info', MOD, `[JotaiWatcher] Store 획득 성공 (소스: ${this.storeSource}, Atom: ${atomCount}개)`);
    } else {
      ConsoleLogger.log('warn', MOD, '[JotaiWatcher] Jotai Store를 찾지 못했습니다');
    }

    return found;
  }

  /** Jotai Store 시그니처 체크 */
  private isJotaiStore(obj: any): obj is JotaiStore {
    return typeof obj.get === 'function'
      && typeof obj.set === 'function'
      && typeof obj.sub === 'function';
  }

  /** 현재 Store 반환 */
  getStore(): JotaiStore | null {
    return this.store;
  }

  /** 마운트된 Atom 목록 반환 */
  getMountedAtoms(): any[] {
    if (!this.store) return [];
    if (typeof this.store.dev4_get_mounted_atoms === 'function') {
      return Array.from(this.store.dev4_get_mounted_atoms());
    }
    // Symbol 키로 내부 Map 접근 시도
    for (const key of Object.getOwnPropertySymbols(this.store)) {
      const value = (this.store as any)[key];
      if (value instanceof Map) {
        return Array.from(value.keys());
      }
    }
    return [];
  }

  private getMountedAtomCount(): number {
    try { return this.getMountedAtoms().length; } catch { return -1; }
  }

  /** 특정 Atom의 상태 변경 구독 */
  subscribe(label: string, atom: any, callback: (value: any) => void): Unsubscribe {
    if (!this.store) {
      ConsoleLogger.log('error', MOD, `[JotaiWatcher] Store 없이 subscribe 시도: ${label}`);
      return () => { };
    }

    // 기존 구독 해제
    this.subscriptions.get(label)?.();

    const unsub = this.store.sub(atom, () => {
      const value = this.store!.get(atom);
      ConsoleLogger.log('info', MOD, `[JotaiWatcher] Atom 변경 감지: "${label}"`, { value });
      callback(value);
    });

    this.subscriptions.set(label, unsub);
    const initialValue = this.store.get(atom);
    ConsoleLogger.log('info', MOD, `[JotaiWatcher] 구독 등록: "${label}" (초기값 타입: ${typeof initialValue})`);

    return () => {
      unsub();
      this.subscriptions.delete(label);
      ConsoleLogger.log('info', MOD, `[JotaiWatcher] 구독 해제: "${label}"`);
    };
  }

  /** 특정 조건에 맞는 Atom을 자동 탐색하여 구독 */
  subscribeByFilter(
    label: string,
    filter: (atom: any, value: any) => boolean,
    callback: (value: any, atom: any) => void
  ): Unsubscribe[] {
    const atoms = this.getMountedAtoms();
    const unsubs: Unsubscribe[] = [];

    atoms.forEach((atom, idx) => {
      try {
        const val = this.store!.get(atom);
        if (filter(atom, val)) {
          const atomLabel = `${label}[${idx}]`;
          unsubs.push(this.subscribe(atomLabel, atom, (v) => callback(v, atom)));
        }
      } catch (e) { /* skip */ }
    });

    ConsoleLogger.log('info', MOD, `[JotaiWatcher] 필터 구독 "${label}": ${unsubs.length}개 Atom 매칭됨`);
    return unsubs;
  }

  /** 모든 구독 해제 */
  cleanup() {
    const count = this.subscriptions.size;
    this.subscriptions.forEach(unsub => unsub());
    this.subscriptions.clear();
    ConsoleLogger.log('info', MOD, `[JotaiWatcher] 정리 완료 (해제된 구독: ${count}개)`);
  }
}

// ─── 2. ReactHookInterceptor ────────────────────────────────

export class ReactHookInterceptor {
  private interceptors = new Map<string, HookInterceptResult>();

  /**
   * 특정 DOM 요소의 React Hook Chain에서 조건에 맞는 State Hook의 dispatch를 가로챔.
   *
   * @param label        - 로그 식별 라벨
   * @param element      - 탐색 시작 DOM 요소
   * @param stateMatcher - hook.memoizedState 가 원하는 state인지 판별하는 함수
   * @param interceptor  - dispatch 호출 시 실행할 인터셉터 (true 반환 시 원본 dispatch 실행 차단)
   */
  intercept(
    label: string,
    element: HTMLElement,
    stateMatcher: (state: any) => boolean,
    interceptor: (action: any, hookState: any, hookNode: any) => { action: any; blocked?: boolean } | void
  ): HookInterceptResult | null {
    // 이미 동일한 엘리먼트에 인터셉터가 부착되어 있다면 스킵
    const existing = this.interceptors.get(label);
    if (existing && existing.element === element) {
      return existing;
    }

    const fiber = ReactFiberExplorer.getFiberNode(element);
    if (!fiber) {
      ConsoleLogger.log('warn', MOD, `[HookInterceptor] Fiber 없음: "${label}"`);
      return null;
    }

    const interceptedHooks: Array<{ hook: any; originalDispatch: Function }> = [];
    const indices: number[] = [];

    let curr = fiber;
    while (curr) {
      let hook = curr.memoizedState;
      let hookIdx = 0;

      while (hook && hookIdx < 50) {
        const state = hook.memoizedState;
        if (stateMatcher(state)) {
          if (hook.queue && typeof hook.queue.dispatch === 'function' && !hook.queue.dispatch._cqcIntercepted) {
            const originalDispatch = hook.queue.dispatch;
            const capturedHook = hook;

            hook.queue.dispatch = function (action: any) {
              const res = interceptor(action, capturedHook.memoizedState, capturedHook);
              if (res && res.blocked === true) {
                ConsoleLogger.log('info', MOD, `[HookInterceptor] "${label}" dispatch 차단됨`);
                return;
              }
              const finalAction = res ? res.action : action;
              return originalDispatch.call(this, finalAction);
            };
            hook.queue.dispatch._cqcIntercepted = true;

            interceptedHooks.push({ hook: capturedHook, originalDispatch });
            indices.push(hookIdx);
          }
        }
        hook = hook.next;
        hookIdx++;
      }
      curr = curr.return;
    }

    if (interceptedHooks.length > 0) {
      const result: HookInterceptResult = {
        hookIndex: indices[0],
        element: element,
        hooks: interceptedHooks.map(ih => ih.hook),
        unintercept: () => {
          interceptedHooks.forEach(({ hook, originalDispatch }) => {
            if (hook.queue) {
              hook.queue.dispatch = originalDispatch;
              delete originalDispatch._cqcIntercepted;
            }
          });
          this.interceptors.delete(label);
          ConsoleLogger.log('info', MOD, `[HookInterceptor] "${label}" 해제 완료 (개수: ${interceptedHooks.length})`);
        }
      };

      // 기존 인터셉터 해제 (다른 엘리먼트일 경우)
      this.interceptors.get(label)?.unintercept();
      this.interceptors.set(label, result);

      ConsoleLogger.log('info', MOD, `[HookInterceptor] "${label}" 부착 성공 (Hook Idxs: ${indices.join(', ')})`);
      return result;
    }

    ConsoleLogger.log('warn', MOD, `[HookInterceptor] "${label}" 매칭되는 Hook을 찾지 못함`);
    return null;
  }

  /** 특정 인터셉터 해제 */
  unintercept(label: string) {
    this.interceptors.get(label)?.unintercept();
  }

  /** 인터셉터 활성 여부 확인 */
  isActive(label: string): boolean {
    return this.interceptors.has(label);
  }

  /** 모든 인터셉터 해제 */
  cleanup() {
    const count = this.interceptors.size;
    this.interceptors.forEach(r => r.unintercept());
    this.interceptors.clear();
    ConsoleLogger.log('info', MOD, `[HookInterceptor] 정리 완료 (해제: ${count}개)`);
  }
}

// ─── 3. DomPresencePoller ───────────────────────────────────

export class DomPresencePoller {
  private pollers = new Map<string, PollerHandle>();

  /**
   * 특정 셀렉터의 DOM 요소가 존재하면 콜백 실행, 이후 제거.
   * MutationObserver 대신 setInterval 기반 경량 폴링.
   */
  waitFor(
    label: string,
    selector: string,
    callback: (element: HTMLElement) => void,
    options: { interval?: number; timeout?: number; persistent?: boolean } = {}
  ): PollerHandle {
    const { interval = 500, timeout = 15000, persistent = false } = options;

    // 기존 폴러 정지
    this.pollers.get(label)?.stop();

    const startTime = Date.now();
    let found = false;
    let lastEl: HTMLElement | null = null;

    const timerId = setInterval(() => {
      const el = document.querySelector(selector) as HTMLElement | null;

      if (el) {
        if (el !== lastEl) {
          lastEl = el;
          if (!found) {
            found = true;
            //ConsoleLogger.log('info', MOD, `[Poller] "${label}" 대상 발견: ${selector} (${Date.now() - startTime}ms)`);
          }
          callback(el);
        }
        if (!persistent) {
          clearInterval(timerId);
          this.pollers.delete(label);
        }
      } else {
        lastEl = null;
        found = false;
        if (!persistent && Date.now() - startTime > timeout) {
          clearInterval(timerId);
          this.pollers.delete(label);
          //ConsoleLogger.log('warn', MOD, `[Poller] "${label}" 타임아웃 (${timeout}ms): ${selector}`);
        }
      }
    }, interval);

    const handle: PollerHandle = {
      id: label,
      stop: () => {
        clearInterval(timerId);
        this.pollers.delete(label);
        //ConsoleLogger.log('info', MOD, `[Poller] "${label}" 중지됨`);
      }
    };

    this.pollers.set(label, handle);
    //ConsoleLogger.log('info', MOD, `[Poller] "${label}" 시작 (selector: ${selector}, interval: ${interval}ms, persistent: ${persistent})`);
    return handle;
  }

  /** 특정 폴러 중지 */
  stop(label: string) {
    this.pollers.get(label)?.stop();
  }

  /** 모든 폴러 중지 */
  cleanup() {
    const count = this.pollers.size;
    this.pollers.forEach(p => p.stop());
    this.pollers.clear();
    //ConsoleLogger.log('info', MOD, `[Poller] 정리 완료 (중지: ${count}개)`);
  }
}

// ─── 4. ReactStateObserver (Facade) ─────────────────────────

export class ReactStateObserver {
  readonly jotai = new JotaiStoreWatcher();
  readonly hooks = new ReactHookInterceptor();
  readonly poller = new DomPresencePoller();

  private _mounted = false;

  get isMounted() { return this._mounted; }

  mount() {
    if (this._mounted) return;
    this._mounted = true;
    //ConsoleLogger.log('info', MOD, '=== ReactStateObserver 마운트 완료 ===');
  }

  cleanup() {
    this.jotai.cleanup();
    this.hooks.cleanup();
    this.poller.cleanup();
    this._mounted = false;
    //ConsoleLogger.log('info', MOD, '=== ReactStateObserver 정리 완료 ===');
  }

  /** 활성 상태 요약 로그 출력 */
  logStatus() {
    const jotaiStore = this.jotai.getStore();
    ConsoleLogger.log('groupCollapsed', MOD, '[상태 요약]', {
      mounted: this._mounted,
      jotaiStore: jotaiStore ? '연결됨' : '미연결',
      jotaiAtoms: jotaiStore ? this.jotai.getMountedAtoms().length : 0,
    });
  }
}
