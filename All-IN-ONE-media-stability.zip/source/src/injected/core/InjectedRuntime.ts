// @ts-nocheck
import { ConsoleLogger } from '../../../dom-utils';
import { ReactStateObserver } from './ReactStateObserver';

export interface InjectedModule {
  name: string;
  runtime?: InjectedRuntime;
  mount?(settings: any): void;
  cleanup?(): void;
  onMessage?(type: string, payload: any, id: number): boolean | Promise<boolean>;
}

export class InjectedRuntime {
  settings: any = null;
  state: any = {
    ready: false,
    core: null,
    root: null,
    gridBypassed: false,
    lastAppliedQuality: null,
    manualQualitySelection: false,
    currentTrack: null,
    isLowLatency: false,
    nativeLLActive: false,
    currentLatency: -1,
    absoluteLatency: -1,
    isQualityRestoring: false,
  };
  modules: InjectedModule[] = [];
  isMounted: boolean = false;
  messageListener: any = null;
  activeChatters: Map<string, string> = new Map();
  observer: ReactStateObserver = new ReactStateObserver();

  constructor() {
    this.messageListener = this.handleMessage.bind(this);
  }

  register(module: InjectedModule) {
    module.runtime = this;
    this.modules.push(module);
  }

  getModule(name: string): InjectedModule | undefined {
    return this.modules.find(m => m.name === name);
  }

  post(type: string, payload?: any) {
    window.postMessage({ direction: 'CQC_TO_CONTENT', type, payload }, '*');
  }

  respond(id: number, payload: any) {
    window.postMessage({ direction: 'CQC_TO_CONTENT', type: 'RESPONSE', id, payload }, '*');
  }

  log(text: string, data?: any, level: 'info' | 'warn' | 'error' | 'group' | 'groupCollapsed' = 'info') {
    ConsoleLogger.log(level, 'Injected', text, data);
  }

  async handleMessage(e: MessageEvent) {
    if (e.source !== window || e.data?.direction !== 'CQC_TO_INJECTED') return;
    const { id, type, payload } = e.data;

    // 1. 공통 라이프사이클 관련 메시지 선처리
    if (type === 'INIT') {
      this.log('INIT 수신', payload, 'groupCollapsed');
      this.settings = payload ?? {};
      window.cqcChatCollectorActive = !!this.settings.chatCollectorEnabled;
      
      this.boot();
      this.respond(id, { ok: true });
      return;
    }

    if (type === 'SETTINGS_UPDATED') {
      this.log('설정 업데이트 수신', payload, 'groupCollapsed');
      this.settings = payload ?? {};
      window.cqcChatCollectorActive = !!this.settings.chatCollectorEnabled;

      // 모듈 전역 이벤트 분배
      this.modules.forEach(m => {
        if (typeof m.mount === 'function') m.mount(this.settings);
      });

      this.respond(id, { ok: true });
      return;
    }

    if (type === 'GLOBAL_CLEANUP') {
      this.log('GLOBAL_CLEANUP 수신: 인젝션 정리');
      this.cleanup();
      this.respond(id, { ok: true });
      return;
    }

    // 2. 모듈별 메시지 핸들러 위임
    for (const m of this.modules) {
      if (typeof m.onMessage === 'function') {
        try {
          const handled = await m.onMessage(type, payload, id);
          if (handled) return;
        } catch (err: any) {
          this.log(`모듈 ${m.name}에서 메시지 ${type} 처리 중 오류 발생`, err, 'error');
          this.respond(id, { error: err.message });
          return;
        }
      }
    }
  }

  boot() {
    if (!this.settings?.enabled) {
      this.log('boot 취소: 확장 기능이 비활성화 상태입니다.', null, 'warn');
      this.cleanup();
      return;
    }

    this.observer.mount();

    this.modules.forEach(m => {
      try {
        if (typeof m.mount === 'function') m.mount(this.settings);
      } catch (err) {
        console.error(`[InjectedRuntime] Mount error for ${m.name}:`, err);
      }
    });
  }

  cleanup() {
    this.observer.cleanup();

    this.modules.forEach(m => {
      try {
        if (typeof m.cleanup === 'function') m.cleanup();
      } catch (err) {
        console.error(`[InjectedRuntime] Cleanup error for ${m.name}:`, err);
      }
    });

    this.state.ready = false;
    this.state.core = null;
    this.state.root = null;
    this.activeChatters.clear();

    this.log('인젝션 런타임 클린업 완료.', null, 'info');
  }

  init() {
    window.addEventListener('message', this.messageListener);
  }

  destroy() {
    window.removeEventListener('message', this.messageListener);
  }
}

export const runtime = new InjectedRuntime();
