import { InjectedModule } from '../core/InjectedRuntime';
import { getReactProps } from '../../../dom-utils';

export class EmojiCopyPasteModule implements InjectedModule {
  name = 'EmojiCopyPasteModule';
  runtime: any;
  settings: any;
  enabled = false;

  private CACHE_KEY = 'chzzk-emoji-url-cache';
  private TOKEN_RE = /(\{:[A-Za-z0-9_-]+:\})/g;
  private TOKEN_EXACT_RE = /^\{:([A-Za-z0-9_-]+):\}$/;

  private emojiUrlCache: Record<string, string> = {};
  private channelCache: Record<string, Set<string>> = {};
  private urlIdToEmojiIdMap: Record<string, string> = {};

  private copyHandler = this.onCopy.bind(this);
  private pasteHandler = this.onPaste.bind(this);
  private clickHandler = this.onClick.bind(this);
  private keydownHandler = this.onKeyDown.bind(this);

  mount(settings: any) {
    this.updateSettings(settings);
  }

  updateSettings(settings: any) {
    this.settings = settings;
    const shouldEnable = !!settings.chatEmojiCopyPasteEnabled || !!settings.chatMessageCopyEnabled;
    if (shouldEnable === this.enabled) return;
    if (shouldEnable) this.enable();
    else this.disable();
  }

  onSettingsUpdate(newSettings: any) {
    this.updateSettings(newSettings);
  }

  cleanup() {
    this.disable();
  }

  private enable() {
    this.enabled = true;
    try {
      this.emojiUrlCache = JSON.parse(localStorage.getItem(this.CACHE_KEY) || '{}') || {};
    } catch {
      this.emojiUrlCache = {};
    }
    this.syncWorkingEmoticon();

    document.addEventListener('copy', this.copyHandler, true);
    document.addEventListener('paste', this.pasteHandler, true);
    document.addEventListener('click', this.clickHandler, true);
    document.addEventListener('keydown', this.keydownHandler, true);
  }

  private disable() {
    this.enabled = false;
    document.removeEventListener('copy', this.copyHandler, true);
    document.removeEventListener('paste', this.pasteHandler, true);
    document.removeEventListener('click', this.clickHandler, true);
    document.removeEventListener('keydown', this.keydownHandler, true);
  }

  private syncWorkingEmoticon() {
    const winAny = window as any;
    if (winAny.__workingEmoticon && typeof winAny.__workingEmoticon === 'object') {
      // Clear properties in __workingEmoticon that are no longer in this.emojiUrlCache
      for (const key in winAny.__workingEmoticon) {
        if (!this.emojiUrlCache[key]) {
          delete winAny.__workingEmoticon[key];
        }
      }
      Object.assign(winAny.__workingEmoticon, this.emojiUrlCache);
    } else {
      winAny.__workingEmoticon = this.emojiUrlCache;
    }
  }

  private cacheEmoji(id: string, src: string) {
    if (!id || !src || this.emojiUrlCache[id] === src) return;
    this.emojiUrlCache[id] = src;
    try {
      localStorage.setItem(this.CACHE_KEY, JSON.stringify(this.emojiUrlCache));
    } catch { }
    this.syncWorkingEmoticon();
  }

  private invalidateEmoji(emojiId: string) {
    delete this.emojiUrlCache[emojiId];
    try {
      localStorage.setItem(this.CACHE_KEY, JSON.stringify(this.emojiUrlCache));
    } catch { }
    this.syncWorkingEmoticon();
  }

  private getEmojiId(src: string) {
    if (!src) return null;
    const cleanUrl = src.split(/[?#]/)[0];
    
    const basicMatch = cleanUrl.match(/\/nng\/glive\/icon\/(.+?)\.[a-z]+$/i);
    if (basicMatch) return basicMatch[1].replace(/\//g, '_');
    
    const filename = cleanUrl.split('/').pop()?.split('.')[0];
    if (!filename) return null;
    
    const tsMatch = filename.match(/^(.+?)_\d+$/);
    return tsMatch ? tsMatch[1] : filename;
  }

  private async getUnlockedEmojis(channelId: string) {
    if (!channelId) return new Set<string>();
    if (this.channelCache[channelId]) return this.channelCache[channelId];
    
    try {
      const res = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${channelId}/emoji-packs`, { credentials: 'include' });
      const data = await res.json();
      const unlocked = new Set<string>();
      
      const isGlobalLocked = data?.content?.emojiPackLocked ?? true;

      // 구독자 이모티콘 오류 수정: pack.emojiPackLocked 속성을 최우선 확인. 없으면 전역 잠금 상태 참조
      const processPacks = (packs: any[]) => {
        if (!Array.isArray(packs)) return;
        packs.forEach(pack => {
          const isLocked = pack.emojiPackLocked ?? pack.locked ?? isGlobalLocked;
          if (!isLocked) {
            const addEmoji = (e: any) => {
              if (!e.emojiId) return;
              const emojiIdStr = String(e.emojiId);
              unlocked.add(emojiIdStr);
              const urlId = this.getEmojiId(e.imageUrl || e.emojiUrl);
              if (urlId) {
                unlocked.add(urlId);
                this.urlIdToEmojiIdMap[urlId] = emojiIdStr;
              }
            };
            if (pack.emojis) pack.emojis.forEach(addEmoji);
            if (pack.tier1Emojis) pack.tier1Emojis.forEach(addEmoji);
            if (!pack.emojiTier2Locked && pack.tier2Emojis) pack.tier2Emojis.forEach(addEmoji);
          }
        });
      };

      processPacks(data?.content?.subscriptionEmojiPacks);
      processPacks(data?.content?.emojiPacks);

      this.channelCache[channelId] = unlocked;
      return unlocked;
    } catch (e) {
      console.error('[CQC] Failed to fetch emoji permission', e);
      return new Set<string>();
    }
  }

  private async checkEmojiPermission(emojiId: string, url: string): Promise<boolean> {
    if (!url || !url.includes('/subscription/')) return true;

    const subMatch = url.match(/\/subscription\/emoji\/([a-zA-Z0-9_]+)\//i);
    if (subMatch) {
      const sourceChannelId = subMatch[1];
      const unlocked = await this.getUnlockedEmojis(sourceChannelId);
      if (unlocked.has(String(emojiId))) return true;
    }

    const currentMatch = window.location.pathname.match(/\/(?:live|video)\/([a-zA-Z0-9_]+)/);
    if (currentMatch) {
      const unlocked = await this.getUnlockedEmojis(currentMatch[1]);
      if (unlocked.has(String(emojiId))) return true;
    }

    return false;
  }

  private isInsideChatMessageText(img: Element) {
    let current: Element | null = img;
    while (current) {
      const reactKey = Object.keys(current).find(k => k.startsWith('__reactProps$'));
      if (reactKey) {
        const props = (current as any)[reactKey];
        if (props?.className && typeof props.className === 'string' && props.className.includes('_text_')) {
          return true;
        }
      }
      if (current.className && typeof current.className === 'string' && current.className.includes('_text_')) {
        return true;
      }
      current = current.parentElement;
    }
    return false;
  }

  private showTooltip(targetElement: Element, text: string, isError: boolean = false) {
    const rect = targetElement.getBoundingClientRect();
    const tooltip = document.createElement('div');
    const textNode = document.createElement('span');
    
    textNode.textContent = text;
    textNode.style.position = 'relative';
    textNode.style.zIndex = '1';
    tooltip.appendChild(textNode);

    const bg = isError ? 'rgba(200, 30, 30, 0.6)' : 'rgba(30, 30, 30, 0.4)';
    const borderColor = isError ? 'rgba(255, 100, 100, 0.3)' : 'rgba(255, 255, 255, 0.2)';

    tooltip.style.cssText = `
      position: fixed; background: ${bg}; backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
      border: 1px solid ${borderColor}; box-shadow: ${isError ? '0 4px 12px rgba(220, 50, 50, 0.3)' : '0 4px 12px rgba(0, 0, 0, 0.15)'};
      color: #fff; padding: 6px 10px; border-radius: 8px; font-size: 12px; font-weight: 500;
      z-index: 999999; pointer-events: none; transition: all 0.2s cubic-bezier(0.25, 0.8, 0.25, 1);
      opacity: 0; transform: translate(-50%, 10px);
    `;

    if (isError && !document.getElementById('cqc-shake-style')) {
      const style = document.createElement('style');
      style.id = 'cqc-shake-style';
      style.textContent = `
        @keyframes cqc-shake {
          0%, 100% { transform: translate(-50%, 0); }
          15%, 45%, 75% { transform: translate(calc(-50% - 4px), 0); }
          30%, 60%, 90% { transform: translate(calc(-50% + 4px), 0); }
        }
      `;
      document.head.appendChild(style);
    }

    const tail = document.createElement('div');
    tail.style.cssText = `
      position: absolute; bottom: -5px; left: 50%; transform: translateX(-50%) rotate(45deg);
      width: 8px; height: 8px; z-index: 0;
      background: ${isError ? 'linear-gradient(135deg, transparent 50%, rgba(200, 30, 30, 0.8) 100%)' : 'linear-gradient(135deg, transparent 50%, rgba(60, 60, 60, 0.7) 100%)'};
      border-right: 1px solid ${borderColor}; border-bottom: 1px solid ${borderColor};
    `;
    tooltip.appendChild(tail);
    document.body.appendChild(tooltip);

    const tooltipRect = tooltip.getBoundingClientRect();
    tooltip.style.left = `${rect.left + rect.width / 2}px`;
    tooltip.style.top = `${rect.top - tooltipRect.height - 8}px`;

    tooltip.offsetHeight; // trigger reflow
    tooltip.style.opacity = '1';
    tooltip.style.animation = isError ? 'cqc-shake 0.4s cubic-bezier(.36,.07,.19,.97) both' : 'none';
    tooltip.style.transform = isError ? 'translate(-50%, 10px)' : 'translate(-50%, 0)';

    setTimeout(() => {
      tooltip.style.animation = 'none';
      tooltip.style.opacity = '0';
      tooltip.style.transform = 'translate(-50%, -10px)';
      setTimeout(() => tooltip.remove(), 200);
    }, 1200);
  }

  private checkEmojiPermissionSync(emojiId: string, url: string): boolean | undefined {
    if (!url || !url.includes('/subscription/')) return true;

    const subMatch = url.match(/\/subscription\/emoji\/([a-zA-Z0-9_]+)\//i);
    const currentMatch = window.location.pathname.match(/\/(?:live|video)\/([a-zA-Z0-9_]+)/);

    const sourceChannelId = subMatch ? subMatch[1] : null;
    const currentChannelId = currentMatch ? currentMatch[1] : null;

    const sourceUnlocked = sourceChannelId ? this.channelCache[sourceChannelId] : null;
    const currentUnlocked = currentChannelId ? this.channelCache[currentChannelId] : null;

    if (sourceUnlocked && sourceUnlocked.has(String(emojiId))) return true;
    if (currentUnlocked && currentUnlocked.has(String(emojiId))) return true;

    const hasSourceCache = !sourceChannelId || !!this.channelCache[sourceChannelId];
    const hasCurrentCache = !currentChannelId || !!this.channelCache[currentChannelId];

    if (hasSourceCache && hasCurrentCache) {
      return false;
    }

    return undefined;
  }

  private onCopy(e: ClipboardEvent) {
    if (!e.isTrusted) return;
    const sel = document.getSelection();
    if (!sel || sel.isCollapsed) return;

    const range = sel.getRangeAt(0);
    const container = range.commonAncestorContainer;
    const parent = container.nodeType === 3 ? container.parentElement : (container as Element);
    
    if (!parent) return;

    let showedTooltip = false;
    const imgs = parent.querySelectorAll?.('img') || [];
    imgs.forEach(img => {
      if (this.isInsideChatMessageText(img) && range.intersectsNode(img)) {
        const urlId = this.getEmojiId(img.src);
        if (urlId) {
          const hasPerm = this.checkEmojiPermissionSync(urlId, img.src);
          if (hasPerm === true || hasPerm === undefined) {
            let emojiId = null;
            if (img.alt) {
              const match = img.alt.match(/^\{:([A-Za-z0-9_-]+):\}$/);
              if (match) emojiId = match[1];
            }
            if (!emojiId) {
              emojiId = this.urlIdToEmojiIdMap[urlId] || urlId;
            }
            img.alt = `{:${emojiId}:}`;
            this.cacheEmoji(emojiId, img.src);
            
            if (hasPerm === undefined) {
              const subMatch = img.src.match(/\/subscription\/emoji\/([a-zA-Z0-9_]+)\//i);
              if (subMatch) {
                this.getUnlockedEmojis(subMatch[1]).catch(() => {});
              }
              const currentMatch = window.location.pathname.match(/\/(?:live|video)\/([a-zA-Z0-9_]+)/);
              if (currentMatch) {
                this.getUnlockedEmojis(currentMatch[1]).catch(() => {});
              }
            }
          } else {
            let emojiId = null;
            if (img.alt) {
              const match = img.alt.match(/^\{:([A-Za-z0-9_-]+):\}$/);
              if (match) emojiId = match[1];
            }
            img.alt = '';
            this.invalidateEmoji(urlId);
            if (emojiId) this.invalidateEmoji(emojiId);
            if (!showedTooltip) {
              this.showTooltip(img, '구독자 전용입니다', true);
              showedTooltip = true;
            }
          }
        }
      }
    });
  }

  private onPaste(e: ClipboardEvent) {
    if (!e.isTrusted) return;
    const target = e.target as HTMLElement;
    
    const isInput = target instanceof HTMLTextAreaElement || target instanceof HTMLInputElement;
    const isContentEditable = target.isContentEditable;
    
    if (!isInput && !isContentEditable) return;

    const clipText = e.clipboardData?.getData('text/plain');
    if (!clipText || !this.TOKEN_RE.test(clipText)) return;

    const tokens = clipText.match(this.TOKEN_RE) || [];
    const hasKnownEmoji = tokens.some(t => {
      const match = t.match(this.TOKEN_EXACT_RE);
      return match && this.emojiUrlCache[match[1]];
    });

    if (!hasKnownEmoji) return;

    e.preventDefault();
    e.stopPropagation();

    this.syncWorkingEmoticon();

    let showedTooltip = false;

    if (isInput) {
      const textarea = target as HTMLTextAreaElement;
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || start;
      const text = textarea.value;

      tokens.forEach(token => {
        const match = token.match(this.TOKEN_EXACT_RE);
        if (match) {
          const emojiId = match[1];
          const url = this.emojiUrlCache[emojiId];
          if (url) {
            const hasPerm = this.checkEmojiPermissionSync(emojiId, url);
            if (hasPerm === false) {
              this.invalidateEmoji(emojiId);
              if (!showedTooltip) {
                this.showTooltip(target, '구독자 전용입니다', true);
                showedTooltip = true;
              }
            } else if (hasPerm === undefined) {
              const subMatch = url.match(/\/subscription\/emoji\/([a-zA-Z0-9_]+)\//i);
              if (subMatch) {
                this.getUnlockedEmojis(subMatch[1]).catch(() => {});
              }
            }
          }
        }
      });

      const newText = text.substring(0, start) + clipText + text.substring(end);

      const nativeSetter = Object.getOwnPropertyDescriptor(
        Object.getPrototypeOf(textarea), "value"
      )?.set;
      
      if (nativeSetter) {
        nativeSetter.call(textarea, newText);
      } else {
        textarea.value = newText;
      }
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      const newPos = start + clipText.length;
      textarea.setSelectionRange(newPos, newPos);
    } else if (isContentEditable) {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      
      const range = sel.getRangeAt(0);
      range.deleteContents();

      const frag = document.createDocumentFragment();
      const parts = clipText.split(this.TOKEN_RE);
      
      parts.forEach(part => {
        const idMatch = part.match(this.TOKEN_EXACT_RE);
        if (idMatch) {
          const emojiId = idMatch[1];
          const url = this.emojiUrlCache[emojiId];
          let hasPerm = false;
          
          if (url) {
            const permStatus = this.checkEmojiPermissionSync(emojiId, url);
            if (permStatus === true || permStatus === undefined) {
              hasPerm = true;
              if (permStatus === undefined) {
                const subMatch = url.match(/\/subscription\/emoji\/([a-zA-Z0-9_]+)\//i);
                if (subMatch) {
                  this.getUnlockedEmojis(subMatch[1]).catch(() => {});
                }
              }
            } else {
              this.invalidateEmoji(emojiId);
              if (!showedTooltip) {
                this.showTooltip(target, '구독자 전용입니다', true);
                showedTooltip = true;
              }
            }
          }
          
          if (hasPerm && url) {
            const img = document.createElement('img');
            img.src = url;
            img.alt = part;
            img.width = 24;
            img.height = 24;
            frag.appendChild(img);
          } else {
            frag.appendChild(document.createTextNode(part));
          }
        } else if (part) {
          frag.appendChild(document.createTextNode(part));
        }
      });

      const lastNode = frag.lastChild;
      if (!lastNode) return;

      range.insertNode(frag);
      
      range.setStartAfter(lastNode);
      range.setEndAfter(lastNode);
      sel.removeAllRanges();
      sel.addRange(range);

      target.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    }
  }

  private async pasteTextToInput(fullText: string) {
    const inputArea = document.querySelector('textarea, [contenteditable="true"], .cm-content') as HTMLElement;
    if (!inputArea) return;
    
    inputArea.focus();

    if (inputArea instanceof HTMLTextAreaElement || inputArea instanceof HTMLInputElement) {
      const currentVal = inputArea.value;
      const nativeSetter = Object.getOwnPropertyDescriptor(
        Object.getPrototypeOf(inputArea), "value"
      )?.set;
      const newVal = currentVal ? currentVal + ' ' + fullText : fullText;
      if (nativeSetter) {
        nativeSetter.call(inputArea, newVal);
      } else {
        inputArea.value = newVal;
      }
      inputArea.dispatchEvent(new Event('input', { bubbles: true }));
    } else if (inputArea.isContentEditable) {
      const sel = window.getSelection();
      if (!sel || sel.rangeCount === 0) return;
      
      const range = sel.getRangeAt(0);
      range.deleteContents();

      const frag = document.createDocumentFragment();
      const parts = (fullText + ' ').split(this.TOKEN_RE);
      
      parts.forEach(part => {
        const idMatch = part.match(this.TOKEN_EXACT_RE);
        if (idMatch) {
          const emojiId = idMatch[1];
          const url = this.emojiUrlCache[emojiId];
          
          if (url) {
            const img = document.createElement('img');
            img.src = url;
            img.alt = part;
            img.width = 24;
            img.height = 24;
            frag.appendChild(img);
          } else {
            frag.appendChild(document.createTextNode(part));
          }
        } else if (part) {
          frag.appendChild(document.createTextNode(part));
        }
      });

      const lastNode = frag.lastChild;
      if (!lastNode) return;

      range.insertNode(frag);
      
      range.setStartAfter(lastNode);
      range.setEndAfter(lastNode);
      sel.removeAllRanges();
      sel.addRange(range);

      inputArea.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    }
  }

  private async onClick(e: MouseEvent) {
    if (!e.isTrusted) return;
    const target = e.target as HTMLElement;
    const imgEl = target instanceof HTMLImageElement ? target : target.closest('button')?.querySelector('img');
    
    if (!imgEl || !this.isInsideChatMessageText(imgEl)) {
      if (this.settings?.chatMessageCopyEnabled) {
        const msgItem = target.closest('[class*="_item_"]') as HTMLElement;
        if (msgItem) {
           const props = getReactProps(msgItem);
           let fullText = '';

           if (props?.children?.props?.chatMessage?.originalContent) {
             fullText = props.children.props.chatMessage.originalContent;
           } else if (props?.children?.props?.chatMessage?.content) {
             fullText = props.children.props.chatMessage.content;
           }

           if (!fullText) return;

           const imgs = Array.from(msgItem.querySelectorAll('img'));
           for (const emojiImg of imgs) {
             if (!this.isInsideChatMessageText(emojiImg)) continue;
             const urlId = this.getEmojiId(emojiImg.src);
             if (!urlId) continue;

             const syncPerm = this.checkEmojiPermissionSync(urlId, emojiImg.src);
             if (syncPerm === false) {
               this.showTooltip(target, '구독자 전용 이모티콘이 포함되어 있습니다', true);
               return;
             }
             if (syncPerm === undefined) {
               const hasPermission = await this.checkEmojiPermission(urlId, emojiImg.src);
               if (!hasPermission) {
                 this.showTooltip(target, '구독자 전용 이모티콘이 포함되어 있습니다', true);
                 return;
               }
             }

             let emojiId = null;
             if (emojiImg.alt) {
               const match = emojiImg.alt.match(/^\{:([A-Za-z0-9_-]+):\}$/);
               if (match) emojiId = match[1];
             }
             if (!emojiId) {
               emojiId = this.urlIdToEmojiIdMap[urlId] || urlId;
             }
             this.cacheEmoji(emojiId, emojiImg.src);
           }

           fullText = fullText.replace(/(\{:[A-Za-z0-9_-]+:\})/g, ' $1 ').replace(/\s+/g, ' ').trim();

           try {
             await navigator.clipboard.writeText(fullText);
             this.showTooltip(target, '메시지 복사 완료');
             this.pasteTextToInput(fullText);
           } catch (err) {
             console.error(err);
           }
        }
      }
      return;
    }

    if (!this.settings?.chatEmojiCopyPasteEnabled) return;

    const urlId = this.getEmojiId(imgEl.src);
    if (!urlId) return;

    let emojiId = null;
    if (imgEl.alt) {
      const match = imgEl.alt.match(/^\{:([A-Za-z0-9_-]+):\}$/);
      if (match) emojiId = match[1];
    }
    if (!emojiId) {
      emojiId = this.urlIdToEmojiIdMap[urlId] || urlId;
    }

    const syncPerm = this.checkEmojiPermissionSync(urlId, imgEl.src);
    if (syncPerm === false) {
      this.showTooltip(imgEl, '구독자 전용입니다', true);
      this.invalidateEmoji(urlId);
      if (emojiId !== urlId) this.invalidateEmoji(emojiId);
      return;
    }

    if (syncPerm === true) {
      this.cacheEmoji(emojiId, imgEl.src);
      try {
        await navigator.clipboard.writeText(` {:${emojiId}:} `);
        this.showTooltip(imgEl, '복사되었습니다');
        if (this.settings?.chatMessageCopyEnabled) {
          this.pasteTextToInput(`{:${emojiId}:}`);
        }
      } catch (err) {
        console.error(err);
      }
      return;
    }

    const hasPermission = await this.checkEmojiPermission(urlId, imgEl.src);
    if (!hasPermission) {
      this.showTooltip(imgEl, '구독자 전용입니다', true);
      this.invalidateEmoji(urlId);
      if (emojiId !== urlId) this.invalidateEmoji(emojiId);
      return;
    }

    this.cacheEmoji(emojiId, imgEl.src);
    try {
      await navigator.clipboard.writeText(` {:${emojiId}:} `);
      this.showTooltip(imgEl, '복사되었습니다');
      if (this.settings?.chatMessageCopyEnabled) {
        this.pasteTextToInput(`{:${emojiId}:}`);
      }
    } catch (err) {
      console.error(err);
      this.showTooltip(imgEl, '복사 실패 (다시 클릭해주세요)', true);
    }
  }

  private onKeyDown(e: KeyboardEvent) {
    if (!e.isTrusted || e.key !== 'Tab') return;
    if (e.shiftKey || e.ctrlKey || e.altKey || e.metaKey) return;

    const textarea = e.target;
    if (!(textarea instanceof HTMLTextAreaElement || textarea instanceof HTMLInputElement)) return;

    const text = textarea.value;
    const pos = textarea.selectionStart ?? 0;
    const beforeText = text.substring(0, pos);
    const lastWordMatch = beforeText.match(/([^\s]+)\s*$/);
    
    if (!lastWordMatch) return;
    const lastWord = lastWordMatch[1];

    if (/^\{:[A-Za-z0-9_-]+:\}$/.test(lastWord) || /[\p{Emoji_Presentation}\p{Extended_Pictographic}]/u.test(lastWord)) {
      e.preventDefault();
      e.stopPropagation();

      const insertStr = ' ' + lastWord;
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || start;
      const newText = text.substring(0, start) + insertStr + text.substring(end);

      const nativeSetter = Object.getOwnPropertyDescriptor(
        textarea instanceof HTMLTextAreaElement ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype,
        "value"
      )?.set;
      
      if (nativeSetter) nativeSetter.call(textarea, newText);
      else textarea.value = newText;
      
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      const newPos = start + insertStr.length;
      textarea.setSelectionRange(newPos, newPos);
    }
  }
}
