// @ts-nocheck
import { InjectedModule } from '../core/InjectedRuntime';
import { getFiberNode, getChannelData, SELECTORS } from '../../../dom-utils';
import { initSidebarHider, cleanupSidebarHider } from '../../modules/core/SidebarHider';

export class SidebarModule implements InjectedModule {
  name = 'SidebarModule';
  runtime: any;
  fastPoll: any = null;
  slowPoll: any = null;
  userCollapsed = false;

  mount(settings: any) {
    this.userCollapsed = false;
    initSidebarHider(settings);
    this.startSidebarExpandPoll();
  }

  cleanup() {
    cleanupSidebarHider();
    this.stopSidebarExpandPoll();
  }

  async onMessage(type: string, payload: any, id: number): Promise<boolean> {
    if (type === 'SET_USER_COLLAPSED') {
      this.userCollapsed = payload;
      this.runtime.respond(id, { ok: true });
      return true;
    }

    if (type === 'EXPAND_FOLLOWING') {
      this.expandSidebarFollowing();
      this.runtime.respond(id, { ok: true });
      return true;
    }

    if (type === 'GET_CHANNEL_DATA') {
      try {
        const { channelId } = payload;
        let el = document.querySelector(`li[data-channel-id="${channelId}"], a[href*="/live/${channelId}"], a[href*="/channel/${channelId}"], [data-channel-id="${channelId}"]`);

        if (el && !el.matches('li')) {
          const parent = el.closest('li') || el.parentElement;
          if (parent) el = parent;
        }

        if (!el) {
          this.runtime.respond(id, { error: 'Element not found', chId: channelId });
          return true;
        }

        const data = getChannelData(el as HTMLElement);
        if (!data) {
          this.runtime.respond(id, { error: 'Data not found', chId: channelId });
          return true;
        }
        this.runtime.respond(id, data);
      } catch (err: any) {
        console.error('[CQC:SidebarModule] GET_CHANNEL_DATA 오류:', err);
        this.runtime.respond(id, { error: err.message, chId: payload?.channelId });
      }
      return true;
    }

    return false;
  }

  startSidebarExpandPoll() {
    this.stopSidebarExpandPoll();
    this.expandSidebarFollowing();
    this.slowPoll = setInterval(() => this.expandSidebarFollowing(), 1000);
  }

  stopSidebarExpandPoll() {
    if (this.fastPoll) {
      clearInterval(this.fastPoll);
      this.fastPoll = null;
    }
    if (this.slowPoll) {
      clearInterval(this.slowPoll);
      this.slowPoll = null;
    }
  }

  expandSidebarFollowing() {
    if (!this.runtime.settings?.followingExpandEnabled || this.userCollapsed) return;

    try {
      const sidebar = document.querySelector('#sidebar');
      if (!sidebar) return;

      let followSection;
      const navSections = document.querySelectorAll(SELECTORS.SIDEBAR_NAV_SECTION);
      followSection = Array.from(navSections).find(nav => {
        const title = nav.querySelector(SELECTORS.SIDEBAR_NAV_TITLE);
        return nav.getClientRects().length > 0 && title && (title.textContent?.includes('팔로잉') || title.textContent?.includes('팔로우'));
      });

      if (!followSection) return;

      let fiber = getFiberNode(followSection as HTMLElement);
      let xatFiber = null;
      for (let i = 0; i < 15 && fiber; i++) {
        if (fiber.memoizedState && fiber.memoizedState.next && fiber.memoizedState.next.next) {
          xatFiber = fiber;
          break;
        }
        fiber = fiber.return;
      }
      if (!xatFiber) return;

      // Boolean Hook 감지 및 true 강제 고정 (새로고침 깜빡임 방지)
      let h = xatFiber.memoizedState;
      const self = this;
      while (h) {
        if (typeof h.memoizedState === 'boolean') {
          if (!h.__cqcPinned) {
            Object.defineProperty(h, 'memoizedState', {
              get() {
                return !self.userCollapsed;
              },
              set(v) {
                // setter 호출 시 무시
              },
              configurable: true,
              enumerable: true
            });
            h.__cqcPinned = true;
            self.runtime.log?.("[사이드바] Boolean Hook 고정 완료");
          }
        }
        h = h.next;
      }

      let hook = xatFiber.memoizedState;
      let arrayHooks = [];
      while (hook) {
        if (Array.isArray(hook.memoizedState)) {
          const firstItem = hook.memoizedState[0];
          if (firstItem && typeof firstItem === 'object' && ('channelId' in firstItem || 'channelName' in firstItem)) {
            arrayHooks.push(hook);
          }
        }
        hook = hook.next;
      }

      if (arrayHooks.length >= 2) {
        const E_hook = arrayHooks[0];
        const T_hook = arrayHooks[1];

        if (E_hook.memoizedState.length > T_hook.memoizedState.length) {
          this.runtime.log(`[사이드바] 팔로잉 확장: ${T_hook.memoizedState.length} -> ${E_hook.memoizedState.length}`);
          
          // React Reconciliation 충돌 방지를 위해 확장 직전에만 오프라인 가상 그룹 헤더 일시 제거
          const headers = document.querySelectorAll('.cqc-offline-group-header, [data-folder-id="cqc-offline-group"]');
          headers.forEach(el => el.remove());
          
          if (T_hook.queue && typeof T_hook.queue.dispatch === 'function') {
            T_hook.queue.dispatch(E_hook.memoizedState);
          }
        }
      }
    } catch (e) { }
  }
}
