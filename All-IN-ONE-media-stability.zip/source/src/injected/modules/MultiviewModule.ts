// @ts-nocheck
import { InjectedModule } from '../core/InjectedRuntime';
import { SELECTORS, triggerReact } from '../../../dom-utils';

export class MultiviewModule implements InjectedModule {
  name = 'MultiviewModule';
  runtime: any;

  clickListener = (e: MouseEvent) => {
    if (!document.body.classList.contains('cqc-is-mv-iframe')) return;

    const target = e.target as HTMLElement;
    const btn = target.closest('button[class*="viewmode-button"], .pzp-pc-viewmode-button, button[class*="viewmode"]');
    if (!btn) return;

    const label = btn.getAttribute('aria-label');
    const player = document.querySelector(SELECTORS.PLAYER);
    if (!player) return;

    const isActuallyWide = label === '기본 화면' || label === '좁은 화면' || label === '전체 화면 종료' ||
      player.classList.contains('pzp-pc-viewmode-wide') ||
      player.classList.contains('pzp-viewmode-wide');

    if (isActuallyWide && (label === '기본 화면' || label === '좁은 화면')) {
      this.runtime.log('[멀티뷰] 좁은 화면 클릭 차단');
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  };

  mount(settings: any) {
    this.initMultiviewGuard();
    this.hookNarrowViewBlock();
  }

  cleanup() {
    document.removeEventListener('click', this.clickListener, true);
  }

  initMultiviewGuard() {
    const urlParams = new URLSearchParams(window.location.search);
    if (!urlParams.has('mv_iframe')) return;

    this.runtime.log('멀티뷰 내비게이션 가드 활성화');
    const originalOpen = window.open;
    window.open = function (url, name, specs) {
      if (url && (url.includes('chzzk.naver.com/') || url.startsWith('/')) && !url.includes('/live/') && !url.includes('/video/')) {
        const activeEl = document.activeElement;
        if (activeEl && activeEl.closest('[class*="live_chatting_message_nickname"]')) {
          //console.log('[CQC:Injected] Blocked unintended navigation from nickname click:', url);
          return null;
        }
      }
      return originalOpen.apply(this, arguments as any);
    };

    /*
    // 멀티뷰 채팅 멈춤 방지 (visibilityState 속이기)
    Object.defineProperty(document, 'visibilityState', {
      get: () => 'visible',
    });
    Object.defineProperty(document, 'hidden', {
      get: () => false,
    });
    document.addEventListener('visibilitychange', (e) => {
      e.stopImmediatePropagation();
    }, true);
    */
  }

  hookNarrowViewBlock() {
    document.addEventListener('click', this.clickListener, true);
  }
}
