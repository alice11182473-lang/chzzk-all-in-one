import React from 'react';
import { createRoot, Root } from 'react-dom/client';

const RealTimeTooltipComponent: React.FC<{
  visible: boolean;
  x: number;
  y: number;
  text: string;
}> = ({ visible, x, y, text }) => {
  if (!visible) return null;

  return (
    <div
      style={{
        position: 'fixed',
        zIndex: 10000,
        background: 'rgba(0, 0, 0, 0.85)',
        color: '#fff',
        padding: '8px 12px',
        borderRadius: '4px',
        fontSize: '13px',
        pointerEvents: 'none',
        whiteSpace: 'nowrap',
        transform: 'translate(-50%, -100%)',
        marginTop: '-8px',
        left: x,
        top: y,
      }}
    >
      {text}
      <div
        style={{
          position: 'absolute',
          top: '100%',
          left: '50%',
          transform: 'translateX(-50%)',
          border: '5px solid transparent',
          borderTopColor: 'rgba(0, 0, 0, 0.85)',
        }}
      />
    </div>
  );
};

export class RealTimeTooltipModule {
  private static root: Root | null = null;
  private static container: HTMLElement | null = null;
  
  private static visible = false;
  private static x = 0;
  private static y = 0;
  private static text = '';

  private static render() {
    if (!this.root) return;
    this.root.render(
      <RealTimeTooltipComponent
        visible={this.visible}
        x={this.x}
        y={this.y}
        text={this.text}
      />
    );
  }

  public static init() {
    if (this.root) return;
    this.container = document.createElement('div');
    this.container.id = 'cqc-realtime-tooltip-container';
    document.body.appendChild(this.container);
    this.root = createRoot(this.container);
    this.render();
  }

  public static show(x: number, y: number, text: string) {
    this.visible = true;
    this.x = x;
    this.y = y;
    this.text = text;
    this.render();
  }

  public static hide() {
    if (!this.visible) return;
    this.visible = false;
    this.render();
  }

  public static destroy() {
    if (this.root) {
      this.root.unmount();
      this.root = null;
    }
    if (this.container) {
      this.container.remove();
      this.container = null;
    }
    this.visible = false;
  }
}
