import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { InjectedModule } from '../core/InjectedRuntime';
import { SELECTORS, getReactProps } from '../../../dom-utils';
import { CqcToolbarArea } from '../components/CqcToolbarArea';

export class ToolbarUiModule implements InjectedModule {
    name = 'ToolbarUiModule';
    runtime: any;
    private root: Root | null = null;
    private container: HTMLDivElement | null = null;
    private mountInterval: NodeJS.Timeout | null = null;
    private currentSettings: any = null;

    mount(settings: any) {
        this.currentSettings = settings;
        if (this.root) {
            try {
                this.root.render(<CqcToolbarArea settings={this.currentSettings} />);
            } catch (err) { }
        }
        this.initMountLoop();
    }

    cleanup() {
        if (this.mountInterval) {
            clearInterval(this.mountInterval);
            this.mountInterval = null;
        }
        this.unmountReact();
    }

    private initMountLoop() {
        // 이미 주입되어 있는지 우선 체크
        this.tryMount();

        // setInterval 폴링만 사용 (MutationObserver 제거)
        if (this.mountInterval) clearInterval(this.mountInterval);
        this.mountInterval = setInterval(() => {
            this.tryMount();
        }, 1000);
    }

    private tryMount() {
        if (!this.currentSettings?.enabled) return;

        let toolbarBox = null;
        let themeBtn = null;
        let profileBtn = null;

        toolbarBox = document.querySelector(SELECTORS.TOOLBAR_BOX as string);
        themeBtn = document.querySelector(SELECTORS.THEME_BTN as string);
        profileBtn = document.querySelector(SELECTORS.TOOLBAR_PROFILE_BTN as string);

        if (!toolbarBox) return;

        let container = document.getElementById('cqc-toolbar-react-root') as HTMLDivElement;
        const isNew = !container;

        if (isNew) {
            container = document.createElement('div');
            container.id = 'cqc-toolbar-react-root';
            container.style.display = 'flex';
            container.style.alignItems = 'center';
            this.container = container;
        }

        if (themeBtn) {
            themeBtn.classList.add('cqc-theme-btn-wrapper');
        }
        if (profileBtn) {
            profileBtn.classList.add('cqc-profile-btn-wrapper');
        }

        // 로그인 여부 체크 및 숨김/표시 처리
        const isLoggedIn = !!profileBtn;
        if (!isLoggedIn) {
            container.style.setProperty('display', 'none', 'important');
        } else {
            container.style.display = 'flex';
        }

        let targetInsertBefore: Element | null = null;
        if (themeBtn) {
            targetInsertBefore = themeBtn.closest(SELECTORS.TOOLBAR_ITEM as string) || themeBtn;
        } else if (profileBtn) {
            targetInsertBefore = profileBtn.closest(SELECTORS.TOOLBAR_ITEM as string) || profileBtn;
        }

        if (targetInsertBefore) {
            if (container.nextSibling !== targetInsertBefore) {
                targetInsertBefore.parentNode?.insertBefore(container, targetInsertBefore);
            }
        } else {
            if (container.parentElement !== toolbarBox) {
                toolbarBox.appendChild(container);
            }
        }

        if (isNew) {
            try {
                this.root = createRoot(container);
                this.root.render(<CqcToolbarArea settings={this.currentSettings} />);
                this.runtime.log('CqcToolbarArea React Mount 성공');
            } catch (err) {
                this.runtime.log('CqcToolbarArea React Mount 실패', err, 'error');
            }
        }
    }

    onSettingsUpdate(newSettings: any) {
        this.currentSettings = newSettings;
        if (this.root) {
            try {
                this.root.render(<CqcToolbarArea settings={this.currentSettings} />);
            } catch (err) {
                this.runtime.log('CqcToolbarArea React re-render 실패', err, 'error');
            }
        }
    }

    private unmountReact() {
        if (this.root) {
            try {
                this.root.unmount();
            } catch (err) { }
            this.root = null;
        }
        if (this.container) {
            this.container.remove();
            this.container = null;
        }
    }
}
