// @ts-nocheck
import { InjectedModule } from '../core/InjectedRuntime';
import { SELECTORS, REGEX, triggerReact, getFiberNode } from '../../../dom-utils';
import { RealTimeTooltipModule } from './RealTimeTooltipModule';

export class ShortcutModule implements InjectedModule {
  name = 'ShortcutModule';
  runtime: any;

  // 단축키용 리스너
  keydownListener = (e: KeyboardEvent) => {
    if ((e as any).isCqcFake) return;

    const target = e.target as HTMLElement;
    const tag = target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (target.isContentEditable) return;
    if (!this.hasPlayer()) return;

    const player = document.querySelector(SELECTORS.PLAYER);
    if (!player) return;

    // ArrowLeft/ArrowRight 직접 가로채기
    const eventKey = e.key;
    if (eventKey === 'ArrowLeft' || eventKey === 'ArrowRight') {
      if (e.ctrlKey || e.shiftKey || e.altKey || e.metaKey) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      const isBackward = eventKey === 'ArrowLeft';
      this.performSeek(isBackward);
      return;
    }

    const defaultShortcuts = {
      'wide_view': { key: 't', ctrl: false, shift: false, alt: false, meta: false },
      'fullscreen': { key: 'f', ctrl: false, shift: false, alt: false, meta: false },
      'backward': { key: '[', ctrl: false, shift: false, alt: false, meta: false },
      'forward': { key: ']', ctrl: false, shift: false, alt: false, meta: false },
      'chatCollector': { key: 'k', ctrl: true, shift: true, alt: false, meta: false }
    };
    const shortcuts = { ...defaultShortcuts, ...(this.runtime.settings?.customShortcuts || {}) };

    let matchedAction = null;
    if (this.isShortcutMatched(e, shortcuts.wide_view)) {
      matchedAction = 'wide_view';
    } else if (this.isShortcutMatched(e, shortcuts.fullscreen)) {
      matchedAction = 'fullscreen';
    } else if (this.isShortcutMatched(e, shortcuts.backward)) {
      matchedAction = 'backward';
    } else if (this.isShortcutMatched(e, shortcuts.forward)) {
      matchedAction = 'forward';
    } else if (this.isShortcutMatched(e, shortcuts.chatCollector)) {
      matchedAction = 'chatCollector';
    }

    if (matchedAction) {
      if (matchedAction === 'wide_view' || matchedAction === 'fullscreen') {
        let btn = null;

        if (matchedAction === 'wide_view') {
          btn = player.querySelector(SELECTORS.VIEW_MODE_BTN);
        } else if (matchedAction === 'fullscreen') {
          btn = player.querySelector(SELECTORS.PLAYER_FULLSCREEN_BTN);
        }

        if (btn) {
          const isMv = document.body.classList.contains('cqc-is-mv-iframe');
          if (matchedAction === 'wide_view' && isMv) {
            const label = btn.getAttribute('aria-label');
            const isActuallyWide = label === '기본 화면' || label === '좁은 화면' || label === '전체 화면 종료' ||
              player.classList.contains('pzp-pc-viewmode-wide') ||
              player.classList.contains('pzp-viewmode-wide');

            if (isActuallyWide) {
              this.runtime.log('[멀티뷰] 좁은 화면 전환 차단');
              e.preventDefault();
              e.stopImmediatePropagation();
              return;
            }
          }

          e.preventDefault();
          e.stopImmediatePropagation();
          if (!triggerReact(btn as HTMLElement)) (btn as any).click();
        }
      } else if (matchedAction === 'backward' || matchedAction === 'forward') {
        e.preventDefault();
        e.stopImmediatePropagation();

        const isBackward = matchedAction === 'backward';
        this.performSeek(isBackward);
      } else if (matchedAction === 'chatCollector') {
        e.preventDefault();
        e.stopImmediatePropagation();
        if (typeof (window as any).cqcToggleChatCollector === 'function') {
          (window as any).cqcToggleChatCollector();
        }
      }
    }
  };


  // 마우스 휠 볼륨 조절 리스너 (볼륨 컨트롤 위에서만 동작)
  wheelListener = (e: WheelEvent) => {
    if (!this.runtime.settings?.wheelVolumeEnabled) return;
    // 볼륨칸 위에서만 — 재생바/영상 위 스크롤은 무시
    if (!(e.target instanceof Element) || !e.target.closest(SELECTORS.PLAYER_VOLUME_CONTROL)) return;

    e.preventDefault();       // 페이지 스크롤 차단
    e.stopPropagation();      // 네이티브 플레이어 휠 핸들러 차단
    this.performVolumeChange(e.deltaY < 0 ? 1 : -1);
  };

  // ── 볼륨 인디케이터 ──
  volumeTooltip: HTMLElement | null = null;
  volumeHideTimer: number | null = null;
  volumeRafId: number | null = null;
  volumeListenersSetup = false;
  lastVolVal = -1;
  lastVolMuted = false;
  volumeWatchingEl: HTMLElement | null = null;

  realTimeHoverTooltipInitialized = false;
  currentVideoNo: string | null = null;
  liveOpenMs: number | null = null;
  isFetching = false;
  currentTargetEl: HTMLElement | null = null;
  lastDisplayedTime: string | null = null;
  mainListenersSetup = false;
  tooltipObserver: MutationObserver | null = null;
  vodTooltipObserver: MutationObserver | null = null;
  vodTooltipLastStr: string | null = null;
  vodTimelineTooltipEl: HTMLElement | null = null;

  TIME_DISPLAY_SELECTORS = SELECTORS.PLAYER_TIME_DISPLAY.split(',').map((s: string) => s.trim());

  mount(settings: any) {
    document.addEventListener('keydown', this.keydownListener, true);
    document.addEventListener('wheel', this.wheelListener, { capture: true, passive: false });

    if (settings.enabled) {
      this.applyWideView();
      this.initRealTimeHoverTooltip();
      this.initVolumeIndicator();
    }
  }

  cleanup() {
    document.removeEventListener('keydown', this.keydownListener, true);
    document.removeEventListener('wheel', this.wheelListener, { capture: true } as any);

    RealTimeTooltipModule.destroy();
    this.cleanupVolumeIndicator();

    if (this.mainListenersSetup) {
      document.removeEventListener('mouseover', this.onMouseOverBound, true);
      document.removeEventListener('mouseout', this.onMouseOutBound, true);
    }
    if (this.tooltipObserver) {
      this.tooltipObserver.disconnect();
      this.tooltipObserver = null;
    }
    if (this.vodTooltipObserver) {
      this.vodTooltipObserver.disconnect();
      this.vodTooltipObserver = null;
    }

    delete (window as any).cqcUpdateRealtimeTooltip;
    delete (window as any).cqcResetRealtimeTooltip;

    this.realTimeHoverTooltipInitialized = false;
    this.mainListenersSetup = false;
  }

  performSeek(isBackward: boolean) {
    const player = document.querySelector(SELECTORS.PLAYER);
    if (!player) return;
    const video = (player.querySelector('video.webplayer-internal-video') ?? player.querySelector('video')) as HTMLVideoElement | null;
    if (!video) return;

    const seekTime = Number(this.runtime.settings?.playbackSeekTime || 5);
    const store = this.runtime.state.root?.$store;

    let targetTime = video.currentTime + (isBackward ? -seekTime : seekTime);

    if (video.seekable && video.seekable.length > 0) {
      const start = video.seekable.start(0);
      const end = video.seekable.end(video.seekable.length - 1);
      if (targetTime < start) targetTime = start;
      if (targetTime > end) targetTime = end;
    } else {
      if (targetTime < 0) targetTime = 0;
      if (video.duration && targetTime > video.duration) targetTime = video.duration;
    }

    video.dataset.cqcTimeshifting = 'true';
    video.dataset.cqcLastSeekTime = Date.now().toString();

    if (store) {
      store.dispatch('seek', targetTime).catch(() => { });
    }
    try {
      video.currentTime = targetTime;
    } catch (e) { }

    this.runtime.log(`[단축키 탐색] ${isBackward ? '이전' : '다음'}으로 ${seekTime}초 이동 (목표: ${targetTime.toFixed(2)}s)`);
  }

  performVolumeChange(dir: number) {
    const player = document.querySelector(SELECTORS.PLAYER);
    if (!player) return;
    const video = (player.querySelector('video.webplayer-internal-video') ?? player.querySelector('video')) as HTMLVideoElement | null;
    if (!video) return;

    // ponytail: 스텝 0.05 고정. 설정으로 빼는 건 요청 오면.
    const next = Math.min(1, Math.max(0, video.volume + dir * 0.05));
    video.volume = next;
    video.muted = next === 0;

    // 휠 볼륨 변경 시에도 인디케이터 표시
    const volControl = player.querySelector(SELECTORS.PLAYER_VOLUME_CONTROL) as HTMLElement | null;
    if (volControl) {
      this.showVolumeIndicator(volControl);
    }

    this.runtime.log(`[휠 볼륨] ${Math.round(next * 100)}%`);
  }

  // ── 볼륨 인디케이터 메서드 ──

  initVolumeIndicator() {
    if (this.volumeListenersSetup) return;
    this.volumeListenersSetup = true;

    document.addEventListener('mouseover', this.onVolumeMouseOver, true);
    document.addEventListener('volumechange', this.onVideoVolumeChange, true);
  }

  cleanupVolumeIndicator() {
    if (this.volumeListenersSetup) {
      document.removeEventListener('mouseover', this.onVolumeMouseOver, true);
      document.removeEventListener('volumechange', this.onVideoVolumeChange, true);
      this.volumeListenersSetup = false;
    }
    if (this.volumeTooltip) {
      this.volumeTooltip.remove();
      this.volumeTooltip = null;
    }
    if (this.volumeRafId) {
      cancelAnimationFrame(this.volumeRafId);
      this.volumeRafId = null;
    }
    if (this.volumeHideTimer) {
      clearTimeout(this.volumeHideTimer);
      this.volumeHideTimer = null;
    }
    this.volumeWatchingEl = null;
  }

  onVolumeMouseOver = (e: MouseEvent) => {
    if (this.runtime.settings?.volumeIndicatorEnabled === false) return;
    const target = e.target as HTMLElement;
    const volControl = target.closest?.(SELECTORS.PLAYER_VOLUME_CONTROL) as HTMLElement | null;
    if (!volControl) return;
    if (volControl === this.volumeWatchingEl) return;

    // 이전 감시 해제
    if (this.volumeWatchingEl) {
      this.volumeWatchingEl.removeEventListener('mousemove', this.onVolumeMouseMove as any);
      this.volumeWatchingEl.removeEventListener('mouseleave', this.onVolumeMouseLeave as any);
    }

    this.volumeWatchingEl = volControl;
    volControl.addEventListener('mousemove', this.onVolumeMouseMove as any, { passive: true });
    volControl.addEventListener('mouseleave', this.onVolumeMouseLeave as any);

    this.showVolumeIndicator(volControl);
  };

  onVolumeMouseMove = () => {
    if (!this.volumeWatchingEl) return;
    if (this.volumeRafId) return;
    this.volumeRafId = requestAnimationFrame(() => {
      if (this.volumeWatchingEl) this.showVolumeIndicator(this.volumeWatchingEl);
      this.volumeRafId = null;
    });
  };

  onVolumeMouseLeave = () => {
    this.hideVolumeIndicator();
    if (this.volumeWatchingEl) {
      this.volumeWatchingEl.removeEventListener('mousemove', this.onVolumeMouseMove as any);
      this.volumeWatchingEl.removeEventListener('mouseleave', this.onVolumeMouseLeave as any);
      this.volumeWatchingEl = null;
    }
    if (this.volumeRafId) {
      cancelAnimationFrame(this.volumeRafId);
      this.volumeRafId = null;
    }
  };

  onVideoVolumeChange = () => {
    // 호버 중이면 즉시 갱신, 휠 변경 시에도 갱신
    if (this.volumeTooltip?.classList.contains('is-visible') && this.volumeWatchingEl) {
      this.showVolumeIndicator(this.volumeWatchingEl);
    }
  };

  showVolumeIndicator(volControl: HTMLElement) {
    if (this.runtime.settings?.volumeIndicatorEnabled === false) {
      this.hideVolumeIndicator();
      return;
    }

    const video = (document.querySelector('video.webplayer-internal-video') || document.querySelector('video')) as HTMLVideoElement | null;
    if (!video) return;

    const volume = Math.round(video.volume * 100);
    const muted = video.muted;

    const container = (document.fullscreenElement || document.querySelector('.pzp') || document.body) as HTMLElement;

    if (!this.volumeTooltip) {
      this.volumeTooltip = document.createElement('div');
      this.volumeTooltip.className = 'cqc-volume-indicator';
    }
    if (this.volumeTooltip.parentElement !== container) {
      container.appendChild(this.volumeTooltip);
    }

    if (volume !== this.lastVolVal || muted !== this.lastVolMuted) {
      this.lastVolVal = volume;
      this.lastVolMuted = muted;
      this.volumeTooltip.textContent = muted ? '음소거' : `${volume}%`;
    }

    const rect = volControl.getBoundingClientRect();
    const containerRect = container !== document.body ? container.getBoundingClientRect() : { left: 0, top: 0 };
    this.volumeTooltip.style.left = `${rect.left + rect.width / 2 - containerRect.left}px`;
    this.volumeTooltip.style.top = `${rect.top - 10 - containerRect.top}px`;

    if (!this.volumeTooltip.classList.contains('is-visible')) {
      this.volumeTooltip.classList.add('is-visible');
    }

    // 휠 볼륨 변경 시 자동 숨김 타이머
    if (this.volumeHideTimer) clearTimeout(this.volumeHideTimer);
    if (!this.volumeWatchingEl) {
      // 호버가 아닌 휠 변경이면 1.5초 후 자동 숨김
      this.volumeHideTimer = window.setTimeout(() => this.hideVolumeIndicator(), 1500);
    }
  }

  hideVolumeIndicator() {
    if (this.volumeTooltip) {
      this.volumeTooltip.classList.remove('is-visible');
    }
    this.lastVolVal = -1;
    this.lastVolMuted = false;
  }

  isShortcutMatched(e: KeyboardEvent, shortcut: any) {
    if (!shortcut) return false;
    const eventKey = e.key.toLowerCase();
    const targetKey = shortcut.key.toLowerCase();

    return eventKey === targetKey &&
      !!e.ctrlKey === !!shortcut.ctrl &&
      !!e.shiftKey === !!shortcut.shift &&
      !!e.altKey === !!shortcut.alt &&
      !!e.metaKey === !!shortcut.meta;
  }

  hasPlayer(u?: string) {
    return REGEX.PLAYER_URL.test(u ?? location.href);
  }

  applyWideView() {
    const isMv = document.body.classList.contains('cqc-is-mv-iframe');
    if (!this.runtime.settings?.enabled || (!this.runtime.settings?.wideViewEnabled && !isMv) || !this.hasPlayer()) return;

    const attempt = (n = 0) => {
      if (!this.runtime.settings?.wideViewEnabled && !isMv) return;
      if (!this.runtime.state.ready) {
        if (n < 10) setTimeout(() => attempt(n + 1), 500);
        return;
      }

      const player = document.querySelector(SELECTORS.PLAYER);
      if (!player) {
        if (n < 10) setTimeout(() => attempt(n + 1), 500);
        return;
      }

      const btn = player.querySelector(SELECTORS.VIEW_MODE_BTN);

      if (!btn) {
        if (n < 10) setTimeout(() => attempt(n + 1), 500);
        return;
      }

      const label = btn.getAttribute('aria-label');
      const isActuallyWide = label === '기본 화면' || label === '좁은 화면' || label === '전체 화면 종료' ||
        player.classList.contains('pzp-pc-viewmode-wide') ||
        player.classList.contains('pzp-viewmode-wide');

      const isMvForced = document.body.classList.contains('cqc-mv-wide-forced');

      if (!isActuallyWide && (label === '넓은 화면' || !label || isMvForced)) {
        this.runtime.log('[자동 넓은 화면] 적용 시도');
        if (!triggerReact(btn as HTMLElement)) (btn as any).click();
      }
    };

    setTimeout(() => attempt(0), 1000);
  }

  formatRealTime(ms: number) {
    const date = new Date(ms);
    return date.toLocaleString('ko', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  }

  getCurrentTime() {
    return this.runtime.state.root?.$store?.state?.currentTime ?? 0;
  }

  updateTooltip() {
    if (!this.currentTargetEl) return;

    const isLiveNow = !!document.querySelector(SELECTORS.PLAYER_LIVE_INDICATOR);
    const storeState = this.runtime.state.root?.$store?.state;
    const currentTime = this.getCurrentTime();

    let realTimeMs = 0;
    if (isLiveNow) {
      const ptsOffset = storeState?.ptsOffset || 0;
      realTimeMs = ptsOffset > 0 ? (ptsOffset + currentTime * 1000) : Date.now();
    } else if (this.liveOpenMs) {
      realTimeMs = this.liveOpenMs + currentTime * 1000;
    } else if (!isLiveNow && !this.liveOpenMs && !this.isFetching) {
      this.updateVideoInfo();
      return;
    }

    if (realTimeMs === 0) return;

    const displayTime = this.formatRealTime(realTimeMs);
    const rect = this.currentTargetEl.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top;

    RealTimeTooltipModule.show(x, y, displayTime);
  }

  hideTooltip() {
    RealTimeTooltipModule.hide();
  }

  onMouseOver(e: MouseEvent) {
    this.updateVideoInfo();
    const target = e.target as HTMLElement;
    for (const sel of this.TIME_DISPLAY_SELECTORS) {
      const timeEl = target.closest(sel);
      if (timeEl instanceof HTMLElement) {
        this.currentTargetEl = timeEl;
        this.updateTooltip();
        return;
      }
    }
  }

  onMouseOut(e: MouseEvent) {
    if (!this.currentTargetEl) return;
    const related = e.relatedTarget;
    if (related instanceof Node && this.currentTargetEl.contains(related)) return;
    this.hideTooltip();
    this.currentTargetEl = null;
  }

  onMouseOverBound = (e: MouseEvent) => this.onMouseOver(e);
  onMouseOutBound = (e: MouseEvent) => this.onMouseOut(e);

  setupTooltipListeners() {
    if (!this.mainListenersSetup) {
      document.addEventListener('mouseover', this.onMouseOverBound, true);
      document.addEventListener('mouseout', this.onMouseOutBound, true);
      this.mainListenersSetup = true;
    }

    const videoEl = document.querySelector('video');
    if (videoEl && !videoEl.dataset.cqcWatchingTooltip) {
      videoEl.dataset.cqcWatchingTooltip = 'true';
      videoEl.addEventListener('timeupdate', () => {
        if (this.currentTargetEl) this.updateTooltip();
      });
    }
  }

  async fetchLiveOpenDate(videoId: string) {
    if (this.isFetching) return;
    this.isFetching = true;
    try {
      const resp = await fetch(`https://api.chzzk.naver.com/service/v2/videos/${videoId}`);
      const data = await resp.json();

      if (data.content?.liveOpenDate) {
        this.liveOpenMs = new Date(data.content.liveOpenDate).getTime();
      } else if (data.content?.videoPublishedAt) {
        this.liveOpenMs = new Date(data.content.videoPublishedAt).getTime();
      }

      if (this.liveOpenMs && this.currentTargetEl) this.updateTooltip();
    } catch (err) {
      this.runtime.log('[실시간 툴팁] 정보 로드 실패:', err);
    } finally {
      this.isFetching = false;
    }
  }

  updateVideoInfo() {
    const isVod = location.pathname.startsWith('/video/');
    const videoId = isVod ? location.pathname.match(/\/video\/(\d+)/)?.[1] : null;

    if (videoId) {
      if (videoId !== this.currentVideoNo || (!this.liveOpenMs && !this.isFetching)) {
        this.currentVideoNo = videoId;
        this.liveOpenMs = null;
        this.fetchLiveOpenDate(videoId);
      }
    } else if (!isVod) {
      this.currentVideoNo = null;
      this.liveOpenMs = null;
    }
  }

  resetTooltip() {
    this.currentVideoNo = null;
    this.liveOpenMs = null;
    this.hideTooltip();
  }

  initRealTimeHoverTooltip() {
    if (this.realTimeHoverTooltipInitialized) return;
    this.realTimeHoverTooltipInitialized = true;

    this.runtime.log('[실시간 툴팁] 초기화됨');

    RealTimeTooltipModule.init();
    this.updateVideoInfo();

    (window as any).cqcUpdateRealtimeTooltip = () => this.updateVideoInfo();
    (window as any).cqcResetRealtimeTooltip = () => this.resetTooltip();

    // MutationObserver 대신 DomPresencePoller 사용
    this.runtime.observer.poller.waitFor(
      'tooltipVideo',
      'video',
      () => this.setupTooltipListeners(),
      { interval: 1000, persistent: true }
    );
    this.setupTooltipListeners();
    this.initVodTimelineTooltip();
  }

  initVodTimelineTooltip() {
    if (!this.runtime.settings?.vodRealTimeTooltipEnabled) return;
    
    this.runtime.observer.poller.waitFor(
      'vodTimelineTooltip',
      SELECTORS.PLAYER,
      (player: Element) => {
        if (this.vodTooltipObserver) {
          this.vodTooltipObserver.disconnect();
        }
        
        this.vodTooltipObserver = new MutationObserver(() => {
          this.updateVodTimelineTooltip();
        });
        
        this.vodTooltipObserver.observe(player, {
          childList: true,
          subtree: true,
          characterData: true,
          attributes: true,
          attributeFilter: ['style', 'class']
        });
      },
      { interval: 1000, persistent: true }
    );
  }

  updateVodTimelineTooltip() {
    if (!this.liveOpenMs) return;
    
    const isVod = location.pathname.startsWith('/video/');
    if (!isVod) {
      if (this.vodTimelineTooltipEl) this.vodTimelineTooltipEl.style.display = 'none';
      return;
    }
    
    const tooltips = document.querySelectorAll(SELECTORS.NATIVE_SLIDER_TOOLTIP);
    let activeTooltip: Element | null = null;
    let activeRect: DOMRect | null = null;
    
    for (const tooltip of Array.from(tooltips)) {
      const rect = tooltip.getBoundingClientRect();
      const style = window.getComputedStyle(tooltip);
      if (rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.opacity !== '0' && style.visibility !== 'hidden') {
        activeTooltip = tooltip;
        activeRect = rect;
        break;
      }
    }
    
    if (!activeTooltip || !activeRect) {
      if (this.vodTimelineTooltipEl) this.vodTimelineTooltipEl.style.display = 'none';
      return;
    }
    
    const timeEl = activeTooltip.querySelector(SELECTORS.NATIVE_SLIDER_TOOLTIP_TIME);
    if (!timeEl) {
      if (this.vodTimelineTooltipEl) this.vodTimelineTooltipEl.style.display = 'none';
      return;
    }
    
    const timeText = timeEl.textContent?.trim();
    if (!timeText) {
      if (this.vodTimelineTooltipEl) this.vodTimelineTooltipEl.style.display = 'none';
      return;
    }
    
    let seconds = 0;
    const parts = timeText.split(':').map(Number);
    if (parts.length === 3) {
      seconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
    } else if (parts.length === 2) {
      seconds = parts[0] * 60 + parts[1];
    }
    
    const realTimeMs = this.liveOpenMs + seconds * 1000;
    const displayTime = this.formatVodRealTime(realTimeMs);
    
    if (!this.vodTimelineTooltipEl) {
      this.vodTimelineTooltipEl = document.createElement('div');
      this.vodTimelineTooltipEl.className = 'cqc-vod-timeline-floating';
      this.vodTimelineTooltipEl.style.position = 'fixed';
      this.vodTimelineTooltipEl.style.zIndex = '999999';
      this.vodTimelineTooltipEl.style.background = 'rgba(0, 0, 0, 0.85)';
      this.vodTimelineTooltipEl.style.color = '#00ffa3';
      this.vodTimelineTooltipEl.style.padding = '5px 10px';
      this.vodTimelineTooltipEl.style.borderRadius = '6px';
      this.vodTimelineTooltipEl.style.fontSize = '12px';
      this.vodTimelineTooltipEl.style.fontWeight = '700';
      this.vodTimelineTooltipEl.style.pointerEvents = 'none';
      this.vodTimelineTooltipEl.style.transform = 'translate(-50%, -100%)'; // 박스 중앙 위쪽 기준
      this.vodTimelineTooltipEl.style.backdropFilter = 'blur(4px)';
      this.vodTimelineTooltipEl.style.boxShadow = '0 4px 12px rgba(0,0,0,0.6)';
      this.vodTimelineTooltipEl.style.border = '1px solid rgba(255,255,255,0.1)';
      this.vodTimelineTooltipEl.style.letterSpacing = '-0.02em';
      document.body.appendChild(this.vodTimelineTooltipEl);
    }
    
    this.vodTimelineTooltipEl.style.display = 'block';
    if (this.vodTimelineTooltipEl.textContent !== displayTime) {
      this.vodTimelineTooltipEl.textContent = displayTime;
    }
    
    // 썸네일 툴팁의 상단 정중앙보다 약간 위쪽으로 배치
    this.vodTimelineTooltipEl.style.left = `${activeRect.left + activeRect.width / 2}px`;
    this.vodTimelineTooltipEl.style.top = `${activeRect.top - 8}px`;
  }
  
  formatVodRealTime(ms: number) {
    const d = new Date(ms);
    const yy = String(d.getFullYear()).slice(-2);
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    
    let hours = d.getHours();
    const ampm = hours < 12 ? '오전' : '오후';
    hours = hours % 12 || 12;
    
    const mins = String(d.getMinutes()).padStart(2, '0');
    const secs = String(d.getSeconds()).padStart(2, '0');
    
    return `${yy}.${mm}.${dd}. ${ampm} ${hours}:${mins}:${secs}`;
  }
}
