import React, { useEffect, useRef, useState } from 'react';

interface StatsState {
  bitrate?: number;
  latency?: number;
  absoluteLatency?: number;
  resolution?: string;
  fps?: number;
  trackId?: string;
  protocol?: string;
  connectionType?: string;
  buffer?: number;
  ptsOffset?: number;
  droppedFrames?: number;
  totalFrames?: number;
  playbackRate?: number;
  playState?: string;
  readyState?: number;
  networkState?: number;
  viewers?: number;
  watchElapsed?: number;
  rawVue?: Record<string, any>;
  rawVideo?: Record<string, any>;
}

interface StreamStatsRootProps {
  settings: any;
  send: (type: string, payload?: any) => Promise<any>;
  onClose: () => void;
  visible: boolean;
}

const fmtWatch = (ms: number) => {
  const sec = Math.floor(ms / 1000);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const ss = sec % 60;
  return h > 0
    ? `${h}:${String(m).padStart(2, '0')}:${String(ss).padStart(2, '0')}`
    : `${m}:${String(ss).padStart(2, '0')}`;
};

export const StreamStatsRoot: React.FC<StreamStatsRootProps> = ({ settings, send, onClose, visible }) => {
  const [stats, setStats] = useState<StatsState | null>(null);
  const [history, setHistory] = useState<{ ts: number; bitrate: number; absoluteLatency: number; buffer: number }[]>([]);
  const [dumpExpanded, setDumpExpanded] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    let updateTimer: any;
    if (visible) {
      setHistory([]);
      const fetchStats = async () => {
        try {
          const s = await send('REQUEST_STATS');
          setStats(s);
          if (s) {
            setHistory(prev => {
              const next = [...prev, {
                ts: Date.now(),
                bitrate: s.bitrate || 0,
                absoluteLatency: s.absoluteLatency || 0,
                buffer: s.buffer || 0
              }];
              if (next.length > 60) next.shift();
              return next;
            });
          }
        } catch (e) {
          console.error('[CQC:Stats] fetch failed', e);
        }
      };
      
      fetchStats();
      updateTimer = setInterval(fetchStats, 1000);
    } else {
      setStats(null);
      setHistory([]);
    }
    
    return () => {
      if (updateTimer) clearInterval(updateTimer);
    };
  }, [visible, send]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || history.length === 0) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const w = canvas.width / dpr;
    const h = canvas.height / dpr;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.save();
    ctx.scale(dpr, dpr);

    const maxPoints = 60;
    const padding = 6;
    const innerW = w - padding * 2;
    const innerH = h - padding * 2;

    const bitrates = history.map(d => d.bitrate);
    let maxBitrate = Math.max(...bitrates, 1000);
    let minBitrate = Math.min(...bitrates);
    if (minBitrate === maxBitrate) {
        minBitrate = maxBitrate * 0.9;
        maxBitrate = maxBitrate * 1.1;
    } else {
        const paddingB = (maxBitrate - minBitrate) * 0.2;
        minBitrate = Math.max(0, minBitrate - paddingB);
        maxBitrate += paddingB;
    }

    const latencies = history.map(d => d.absoluteLatency !== -1 ? d.absoluteLatency : 0);
    let maxLat = Math.max(...latencies, 1);
    let minLat = Math.min(...latencies);
    if (minLat === maxLat) {
        minLat = Math.max(0, maxLat - 1);
        maxLat = maxLat + 1;
    } else {
        const paddingL = (maxLat - minLat) * 0.2;
        minLat = Math.max(0, minLat - paddingL);
        maxLat += paddingL;
    }

    const buffers = history.map(d => d.buffer || 0);
    let maxBuf = Math.max(...buffers, 1);
    let minBuf = Math.min(...buffers);
    if (minBuf === maxBuf) {
        minBuf = Math.max(0, maxBuf - 1);
        maxBuf = maxBuf + 1;
    } else {
        const paddingBuf = (maxBuf - minBuf) * 0.2;
        minBuf = Math.max(0, minBuf - paddingBuf);
        maxBuf += paddingBuf;
    }

    // Create line gradients
    const bitrateLineGrad = ctx.createLinearGradient(padding, 0, w - padding, 0);
    bitrateLineGrad.addColorStop(0, '#00d2ff'); // Neon Blue/Cyan
    bitrateLineGrad.addColorStop(1, '#00ffa3'); // Neon Mint/Green

    const latencyLineGrad = ctx.createLinearGradient(padding, 0, w - padding, 0);
    latencyLineGrad.addColorStop(0, '#8a2be2'); // Neon Violet
    latencyLineGrad.addColorStop(1, '#ff007f'); // Neon Pink

    const bufferLineGrad = ctx.createLinearGradient(padding, 0, w - padding, 0);
    bufferLineGrad.addColorStop(0, '#ffd700'); // Gold/Yellow
    bufferLineGrad.addColorStop(1, '#ff8c00'); // Dark Orange

    // Bitrate Area Fill (vertical gradient)
    ctx.beginPath();
    ctx.moveTo(padding, h - padding);
    history.forEach((d, i) => {
      const x = padding + (i / (maxPoints - 1)) * innerW;
      const y = h - padding - ((d.bitrate - minBitrate) / (maxBitrate - minBitrate || 1)) * innerH;
      ctx.lineTo(x, y);
    });
    ctx.lineTo(padding + ((history.length - 1) / (maxPoints - 1)) * innerW, h - padding);
    ctx.closePath();
    const bitAreaGrad = ctx.createLinearGradient(0, padding, 0, h - padding);
    bitAreaGrad.addColorStop(0, 'rgba(0, 255, 163, 0.16)');
    bitAreaGrad.addColorStop(1, 'rgba(0, 210, 255, 0.01)');
    ctx.fillStyle = bitAreaGrad;
    ctx.fill();

    // Bitrate Line
    ctx.beginPath();
    history.forEach((d, i) => {
      const x = padding + (i / (maxPoints - 1)) * innerW;
      const y = h - padding - ((d.bitrate - minBitrate) / (maxBitrate - minBitrate || 1)) * innerH;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = bitrateLineGrad;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();

    // Latency Area Fill (vertical gradient)
    ctx.beginPath();
    ctx.moveTo(padding, h - padding);
    history.forEach((d, i) => {
      const lat = d.absoluteLatency !== -1 ? d.absoluteLatency : 0;
      const x = padding + (i / (maxPoints - 1)) * innerW;
      const y = h - padding - ((lat - minLat) / (maxLat - minLat || 1)) * innerH;
      ctx.lineTo(x, y);
    });
    ctx.lineTo(padding + ((history.length - 1) / (maxPoints - 1)) * innerW, h - padding);
    ctx.closePath();
    const latAreaGrad = ctx.createLinearGradient(0, padding, 0, h - padding);
    latAreaGrad.addColorStop(0, 'rgba(255, 0, 127, 0.10)');
    latAreaGrad.addColorStop(1, 'rgba(138, 43, 226, 0.01)');
    ctx.fillStyle = latAreaGrad;
    ctx.fill();

    // Latency Line
    ctx.beginPath();
    history.forEach((d, i) => {
      const lat = d.absoluteLatency !== -1 ? d.absoluteLatency : 0;
      const x = padding + (i / (maxPoints - 1)) * innerW;
      const y = h - padding - ((lat - minLat) / (maxLat - minLat || 1)) * innerH;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = latencyLineGrad;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();

    // Buffer Area Fill
    ctx.beginPath();
    ctx.moveTo(padding, h - padding);
    history.forEach((d, i) => {
      const buf = d.buffer || 0;
      const x = padding + (i / (maxPoints - 1)) * innerW;
      const y = h - padding - ((buf - minBuf) / (maxBuf - minBuf || 1)) * innerH;
      ctx.lineTo(x, y);
    });
    ctx.lineTo(padding + ((history.length - 1) / (maxPoints - 1)) * innerW, h - padding);
    ctx.closePath();
    const bufAreaGrad = ctx.createLinearGradient(0, padding, 0, h - padding);
    bufAreaGrad.addColorStop(0, 'rgba(255, 215, 0, 0.10)');
    bufAreaGrad.addColorStop(1, 'rgba(255, 140, 0, 0.01)');
    ctx.fillStyle = bufAreaGrad;
    ctx.fill();

    // Buffer Line
    ctx.beginPath();
    history.forEach((d, i) => {
      const buf = d.buffer || 0;
      const x = padding + (i / (maxPoints - 1)) * innerW;
      const y = h - padding - ((buf - minBuf) / (maxBuf - minBuf || 1)) * innerH;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = bufferLineGrad;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();

    ctx.restore();
  }, [history]);

  // Set canvas DPR on mount/visibility
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !visible) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = 70 * dpr;
  }, [visible]);

  if (!visible) return null;

  const useMarquee = (ref: React.RefObject<HTMLSpanElement | null>, wrapperRef: React.RefObject<HTMLDivElement | null>) => {
    useEffect(() => {
      const el = ref.current;
      const wrapper = wrapperRef.current;
      if (!el || !wrapper) return;
      const overflow = el.scrollWidth - wrapper.clientWidth;
      if (overflow > 2) {
        el.classList.add('cqc-marquee');
        el.style.setProperty('--scroll-dist', `${-overflow}px`);
      } else {
        el.classList.remove('cqc-marquee');
        el.style.removeProperty('--scroll-dist');
      }
    });
  };

  const ValSpan = ({ formatted, raw }: { formatted: string; raw: string }) => {
    const wrapperRef = useRef<HTMLDivElement>(null);
    const fmtRef = useRef<HTMLSpanElement>(null);
    useMarquee(fmtRef, wrapperRef);
    return (
      <div className="cqc-stats-val-wrapper" ref={wrapperRef}>
        <span ref={fmtRef} className="cqc-stats-val cqc-stats-val--formatted">{formatted}</span>
        <span className="cqc-stats-val cqc-stats-val--raw">{raw}</span>
      </div>
    );
  };

  const Row = ({ title, formatted, raw, tooltip }: any) => (
    <div className="cqc-stats-row">
      <span className="cqc-stats-key">
        {title}
        {tooltip && <span className="cqc-stats-help-icon" title={tooltip}> ⓘ</span>}
      </span>
      <ValSpan formatted={formatted} raw={raw} />
    </div>
  );

  const Card = ({ title, formatted, raw, dotClass }: any) => {
    const wrapperRef = useRef<HTMLDivElement>(null);
    const fmtRef = useRef<HTMLSpanElement>(null);
    useMarquee(fmtRef, wrapperRef);
    return (
      <div className="cqc-stats-card">
        <div className="cqc-stats-card-title">
          {title}
          <span className={`cqc-status-dot ${dotClass}`} />
        </div>
        <div className="cqc-stats-val-wrapper cqc-stats-card-value-wrapper" ref={wrapperRef}>
          <span ref={fmtRef} className="cqc-stats-val cqc-stats-val--formatted">{formatted}</span>
          <span className="cqc-stats-val cqc-stats-val--raw">{raw}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="cqc-stats-overlay cqc-stats-overlay--show">
      {/* Header */}
      <div className="cqc-stats-header">
        <h3>
          <span className="cqc-stats-accent-dot" />
          스트림 통계
        </h3>
        <button className="cqc-stats-close" title="닫기" onClick={onClose}>✕</button>
      </div>

      <div className="cqc-stats-body">
        {/* Hero Cards */}
        <div className="cqc-stats-grid">
          <Card 
            title="비트레이트" 
            formatted={stats?.bitrate ? (stats.bitrate / 1000).toFixed(1) + ' Mbps' : '—'} 
            raw={String(stats?.bitrate || 'null')}
            dotClass={!stats?.bitrate ? 'cqc-status-dot--gray' : (stats.bitrate > 5000 ? 'cqc-status-dot--good' : (stats.bitrate > 2000 ? 'cqc-status-dot--warn' : 'cqc-status-dot--error'))}
          />
          <Card 
            title="지연 시간 (Edge)" 
            formatted={stats?.latency !== undefined && stats.latency !== -1 ? stats.latency.toFixed(2) + 's' : '—'} 
            raw={String(stats?.latency)}
            dotClass={stats?.latency === -1 || stats?.latency === undefined ? 'cqc-status-dot--gray' : (stats.latency < 3 ? 'cqc-status-dot--good' : (stats.latency < 6 ? 'cqc-status-dot--warn' : 'cqc-status-dot--error'))}
          />
        </div>

        {/* Chart */}
        <div className="cqc-stats-section cqc-stats-chart-wrapper">
          <canvas ref={canvasRef} className="cqc-stats-canvas" />
          <div className="cqc-stats-chart-legend">
            <span className="cqc-stats-legend-item">
              <span className="cqc-stats-legend-dot cqc-stats-legend-dot--bitrate" />
              비트레이트
            </span>
            <span className="cqc-stats-legend-item">
              <span className="cqc-stats-legend-dot cqc-stats-legend-dot--latency" />
              지연 시간
            </span>
            <span className="cqc-stats-legend-item">
              <span className="cqc-stats-legend-dot cqc-stats-legend-dot--buffer" style={{background: 'linear-gradient(135deg, #ffd700, #ff8c00)'}} />
              버퍼
            </span>
          </div>
        </div>

        {/* 비디오 & 네트워크 */}
        <div className="cqc-stats-section">
          <div className="cqc-stats-group-title">비디오 &amp; 네트워크</div>
          <Row title="해상도 / 프레임" formatted={`${stats?.resolution || '—'} @ ${stats?.fps || 0}fps`} raw={`${stats?.rawVue?.videoWidth}x${stats?.rawVue?.videoHeight} ${stats?.fps}`} />
          <Row title="코덱" formatted={stats?.trackId?.match(/\.(avc1|hevc|vp9|av01)[^.]*/)?.[0]?.slice(1) || '—'} raw={String(stats?.trackId || 'null')} />
          <Row title="프로토콜" formatted={`${stats?.protocol || '—'} / ${stats?.connectionType || '—'}`} raw={`${stats?.rawVue?.protocol} ${stats?.rawVue?.connectionType}`} />
        </div>

        {/* 재생 상태 */}
        <div className="cqc-stats-section">
          <div className="cqc-stats-group-title">재생 상태</div>
          <Row title="방송 지연 (PTS)" tooltip="서버 송출 타임스탬프 기준. 실제 시청자와 스트리머 간의 절대 지연." formatted={stats?.absoluteLatency !== undefined && stats.absoluteLatency !== -1 ? stats.absoluteLatency.toFixed(2) + 's' : '—'} raw={String(stats?.absoluteLatency)} />
          <Row title="버퍼 / 오프셋" formatted={`${stats?.buffer?.toFixed(2) || '0.00'}s / ${typeof stats?.ptsOffset === 'number' ? stats.ptsOffset.toFixed(3) : '—'}`} raw={`${stats?.buffer !== undefined ? stats.buffer.toFixed(6) + 's' : 'null'} / ${stats?.ptsOffset !== undefined ? stats.ptsOffset.toFixed(6) + 's' : 'null'}`} />
          <Row title="드롭된 프레임" formatted={stats?.totalFrames && stats.totalFrames > 0 ? `${stats.droppedFrames} (${((stats.droppedFrames! / stats.totalFrames!) * 100).toFixed(2)}%)` : `${stats?.droppedFrames || 0} (0.00%)`} raw={String(stats?.droppedFrames)} />
          <Row title="재생 속도" formatted={stats?.playbackRate && stats.playbackRate !== 1 ? `${stats.playbackRate.toFixed(2)}x` : '1.00x'} raw={String(stats?.rawVue?.playbackRate)} />
          <Row title="재생/네트워크 상태" formatted={`${stats?.playState || '—'} / ${stats?.readyState || 0}`} raw={`${stats?.rawVue?.playState} ${stats?.readyState} ${stats?.networkState}`} />
        </div>

        {/* RAW STATE DUMP */}
        <div className="cqc-stats-section cqc-stats-dump-sec">
          <div className="cqc-stats-group-title" onClick={() => setDumpExpanded(!dumpExpanded)}>
            RAW STATE DUMP
            <span className="cqc-dump-toggle">{dumpExpanded ? '▲' : '▼'}</span>
          </div>
          {dumpExpanded && (
            <div className="cqc-stats-dump-content">
              {stats?.rawVue && (
                <>
                  <div className="cqc-stats-dump-label" style={{ color: '#00ffa3' }}>[VUE]</div>
                  {Object.entries(stats.rawVue).map(([k, v]) => (
                    <div className="cqc-stats-row" key={`vue-${k}`}>
                      <span className="cqc-stats-key" style={{ color: '#00ffa3' }}>{k}</span>
                      <span className="cqc-stats-val">{String(v)}</span>
                    </div>
                  ))}
                </>
              )}
              {stats?.rawVideo && (
                <>
                  <div className="cqc-stats-dump-label" style={{ color: '#61dafb', marginTop: '8px' }}>[VIDEO]</div>
                  {Object.entries(stats.rawVideo).map(([k, v]) => (
                    <div className="cqc-stats-row" key={`vid-${k}`}>
                      <span className="cqc-stats-key" style={{ color: '#61dafb' }}>{k}</span>
                      <span className="cqc-stats-val">{String(v)}</span>
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
