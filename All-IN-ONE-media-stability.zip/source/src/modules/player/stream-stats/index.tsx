import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import Browser from 'webextension-polyfill';
import { SELECTORS, isShortcutMatched, log as cqcLog } from '../../../../dom-utils';
import { StreamStatsRoot } from './StreamStatsRoot';

const log = (...args: any[]) => cqcLog('StreamStats', ...args);

let _activeRoot: Root | null = null;
let _activeContainer: HTMLElement | null = null;
let _isVisible = false;
let _settings: any = null;
let _send: any = null;

const mountReact = () => {
  if (!_activeContainer || !_activeContainer.isConnected) {
    if (_activeRoot) {
      _activeRoot.unmount();
      _activeRoot = null;
    }
    
    const player = document.querySelector(SELECTORS.PLAYER);
    const parent = player ?? document.body;
    
    _activeContainer = document.createElement('div');
    _activeContainer.className = 'cqc-stream-stats-react-root';
    parent.appendChild(_activeContainer);
    
    _activeRoot = createRoot(_activeContainer);
  }

  const handleClose = () => {
    _isVisible = false;
    mountReact(); // Re-render to hide
  };

  _activeRoot?.render(
    <StreamStatsRoot 
      settings={_settings} 
      send={_send} 
      visible={_isVisible} 
      onClose={handleClose} 
    />
  );
};

export const initStreamStats = (settings: any, send: any, cleanups: any[]) => {
  _settings = settings;
  _send = send;
  _isVisible = false;

  const toggle = (forceClose = false) => {
    _isVisible = forceClose ? false : !_isVisible;
    mountReact();
  };

  const onKey = (e: KeyboardEvent) => {
    const shortcut = _settings?.customShortcuts?.stats;
    if (shortcut && isShortcutMatched(e, shortcut)) {
      if (!_settings?.streamStatsEnabled) return;
      e.preventDefault();
      toggle();
    }
  };

  document.addEventListener('keydown', onKey);
  if (cleanups) {
    cleanups.push(() => {
      document.removeEventListener('keydown', onKey);
      if (_activeRoot) {
        _activeRoot.unmount();
        _activeRoot = null;
      }
      if (_activeContainer) {
        _activeContainer.remove();
        _activeContainer = null;
      }
    });
  }
  
  (window as any).__cqcStatsToggle = toggle;
};

export const initContextMenuStats = (settings: any, observers: any[]) => {
  const PANE_SEL = SELECTORS.CONTEXT_MENU_PANE;
  const LIST_SEL = SELECTORS.CONTEXT_MENU_LIST;
  const INJECT_ATTR = 'data-cqc-ctx';

  const inject = (pane: HTMLElement) => {
    if (!settings?.statsContextMenuEnabled) return;
    const list = pane.querySelector(LIST_SEL);
    if (!list || list.querySelector(`[${INJECT_ATTR}]`)) return;

    const liStats = document.createElement('li');
    liStats.setAttribute('role', 'menuitem');
    liStats.className = SELECTORS.CONTEXT_MENU_ITEM_CLASS;
    liStats.setAttribute(INJECT_ATTR, '');

    const btnStats = document.createElement('button');
    btnStats.className = SELECTORS.CONTEXT_MENU_ITEM_BTN_CLASS;
    btnStats.textContent = '스트림 통계';
    btnStats.addEventListener('click', () => {
      (window as any).__cqcStatsToggle?.();
    });

    liStats.appendChild(btnStats);
    list.appendChild(liStats);

    const liSettings = document.createElement('li');
    liSettings.setAttribute('role', 'menuitem');
    liSettings.className = SELECTORS.CONTEXT_MENU_ITEM_CLASS;
    liSettings.setAttribute(INJECT_ATTR, '');

    const btnSettings = document.createElement('button');
    btnSettings.className = SELECTORS.CONTEXT_MENU_ITEM_BTN_CLASS;
    btnSettings.textContent = '환경설정';
    btnSettings.addEventListener('click', () => {
      Browser.runtime.sendMessage({ type: 'OPEN_SETTINGS' });
    });

    liSettings.appendChild(btnSettings);
    list.appendChild(liSettings);
  };

  const observer = new MutationObserver((mutations) => {
    if (!settings?.statsContextMenuEnabled) return;
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (!(node instanceof HTMLElement)) continue;
        if (node.matches?.(PANE_SEL)) { inject(node); continue; }
        const pane = node.querySelector?.(PANE_SEL);
        if (pane) inject(pane as HTMLElement);
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
  if (observers) observers.push(observer);
};
