import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { PlaybackBarRoot, PlaybackBarRootRef } from './PlaybackBarRoot';
import { PlayerState } from './usePlaybackBar';
import { VolumeIndicator } from './VolumeIndicator';
import { log as cqcLog, SELECTORS } from '../../../../dom-utils';

const log = (...args: any[]) => cqcLog('PlaybackBarModule', ...args);

let _activeRoot: Root | null = null;
let _activeContainer: HTMLElement | null = null;
let _activeRef: PlaybackBarRootRef | null = null;

let _volumeRoot: Root | null = null;
let _volumeContainer: HTMLElement | null = null;

export const initPlaybackBar = (settings: any, send: (type: string, payload?: any) => Promise<any>) => {
    if (_activeRoot) {
        log('기존 재생바 인스턴스 발견, 파괴 후 재생성');
        _activeRoot.unmount();
        _activeRoot = null;
        if (_activeContainer) _activeContainer.remove();
        _activeRef = null;
    }

    const container = document.createElement('div');
    container.className = 'cqc-playback-bar-react-root';
    document.body.appendChild(container);

    const root = createRoot(container);
    _activeRoot = root;
    _activeContainer = container;

    const ref = React.createRef<PlaybackBarRootRef>();
    root.render(<PlaybackBarRoot ref={ref} settings={settings} send={send} />);

    // 마운트 시 참조 저장 (약간 지연될 수 있으나 프록시 객체를 반환함)
    setTimeout(() => {
        if (ref.current) _activeRef = ref.current;
    }, 0);

    return {
        destroy: () => {
            log('재생바 파괴');
            if (_activeRoot) {
                _activeRoot.unmount();
                _activeRoot = null;
            }
            if (_activeContainer) {
                _activeContainer.remove();
                _activeContainer = null;
            }
            _activeRef = null;
        },
        update: (state: PlayerState) => {
            if (_activeRef) _activeRef.updateState(state);
            else if (ref.current) ref.current.updateState(state);
        },
        initPlaybackSpeed: () => {
            if (_activeRef) _activeRef.enablePlaybackSpeed(true);
            else if (ref.current) ref.current.enablePlaybackSpeed(true);
        },
        destroyPlaybackSpeed: () => {
            if (_activeRef) _activeRef.enablePlaybackSpeed(false);
            else if (ref.current) ref.current.enablePlaybackSpeed(false);
        },
        resetPlaybackSpeed: () => {
            if (_activeRef) _activeRef.resetPlaybackSpeed();
            else if (ref.current) ref.current.resetPlaybackSpeed();
        },
        get ui() { return container; }
    };
};

export const initPlayerUIHooks = (state: any, settings: any) => {
    log('initPlayerUIHooks 시작 (React 전환)');
    if (_volumeRoot) {
        _volumeRoot.unmount();
        _volumeRoot = null;
    }
    if (_volumeContainer) {
        _volumeContainer.remove();
        _volumeContainer = null;
    }

    const container = document.createElement('div');
    container.className = 'cqc-volume-indicator-react-root';
    document.body.appendChild(container);
    
    const root = createRoot(container);
    _volumeRoot = root;
    _volumeContainer = container;
    
    root.render(<VolumeIndicator state={state} settings={settings} />);
};

export { PlaybackBarRoot } from './PlaybackBarRoot';
export { VolumeIndicator } from './VolumeIndicator';
