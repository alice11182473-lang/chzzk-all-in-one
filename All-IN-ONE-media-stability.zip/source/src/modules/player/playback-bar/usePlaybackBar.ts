import { useRef, useMemo, useEffect } from 'react';

export interface PlayerStateDebug {
    currentTime: number;
    duration: number;
    onLive: boolean;
    live: boolean;
    timeMachine: boolean;
    seekableStart?: number;
}

export interface PlayerState {
    debug: PlayerStateDebug;
    currentLatency?: number;
    seekableStart?: number;
}

export function usePlaybackBar(playerState: PlayerState | null, isDragging: boolean) {
    const latencyHistory = useRef<number[]>([]);
    const lastSafeMargin = useRef<number>(1.0);
    const lastDisplayPercent = useRef<number | undefined>(undefined);

    // 방송 변경 또는 새 HLS 스트림 감지 시 상태 강제 초기화
    const prevDuration = useRef<number>(0);
    useEffect(() => {
        if (!playerState?.debug) return;
        const duration = playerState.debug.duration;
        if (prevDuration.current && (prevDuration.current - duration > 60 || duration - prevDuration.current > 3600)) {
            lastDisplayPercent.current = undefined;
            latencyHistory.current = [];
            lastSafeMargin.current = 1.0;
        }
        prevDuration.current = duration;
    }, [playerState?.debug?.duration]);

    const trackLiveMargin = (state: PlayerState) => {
        const curLat = state.currentLatency;
        if (typeof curLat === 'number' && curLat > 0 && curLat < 30) {
            latencyHistory.current.push(curLat);
            if (latencyHistory.current.length > 50) latencyHistory.current.shift();
        }

        if (latencyHistory.current.length > 0) {
            const minObserved = Math.min(...latencyHistory.current);
            lastSafeMargin.current = Math.min(6, Math.max(1.5, minObserved - 0.5));
        }
        return lastSafeMargin.current;
    };

    const getBufferedEnd = () => {
        try {
            const video = (
                document.querySelector('video.webplayer-internal-video') ??
                document.querySelector('video')
            ) as HTMLVideoElement | null;
            if (video && video.buffered && video.buffered.length > 0) {
                const end = video.buffered.end(video.buffered.length - 1);
                if (isFinite(end) && end > 0) return end;
            }
        } catch (_) { }
        return null;
    };

    const seekRangeInfo = useMemo(() => {
        if (!playerState || !playerState.debug) return null;
        
        const s = playerState.debug;
        let duration = s.duration;
        
        if (!isFinite(duration)) {
            const lat = typeof playerState.currentLatency === 'number' ? playerState.currentLatency : 0;
            duration = s.currentTime + (lat >= 0 ? lat : 0);
        }
        if (!isFinite(duration) || duration <= 0) return null;

        const seekableStart = playerState.seekableStart || 0;
        trackLiveMargin(playerState);

        const effectiveStart = seekableStart > 0 ? seekableStart + 2.0 : 0;
        const bufferedEnd = s.live === true ? getBufferedEnd() : null;
        const liveEdge = bufferedEnd ?? duration;
        const endMargin = bufferedEnd !== null ? 0.5 : lastSafeMargin.current;
        const effectiveEnd = Math.max(effectiveStart + 0.1, liveEdge - endMargin);
        const effectiveDuration = Math.max(0.1, effectiveEnd - effectiveStart);

        return { effectiveStart, effectiveEnd, effectiveDuration, liveEdge, duration, seekableStart };
    }, [playerState]);

    const displayState = useMemo(() => {
        if (!seekRangeInfo || !playerState) return null;
        const s = playerState.debug;
        const { effectiveStart, effectiveDuration, liveEdge, duration, seekableStart } = seekRangeInfo;
        const current = s.currentTime;
        const diff = current - liveEdge;

        const isLivePlayback = s.live === true;
        const isEffectivelyLive = isLivePlayback && (s.onLive || diff >= -2.5);
        const displayOffset = isEffectivelyLive ? 0 : Math.min(0, diff);

        let displayPercent = isEffectivelyLive ? 1 : Math.min(1, Math.max(0, (current - effectiveStart) / effectiveDuration));

        if (isLivePlayback && !isEffectivelyLive && lastDisplayPercent.current !== undefined && !isDragging) {
            const jitterThreshold = 1.5 / effectiveDuration;
            if (displayPercent < lastDisplayPercent.current && (lastDisplayPercent.current - displayPercent) <= jitterThreshold) {
                displayPercent = lastDisplayPercent.current;
            }
        }
        
        if (!isDragging) {
            lastDisplayPercent.current = displayPercent;
        }

        return {
            isLivePlayback,
            isEffectivelyLive,
            displayOffset,
            displayPercent,
            duration,
            seekableStart,
            effectiveStart,
            effectiveDuration,
            liveEdge
        };
    }, [seekRangeInfo, playerState, isDragging]);

    return displayState;
}
