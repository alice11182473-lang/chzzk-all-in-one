import React, { useRef, useState, useEffect, PointerEvent, KeyboardEvent } from 'react';
import { createPortal } from 'react-dom';
import { useThumbnail } from './useThumbnail';
import { usePlaybackBar, PlayerState } from './usePlaybackBar';

interface PlaybackBarUIProps {
    settings: any;
    send: (type: string, payload?: any) => Promise<any>;
    playerState: PlayerState | null;
    playerContainer: Element | null;
}

const formatOffsetTime = (seconds: number) => {
    if (isNaN(seconds) || !isFinite(seconds)) return '00:00';
    const abs = Math.abs(seconds);
    const h = Math.floor(abs / 3600);
    const m = Math.floor((abs % 3600) / 60);
    const s = Math.floor(abs % 60);
    const pad = (n: number) => String(n).padStart(2, '0');
    const str = h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
    return seconds < -0.5 ? `-${str}` : str;
};

export const PlaybackBarUI: React.FC<PlaybackBarUIProps> = ({ settings, send, playerState, playerContainer }) => {
    const barRef = useRef<HTMLDivElement>(null);
    const [isDragging, setIsDragging] = useState(false);
    const [hoverPercent, setHoverPercent] = useState<number>(-1);
    const [hoverThumbUrl, setHoverThumbUrl] = useState<string | null>(null);
    const [isFullscreen, setIsFullscreen] = useState(false);

    const { captureThumbnail, fetchThumbnail } = useThumbnail();
    const displayState = usePlaybackBar(playerState, isDragging);

    useEffect(() => {
        if (playerState?.debug?.currentTime) {
            captureThumbnail(playerState.debug.currentTime);
        }
    }, [playerState?.debug?.currentTime, captureThumbnail]);

    useEffect(() => {
        const onFullscreenChange = () => {
            const isFs = !!(
                document.fullscreenElement ||
                (document as any).webkitFullscreenElement ||
                (document as any).mozFullScreenElement
            );
            setIsFullscreen(isFs);
        };
        document.addEventListener('fullscreenchange', onFullscreenChange);
        document.addEventListener('webkitfullscreenchange', onFullscreenChange);
        document.addEventListener('mozfullscreenchange', onFullscreenChange);
        onFullscreenChange();
        return () => {
            document.removeEventListener('fullscreenchange', onFullscreenChange);
            document.removeEventListener('webkitfullscreenchange', onFullscreenChange);
            document.removeEventListener('mozfullscreenchange', onFullscreenChange);
        };
    }, []);

    useEffect(() => {
        const onKeyDown = (e: globalThis.KeyboardEvent) => {
            if (!playerState || !settings?.playbackBarEnabled) return;
            const target = e.target as HTMLElement;
            if (target.matches('input, textarea, [contenteditable="true"]') || target.isContentEditable) return;

            if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
                e.preventDefault();
                e.stopImmediatePropagation();

                const video = (
                    document.querySelector('video.webplayer-internal-video') ??
                    document.querySelector('video')
                ) as HTMLVideoElement | null;

                const delta = e.key === 'ArrowLeft' ? -10 : 10;
                const currentTime = video ? video.currentTime : playerState.debug.currentTime;

                if (!displayState) return;
                const { effectiveStart, effectiveDuration } = displayState;
                const effectiveEnd = effectiveStart + effectiveDuration;

                let targetTime = currentTime + delta;
                if (targetTime < effectiveStart) targetTime = effectiveStart;
                if (targetTime > effectiveEnd) targetTime = effectiveEnd;

                // 탐색 명령 전송
                send('CQC_SEEK', { time: targetTime });
            }
        };
        document.addEventListener('keydown', onKeyDown, { capture: true });
        return () => document.removeEventListener('keydown', onKeyDown, { capture: true });
    }, [playerState, displayState, settings?.playbackBarEnabled, send]);

    const getPercent = (e: React.PointerEvent<HTMLDivElement>) => {
        if (!barRef.current) return -1;
        const rect = barRef.current.getBoundingClientRect();
        if (rect.width === 0) return -1;
        return Math.max(0, Math.min(e.clientX - rect.left, rect.width)) / rect.width;
    };

    const updatePreview = async (e: React.PointerEvent<HTMLDivElement>) => {
        const percent = getPercent(e);
        if (percent < 0 || !displayState) return;
        
        setHoverPercent(percent);
        const { effectiveStart, effectiveDuration } = displayState;
        const targetTime = effectiveStart + (effectiveDuration * percent);
        
        const url = await fetchThumbnail(targetTime);
        if (url !== null) {
            setHoverThumbUrl(url);
        }
    };

    const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
        e.stopPropagation();
        e.preventDefault();
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        setIsDragging(true);
        updatePreview(e);
    };

    const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
        updatePreview(e);
    };

    const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
        if (isDragging) {
            try { (e.target as HTMLElement).releasePointerCapture(e.pointerId); } catch (_) { }

            const percent = getPercent(e);
            if (percent >= 0 && displayState) {
                const { effectiveStart, effectiveDuration } = displayState;
                if (percent > 0.998) {
                    send('CQC_GO_LIVE');
                } else {
                    let targetTime = effectiveStart + (effectiveDuration * percent);
                    if (targetTime < effectiveStart) targetTime = effectiveStart;
                    send('CQC_SEEK', { time: targetTime });
                }
            }
        }
        setIsDragging(false);
        setHoverPercent(-1);
    };

    const onMouseLeave = () => {
        if (!isDragging) setHoverPercent(-1);
    };

    const onLiveBtnClick = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        send('CQC_GO_LIVE');
    };

    if (!displayState) return null;

    const {
        isLivePlayback,
        isEffectivelyLive,
        displayOffset,
        displayPercent,
        duration,
        seekableStart,
        effectiveStart,
        effectiveDuration,
        liveEdge
    } = displayState;

    const currentPercent = isDragging && hoverPercent >= 0 ? hoverPercent : displayPercent;

    const showHover = hoverPercent >= 0;
    const hoverTargetTime = effectiveStart + (effectiveDuration * hoverPercent);
    const hoverOffset = hoverTargetTime - liveEdge;

    const isTopRight = settings?.playbackBarTimeTopRight !== false;

    return (
        <>
            {isTopRight && playerContainer && createPortal(
                <div className={`cqc-pb-info ${isFullscreen ? 'is-fullscreen' : ''}`}>
                    {settings?.playbackBarTimeEnabled !== false && (
                        <span className="cqc-pb-time">{formatOffsetTime(displayOffset)}</span>
                    )}
                    <button className={`cqc-pb-live-btn ${isEffectivelyLive ? 'is-live' : ''}`} onClick={onLiveBtnClick}>
                        <span className="cqc-pb-live-dot"></span>LIVE
                    </button>
                </div>,
                playerContainer
            )}
            
            <div className={`cqc-playback-bar-container ${isEffectivelyLive ? 'is-live-edge' : ''} ${isDragging ? 'is-dragging' : ''} ${isFullscreen ? 'is-fullscreen' : ''}`}>
                {!isTopRight && (
                    <div className="cqc-pb-info">
                        {settings?.playbackBarTimeEnabled !== false && (
                            <span className="cqc-pb-time">{formatOffsetTime(displayOffset)}</span>
                        )}
                        <button className={`cqc-pb-live-btn ${isEffectivelyLive ? 'is-live' : ''}`} onClick={onLiveBtnClick}>
                            <span className="cqc-pb-live-dot"></span>LIVE
                        </button>
                    </div>
                )}
                
                <div 
                    className="cqc-playback-bar" 
                    ref={barRef}
                    onPointerDown={onPointerDown}
                    onPointerMove={onPointerMove}
                    onPointerUp={onPointerUp}
                    onPointerCancel={onPointerUp}
                    onMouseLeave={onMouseLeave}
                >
                    <div className="cqc-pb-track">
                        <div 
                            className="cqc-pb-dvrzone" 
                            style={{ display: isLivePlayback && duration > 0 && seekableStart > 0 ? 'block' : 'none', width: '1%' }} 
                        />
                        <div 
                            className="cqc-pb-redzone" 
                            style={{ display: isLivePlayback && duration > 0 ? 'block' : 'none', width: '1.2%' }}
                        >
                            <div className="cqc-pb-redzone-label">실시간 방송 지점 (클릭 시 마지막 데이터로 재생)</div>
                        </div>
                        <div className="cqc-pb-progress" style={{ width: `${currentPercent * 100}%` }} />
                    </div>
                    
                    <div className="cqc-pb-hover-container" style={{ opacity: showHover ? 1 : 0, left: `${hoverPercent * 100}%` }}>
                        <img className="cqc-pb-hover-thumb" src={hoverThumbUrl || undefined} style={{ display: hoverThumbUrl ? 'block' : 'none' }} />
                        <div className="cqc-pb-hover-time">{showHover ? formatOffsetTime(hoverOffset) : '00:00'}</div>
                    </div>

                    <div className="cqc-pb-handle" style={{ left: `${currentPercent * 100}%` }} />
                </div>
            </div>
        </>
    );
};
