import React, { useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { createPortal } from 'react-dom';
import { PlaybackBarUI } from './PlaybackBarUI';
import { PlaybackSpeedMenu } from './PlaybackSpeedMenu';
import { SELECTORS, log as cqcLog } from '../../../../dom-utils';
import { PlayerState } from './usePlaybackBar';

const log = (...args: any[]) => cqcLog('PlaybackBarRoot', ...args);

export interface PlaybackBarRootProps {
    settings: any;
    send: (type: string, payload?: any) => Promise<any>;
}

export interface PlaybackBarRootRef {
    updateState: (state: PlayerState) => void;
    resetPlaybackSpeed: () => void;
    enablePlaybackSpeed: (enable: boolean) => void;
}

export const PlaybackBarRoot = forwardRef<PlaybackBarRootRef, PlaybackBarRootProps>(({ settings, send }, ref) => {
    const [playerState, setPlayerState] = useState<PlayerState | null>(null);
    const [speedEnabled, setSpeedEnabled] = useState(!!settings?.playbackSpeedEnabled);
    const [bottomBar, setBottomBar] = useState<Element | null>(null);
    const [playerContainer, setPlayerContainer] = useState<Element | null>(null);
    const [speedContainer, setSpeedContainer] = useState<HTMLElement | null>(null);
    const [speedKey, setSpeedKey] = useState(0);

    useEffect(() => {
        setSpeedEnabled(!!settings?.playbackSpeedEnabled);
    }, [settings?.playbackSpeedEnabled]);

    useEffect(() => {
        if (settings?.playbackBarTimeTopRight !== false) {
            document.documentElement.classList.add('cqc-pb-time-top-right-active');
        } else {
            document.documentElement.classList.remove('cqc-pb-time-top-right-active');
        }
        return () => {
            document.documentElement.classList.remove('cqc-pb-time-top-right-active');
        };
    }, [settings?.playbackBarTimeTopRight]);

    useImperativeHandle(ref, () => ({
        updateState: (state: PlayerState) => {
            setPlayerState(state);
        },
        resetPlaybackSpeed: () => {
            const v = document.querySelector('video') as HTMLVideoElement | null;
            if (v) v.playbackRate = 1.0;
            // Key 변경으로 PlaybackSpeedMenu를 다시 마운트하여 내부 상태 초기화
            setSpeedKey(k => k + 1);
        },
        enablePlaybackSpeed: (enable: boolean) => {
            setSpeedEnabled(enable);
        }
    }));

    useEffect(() => {
        // 포탈용 DOM 컨테이너 탐색
        const updateContainers = () => {
            const player = document.querySelector(SELECTORS.PLAYER_PC);
            if (!player) return;

            setPlayerContainer(prev => prev !== player ? player : prev);

            let bBar = player.querySelector(SELECTORS.PLAYER_BOTTOM);
            if (bBar && (bBar.classList.contains('pzp-pc__video') || bBar.classList.contains('pzp-pc__poster'))) {
                bBar = player.querySelector('.pzp-pc__bottom') || player.querySelector('.pzp-pc-bottom');
            }
            if (bBar) {
                setBottomBar(prev => prev !== bBar ? bBar : prev);
            }

            const rControls = player.querySelector(SELECTORS.PLAYER_CONTROL_BAR_RIGHT);
            if (rControls) {
                let container = rControls.querySelector('#cqc-speed-container') as HTMLElement | null;
                if (!container) {
                    container = document.createElement('div');
                    container.id = 'cqc-speed-container';
                    container.style.display = 'contents';

                    const recBtn = rControls.querySelector('#cqc-record-btn');
                    const qualityBtn = rControls.querySelector(SELECTORS.PLAYER_SETTING_BTN) || 
                                     rControls.querySelector('.pzp-pc-setting-button') || 
                                     rControls.querySelector('.pzp-ui-setting-button');

                    if (recBtn) {
                        if (recBtn.nextSibling) rControls.insertBefore(container, recBtn.nextSibling);
                        else rControls.appendChild(container);
                    } else if (qualityBtn) {
                        rControls.insertBefore(container, qualityBtn);
                    } else {
                        const fullscreenBtn = rControls.querySelector(SELECTORS.PLAYER_FULLSCREEN_BTN);
                        if (fullscreenBtn) {
                            rControls.insertBefore(container, fullscreenBtn);
                        } else {
                            rControls.appendChild(container);
                        }
                    }
                }
                const targetContainer = container;
                setSpeedContainer(prev => prev !== targetContainer ? targetContainer : prev);
            }
        };

        const interval = setInterval(updateContainers, 800);
        updateContainers();

        return () => {
            clearInterval(interval);
            const container = document.getElementById('cqc-speed-container');
            if (container) container.remove();
        };
    }, []);

    useEffect(() => {
        // 네이티브 UI 토글
        const isLiveMode = !!document.querySelector(SELECTORS.PLAYER_PC)?.classList.contains('pzp-pc--live');
        const hide = isLiveMode && settings?.playbackBarEnabled;

        const elements = [
            document.querySelector(SELECTORS.NATIVE_PROGRESS_SLIDER),
            document.querySelector(SELECTORS.NATIVE_SLIDER_WRAP)
        ].filter(el => !!el) as HTMLElement[];

        for (const el of elements) {
            if (hide) {
                if (el.dataset.cqcOriginalDisplay === undefined) {
                    el.dataset.cqcOriginalDisplay = el.style.display || '';
                }
                el.style.display = 'none';
            } else {
                if (el.dataset.cqcOriginalDisplay !== undefined) {
                    el.style.display = el.dataset.cqcOriginalDisplay;
                    delete el.dataset.cqcOriginalDisplay;
                } else {
                    el.style.display = '';
                }
            }
        }
    }, [playerState?.debug?.duration, settings?.playbackBarEnabled]);

    // UI 주입 여부 판단
    const isLiveMode = !!document.querySelector(SELECTORS.PLAYER_PC)?.classList.contains('pzp-pc--live');
    const shouldRenderBar = isLiveMode && settings?.playbackBarEnabled && bottomBar;

    return (
        <>
            {shouldRenderBar && createPortal(
                <PlaybackBarUI settings={settings} send={send} playerState={playerState} playerContainer={playerContainer} />,
                bottomBar
            )}
            
            {speedEnabled && speedContainer && createPortal(
                <PlaybackSpeedMenu key={speedKey} settings={settings} onRateChange={(rate) => send('SET_PLAYBACK_SPEED', rate)} />,
                speedContainer
            )}
        </>
    );
});

