import React, { useState, useEffect, useRef } from 'react';
import { SELECTORS } from '../../../../dom-utils';

interface PlaybackSpeedMenuProps {
    settings: any;
    onRateChange?: (rate: number) => void;
}

export const PlaybackSpeedMenu: React.FC<PlaybackSpeedMenuProps> = ({ settings, onRateChange }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [currentRate, setCurrentRate] = useState(1.0);
    const hideTimerRef = useRef<NodeJS.Timeout | null>(null);
    const containerRef = useRef<HTMLButtonElement>(null);

    useEffect(() => {
        if (!settings?.playbackSpeedEnabled) return;

        // 필요한 경우 스타일 주입 (일반적인 React에서는 css module이나 전역 css를 사용하지만, 원본처럼 단순하게 style 태그로 처리 가능)
        const STYLE_ID = 'cqc-playback-speed-style';
        if (!document.getElementById(STYLE_ID)) {
            const style = document.createElement('style');
            style.id = STYLE_ID;
            style.textContent = `
                .cqc-speed-menu { position: absolute; bottom: 100%; right: 0; background: rgba(20,20,20,0.95); border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; padding: 4px; display: none; flex-direction: column; gap: 2px; min-width: 65px; z-index: 1000; box-shadow: 0 4px 12px rgba(0,0,0,0.5); }
                .cqc-speed-menu.is-open { display: flex; }
                .pzp-pc--hide-ui .cqc-speed-menu, .pzp-pc:not(.pzp-pc--controls) .cqc-speed-menu { display: none !important; }
                #cqc-playback-speed.is-menu-open .pzp-button__tooltip { display: none !important; }
                .cqc-speed-item { padding: 8px 12px; border-radius: 3px; cursor: pointer; font-size: 13px; text-align: center; transition: background 0.2s, color 0.2s; color: #eee; font-family: 'Pretendard', sans-serif; }
                .cqc-speed-item:hover { background: rgba(255,255,255,0.1); color: #fff; }
                .cqc-speed-item.is-active { color: #00ffa3; font-weight: 700; background: rgba(0, 255, 163, 0.1); }
            `;
            document.head.appendChild(style);
        }

        const v = document.querySelector('video') as HTMLVideoElement | null;
        if (v) {
            const handleRateChange = () => {
                //console.log('[CQC:SpeedMenu] 비디오 playbackRate 변경 이벤트 감지:', v.playbackRate, '(기존 UI 속도:', currentRate, ')');
                if (v.playbackRate !== currentRate) {
                    setCurrentRate(v.playbackRate);
                }
            };
            v.addEventListener('ratechange', handleRateChange);
            return () => v.removeEventListener('ratechange', handleRateChange);
        }
    }, [settings?.playbackSpeedEnabled, currentRate]);

    useEffect(() => {
        const handleClickOutside = (e: MouseEvent) => {
            if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('click', handleClickOutside);
        return () => document.removeEventListener('click', handleClickOutside);
    }, []);

    const show = () => {
        if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
        setIsOpen(true);
    };

    const hide = () => {
        if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
        hideTimerRef.current = setTimeout(() => setIsOpen(false), 200);
    };

    const setSpeed = (e: React.MouseEvent, s: number) => {
        e.stopPropagation();
        //console.log('[CQC:SpeedMenu] UI에서 수동 배속 설정 클릭:', s);
        const v = document.querySelector('video') as HTMLVideoElement | null;
        if (v) {
            v.playbackRate = s;
            setCurrentRate(s);
            onRateChange?.(s);
            setIsOpen(false);
        }
    };

    if (!settings?.playbackSpeedEnabled) return null;

    return (
        <button
            ref={containerRef}
            id="cqc-playback-speed"
            className={`pzp-button pzp-pc-ui-button cqc-speed-btn ${isOpen ? 'is-menu-open' : ''}`}
            aria-label="재생 속도"
            onMouseEnter={show}
            onMouseLeave={hide}
        >
            <span className="pzp-button__tooltip pzp-button__tooltip--top">재생 속도 ({currentRate.toFixed(2)}x)</span>
            <span className="pzp-ui-icon">
                <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" className="pzp-ui-icon__svg">
                    <path d="M18 11V18L22 21" stroke="white" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="18" cy="18" r="10" stroke="white" strokeWidth="1.7" fill="none" />
                </svg>
            </span>
            <div className={`cqc-speed-menu ${isOpen ? 'is-open' : ''}`} onMouseEnter={show} onMouseLeave={hide}>
                {[0.5, 0.75, 1.0, 1.25, 1.5, 2.0].map(s => (
                    <div
                        key={s}
                        className={`cqc-speed-item ${s === currentRate ? 'is-active' : ''}`}
                        onClick={(e) => setSpeed(e, s)}
                    >
                        {s.toFixed(2)}x
                    </div>
                ))}
            </div>
        </button>
    );
};
