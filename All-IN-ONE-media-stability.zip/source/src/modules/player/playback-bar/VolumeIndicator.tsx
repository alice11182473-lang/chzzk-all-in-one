import React, { useEffect } from 'react';
import { SELECTORS, getReactStore } from '../../../../dom-utils';

export interface VolumeIndicatorProps {
    state: any;
    settings: any;
}

export const VolumeIndicator: React.FC<VolumeIndicatorProps> = ({ state, settings }) => {
    useEffect(() => {
        let tooltip: HTMLElement | null = null;
        let lastVol = -1;
        let lastMuted = false;
        let lastRect = { left: 0, top: 0, width: 0 };
        let rafId: number | null = null;

        const updateVolumeTooltip = (volControl: HTMLElement, force = false) => {
            if (!state.ready || !state.root) return;
            if (settings?.volumeIndicatorEnabled === false) {
                if (tooltip) tooltip.classList.remove('is-visible');
                return;
            }

            const video = (document.querySelector('video.webplayer-internal-video') || document.querySelector('video')) as HTMLVideoElement | null;

            let volume = 0;
            let muted = false;
            let hasValue = false;

            if (video) {
                volume = Math.round(video.volume * 100);
                muted = video.muted;
                hasValue = true;
            } else {
                const store = getReactStore(state.root as HTMLElement);
                const fs = store?.state;
                if (fs) {
                    let v = fs.volume != null ? fs.volume : (fs.player?.volume != null ? fs.player.volume : (state.core?.volume != null ? state.core.volume : 0));
                    volume = v > 1 ? Math.round(v) : Math.round(v * 100);
                    muted = !!(fs.muted || fs.player?.muted);
                    hasValue = true;
                }
            }

            if (!hasValue) return;

            const container = document.fullscreenElement || document.querySelector('.pzp') || document.body;

            if (!tooltip) {
                tooltip = document.createElement('div');
                tooltip.className = 'cqc-volume-indicator';
            }
            if (tooltip.parentElement !== container) {
                container.appendChild(tooltip);
            }

            if (force || volume !== lastVol || muted !== lastMuted) {
                lastVol = volume;
                lastMuted = muted;
                tooltip.textContent = muted ? '음소거' : `${volume}%`;
            }

            const rect = volControl.getBoundingClientRect();
            if (force || rect.left !== lastRect.left || rect.top !== lastRect.top || rect.width !== lastRect.width) {
                lastRect = { left: rect.left, top: rect.top, width: rect.width };

                const containerRect = container !== document.body ? container.getBoundingClientRect() : { left: 0, top: 0 };
                const left = rect.left + rect.width / 2 - containerRect.left;
                const top = rect.top - 10 - containerRect.top;

                tooltip.style.left = `${left}px`;
                tooltip.style.top = `${top}px`;
            }

            if (!tooltip.classList.contains('is-visible')) {
                tooltip.classList.add('is-visible');
            }
        };

        const onMouseOver = (e: MouseEvent) => {
            const target = e.target as HTMLElement;
            const volControl = target.closest(SELECTORS.PLAYER_VOLUME_CONTROL) as HTMLElement;
            if (!volControl) return;
            if (settings?.volumeIndicatorEnabled === false) return;

            const el = volControl as HTMLElement;
            if (el.dataset.cqcWatching === 'true') return;
            el.dataset.cqcWatching = 'true';

            const onMove = () => {
                if (rafId) return;
                rafId = requestAnimationFrame(() => {
                    updateVolumeTooltip(el);
                    rafId = null;
                });
            };

            const onLeave = () => {
                if (tooltip) tooltip.classList.remove('is-visible');
                el.removeEventListener('mousemove', onMove);
                el.removeEventListener('mouseleave', onLeave);
                delete el.dataset.cqcWatching;
                if (rafId) {
                    cancelAnimationFrame(rafId);
                    rafId = null;
                }
            };

            el.addEventListener('mousemove', onMove, { passive: true });
            el.addEventListener('mouseleave', onLeave);

            updateVolumeTooltip(el, true);
        };

        const onVolumeChange = () => {
            if (tooltip && tooltip.classList.contains('is-visible')) {
                const volControl = document.querySelector(SELECTORS.PLAYER_VOLUME_CONTROL) as HTMLElement;
                if (volControl) {
                    updateVolumeTooltip(volControl);
                }
            }
        };

        document.addEventListener('mouseover', onMouseOver, true);
        document.addEventListener('volumechange', onVolumeChange, true);

        return () => {
            document.removeEventListener('mouseover', onMouseOver, true);
            document.removeEventListener('volumechange', onVolumeChange, true);
            if (tooltip) {
                tooltip.remove();
            }
            if (rafId) cancelAnimationFrame(rafId);
        };
    }, [state, settings]);

    return null;
};
