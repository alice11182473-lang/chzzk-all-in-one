import { useEffect, useRef, useCallback } from 'react';
import { saveThumbnail, getClosestThumbnail, clearThumbnails } from '../../../../shared/db';
// @ts-ignore
import { createImageEncoderWorker } from '../../../../shared/worker';

const THUMB_WIDTH = 160;
const THUMB_HEIGHT = 90;

export function useThumbnail() {
    const workerRef = useRef<Worker | null>(null);
    const msgIdCounter = useRef(0);
    const lastCaptureTime = useRef(0);
    const _thumbRequestId = useRef(0);

    useEffect(() => {
        const worker = createImageEncoderWorker();
        worker.onmessage = (e: MessageEvent) => {
            if (e.data.status === 'success') {
                saveThumbnail(e.data.time, e.data.dataUrl).catch((err: any) => {
                    console.error('[CQC:PlaybackBar] 썸네일 DB 저장 실패:', err);
                });
            } else if (e.data.status === 'error') {
                console.error('[CQC:PlaybackBar] 워커 썸네일 인코딩 중 에러:', e.data.error);
            }
        };
        worker.onerror = (err: any) => console.error('[CQC:PlaybackBar] 워커 초기화/구동 에러:', err);
        workerRef.current = worker;

        return () => {
            if (workerRef.current) {
                try { workerRef.current.terminate(); } catch (e) {
                    console.error('[CQC:PlaybackBar] 워커 종료 권한 에러:', e);
                }
                workerRef.current = null;
            }
            clearThumbnails().catch((err: any) => {
                console.error('[CQC:PlaybackBar] 썸네일 정리 실패:', err);
            });
        };
    }, []);

    const captureThumbnail = useCallback((currentTime: number) => {
        try {
            if (!workerRef.current || document.visibilityState !== 'visible') return;

            const now = Date.now();
            if (now - lastCaptureTime.current < 1000) return;

            const video = (
                document.querySelector('video.webplayer-internal-video') ??
                document.querySelector('video')
            ) as HTMLVideoElement | null;
            
            if (!video || video.readyState < 2) return;

            lastCaptureTime.current = now;

            createImageBitmap(video, { resizeWidth: THUMB_WIDTH, resizeHeight: THUMB_HEIGHT })
                .then(bmp => {
                    if (workerRef.current) {
                        workerRef.current.postMessage({
                            id: msgIdCounter.current++,
                            type: 'ENCODE_IMAGE_BITMAP',
                            payload: { bmp, time: currentTime }
                        }, [bmp]);
                    }
                }).catch((e) => {
                    // console.error('[CQC:PlaybackBar] createImageBitmap 캡처 에러:', e);
                });
        } catch (e) {
            console.error('[CQC:PlaybackBar] captureThumbnail 치명적 에러:', e);
        }
    }, []);

    const fetchThumbnail = useCallback(async (targetTime: number) => {
        const requestId = ++_thumbRequestId.current;
        try {
            const url = await getClosestThumbnail(targetTime);
            if (requestId !== _thumbRequestId.current) return null; // 경쟁 조건 방어
            return url;
        } catch (err) {
            console.error('[CQC:PlaybackBar] 썸네일 불러오기 중 에러:', err);
            return null;
        }
    }, []);

    return { captureThumbnail, fetchThumbnail };
}
