// @ts-nocheck
import { initSharpness } from '../../../sharpness';
import { initAudio } from '../../../audio';
import { initScreenshot } from '../../../screenshot';
import { initRecorder } from '../../../recorder';
import { initAmbient, tryInjectAmbient, cleanupAmbient } from '../../../ambient';
import { initHoverPreview } from '../../../hover-preview';
import { initPlaybackBar } from '../../../playback-bar';
import { log as cqcLog } from '../../../dom-utils';
import { WatchTimerModule } from '../ui/WatchTimerModule';
import { initStreamStats, initContextMenuStats } from './stream-stats';
import { runtime } from '../../core/RuntimeManager';
import { UIVisibilityModule } from '../ui/UIVisibilityModule';

const log = (...args) => cqcLog('PlayerModule', ...args);

export class PlayerModule {
  mount(settings, sendFn, eventBus) {
    this.settings = settings;
    this.send = sendFn;
    this.eventBus = eventBus || runtime.eventBus;

    if (!navigator.userAgent.includes('Firefox')) {
      initSharpness();
    }
    initAudio();
    initScreenshot();
    initRecorder();
    initAmbient();
    initHoverPreview(this.settings);

    // Watch Timer (content.js 내부에 있던 로직 모듈화)
    window.cqcWatchTimer = WatchTimerModule.init(this.settings);

    // 타이머/옵저버 등록 (정리 목적으로 runtime의 배열 전달)
    initStreamStats(this.settings, this.send, runtime.cleanups || []);
    initContextMenuStats(this.settings, runtime.observers || []);
    UIVisibilityModule.applyMediaButtonVisibility(this.settings);

    // 재생 바
    this.initOrResetPlaybackBar();

    // 이벤트 구독
    if (this.eventBus) {
      this.eventBus.on('SETTINGS_UPDATED', (newSettings) => {
        this.settings = newSettings;
        this.initOrResetPlaybackBar();
        UIVisibilityModule.applyMediaButtonVisibility(this.settings);
        UIVisibilityModule.applyPlayerMenuVisibility(this.settings);
        // 기타 재설정이 필요한 훅들이 있으면 여기서 호출
      });

      this.eventBus.on('UI_VISIBILITY_UPDATE', () => {
        UIVisibilityModule.applyPlayerMenuVisibility(this.settings);
      });

      this.eventBus.on('TRIGGER_PLAYBACK_BAR', () => {
        this.initOrResetPlaybackBar();
      });

      this.eventBus.on('PLAYER_STATE_UPDATE', (payload) => {
        if (this.pb) {
          this.pb.update(payload);
        }
      });

      this.eventBus.on('RESET_PLAYBACK_SPEED_REQ', () => {
        console.log('[CQC:Content] RESET_PLAYBACK_SPEED_REQ 수신 -> 재생 배속 리셋 수행');
        if (this.pb) {
          this.pb.resetPlaybackSpeed();
        }
      });

      this.eventBus.on('RESET_PLAYBACK_SPEED', () => {
        console.log('[CQC:Content] RESET_PLAYBACK_SPEED 수신 -> 재생 배속 리셋 수행');
        if (this.pb) {
          this.pb.resetPlaybackSpeed();
        }
      });
    }
  }

  initOrResetPlaybackBar() {
    if (this.pb) {
      this.pb.destroy?.();
      this.pb = null;
    }
    this.pb = initPlaybackBar(this.settings, this.send);
    if (this.settings?.playbackSpeedEnabled && this.pb) {
      this.pb.initPlaybackSpeed();
    }
  }

  cleanup() {
    if (this.pb) {
      this.pb.destroy?.();
      this.pb = null;
    }
    if (typeof cleanupAmbient === 'function') {
      cleanupAmbient(true);
    }
  }

  onRouteChange(routeInfo, settings) {
    this.settings = settings || this.settings;

    // 라우트 변경 시 떠 있는 미리보기 카드 즉시 숨김
    if (window.cqcHoverPreview && typeof window.cqcHoverPreview.hideCard === 'function') {
      window.cqcHoverPreview.hideCard();
    }

    // 앰비언트 등 기타 갱신 로직
    if (routeInfo.isLive) {
      if (typeof tryInjectAmbient === 'function') {
        tryInjectAmbient();
        setTimeout(() => { tryInjectAmbient(); }, 500);
        setTimeout(() => { tryInjectAmbient(); }, 1500);
        setTimeout(() => { tryInjectAmbient(); }, 3000);
      }
    } else {
      if (typeof cleanupAmbient === 'function') {
        cleanupAmbient(true);
      }
    }
  }
}
