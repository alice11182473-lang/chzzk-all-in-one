import { SELECTORS, initSelectors, showToast, DEFAULT_SELECTORS } from '../../../dom-utils';
import { generateRobustSelector, getFiberComponentPath, testSelector, findMatchingSelectorKey, SelectorCandidate } from '../../utils/SelectorEngine';

const SLOT_GROUPS: Record<string, string[]> = {
    '🎬 플레이어': [
        'PLAYER', 'PLAYER_CONTAINER', 'PLAYER_BOTTOM', 'PLAYER_CONTROL_BAR', 
        'PLAYER_CONTROL_BAR_RIGHT', 'PLAYER_SETTING_BTN', 'PLAYER_LIVE_INDICATOR', 
        'PLAYER_VOLUME_CONTROL', 'PLAYER_TIME_DISPLAY', 'PLAYER_FULLSCREEN_BTN', 
        'PLAYER_QUALITY_ITEM', 'PLAYER_QUALITY_ITEM_PREFIX', 'PLAYER_BUTTON_TOOLTIP', 
        'CONTEXT_MENU_PANE', 'CONTEXT_MENU_LIST', 'SETTINGS_MENU', 
        'NATIVE_PROGRESS_SLIDER', 'NATIVE_SLIDER_WRAP', 'VIEW_MODE_BTN'
    ],
    '📂 사이드바': [
        'SIDEBAR_ASIDE', 'SIDEBAR_ASIDE_WRAPPER', 'SIDEBAR_CONTENT', 
        'SIDEBAR_LIST_CONTAINER', 'SIDEBAR_ITEM', 'SIDEBAR_NAV_LINK', 
        'SIDEBAR_LIVE_INDICATOR', 'SIDEBAR_OBSERVER_SPINNER', 'SIDEBAR_REFRESH_BTN', 
        'SIDEBAR_BANNER', 'SIDEBAR_MENU_LINK', 'FOLLOWING_ANCHOR', 
        'NAV_ITEM', 'NAV_SECTION', 'NAV_TITLE', 'LAYOUT_BODY'
    ],
    '💬 채팅': [
        'CHAT_ASIDE', 'CHAT_CONTAINER', 'CHAT_BLINDED_CONTAINER', 'CHAT_DONATION', 
        'CHAT_FOLD_BTN', 'CHAT_HEADER', 'CHAT_ITEM', 'CHAT_ITEM_CONTAINER', 
        'CHAT_LIST_CONTAINER', 'CHAT_LIST_WRAPPER_ALT', 'CHAT_MESSAGE', 
        'CHAT_MESSAGE_TEXT', 'CHAT_MORE_MENU_BTN', 'CHAT_NICKNAME', 
        'CHAT_PROFILE_INFO', 'CHAT_PROFILE_POPUP', 'VOD_RECOMMEND'
    ],
    '🖥 UI/레이아웃': [
        'AD_POPUP', 'HOME_BANNER', 'RS_BANNER', 'MORE_BTN', 'TOPIC_TAB_CONTAINER', 
        'TOPIC_TAB_ELEMENTS', 'TOPIC_TAB_LIST', 'TAB_ITEM', 'TAB_LIST', 'TOOLBAR_BOX', 
        'TOOLBAR_BOX_ALT', 'TOOLBAR_ITEM', 'TOOLBAR_PROFILE_BTN', 'VIDEO_INFO_DATA', 
        'VIDEO_ITEM', 'VIDEO_LIST', 'LIVE_INFO_CONTAINER', 'LIVE_INFO_DETAILS', 
        'LIVE_INFO_LAYER', 'LIVE_LINK', 'LIVE_PLAYER_ALT', 'LIVE_VIDEO_CONTAINER', 
        'STREAMER_SHOP', 'STUDIO_BUTTON'
    ],
    '🔧 헤더/기타': [
        'CHEAT_KEY_BTN', 'CHEAT_KEY_CLOSE_BTN', 'CHEAT_KEY_POPUP', 
        'CHEAT_KEY_TOOLTIP_CLOSE_BTN', 'CHEAT_KEY_TOOLTIP_CONTAINER', 
        'CHEESE_BTN', 'NOTI_BTN', 'THEME_BTN'
    ]
};

const SLOT_NAMES: Record<string, string> = {
    'PLAYER': '비디오 플레이어',
    'PLAYER_CONTAINER': '플레이어 컨테이너',
    'PLAYER_BOTTOM': '플레이어 하단 컨트롤 영역',
    'PLAYER_CONTROL_BAR': '재생 컨트롤 바',
    'PLAYER_CONTROL_BAR_RIGHT': '컨트롤 바 우측 영역',
    'PLAYER_SETTING_BTN': '플레이어 설정 버튼',
    'PLAYER_LIVE_INDICATOR': '라이브 방송 표시기',
    'PLAYER_VOLUME_CONTROL': '음량 조절 영역',
    'PLAYER_TIME_DISPLAY': '재생 시간 표시기',
    'PLAYER_FULLSCREEN_BTN': '전체화면 버튼',
    'PLAYER_QUALITY_ITEM': '화질 설정 메뉴 항목',
    'PLAYER_QUALITY_ITEM_PREFIX': '선택 화질 체크마크',
    'PLAYER_BUTTON_TOOLTIP': '플레이어 버튼 툴팁',
    'CONTEXT_MENU_PANE': '플레이어 우클릭 커스텀 메뉴',
    'CONTEXT_MENU_LIST': '우클릭 메뉴 항목 리스트',
    'SETTINGS_MENU': '플레이어 설정 레이어',
    'NATIVE_PROGRESS_SLIDER': 'VOD 탐색 슬라이더',
    'NATIVE_SLIDER_WRAP': 'VOD 탐색 슬라이더 래퍼',
    'VIEW_MODE_BTN': '화면 뷰 모드 전환 버튼',
    'SIDEBAR_ASIDE': '좌측 사이드바 전체',
    'SIDEBAR_ASIDE_WRAPPER': '사이드바 컨테이너',
    'SIDEBAR_CONTENT': '사이드바 콘텐츠 영역',
    'SIDEBAR_LIST_CONTAINER': '팔로우 채널 목록',
    'SIDEBAR_ITEM': '팔로우 채널 항목',
    'SIDEBAR_NAV_LINK': '사이드바 내 개별 메뉴 링크',
    'SIDEBAR_LIVE_INDICATOR': '사이드바 라이브 배지',
    'SIDEBAR_OBSERVER_SPINNER': '사이드바 무한스크롤 로딩',
    'SIDEBAR_REFRESH_BTN': '사이드바 새로고침 버튼',
    'SIDEBAR_BANNER': '사이드바 광고 배너',
    'SIDEBAR_MENU_LINK': '사이드바 메인 메뉴 링크',
    'FOLLOWING_ANCHOR': '팔로잉 바로가기 링크',
    'NAV_ITEM': '네비게이션 메뉴 버튼',
    'NAV_SECTION': '사이드바 그룹 헤더',
    'NAV_TITLE': '사이드바 그룹 제목',
    'LAYOUT_BODY': '치지직 레이아웃 본문',
    'CHAT_ASIDE': '우측 채팅창 영역',
    'CHAT_CONTAINER': '실시간 채팅 메시지 창',
    'CHAT_BLINDED_CONTAINER': '가려진 채팅 가림막',
    'CHAT_DONATION': '후원(치즈) 메시지 컨테이너',
    'CHAT_FOLD_BTN': '채팅창 접기/열기 버튼',
    'CHAT_HEADER': '채팅창 헤더 영역',
    'CHAT_ITEM': '개별 채팅 메시지 행',
    'CHAT_ITEM_CONTAINER': '채팅 메시지 본문 영역',
    'CHAT_LIST_CONTAINER': '채팅 메시지 목록',
    'CHAT_LIST_WRAPPER_ALT': '채팅창 스크롤 래퍼',
    'CHAT_MESSAGE': '채팅 메시지 텍스트 래퍼',
    'CHAT_MESSAGE_TEXT': '채팅 텍스트 내용',
    'CHAT_MORE_MENU_BTN': '채팅 더보기 메뉴 버튼',
    'CHAT_NICKNAME': '채팅창 유저 닉네임',
    'CHAT_PROFILE_INFO': '유저 프로필 요약 카드',
    'CHAT_PROFILE_POPUP': '프로필 정보 팝업',
    'VOD_RECOMMEND': 'VOD 종료 추천 영상',
    'AD_POPUP': '진입 시 광고 팝업',
    'HOME_BANNER': '홈 최상단 배너 광고',
    'RS_BANNER': '추천 스트리머 우측 광고',
    'MORE_BTN': '목록 하단 더보기 버튼',
    'TOPIC_TAB_CONTAINER': '토픽 분류 탭 컨테이너',
    'TOPIC_TAB_ELEMENTS': '토픽 탭 개별 항목',
    'TOPIC_TAB_LIST': '토픽 탭 전체 목록',
    'TAB_ITEM': '일반 탭 버튼',
    'TAB_LIST': '일반 탭 목록',
    'TOOLBAR_BOX': '헤더 툴바 영역 박스',
    'TOOLBAR_BOX_ALT': '대체 헤더 툴바 박스',
    'TOOLBAR_ITEM': '헤더 툴바 개별 아이템',
    'TOOLBAR_PROFILE_BTN': '우측 상단 프로필 버튼',
    'VIDEO_INFO_DATA': '방송 상세 정보 영역',
    'VIDEO_ITEM': '방송/VOD 썸네일 카드',
    'VIDEO_LIST': '비디오 카드 그리드 목록',
    'LIVE_INFO_CONTAINER': '라이브 방송 정보 박스',
    'LIVE_INFO_DETAILS': '라이브 방송 상세 설명',
    'LIVE_INFO_LAYER': '라이브 썸네일 오버레이',
    'LIVE_LINK': '라이브 방송 이동 링크',
    'LIVE_PLAYER_ALT': '라이브 플레이어 대체 영역',
    'LIVE_VIDEO_CONTAINER': '라이브 비디오 컨테이너',
    'STREAMER_SHOP': '굿즈 샵 연동 영역',
    'STUDIO_BUTTON': '스트리머 스튜디오 이동 버튼',
    'CHEAT_KEY_BTN': '치트키 팝업 활성화 버튼',
    'CHEAT_KEY_CLOSE_BTN': '치트키 팝업 닫기 버튼',
    'CHEAT_KEY_POPUP': '치트키 이모티콘 팝업 창',
    'CHEAT_KEY_TOOLTIP_CLOSE_BTN': '치트키 툴팁 닫기 버튼',
    'CHEAT_KEY_TOOLTIP_CONTAINER': '치트키 도움말 컨테이너',
    'CHEESE_BTN': '치즈 후원하기 버튼',
    'NOTI_BTN': '우측 상단 알림 버튼',
    'THEME_BTN': '테마 전환(다크/라이트) 버튼'
};


const SLOT_DESCRIPTIONS: Record<string, string> = {
    // 플레이어
    'PLAYER': '치지직 웹 플레이어의 핵심 비디오 요소(video 태그). [단축키 제어, 재생 속도 조절, 마우스 휠 볼륨 조절] 기능이 비디오 요소에 직접 접근하기 위해 필수적입니다.',
    'PLAYER_CONTAINER': '웹 플레이어 전체를 감싸는 최상위 컨테이너. [플레이어 레이아웃 모드 감지 및 단축키 활성화 판별]을 위해 필요한 영역입니다.',
    'PLAYER_BOTTOM': '웹 플레이어 하단 영역(컨트롤러 감싸는 영역). [마우스 호버 시 플레이어 컨트롤러 표시 제어] 및 하단 여백 보정에 사용됩니다.',
    'PLAYER_CONTROL_BAR': '재생, 음량, 화질 등 컨트롤 버튼들이 모여 있는 바. [재생 제어 버튼 감지 및 볼륨 조절 슬라이더 상태 파악]을 위해 참조됩니다.',
    'PLAYER_CONTROL_BAR_RIGHT': '컨트롤 바 우측 영역 (화질, 레이아웃 설정 등). [설정 메뉴(화질/속도) 및 화면 모드 버튼 탐색]을 위해 참조됩니다.',
    'PLAYER_SETTING_BTN': '플레이어 내부 톱니바퀴 모양 설정 버튼. [화질 자동 고정 기능]이 설정 메뉴 레이어를 열기 위해 클릭해야 하는 버튼입니다.',
    'PLAYER_LIVE_INDICATOR': '플레이어 내의 LIVE 빨간 배지 요소. VOD와 라이브 방송을 구별하여 [라이브 지연시간 최적화(단축키)] 작동을 조절하기 위해 필요합니다.',
    'PLAYER_VOLUME_CONTROL': '음량 조절 영역/버튼. [마우스 휠 음량 조절 및 음소거 제어]의 호버/휠 이벤트 타겟으로 필요합니다.',
    'PLAYER_TIME_DISPLAY': 'VOD 등에서 시간을 표시하는 텍스트 영역. VOD 플레이 시 [단축키 시간 이동 동기화 및 타임스탬프 계산]을 위해 텍스트를 파싱합니다.',
    'PLAYER_FULLSCREEN_BTN': '전체화면 전환 버튼. [전체화면 전환 단축키(F/더블클릭)] 및 확장프로그램의 전체화면 보정 동작 시 연동됩니다.',
    'PLAYER_QUALITY_ITEM': '화질 설정 메뉴 내의 각 화질 항목. [사용자 설정 선호 화질로의 강제 화질 고정] 시 강제 클릭하는 대상입니다.',
    'PLAYER_QUALITY_ITEM_PREFIX': '선택된 화질 앞에 표시되는 체크마크 아이콘. [현재 재생 중인 화질 감지] 및 고정 여부 체크 시 사용됩니다.',
    'PLAYER_BUTTON_TOOLTIP': '마우스 호버 시 나오는 버튼 툴팁 요소. [마우스 휠 볼륨 조절 시 팝업 툴팁 표시]를 덮어씌우거나 커스텀 텍스트를 연출할 때 필요합니다.',
    'CONTEXT_MENU_PANE': '플레이어 우클릭 시 나오는 커스텀 컨텍스트 메뉴 패널. [치지직 자체 우클릭 잠금 우회 및 브라우저 기본 우클릭 복원]을 위해 요소를 감지하고 제거합니다.',
    'CONTEXT_MENU_LIST': '컨텍스트 메뉴 항목 리스트. [기본 메뉴 강제 노출 및 우클릭 이벤트 차단 우회] 처리를 위한 내부 대상입니다.',
    'SETTINGS_MENU': '설정(톱니바퀴) 클릭 시 열리는 화질/속도 설정 레이어. [재생 속도 및 화질 고정 로직]이 팝업 메뉴 상태를 읽고 제어하기 위해 필요합니다.',
    'NATIVE_PROGRESS_SLIDER': 'VOD 탐색기 슬라이더 바. [VOD 단축키(방향키) 시간 탐색 및 재생 진행률 수동 조절] 기능의 마우스 드래그 트리거용입니다.',
    'NATIVE_SLIDER_WRAP': 'VOD 슬라이더를 감싸는 래퍼. [탐색바 호버 시 썸네일 미리보기 및 마우스 클릭 좌표 계산]에 활용됩니다.',
    'VIEW_MODE_BTN': '넓은 화면/기본 화면 등 뷰 모드 전환 버튼. [레이아웃 크기 변경 감지 및 단축키 조작]의 타겟 버튼입니다.',
    // 사이드바
    'SIDEBAR_ASIDE': '좌측 내비게이션/사이드바 영역 전체. [사이드바 마우스 드래그 리사이즈 및 사이드바 숨기기 단축키] 제어를 위해 필수적입니다.',
    'SIDEBAR_ASIDE_WRAPPER': '사이드바를 감싸는 컨테이너 wrapper. [사이드바 넓이 고정 및 리사이즈 마우스 드래그 영역 감지]를 위해 참조됩니다.',
    'SIDEBAR_CONTENT': '사이드바 내부의 실제 팔로우 목록 등 콘텐츠 스크롤 영역. [팔로우 스트리머 목록 스크롤 감시 및 리스트 아이템 추출]을 위한 타겟 영역입니다.',
    'SIDEBAR_LIST_CONTAINER': '팔로우 스트리머 리스트 컨테이너. [폴더별 분류 기능 및 실시간 스트리머 정렬 필터링]이 자식 요소를 관리하기 위해 필수입니다.',
    'SIDEBAR_ITEM': '팔로우 리스트의 각 스트리머 항목. [스트리머 폴더 관리(드래그 앤 드롭 이동) 및 라이브 스트리머 숨김 필터링]의 타겟 노드입니다.',
    'SIDEBAR_NAV_LINK': '사이드바 내의 개별 메뉴 링크 버튼. [사이드바 축소 모드일 때 툴팁 강제 노출 및 이동 차단] 제어 시 필요합니다.',
    'SIDEBAR_LIVE_INDICATOR': '사이드바 스트리머가 방송 중일 때 표시되는 라이브 배지. [라이브 중인 방송 개수 카운트 및 폴더 헤더 실시간 라이브 스트리머 수 표시] 시 사용됩니다.',
    'SIDEBAR_OBSERVER_SPINNER': '사이드바 목록 무한스크롤 시 나타나는 로딩 스피너. [스크롤 하단 도달 시 폴더 자동 정렬 및 추가 스트리머 로드 트리거링]에 필수적입니다.',
    'SIDEBAR_REFRESH_BTN': '사이드바 목록 새로고침 버튼. [팔로우 목록 실시간 자동 갱신 및 커스텀 새로고침 기능] 연동에 사용됩니다.',
    'SIDEBAR_BANNER': '사이드바 하단 광고/프로모션 배너. [광고 차단(사이드바 배너 숨기기)] 기능 적용 시 화면에서 숨기는 대상입니다.',
    'SIDEBAR_MENU_LINK': '사이드바 상단 치지직 홈/라이브 등 메인 메뉴 링크. [사이드바 메뉴 클릭 시 폴더 상태 동기화 및 렌더링 유지]를 위해 감시합니다.',
    'FOLLOWING_ANCHOR': '팔로잉 메뉴 바로가기 링크. [단축키 또는 마우스 제어로 팔로잉 메뉴 즉시 이동] 처리에 필요합니다.',
    'NAV_ITEM': '헤더 또는 메뉴의 네비게이션 아이템. [상단 헤더 커스텀 메뉴 추가 및 스타일 조절] 시 기준점이 되는 버튼입니다.',
    'NAV_SECTION': '사이드바 그룹 영역 구획선/헤더. [사이드바 축소/확장 시 특정 카테고리(예: 추천 채널) 숨김 필터] 처리를 위해 필요합니다.',
    'NAV_TITLE': '사이드바 메뉴 그룹 제목. [추천 채널 영역 완전 숨기기 및 텍스트 교체] 적용 시 필요합니다.',
    'LAYOUT_BODY': '치지직 전체 페이지 레이아웃 본문. [사이드바 넓이 및 채팅창 넓이에 맞춘 중앙 메인 플레이어 반응형 크기 자동 계산] 시 넓이를 감시합니다.',
    // 채팅
    'CHAT_ASIDE': '우측 채팅창 영역 전체. [채팅창 마우스 드래그 리사이즈 및 채팅창 강제 숨기기 단축키] 제어를 위해 필수적입니다.',
    'CHAT_CONTAINER': '채팅 메시지들이 출력되는 메인 컨테이너. [실시간 채팅 내용 수집, 닉네임 필터링, 차단 유저 차단]을 위해 내부 Mutation 감시가 일어나는 핵심 영역입니다.',
    'CHAT_BLINDED_CONTAINER': '블라인드 처리된 채팅 메시지를 덮는 가림막. [클린봇에 의해 가려진 채팅을 옵션에 따라 자동으로 즉시 해제 및 강제 노출] 시 사용됩니다.',
    'CHAT_DONATION': '후원(치즈) 메시지 컨테이너. [후원 메시지 필터링 및 후원 채팅 화면에서 숨기기 옵션] 적용 시 타겟이 됩니다.',
    'CHAT_FOLD_BTN': '채팅창 접기/열기 버튼. [채팅창 토글 단축키 및 강제 접기/열기 동작] 시 확장프로그램이 직접 클릭하는 버튼입니다.',
    'CHAT_HEADER': '채팅창 최상단 헤더 영역(접기 버튼 및 설정 버튼 포함). [채팅 팝업 분리 기능 및 커스텀 설정 톱니바퀴 버튼 추가]를 위해 접근하는 위치입니다.',
    'CHAT_ITEM': '개별 채팅 행 요소. [닉네임 필터링, 키워드 블랙리스트 감지 시 특정 채팅 행 숨김/강조 스타일링] 처리의 타겟 요소입니다.',
    'CHAT_ITEM_CONTAINER': '채팅 행의 내부 실 콘텐츠 영역. [타임스탬프 삽입 및 닉네임 복사/차단 버튼 추가]를 위한 DOM 조작 영역입니다.',
    'CHAT_LIST_CONTAINER': '채팅창 메시지 리스트 컨테이너. [채팅 스크롤 고정 보정 및 채팅 청소 기능] 적용 시 대상을 감지합니다.',
    'CHAT_LIST_WRAPPER_ALT': '채팅창 스크롤 래퍼 (대체제). [채팅 자동 스크롤 및 스크롤 바 스타일 커스텀] 제어를 위해 사용됩니다.',
    'CHAT_MESSAGE': '채팅 메시지 본문 컨테이너. [이모티콘 자동 확대 및 텍스트 번역 기능] 연동 시 필요합니다.',
    'CHAT_MESSAGE_TEXT': '채팅 텍스트 내용. [키워드 감지 및 특정 단어 알림 기능] 작동 시 문자열을 읽는 타겟입니다.',
    'CHAT_MORE_MENU_BTN': '채팅 항목 내 더보기/신고 버튼. [유저 차단 바로가기 메뉴 추가 및 상세 프로필 읽기]에 접근하기 위해 사용됩니다.',
    'CHAT_NICKNAME': '채팅창 유저 닉네임. [닉네임 클릭 시 빠른 차단/팔로우 등록 및 커스텀 배지(치트키) 뱃지 삽입]을 위해 참조됩니다.',
    'CHAT_PROFILE_INFO': '채팅창 닉네임 클릭 시 나오는 프로필 요약 카드. [해당 유저의 스트리밍 상태 조회 및 유저 상세 정보 수집] 기능 연동 시 사용됩니다.',
    'CHAT_PROFILE_POPUP': '프로필 정보 팝업 레이어. [프로필 레이어 활성화 감지 및 우회 닫기] 처리에 활용됩니다.',
    'VOD_RECOMMEND': 'VOD 종료 시 우측에 노출되는 추천 영상 영역. [영상이 완전히 종료되었을 때 추천 영상 노출 차단] 시 강제 숨김 처리하기 위해 필요합니다.',
    // UI/레이아웃
    'AD_POPUP': '페이지에 진입 시 최초로 노출되는 팝업 광고 레이어. [진입 즉시 팝업 광고 자동 닫기] 옵션 작동을 위해 감지하여 닫기 이벤트를 발생시키는 대상입니다.',
    'HOME_BANNER': '홈 화면 최상단 메인 롤링 배너. [홈 광고 제거 및 레이아웃 정리] 시 요소를 숨기기 위해 필요합니다.',
    'RS_BANNER': '홈/라이브 화면의 추천 스트리머 우측 광고 배너. [우측 배너 광고 숨기기] 기능 적용 시 대상을 화면에서 강제 제거하기 위해 필요합니다.',
    'MORE_BTN': '리스트 하단 "더보기" 버튼. [자동 더보기(무한 스크롤)] 기능 활성화 시, 스크롤 하단 도달할 때 강제로 클릭을 유발할 버튼입니다.',
    'TOPIC_TAB_CONTAINER': '방송 목록 등에서 주제 분류(토픽) 탭 컨테이너. [라이브/VOD 목록에서 불필요한 카테고리 숨김 필터] 적용 시 기준점으로 사용됩니다.',
    'TOPIC_TAB_ELEMENTS': '토픽 탭 내부 개별 항목 요소들. [원치 않는 토픽 탭(예: e스포츠 등) 강제 필터링 및 숨김] 처리용입니다.',
    'TOPIC_TAB_LIST': '토픽 탭 전체 목록. [토픽 메뉴 내 커스텀 메뉴 삽입] 시 참조됩니다.',
    'TAB_ITEM': '일반적인 탭 메뉴 항목. [채널 페이지 내 동영상/라이브 탭 커스텀 순서 변경] 시 연동됩니다.',
    'TAB_LIST': '일반적인 탭 메뉴 목록. [정렬 상태 및 커스텀 탭 삽입]을 위한 앵커 영역입니다.',
    'TOOLBAR_BOX': '헤더 영역의 툴바(로그인, 알림 등) 박스. [로그인 정보 감지 및 툴바 영역에 확장프로그램 퀵 링크 메뉴 삽입] 시 필수입니다.',
    'TOOLBAR_BOX_ALT': '대체 툴바 박스. [헤더 레이아웃 스타일 보정]을 위해 필요합니다.',
    'TOOLBAR_ITEM': '툴바 내부 개별 버튼/아이템. [로그인 상태 감지 및 알림 배지 개수 읽기] 시 요소를 참조합니다.',
    'TOOLBAR_PROFILE_BTN': '우측 상단 로그인 유저 프로필 아이콘 버튼. [현재 로그인된 채널 ID 및 정보 추출]을 위해 프로필 데이터를 조회하는 대상입니다.',
    'VIDEO_INFO_DATA': '방송 상세 정보(제목, 시청자 수, 카테고리 등) 표시 영역. [방송 정보(스트리머명, 방제목)를 수집하여 팝업이나 다중뷰 창 제목에 노출]할 때 필수적입니다.',
    'VIDEO_ITEM': '방송 목록, 추천 목록의 각 비디오 썸네일 카드 아이템. [차단한 스트리머 방송 숨기기, 시청 기록 있는 방송 썸네일 불투명화] 등 필터링을 카드 단위로 적용할 때 필요합니다.',
    'VIDEO_LIST': '비디오 카드들이 배치되는 그리드/리스트 컨테이너. [방송 목록 커스텀 그리드 배열(예: 한 줄에 5개 표시) 및 필터링 후 레이아웃 재배치]를 위해 사용됩니다.',
    'LIVE_INFO_CONTAINER': '라이브 방송 정보 박스. [시청자 수 실시간 모니터링 및 녹화 시작 시 스트리머명 추출]을 위해 참조됩니다.',
    'LIVE_INFO_DETAILS': '라이브 방송 상세 설명 정보. [카테고리 정보 및 태그 추출] 시 연동됩니다.',
    'LIVE_INFO_LAYER': '라이브 썸네일 위의 오버레이 레이어. [썸네일 미리보기 마우스 호버 기능] 작동을 위한 오버레이 레이어 감지용입니다.',
    'LIVE_LINK': '라이브 영상으로 이동하는 썸네일 링크. [라이브 클릭 시 새창 열기 옵션 또는 다중뷰 등록] 기능 연동을 위해 href 속성을 추출합니다.',
    'LIVE_PLAYER_ALT': '라이브 비디오 플레이어 대체 영역. [플레이어 렌더링 실패 시 우회 복구 로직] 적용 시 감지합니다.',
    'LIVE_VIDEO_CONTAINER': '라이브 방송 시청 시 플레이어를 감싸는 비디오 부모 컨테이너. [다중 송출 또는 앰비언트 라이트(배경광) 효과 렌더링 영역]의 캔버스 앵커로 필요합니다.',
    'STREAMER_SHOP': '스트리머 굿즈 샵 연동 배너/영역. [스트리머 샵 메뉴 강제 숨김] 설정 시 영역을 감지해 숨기기 위해 필요합니다.',
    'STUDIO_BUTTON': '스트리머 스튜디오 이동 버튼. [일반 유저 화면에서 스트리머 스튜디오 버튼을 제거하여 레이아웃 축소]할 때 사용됩니다.',
    // 헤더/기타
    'CHEAT_KEY_BTN': '치트키 팝업 활성화 버튼. [채팅창 하단 치트키(이모티콘) 창 강제 열기 및 핫키 작동] 시 필요합니다.',
    'CHEAT_KEY_CLOSE_BTN': '치트키 팝업 닫기 버튼. [치트키 창 자동 닫기 및 포커스 반환]을 위해 제어합니다.',
    'CHEAT_KEY_POPUP': '치트키(이모티콘 팩 등) 리스트 팝업 창. [치트키 창 위치 자동 조정 및 스크롤 감지]를 위해 필요합니다.',
    'CHEAT_KEY_TOOLTIP_CLOSE_BTN': '치트키 도움말/툴팁 닫기 버튼. [거슬리는 이모티콘 도움말 팝업의 자동 닫기 처리]에 필수입니다.',
    'CHEAT_KEY_TOOLTIP_CONTAINER': '치트키 도움말 컨테이너. [도움말 자동 비활성화] 시 필요합니다.',
    'CHEESE_BTN': '채팅창 하단 치즈 후원하기 버튼. [채팅창 하단 후원 버튼 숨기기] 옵션 적용 시 영역을 제거하기 위해 필요합니다.',
    'NOTI_BTN': '우측 상단 알림 버튼. [알림 팝업 감지 및 헤더 정리] 시 필요합니다.',
    'THEME_BTN': '치지직 헤더 내 테마 전환(다크/라이트) 버튼. [수동으로 다크/라이트 테마 강제 연동 및 감시]를 위해 필요합니다.'
};


const GROUP_ICONS: Record<string, string> = {
    '🚨 오류 및 미매칭': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#ff3838" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
            <line x1="12" y1="9" x2="12" y2="13"></line>
            <line x1="12" y1="17" x2="12.01" y2="17"></line>
        </svg>
    `,
    '🎬 플레이어': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <polygon points="23 7 16 12 23 17 23 7"></polygon>
            <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
        </svg>
    `,
    '📂 사이드바': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
            <line x1="9" y1="3" x2="9" y2="21"></line>
        </svg>
    `,
    '💬 채팅': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
        </svg>
    `,
    '🖥 UI/레이아웃': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
            <line x1="2" y1="10" x2="22" y2="10"></line>
            <line x1="12" y1="17" x2="12" y2="21"></line>
            <line x1="8" y1="21" x2="16" y2="21"></line>
        </svg>
    `,
    '🔧 헤더/기타': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
        </svg>
    `,
    '⚙ 기타': `
        <svg class="cqc-inspector-group-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 5px; vertical-align: middle;">
            <circle cx="12" cy="12" r="3"></circle>
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
        </svg>
    `
};

export class SelectorInspector {
    private static instance: SelectorInspector | null = null;

    private isInspecting = false;
    private activeSlot: string = '';
    private selectedCandidate: string | null = null;
    private hoverEl: HTMLElement | null = null;

    private highlightOverlay: HTMLDivElement | null = null;
    private guideOverlays: HTMLDivElement[] = [];
    private panelEl: HTMLDivElement | null = null;

    private candidates: SelectorCandidate[] = [];
    private fiberPath: string[] = [];

    private collapsedGroups: Set<string> = new Set();
    private searchQuery = '';

    // 드래그 상태
    private isDragging = false;
    private dragStartX = 0;
    private dragStartY = 0;
    private panelLeft = 0;
    private panelTop = 0;

    static getInstance() {
        if (!SelectorInspector.instance) {
            SelectorInspector.instance = new SelectorInspector();
        }
        return SelectorInspector.instance;
    }

    constructor() {
        Object.keys(SLOT_GROUPS).forEach(g => this.collapsedGroups.add(g));
        this.activeSlot = Object.keys(SELECTORS)[0] || '';
    }

    async start() {
        if (this.panelEl) return;
        this.searchQuery = ''; // 초기화

        try {
            const res = await chrome.runtime.sendMessage({ action: 'CQC_GET_SETTINGS' });
            if (res && res.customSelectors) {
                initSelectors(res.customSelectors);
            }
        } catch (e) {
            console.error('[CQC:Inspector] 설정 로드 실패', e);
        }

        this.createPanel();
        this.createOverlays();
        this.buildLayoutSkeleton();
        this.updatePanelBody();
        this.drawGuideOverlays();
    }

    stop() {
        this.stopInspectingMode();
        this.removePanel();
        this.removeOverlays();
    }

    private createPanel() {
        this.panelEl = document.createElement('div');
        this.panelEl.className = 'cqc-inspector-panel';
        
        const header = document.createElement('div');
        header.className = 'cqc-inspector-panel-header';
        
        const title = document.createElement('div');
        title.className = 'cqc-inspector-panel-title';
        title.innerHTML = `
            <img src="${chrome.runtime.getURL('icons/icon128.png')}" style="width: 18px; height: 18px; border-radius: 4px; display: inline-block; vertical-align: middle; margin-right: 6px;" />
            치지직 셀렉터 편집기
        `;

        const closeBtn = document.createElement('button');
        closeBtn.className = 'cqc-inspector-panel-close';
        closeBtn.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
        `;
        closeBtn.onclick = () => this.stop();

        header.appendChild(title);
        header.appendChild(closeBtn);

        const body = document.createElement('div');
        body.className = 'cqc-inspector-panel-body';

        this.panelEl.appendChild(header);
        this.panelEl.appendChild(body);
        document.body.appendChild(this.panelEl);

        header.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.dragStartX = e.clientX;
            this.dragStartY = e.clientY;
            const rect = this.panelEl!.getBoundingClientRect();
            this.panelLeft = rect.left;
            this.panelTop = rect.top;
            this.panelEl!.style.bottom = 'auto';
            this.panelEl!.style.right = 'auto';
            this.panelEl!.style.left = `${this.panelLeft}px`;
            this.panelEl!.style.top = `${this.panelTop}px`;
            e.preventDefault();
        });

        const onMouseMove = (e: MouseEvent) => {
            if (!this.isDragging || !this.panelEl) return;
            const dx = e.clientX - this.dragStartX;
            const dy = e.clientY - this.dragStartY;
            this.panelEl.style.left = `${this.panelLeft + dx}px`;
            this.panelEl.style.top = `${this.panelTop + dy}px`;
        };

        const onMouseUp = () => {
            this.isDragging = false;
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    private removePanel() {
        if (this.panelEl) {
            this.panelEl.remove();
            this.panelEl = null;
        }
    }

    private createOverlays() {
        this.highlightOverlay = document.createElement('div');
        this.highlightOverlay.className = 'cqc-inspector-highlight';
        this.highlightOverlay.style.display = 'none';

        const badge = document.createElement('div');
        badge.className = 'cqc-inspector-badge';
        this.highlightOverlay.appendChild(badge);

        document.body.appendChild(this.highlightOverlay);
    }

    private removeOverlays() {
        if (this.highlightOverlay) {
            this.highlightOverlay.remove();
            this.highlightOverlay = null;
        }
        this.clearGuideOverlays();
    }

    private clearGuideOverlays() {
        this.guideOverlays.forEach(o => o.remove());
        this.guideOverlays = [];
    }

    private drawGuideOverlays() {
        this.clearGuideOverlays();
        if (!this.activeSlot) return;

        const currentSelector = SELECTORS[this.activeSlot];
        if (!currentSelector) return;

        try {
            const elements = document.querySelectorAll(currentSelector);
            elements.forEach((el, index) => {
                if (!(el instanceof HTMLElement)) return;
                const rect = el.getBoundingClientRect();
                const scrollX = window.scrollX;
                const scrollY = window.scrollY;

                const guide = document.createElement('div');
                guide.className = 'cqc-inspector-guide';
                guide.style.width = `${rect.width}px`;
                guide.style.height = `${rect.height}px`;
                guide.style.left = `${rect.left + scrollX}px`;
                guide.style.top = `${rect.top + scrollY}px`;

                const badge = document.createElement('div');
                badge.className = 'cqc-inspector-guide-badge';
                badge.innerText = `현재 [${this.activeSlot}] - 매칭 ${index + 1}`;
                guide.appendChild(badge);

                document.body.appendChild(guide);
                this.guideOverlays.push(guide);
            });
        } catch (e) {
            // invalid selector 무시
        }
    }

    private startInspectingMode(slotKey: string) {
        this.activeSlot = slotKey;
        this.isInspecting = true;
        this.selectedCandidate = null;
        this.candidates = [];
        this.fiberPath = [];
        this.clearGuideOverlays();

        document.body.style.cursor = 'crosshair';

        document.addEventListener('mouseover', this.handleMouseOver, true);
        document.addEventListener('click', this.handleMouseClick, true);
        document.addEventListener('keydown', this.handleKeyDown, true);
        
        this.updatePanelBody();
    }

    private stopInspectingMode() {
        this.isInspecting = false;
        document.body.style.cursor = '';

        document.removeEventListener('mouseover', this.handleMouseOver, true);
        document.removeEventListener('click', this.handleMouseClick, true);
        document.removeEventListener('keydown', this.handleKeyDown, true);

        if (this.highlightOverlay) {
            this.highlightOverlay.style.display = 'none';
        }
    }

    private handleMouseOver = (e: MouseEvent) => {
        if (!this.isInspecting || !this.highlightOverlay) return;

        const target = e.target as HTMLElement;
        if (!target || target === this.panelEl || this.panelEl?.contains(target)) return;

        this.hoverEl = target;
        const rect = target.getBoundingClientRect();
        const scrollX = window.scrollX;
        const scrollY = window.scrollY;

        this.highlightOverlay.style.width = `${rect.width}px`;
        this.highlightOverlay.style.height = `${rect.height}px`;
        this.highlightOverlay.style.left = `${rect.left + scrollX}px`;
        this.highlightOverlay.style.top = `${rect.top + scrollY}px`;
        this.highlightOverlay.style.display = 'block';

        const badge = this.highlightOverlay.querySelector('.cqc-inspector-badge') as HTMLDivElement;
        if (badge) {
            const path = getFiberComponentPath(target);
            const compName = path[0] || target.tagName.toLowerCase();
            const matchingKey = findMatchingSelectorKey(target);
            badge.innerText = `${target.tagName.toLowerCase()} | React: ${compName}${matchingKey ? ` [✓ ${matchingKey}]` : ''}`;
        }
    };

    private handleMouseClick = (e: MouseEvent) => {
        if (!this.isInspecting) return;
        e.preventDefault();
        e.stopPropagation();

        const target = e.target as HTMLElement;
        if (!target || target === this.panelEl || this.panelEl?.contains(target)) return;

        this.stopInspectingMode();

        this.candidates = generateRobustSelector(target);
        this.fiberPath = getFiberComponentPath(target);

        const uniqueCandidate = this.candidates.find(c => c.matches === 1);
        this.selectedCandidate = uniqueCandidate ? uniqueCandidate.selector : (this.candidates[0]?.selector || null);

        this.updatePanelBody();
    };

    private handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
            this.stopInspectingMode();
            this.updatePanelBody();
            this.drawGuideOverlays();
        }
    };

    private buildLayoutSkeleton() {
        if (!this.panelEl) return;
        const body = this.panelEl.querySelector('.cqc-inspector-panel-body') as HTMLDivElement;
        if (!body) return;

        body.innerHTML = `
            <div class="cqc-inspector-inspect-view" style="display: none;"></div>
            <div class="cqc-inspector-main-view" style="display: flex; flex-direction: column; height: 100%; overflow: hidden; gap: 8px;">
                <div class="cqc-inspector-search-container" style="display: flex; position: relative;">
                    <input type="text" class="cqc-inspector-search-input" placeholder="슬롯 키 이름 또는 용도 검색..." style="width: 100%; border-radius: 8px; padding: 8px 12px 8px 30px; font-size: 12px; outline: none; transition: border-color 0.2s;" />
                    <svg class="cqc-inspector-search-icon" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: #718096; pointer-events: none;">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </div>
                <div class="cqc-inspector-list-scroll-section" style="flex: 1; overflow-y: auto; padding-right: 2px;"></div>
                <div class="cqc-inspector-detail-card-section"></div>
            </div>
        `;

        const searchInput = body.querySelector('.cqc-inspector-search-input') as HTMLInputElement;
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                this.searchQuery = (e.target as HTMLInputElement).value;
                this.renderSlotsList();
            });
        }
    }

    private updatePanelBody() {
        if (!this.panelEl) return;
        const body = this.panelEl.querySelector('.cqc-inspector-panel-body') as HTMLDivElement;
        if (!body) return;

        body.innerHTML = '';

        if (this.isInspecting) {
            body.innerHTML = `
                <div class="cqc-inspector-status">
                    <div>요소 피킹 모드 활성화됨</div>
                    <div style="font-size: 11px; margin-top: 4px; color: #00ffa3; font-weight: bold;">[${this.activeSlot}] 설정 중...</div>
                    <div style="font-size: 10px; margin-top: 4px; color: #718096;">화면 대상을 클릭하거나 [ESC]로 취소하세요.</div>
                </div>
                <button class="cqc-inspector-btn cqc-inspector-btn-secondary" id="cqc-inspect-cancel-btn">
                    피킹 취소
                </button>
            `;
            body.querySelector('#cqc-inspect-cancel-btn')!.addEventListener('click', () => {
                this.stopInspectingMode();
                this.updatePanelBody();
                this.drawGuideOverlays();
            });
            return;
        }

        if (this.selectedCandidate !== null) {
            const slotTitle = document.createElement('div');
            slotTitle.className = 'cqc-inspector-status';
            slotTitle.style.textAlign = 'left';
            slotTitle.innerHTML = `
                <div style="font-size: 11px; color: #a0aec0; text-transform: uppercase;">선택한 슬롯</div>
                <div style="font-size: 14px; font-weight: 700; color: #00ffa3; margin-top: 2px;">${this.activeSlot}</div>
            `;
            body.appendChild(slotTitle);

            if (this.fiberPath.length > 0) {
                const fiberDiv = document.createElement('div');
                fiberDiv.className = 'cqc-inspector-fiber-path';
                fiberDiv.innerHTML = `
                    <div class="cqc-inspector-label" style="margin-bottom: 6px;">React 컴포넌트 경로</div>
                    <div class="cqc-inspector-breadcrumb">
                        ${this.fiberPath.map((name, i) => `<span class="${i === 0 ? 'active-component' : ''}">${name}</span>`).join('')}
                    </div>
                `;
                body.appendChild(fiberDiv);
            }

            const listDiv = document.createElement('div');
            listDiv.className = 'cqc-inspector-candidate-list';
            listDiv.innerHTML = `<div class="cqc-inspector-label">추천 셀렉터 후보군</div>`;

            const itemsContainer = document.createElement('div');
            itemsContainer.style.display = 'flex';
            itemsContainer.style.flexDirection = 'column';
            itemsContainer.style.gap = '8px';

            this.candidates.forEach(cand => {
                const item = document.createElement('div');
                item.className = 'cqc-inspector-candidate-item';
                if (this.selectedCandidate === cand.selector) {
                    item.style.borderColor = '#00ffa3';
                    item.style.background = 'rgba(0, 255, 163, 0.05)';
                }

                const matchesClass = cand.matches === 1 ? 'unique' : (cand.matches === 0 ? 'zero' : 'multi');
                const matchesText = cand.matches === 1 ? '유일 매칭' : `${cand.matches}개 매칭`;

                item.innerHTML = `
                    <div class="cqc-inspector-candidate-header">
                        <span class="cqc-inspector-strategy">${cand.strategy}</span>
                        <span class="cqc-inspector-match-badge ${matchesClass}">${matchesText}</span>
                    </div>
                    <div class="cqc-inspector-selector-text">${cand.selector}</div>
                `;

                item.addEventListener('mouseenter', () => this.drawTempHighlights(cand.selector));
                item.addEventListener('mouseleave', () => this.clearGuideOverlays());

                item.onclick = () => {
                    this.selectedCandidate = cand.selector;
                    this.updatePanelBody();
                };

                itemsContainer.appendChild(item);
            });

            listDiv.appendChild(itemsContainer);
            body.appendChild(listDiv);

            const footer = document.createElement('div');
            footer.style.display = 'flex';
            footer.style.gap = '8px';
            footer.style.marginTop = '12px';

            const saveBtn = document.createElement('button');
            saveBtn.className = 'cqc-inspector-btn';
            saveBtn.style.flex = '1';
            saveBtn.innerText = '설정 저장';
            saveBtn.onclick = () => this.saveSelected();

            const retryBtn = document.createElement('button');
            retryBtn.className = 'cqc-inspector-btn cqc-inspector-btn-secondary';
            retryBtn.innerText = '취소';
            retryBtn.onclick = () => {
                this.selectedCandidate = null;
                this.candidates = [];
                this.fiberPath = [];
                this.updatePanelBody();
                this.drawGuideOverlays();
            };

            footer.appendChild(retryBtn);
            footer.appendChild(saveBtn);
            body.appendChild(footer);
            return;
        }

        // 일반 상태: 2단 분할 레이아웃
        const wrapper = document.createElement('div');
        wrapper.className = 'cqc-inspector-split-layout';
        wrapper.style.display = 'flex';
        wrapper.style.flexDirection = 'column';
        wrapper.style.height = '100%';
        wrapper.style.overflow = 'hidden';

        const listSection = document.createElement('div');
        listSection.className = 'cqc-inspector-list-section';
        listSection.style.flex = '1';
        listSection.style.overflowY = 'auto';
        listSection.style.paddingRight = '4px';

        // 검색창 UI 추가
        const searchBox = document.createElement('div');
        searchBox.className = 'cqc-inspector-search-container';
        searchBox.innerHTML = `
            <div class="cqc-inspector-search-box">
                <svg class="cqc-inspector-search-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input type="text" class="cqc-inspector-search-input" placeholder="슬롯 이름 검색..." value="${this.searchQuery}" />
            </div>
        `;
        listSection.appendChild(searchBox);

        // 사용 가이드 박스 추가
        const guideBox = document.createElement('div');
        guideBox.className = 'cqc-inspector-guide-box';
        guideBox.innerHTML = `
            <div class="cqc-inspector-guide-title">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                </svg>
                인스펙터 사용 가이드
            </div>
            <div class="cqc-inspector-guide-item">
                <span class="cqc-inspector-guide-bullet">1.</span>
                <span>목록에서 슬롯 선택 시, 지정 요소가 화면에 <b style="color: #ff007f;">분홍 점선</b>으로 강조됩니다.</span>
            </div>
            <div class="cqc-inspector-guide-item">
                <span class="cqc-inspector-guide-bullet">2.</span>
                <span>하단 상세창에서 🎯 피킹 버튼을 누르고 화면 요소를 클릭하면 React Fiber 트리를 추적해 로버스트 셀렉터를 자동 생성합니다.</span>
            </div>
        `;
        listSection.appendChild(guideBox);

        const listContainer = document.createElement('div');
        listContainer.style.display = 'flex';
        listContainer.style.flexDirection = 'column';
        listContainer.style.gap = '2px';
        listContainer.style.marginTop = '8px';

        const sortedGroups = Object.keys(SLOT_GROUPS);
        const classifiedKeys = new Set(Object.values(SLOT_GROUPS).flat());
        const otherKeys = Object.keys(SELECTORS).filter(k => !classifiedKeys.has(k));

        const renderGroup = (groupName: string, keys: string[]) => {
            if (keys.length === 0) return;

            const isCollapsed = this.collapsedGroups.has(groupName);
            const cleanGroupName = groupName
                .replace('🎬', '')
                .replace('📂', '')
                .replace('💬', '')
                .replace('🖥', '')
                .replace('🔧', '')
                .replace('⚙', '')
                .replace('🚨', '')
                .trim();
            const groupIcon = GROUP_ICONS[groupName] || GROUP_ICONS['⚙ 기타'];

            const groupHeader = document.createElement('div');
            groupHeader.className = 'cqc-inspector-group-header';
            groupHeader.setAttribute('data-group-name', groupName);
            
            const chevron = isCollapsed ? `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            ` : `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(180deg);">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            `;

            groupHeader.innerHTML = `
                <span style="display: inline-flex; align-items: center; gap: 4px; font-weight: 700;">
                    ${groupIcon}
                    <span>${cleanGroupName}</span>
                    <span style="color: #718096; font-size: 11px; font-weight: normal;">(${keys.length})</span>
                </span>
                <span style="display: flex; align-items: center; color: #718096;">${chevron}</span>
            `;

            groupHeader.onclick = () => {
                if (this.collapsedGroups.has(groupName)) {
                    this.collapsedGroups.delete(groupName);
                } else {
                    this.collapsedGroups.add(groupName);
                }
                this.updatePanelBody();
            };

            listContainer.appendChild(groupHeader);

            if (true) {
                // 검색 제어를 유연하게 하기 위해 DOM 구조는 collapsed 무관하게 항시 렌더하되, collapsed 상태에 따라 숨김 처리
                const groupContent = document.createElement('div');
                groupContent.className = 'cqc-inspector-group-content';
                groupContent.setAttribute('data-content-group', groupName);
                groupContent.style.display = isCollapsed ? 'none' : 'block';

                keys.sort().forEach(key => {
                    const selector = SELECTORS[key] || '';
                    const isCustomized = (DEFAULT_SELECTORS as Record<string, string>)[key] !== selector;
                    const matchesCount = testSelector(selector);

                    const item = document.createElement('div');
                    item.className = `cqc-inspector-slot-item ${isCustomized ? 'customized' : ''} ${this.activeSlot === key ? 'active' : ''}`;
                    item.setAttribute('data-selector-val', selector);

                    const info = document.createElement('div');
                    info.className = 'cqc-inspector-slot-info';
                    info.style.display = 'flex';
                    info.style.justifyContent = 'space-between';
                    info.style.alignItems = 'center';
                    info.style.width = '100%';
                    
                    const displayName = SLOT_NAMES[key] || key;

                    info.innerHTML = `
                        <span style="display: inline-flex; align-items: center; gap: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1;">
                            ${isCustomized ? '<span class="cqc-inspector-custom-dot" title="사용자 지정됨">●</span>' : ''}
                            <span class="cqc-inspector-slot-name-text">${displayName}</span>
                            <span class="cqc-inspector-slot-key-sub">${key}</span>
                        </span>
                    `;

                    info.onclick = () => {
                        this.activeSlot = key;
                        this.drawGuideOverlays();
                        this.updatePanelBody();
                    };

                    item.appendChild(info);
                    groupContent.appendChild(item);
                });

                listContainer.appendChild(groupContent);
            }
        };

        // 매칭 수 0개인 오류 및 미매칭 슬롯들 추출
        const errorKeys: string[] = [];
        Object.keys(SELECTORS).forEach(key => {
            const selector = SELECTORS[key] || '';
            if (testSelector(selector) === 0) {
                errorKeys.push(key);
            }
        });

        if (errorKeys.length > 0) {
            renderGroup('🚨 오류 및 미매칭', errorKeys);
        }

        sortedGroups.forEach(gName => {
            const keys = SLOT_GROUPS[gName].filter(k => SELECTORS[k] !== undefined);
            renderGroup(gName, keys);
        });

        if (otherKeys.length > 0) {
            renderGroup('⚙ 기타', otherKeys);
        }

        listSection.appendChild(listContainer);
        wrapper.appendChild(listSection);

        // 2단: 하단 상세 영역
        const detailSection = document.createElement('div');
        detailSection.className = 'cqc-inspector-detail-section';

        if (this.activeSlot) {
            const selector = SELECTORS[this.activeSlot] || '';
            const isCustomized = (DEFAULT_SELECTORS as Record<string, string>)[this.activeSlot] !== selector;
            const matchesCount = testSelector(selector);
            const desc = SLOT_DESCRIPTIONS[this.activeSlot] || '용도 정의되지 않은 슬롯';

            const matchBadgeText = matchesCount === 1 ? '✓ 유일 매칭' : (matchesCount === 0 ? '0개 매칭 (구조 오류)' : `${matchesCount}개 다중 매칭`);
            const matchBadgeClass = matchesCount === 1 ? 'unique' : (matchesCount === 0 ? 'zero' : 'multi');

            detailSection.innerHTML = `
                <div class="cqc-inspector-detail-card">
                    <div class="cqc-inspector-detail-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span class="cqc-inspector-detail-key" style="font-weight: 800; font-size: 13px; color: #00ffa3;">${this.activeSlot}</span>
                        <span class="cqc-inspector-match-badge ${matchBadgeClass}" style="padding: 2px 6px; font-size: 9px; font-weight: bold; border-radius: 4px;">${matchBadgeText}</span>
                    </div>
                    <div class="cqc-inspector-detail-desc" style="font-size: 10.5px; color: #cbd5e1; line-height: 1.4; margin-bottom: 8px; word-break: keep-all;">${desc}</div>
                    <div class="cqc-inspector-detail-value-box" style="background: rgba(0, 0, 0, 0.2); border-radius: 6px; padding: 6px 8px; border: 1px solid rgba(255, 255, 255, 0.04); margin-bottom: 8px;">
                        <div class="cqc-inspector-label" style="font-size: 8px; color: #718096; text-transform: uppercase; margin-bottom: 2px;">현재 셀렉터 경로</div>
                        <div class="cqc-inspector-detail-value" style="font-family: monospace; font-size: 10px; color: #e2e8f0; word-break: break-all; user-select: text;">${selector}</div>
                    </div>
                    <div class="cqc-inspector-detail-actions" style="display: flex; gap: 6px;">
                        <button class="cqc-inspector-btn" id="cqc-detail-pick-btn" style="flex: 1; padding: 7px; font-size: 11.5px; display: inline-flex; align-items: center; justify-content: center; gap: 4px;">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="M12 2v20M2 12h20"></path>
                            </svg>
                            화면 피킹
                        </button>
                        ${isCustomized ? `
                            <button class="cqc-inspector-btn cqc-inspector-btn-secondary reset" id="cqc-detail-reset-btn" style="padding: 7px 10px;" title="기본값 복원">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path>
                                </svg>
                            </button>
                        ` : ''}
                    </div>
                </div>
            `;

            setTimeout(() => {
                const pickBtn = detailSection.querySelector('#cqc-detail-pick-btn');
                if (pickBtn) {
                    pickBtn.addEventListener('click', () => {
                        this.startInspectingMode(this.activeSlot);
                    });
                }
                const resetBtn = detailSection.querySelector('#cqc-detail-reset-btn');
                if (resetBtn) {
                    resetBtn.addEventListener('click', async () => {
                        if (!confirm(`[${this.activeSlot}] 설정을 기본 셀렉터로 초기화하시겠습니까?`)) return;
                        await this.resetSelector(this.activeSlot);
                    });
                }
            }, 0);
        } else {
            detailSection.innerHTML = `
                <div class="cqc-inspector-detail-placeholder" style="text-align: center; color: #718096; font-size: 11px; padding: 24px 12px; border: 1px dashed rgba(255, 255, 255, 0.05); border-radius: 8px; background: rgba(255,255,255,0.01);">
                    목록에서 슬롯을 선택하면 설명 및 설정창이 이곳에 표시됩니다.
                </div>
            `;
        }

        wrapper.appendChild(detailSection);
        body.appendChild(wrapper);

        // 이벤트 리스너 바인딩
        const searchInput = searchBox.querySelector('.cqc-inspector-search-input') as HTMLInputElement;
        searchInput.addEventListener('input', () => {
            this.searchQuery = searchInput.value.trim().toLowerCase();
            this.filterSlots();
        });

        // 비동기로 이전 필터링 상태 적용
        setTimeout(() => this.filterSlots(), 0);
    }

    private filterSlots() {
        if (!this.panelEl) return;
        const headers = this.panelEl.querySelectorAll('.cqc-inspector-group-header');

        headers.forEach((header) => {
            const groupName = header.getAttribute('data-group-name');
            if (!groupName) return;

            const groupContent = this.panelEl!.querySelector(`[data-content-group="${groupName}"]`) as HTMLDivElement;
            if (!groupContent) return;

            const items = groupContent.querySelectorAll('.cqc-inspector-slot-item');
            let visibleCount = 0;

            items.forEach(item => {
                const nameText = item.querySelector('.cqc-inspector-slot-name-text')?.textContent?.toLowerCase() || '';
                const keyText = item.querySelector('.cqc-inspector-slot-key-sub')?.textContent?.toLowerCase() || '';
                const selectorVal = item.getAttribute('data-selector-val')?.toLowerCase() || '';
                
                const htmlItem = item as HTMLDivElement;
                if (nameText.includes(this.searchQuery) || keyText.includes(this.searchQuery) || selectorVal.includes(this.searchQuery)) {
                    htmlItem.style.display = 'flex';
                    visibleCount++;
                } else {
                    htmlItem.style.display = 'none';
                }
            });

            const htmlHeader = header as HTMLDivElement;
            if (visibleCount > 0 || this.searchQuery === '') {
                htmlHeader.style.display = 'flex';
                if (this.searchQuery !== '') {
                    groupContent.style.display = 'block';
                } else {
                    const isCollapsed = this.collapsedGroups.has(groupName);
                    groupContent.style.display = isCollapsed ? 'none' : 'block';
                }
            } else {
                htmlHeader.style.display = 'none';
                groupContent.style.display = 'none';
            }
        });
    }

    private renderInspectMode(container: HTMLDivElement) {
        container.innerHTML = '';

        if (this.isInspecting) {
            container.innerHTML = `
                <div class="cqc-inspector-status">
                    <div>요소 피킹 모드 활성화됨</div>
                    <div style="font-size: 11px; margin-top: 4px; color: #00ffa3; font-weight: bold;">[${this.activeSlot}] 설정 중...</div>
                    <div style="font-size: 10px; margin-top: 4px; color: #718096;">화면 대상을 클릭하거나 [ESC]로 취소하세요.</div>
                </div>
                <button class="cqc-inspector-btn cqc-inspector-btn-secondary" id="cqc-inspect-cancel-btn">
                    피킹 취소
                </button>
            `;
            container.querySelector('#cqc-inspect-cancel-btn')!.addEventListener('click', () => {
                this.stopInspectingMode();
                this.updatePanelBody();
                this.drawGuideOverlays();
            });
            return;
        }

        if (this.selectedCandidate !== null) {
            const slotTitle = document.createElement('div');
            slotTitle.className = 'cqc-inspector-status';
            slotTitle.style.textAlign = 'left';
            slotTitle.innerHTML = `
                <div style="font-size: 11px; color: #a0aec0; text-transform: uppercase;">선택한 슬롯</div>
                <div style="font-size: 14px; font-weight: 700; color: #00ffa3; margin-top: 2px;">${this.activeSlot}</div>
            `;
            container.appendChild(slotTitle);

            if (this.fiberPath.length > 0) {
                const fiberDiv = document.createElement('div');
                fiberDiv.className = 'cqc-inspector-fiber-path';
                fiberDiv.innerHTML = `
                    <div class="cqc-inspector-label" style="margin-bottom: 6px;">React 컴포넌트 경로</div>
                    <div class="cqc-inspector-breadcrumb">
                        ${this.fiberPath.map((name, i) => `<span class="${i === 0 ? 'active-component' : ''}">${name}</span>`).join('')}
                    </div>
                `;
                container.appendChild(fiberDiv);
            }

            const listDiv = document.createElement('div');
            listDiv.className = 'cqc-inspector-candidate-list';
            listDiv.innerHTML = `<div class="cqc-inspector-label">추천 셀렉터 후보군</div>`;

            const itemsContainer = document.createElement('div');
            itemsContainer.style.display = 'flex';
            itemsContainer.style.flexDirection = 'column';
            itemsContainer.style.gap = '8px';

            this.candidates.forEach(cand => {
                const item = document.createElement('div');
                item.className = 'cqc-inspector-candidate-item';
                if (this.selectedCandidate === cand.selector) {
                    item.style.borderColor = '#00ffa3';
                    item.style.background = 'rgba(0, 255, 163, 0.05)';
                }

                const matchesClass = cand.matches === 1 ? 'unique' : (cand.matches === 0 ? 'zero' : 'multi');
                const matchesText = cand.matches === 1 ? '유일 매칭' : `${cand.matches}개 매칭`;

                item.innerHTML = `
                    <div class="cqc-inspector-candidate-header">
                        <span class="cqc-inspector-strategy">${cand.strategy}</span>
                        <span class="cqc-inspector-match-badge ${matchesClass}">${matchesText}</span>
                    </div>
                    <div class="cqc-inspector-selector-text">${cand.selector}</div>
                `;

                item.addEventListener('mouseenter', () => this.drawTempHighlights(cand.selector));
                item.addEventListener('mouseleave', () => this.clearGuideOverlays());

                item.onclick = () => {
                    this.selectedCandidate = cand.selector;
                    this.updatePanelBody();
                };

                itemsContainer.appendChild(item);
            });

            listDiv.appendChild(itemsContainer);
            container.appendChild(listDiv);

            const footer = document.createElement('div');
            footer.style.display = 'flex';
            footer.style.gap = '8px';
            footer.style.marginTop = '12px';

            const saveBtn = document.createElement('button');
            saveBtn.className = 'cqc-inspector-btn';
            saveBtn.style.flex = '1';
            saveBtn.innerText = '설정 저장';
            saveBtn.onclick = () => this.saveSelected();

            const retryBtn = document.createElement('button');
            retryBtn.className = 'cqc-inspector-btn cqc-inspector-btn-secondary';
            retryBtn.innerText = '취소';
            retryBtn.onclick = () => {
                this.selectedCandidate = null;
                this.candidates = [];
                this.fiberPath = [];
                this.updatePanelBody();
                this.drawGuideOverlays();
            };

            footer.appendChild(retryBtn);
            footer.appendChild(saveBtn);
            container.appendChild(footer);
        }
    }

    private renderSlotsList() {
        if (!this.panelEl) return;
        const listSection = this.panelEl.querySelector('.cqc-inspector-list-scroll-section') as HTMLDivElement;
        if (!listSection) return;

        listSection.innerHTML = '';

        const query = this.searchQuery.toLowerCase().trim();
        const matchesQuery = (k: string) => {
            if (!query) return true;
            const desc = SLOT_DESCRIPTIONS[k] || '';
            return k.toLowerCase().includes(query) || desc.toLowerCase().includes(query);
        };

        // 가이드박스는 검색어가 없을 때만 표시
        if (!query) {
            const guideBox = document.createElement('div');
            guideBox.className = 'cqc-inspector-guide-box';
            guideBox.innerHTML = `
                <div class="cqc-inspector-guide-title">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="16" x2="12" y2="12"></line>
                        <line x1="12" y1="8" x2="12.01" y2="8"></line>
                    </svg>
                    인스펙터 사용 가이드
                </div>
                <div class="cqc-inspector-guide-item">
                    <span class="cqc-inspector-guide-bullet">1.</span>
                    <span>목록에서 슬롯 선택 시, 지정 요소가 화면에 <b style="color: #ff007f;">분홍 점선</b>으로 강조됩니다.</span>
                </div>
                <div class="cqc-inspector-guide-item">
                    <span class="cqc-inspector-guide-bullet">2.</span>
                    <span>하단 상세창에서 🎯 피킹 버튼을 누르고 화면 요소를 클릭하면 React Fiber 트리를 추적해 로버스트 셀렉터를 자동 생성합니다.</span>
                </div>
                <div class="cqc-inspector-guide-item">
                    <span class="cqc-inspector-guide-bullet">3.</span>
                    <span>매칭 수가 0개이면 치지직 구조 변경으로 먹통이 된 상태입니다. 🎯 피킹을 수행하거나 복원(↺) 버튼을 누르세요.</span>
                </div>
            `;
            listSection.appendChild(guideBox);
        }

        const listContainer = document.createElement('div');
        listContainer.style.display = 'flex';
        listContainer.style.flexDirection = 'column';
        listContainer.style.gap = '2px';
        listContainer.style.marginTop = query ? '0px' : '8px';

        const sortedGroups = Object.keys(SLOT_GROUPS);
        const classifiedKeys = new Set(Object.values(SLOT_GROUPS).flat());
        const otherKeys = Object.keys(SELECTORS).filter(k => !classifiedKeys.has(k));

        const renderGroup = (groupName: string, keys: string[]) => {
            const filteredKeys = keys.filter(matchesQuery);
            if (filteredKeys.length === 0) return;

            const isCollapsed = query ? false : this.collapsedGroups.has(groupName);
            const cleanGroupName = groupName
                .replace('🎬', '')
                .replace('📂', '')
                .replace('💬', '')
                .replace('🖥', '')
                .replace('🔧', '')
                .replace('⚙', '')
                .replace('🚨', '')
                .trim();
            const groupIcon = GROUP_ICONS[groupName] || GROUP_ICONS['⚙ 기타'];

            const groupHeader = document.createElement('div');
            groupHeader.className = 'cqc-inspector-group-header';
            
            const chevron = isCollapsed ? `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            ` : `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="transform: rotate(180deg);">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            `;

            groupHeader.innerHTML = `
                <span style="display: inline-flex; align-items: center; gap: 4px; font-weight: 700;">
                    ${groupIcon}
                    <span>${cleanGroupName}</span>
                    <span style="color: #718096; font-size: 11px; font-weight: normal;">(${filteredKeys.length}/${keys.length})</span>
                </span>
                <span style="display: flex; align-items: center; color: #718096;">${chevron}</span>
            `;

            groupHeader.onclick = () => {
                if (query) return; // 검색 중일 때는 토글 잠금
                if (this.collapsedGroups.has(groupName)) {
                    this.collapsedGroups.delete(groupName);
                } else {
                    this.collapsedGroups.add(groupName);
                }
                this.updatePanelBody();
            };

            listContainer.appendChild(groupHeader);

            if (!isCollapsed) {
                const groupContent = document.createElement('div');
                groupContent.className = 'cqc-inspector-group-content';

                filteredKeys.sort().forEach(key => {
                    const selector = SELECTORS[key] || '';
                    const isCustomized = (DEFAULT_SELECTORS as Record<string, string>)[key] !== selector;
                    const matchesCount = testSelector(selector);

                    const item = document.createElement('div');
                    item.className = `cqc-inspector-slot-item ${isCustomized ? 'customized' : ''} ${this.activeSlot === key ? 'active' : ''}`;

                    const info = document.createElement('div');
                    info.className = 'cqc-inspector-slot-info';
                    info.style.display = 'flex';
                    info.style.justifyContent = 'space-between';
                    info.style.alignItems = 'center';
                    info.style.width = '100%';
                    
                    info.innerHTML = `
                        <span class="cqc-inspector-slot-key-text">${key}</span>
                    `;

                    info.onclick = () => {
                        this.activeSlot = key;
                        this.drawGuideOverlays();
                        this.updatePanelBody();
                    };

                    item.appendChild(info);
                    groupContent.appendChild(item);
                });

                listContainer.appendChild(groupContent);
            }
        };

        sortedGroups.forEach(gName => {
            const keys = SLOT_GROUPS[gName].filter(k => SELECTORS[k] !== undefined);
            renderGroup(gName, keys);
        });

        if (otherKeys.length > 0) {
            renderGroup('⚙ 기타', otherKeys);
        }

        listSection.appendChild(listContainer);
    }

    private renderDetailSection() {
        if (!this.panelEl) return;
        const detailSection = this.panelEl.querySelector('.cqc-inspector-detail-card-section') as HTMLDivElement;
        if (!detailSection) return;

        detailSection.innerHTML = '';

        if (this.activeSlot) {
            const selector = SELECTORS[this.activeSlot] || '';
            const isCustomized = (DEFAULT_SELECTORS as Record<string, string>)[this.activeSlot] !== selector;
            const matchesCount = testSelector(selector);
            const desc = SLOT_DESCRIPTIONS[this.activeSlot] || '용도 정의되지 않은 슬롯';

            const matchBadgeText = matchesCount === 1 ? '✓ 유일 매칭' : (matchesCount === 0 ? '0개 매칭 (구조 오류)' : `${matchesCount}개 다중 매칭`);
            const matchBadgeClass = matchesCount === 1 ? 'unique' : (matchesCount === 0 ? 'zero' : 'multi');

            detailSection.innerHTML = `
                <div class="cqc-inspector-detail-card">
                    <div class="cqc-inspector-detail-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span class="cqc-inspector-detail-key" style="font-weight: 800; font-size: 13px; color: #00ffa3;">${this.activeSlot}</span>
                        <span class="cqc-inspector-match-badge ${matchBadgeClass}" style="padding: 2px 6px; font-size: 9px; font-weight: bold; border-radius: 4px;">${matchBadgeText}</span>
                    </div>
                    <div class="cqc-inspector-detail-desc" style="font-size: 10.5px; color: #cbd5e1; line-height: 1.4; margin-bottom: 8px; word-break: keep-all;">${desc}</div>
                    <div class="cqc-inspector-detail-value-box" style="background: rgba(0, 0, 0, 0.2); border-radius: 6px; padding: 6px 8px; border: 1px solid rgba(255, 255, 255, 0.04); margin-bottom: 8px;">
                        <div class="cqc-inspector-label" style="font-size: 8px; color: #718096; text-transform: uppercase; margin-bottom: 2px;">현재 셀렉터 경로</div>
                        <div class="cqc-inspector-detail-value" style="font-family: monospace; font-size: 10px; color: #e2e8f0; word-break: break-all; user-select: text;">${selector}</div>
                    </div>
                    <div class="cqc-inspector-detail-actions" style="display: flex; gap: 6px;">
                        <button class="cqc-inspector-btn" id="cqc-detail-pick-btn" style="flex: 1; padding: 7px; font-size: 11.5px; display: inline-flex; align-items: center; justify-content: center; gap: 4px;">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="M12 2v20M2 12h20"></path>
                            </svg>
                            화면 피킹
                        </button>
                        ${isCustomized ? `
                            <button class="cqc-inspector-btn cqc-inspector-btn-secondary reset" id="cqc-detail-reset-btn" style="padding: 7px 10px;" title="기본값 복원">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path>
                                </svg>
                            </button>
                        ` : ''}
                    </div>
                </div>
            `;

            // 이벤트 수동 바인딩
            setTimeout(() => {
                const pickBtn = detailSection.querySelector('#cqc-detail-pick-btn');
                if (pickBtn) {
                    pickBtn.addEventListener('click', () => {
                        this.startInspectingMode(this.activeSlot);
                    });
                }
                const resetBtn = detailSection.querySelector('#cqc-detail-reset-btn');
                if (resetBtn) {
                    resetBtn.addEventListener('click', async () => {
                        if (!confirm(`[${this.activeSlot}] 설정을 기본 셀렉터로 초기화하시겠습니까?`)) return;
                        await this.resetSelector(this.activeSlot);
                    });
                }
            }, 0);
        } else {
            detailSection.innerHTML = `
                <div class="cqc-inspector-detail-placeholder" style="text-align: center; color: #718096; font-size: 11px; padding: 24px 12px; border: 1px dashed rgba(255, 255, 255, 0.05); border-radius: 8px; background: rgba(255,255,255,0.01);">
                    목록에서 슬롯을 선택하면 설명 및 설정창이 이곳에 표시됩니다.
                </div>
            `;
        }
    }

    private drawTempHighlights(selector: string) {
        this.clearGuideOverlays();
        try {
            const elements = document.querySelectorAll(selector);
            elements.forEach((el, index) => {
                if (!(el instanceof HTMLElement)) return;
                const rect = el.getBoundingClientRect();
                const scrollX = window.scrollX;
                const scrollY = window.scrollY;

                const guide = document.createElement('div');
                guide.className = 'cqc-inspector-guide';
                guide.style.width = `${rect.width}px`;
                guide.style.height = `${rect.height}px`;
                guide.style.left = `${rect.left + scrollX}px`;
                guide.style.top = `${rect.top + scrollY}px`;
                guide.style.borderColor = '#00ffa3';
                guide.style.backgroundColor = 'rgba(0, 255, 163, 0.08)';

                const badge = document.createElement('div');
                badge.className = 'cqc-inspector-guide-badge';
                badge.style.borderColor = '#00ffa3';
                badge.style.color = '#00ffa3';
                badge.innerText = `매칭 ${index + 1}`;
                guide.appendChild(badge);

                document.body.appendChild(guide);
                this.guideOverlays.push(guide);
            });
        } catch (e) {
            // 무시
        }
    }

    private async saveSelected() {
        if (!this.activeSlot || !this.selectedCandidate) return;

        try {
            const response = await chrome.runtime.sendMessage({
                action: 'CQC_SAVE_SELECTOR',
                key: this.activeSlot,
                selector: this.selectedCandidate
            });

            if (response && response.success) {
                initSelectors(response.customSelectors);
                showToast(`[${this.activeSlot}] 저장 완료!`);
                this.selectedCandidate = null;
                this.candidates = [];
                this.fiberPath = [];
                this.updatePanelBody();
                this.drawGuideOverlays();
            } else {
                showToast('저장 실패!');
            }
        } catch (e) {
            console.error('[CQC:Inspector] 저장 실패', e);
            showToast('저장 중 통신 오류 발생!');
        }
    }

    private async resetSelector(slotKey: string) {
        try {
            const response = await chrome.runtime.sendMessage({
                action: 'CQC_RESET_SELECTOR',
                key: slotKey
            });

            if (response && response.success) {
                initSelectors(response.customSelectors);
                showToast(`[${slotKey}] 기본값 복원 완료!`);
                this.updatePanelBody();
                this.drawGuideOverlays();
            } else {
                showToast('복원 실패!');
            }
        } catch (e) {
            console.error('[CQC:Inspector] 복원 실패', e);
            showToast('복원 중 통신 오류 발생!');
        }
    }
}
