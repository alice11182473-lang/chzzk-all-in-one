import React, { useEffect, useState } from 'react';
import { createRoot, Root } from 'react-dom/client';
import { SELECTORS, REGEX } from '../../../dom-utils';

export interface WatchTimerSettings {
  watchTimerEnabled?: boolean;
}

const WatchTimerComponent: React.FC<{ startTime: number }> = ({ startTime }) => {
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const fmt = (ms: number) => {
      const sec = Math.floor(ms / 1000);
      const h = String(Math.floor(sec / 3600)).padStart(2, '0');
      const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
      const s = String(sec % 60).padStart(2, '0');
      return `${h}:${m}:${s} 시청중`;
    };

    const tick = () => {
      setTimeStr(fmt(Date.now() - startTime));
    };

    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [startTime]);

  return (
    <span
      id="cqc-watch-timer"
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        color: '#fff',
        fontSize: '12px',
        marginLeft: '8px',
        opacity: 0.85,
        fontVariantNumeric: 'tabular-nums',
        whiteSpace: 'nowrap',
      }}
    >
      {timeStr}
    </span>
  );
};

export class WatchTimerModule {
  private static root: Root | null = null;
  private static container: HTMLElement | null = null;
  private static startTime: number = 0;
  private static lastPath: string = '';
  private static settings: WatchTimerSettings | null = null;

  public static init(settings?: WatchTimerSettings) {
    this.settings = settings || null;
    return {
      start: () => this.start(),
      stop: () => this.stop(),
      cleanup: () => this.stop()
    };
  }

  public static start(): void {
    if (this.settings?.watchTimerEnabled === false) {
      this.stop();
      return;
    }

    const path = location.pathname.match(REGEX.PLAYER_ROUTE)?.[0] ?? '';
    const isSame = path !== '' && path === this.lastPath;
    this.lastPath = path;

    if (!isSame) {
      this.startTime = Date.now();
    }

    this.inject();
  }

  private static inject(): void {
    if (this.root) return; // already injected

    const bar = document.querySelector(SELECTORS.PLAYER_CONTROL_BAR);
    if (!bar) return;

    this.container = document.createElement('div');
    this.container.style.display = 'inline-flex';
    bar.appendChild(this.container);

    this.root = createRoot(this.container);
    this.root.render(<WatchTimerComponent startTime={this.startTime} />);
  }

  public static stop(): void {
    if (this.root) {
      this.root.unmount();
      this.root = null;
    }
    if (this.container) {
      this.container.remove();
      this.container = null;
    }
  }
}
