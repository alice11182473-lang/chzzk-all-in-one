export interface UIVisibilitySettings {
  screenshotEnabled?: boolean;
  recorderEnabled?: boolean;
  hideSharpMenu?: boolean;
  hideAudioMenu?: boolean;
  [key: string]: any;
}

export class UIVisibilityModule {
  public static applyMediaButtonVisibility(settings?: UIVisibilitySettings): void {
    document.body.classList.toggle('cqc-screenshot-on', settings?.screenshotEnabled !== false);
    document.body.classList.toggle('cqc-recorder-on', settings?.recorderEnabled !== false);
  }

  public static applyPlayerMenuVisibility(settings?: UIVisibilitySettings): void {
    document.body.classList.toggle('cqc-hide-sharp-menu', !!settings?.hideSharpMenu);
    document.body.classList.toggle('cqc-hide-audio-menu', !!settings?.hideAudioMenu);
  }
}
