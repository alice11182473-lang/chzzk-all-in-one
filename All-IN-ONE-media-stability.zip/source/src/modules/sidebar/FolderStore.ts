import { initDB, getKV, setKV } from '../../../shared/db';
import { STORAGE_KEY, DEFAULT_COLOR, LOG } from './FolderConstants';
import Browser from 'webextension-polyfill';

/**
 * 사이드바 폴더 데이터 모델
 */
export interface FolderData {
  /** 폴더 고유 ID */
  id: string;
  /** 폴더명 */
  name: string;
  /** 폴더 열림/닫힘 상태 */
  isExpanded: boolean;
  /** 폴더 내 채널 ID 목록 */
  items: string[];
  /** 폴더 표시 색상 */
  color: string;
  /** 폴더 아이콘 URL */
  iconUrl?: string;
  /** 정렬 기준 설정 */
  sortBy?: 'custom' | 'name' | 'viewers' | 'viewer';
  /** 정렬 방향 설정 */
  sortDir?: 'asc' | 'desc';
}

/**
 * 사이드바 폴더 — 데이터 영속 레이어 (IndexedDB)
 * 폴더 데이터의 CRUD 및 저장을 담당합니다.
 */
export class FolderStore {
  private _folders: FolderData[] = [];
  private _ready: boolean = false;

  /** 현재 저장된 폴더 목록 */
  get folders(): FolderData[] { return this._folders; }
  /** DB 초기화 완료 여부 */
  get isReady(): boolean { return this._ready; }

  /**
   * DB를 초기화하고 저장된 폴더 데이터를 불러옵니다.
   */
  async init(): Promise<void> {
    try {
      await initDB();
    } catch (e) {
      LOG('IndexedDB initialization failed', e);
    }
    await this.load();
    this._ready = true;
  }

  /**
   * KV 저장소에서 폴더 데이터를 불러옵니다.
   */
  async load(): Promise<void> {
    try {
      const res = await Browser.storage.local.get(STORAGE_KEY);
      if (res[STORAGE_KEY]) {
        this._folders = Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY] : [];
        return;
      }
    } catch (e) {
      LOG('Failed to load from storage.local', e);
    }

    // 마이그레이션: 기존 IndexedDB에서 불러오기
    const saved = await getKV(STORAGE_KEY);
    this._folders = Array.isArray(saved) ? saved : [];
    
    if (this._folders.length > 0) {
      await this.save(); // storage.local로 마이그레이션
    }
  }

  /**
   * 현재 폴더 목록을 저장소에 씁니다.
   */
  async save(): Promise<void> {
    try {
      await Browser.storage.local.set({ [STORAGE_KEY]: this._folders });
    } catch (e) {
      LOG('Failed to save to storage.local', e);
    }
    // 안전을 위해 IndexedDB에도 백업
    await setKV(STORAGE_KEY, this._folders);
  }

  /**
   * 특정 채널이 속한 폴더를 찾습니다.
   * @param channelId 찾을 채널 ID
   * @returns 해당 채널이 속한 폴더 객체 (없으면 undefined)
   */
  folderOf(channelId: string): FolderData | undefined {
    return this._folders.find(f => f.items.includes(channelId));
  }

  /**
   * 모든 폴더에서 특정 채널을 제거합니다.
   * 빈 폴더는 자동으로 삭제됩니다.
   * @param channelId 제거할 채널 ID
   */
  removeChannel(channelId: string): void {
    for (const f of this._folders) {
      const idx = f.items.indexOf(channelId);
      if (idx > -1) f.items.splice(idx, 1);
    }
    this._folders = this._folders.filter(f => f.items.length > 0);
  }

  /**
   * 새로운 폴더를 생성하고 두 채널을 이동시킵니다.
   * @param ch1 첫 번째 채널 ID
   * @param ch2 두 번째 채널 ID
   * @returns 생성된 폴더 객체
   */
  createFolder(ch1: string, ch2: string): FolderData {
    this.removeChannel(ch1);
    this.removeChannel(ch2);
    const folder: FolderData = {
      id: 'f_' + Date.now().toString(36),
      name: '새 폴더',
      isExpanded: true,
      items: [ch1, ch2],
      color: DEFAULT_COLOR,
    };
    this._folders.push(folder);
    return folder;
  }

  /**
   * 특정 채널을 폴더로 이동시킵니다.
   * @param channelId 이동시킬 채널 ID
   * @param folderId 목적지 폴더 ID
   */
  moveToFolder(channelId: string, folderId: string): void {
    this.removeChannel(channelId);
    const f = this._folders.find(x => x.id === folderId);
    if (f) f.items.push(channelId);
  }

  /**
   * 폴더를 삭제합니다.
   * @param folderId 삭제할 폴더 ID
   */
  deleteFolder(folderId: string): void {
    this._folders = this._folders.filter(f => f.id !== folderId);
  }

  /**
   * 폴더 순서를 변경합니다.
   * @param srcId 이동할 폴더 ID
   * @param dstId 목적지 위치의 폴더 ID
   */
  reorderFolders(srcId: string, dstId: string): void {
    const srcIdx = this._folders.findIndex(f => f.id === srcId);
    const dstIdx = this._folders.findIndex(f => f.id === dstId);
    if (srcIdx === -1 || dstIdx === -1 || srcIdx === dstIdx) return;
    const [removed] = this._folders.splice(srcIdx, 1);
    this._folders.splice(dstIdx, 0, removed);
  }
}
