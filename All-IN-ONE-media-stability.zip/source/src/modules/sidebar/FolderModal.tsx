import React, { useEffect, useState, useRef, useMemo } from 'react';
import { createRoot, Root } from 'react-dom/client';
import Hls from 'hls.js';
import { DEFAULT_COLOR, PRESET_COLORS, SVG } from './FolderConstants';
import { FolderData, FolderStore } from './FolderStore';
import { ContextMenu } from './FolderContextMenu';
import { DragDropManager, autoScrollNearEdge } from './FolderDragDrop';
import { getKV, setKV } from '../../../shared/db';
import { triggerReact, SELECTORS, getChannelData } from '../../../dom-utils';

const SVG_MUTE = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"></path><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>`;
const SVG_UNMUTE = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>`;

export interface FolderModalUtils {
  findFollowingSection?: () => HTMLElement | null;
  extractChannelId?: (href?: string | null) => string | null;
  isLiveChannel?: (el: HTMLElement) => boolean;
  isSidebarCollapsed?: () => boolean;
}

interface EntryData {
  id: string;
  icon: string;
  name: string;
  isLive: boolean;
  href: string;
  liveTitle: string;
  viewers: number;
  category: string;
  thumbSrc: string;
}

interface SortPref {
  key: string;
  dir: 'asc' | 'desc';
}

const AddChannelPanel: React.FC<{
  folder: FolderData;
  store: FolderStore;
  unaffiliated: any[];
  onClose: () => void;
  onAdded: () => void;
  fetchUnaffiliated: () => void;
  search: string;
}> = ({ folder, store, unaffiliated, onClose, onAdded, fetchUnaffiliated, search }) => {
  const filtered = useMemo(() => {
    if (!search) return unaffiliated;
    const q = search.toLowerCase();
    return unaffiliated.filter(ch => ch.name.toLowerCase().includes(q));
  }, [unaffiliated, search]);

  return (
    <div className="cqc-add-panel">
      <div className="cqc-section-header">
        <span className="cqc-section-label cqc-section-label--add">ADD CHANNELS</span>
        <span className="cqc-section-add-count">{filtered.length}</span>
        <div className="cqc-section-divider"></div>
        <button className="cqc-add-panel-close-btn" onClick={onClose} title="닫기">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
      <div className="cqc-add-panel-list">
        {filtered.length === 0 ? (
          <div className="cqc-add-no-data">추가 가능한 채널이 없습니다</div>
        ) : (
          filtered.map(ch => (
            <div key={ch.id} className="cqc-add-ch-card">
              <div className="cqc-add-ch-info">
                <img src={ch.icon} className={`cqc-add-ch-icon ${ch.live ? '' : 'is-offline'}`} alt="" />
                <div className="cqc-add-ch-meta">
                  <span className="cqc-add-ch-name">{ch.name}</span>
                  {ch.live && <span className="cqc-add-ch-live-badge">LIVE</span>}
                </div>
              </div>
              <button
                className="cqc-add-ch-action-btn"
                title="폴더에 추가"
                onClick={async () => {
                  store.moveToFolder(ch.id, folder.id);
                  await store.save();
                  onAdded();
                  fetchUnaffiliated();
                }}
              >
                <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const FolderModalComponent: React.FC<{
  folder: FolderData;
  allItems: HTMLElement[];
  x: number;
  y: number;
  ddManager: DragDropManager;
  onDrop: Function;
  store: FolderStore;
  ctxMenu: ContextMenu;
  send: Function;
  utils: FolderModalUtils;
  onClose: () => void;
  onChanged?: () => void;
}> = ({ folder, allItems, x, y, ddManager, onDrop, store, ctxMenu, send, utils, onClose, onChanged }) => {
  const [entries, setEntries] = useState<EntryData[]>([]);
  const [sortPref, setSortPref] = useState<SortPref>({ key: 'custom', dir: 'asc' });
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [width, setWidth] = useState(480);
  const [height, setHeight] = useState(600);
  const [posX, setPosX] = useState(x);
  const [posY, setPosY] = useState(y);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [unaffiliated, setUnaffiliated] = useState<any[]>([]);
  const [animate, setAnimate] = useState(false);
  const [subOpen, setSubOpen] = useState<'color' | 'icon' | null>(null);
  const [iconUrl, setIconUrl] = useState(folder.iconUrl && !folder.iconUrl.startsWith('data:') ? folder.iconUrl : '');
  const [isRenaming, setIsRenaming] = useState(false);
  const [tempColor, setTempColor] = useState(folder.color || DEFAULT_COLOR);

  const popoverRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLSpanElement>(null);

  // 폴더 아이콘 및 색상 변경 감지
  useEffect(() => {
    setIconUrl(folder.iconUrl && !folder.iconUrl.startsWith('data:') ? folder.iconUrl : '');
  }, [folder.iconUrl]);

  useEffect(() => {
    setTempColor(folder.color || DEFAULT_COLOR);
  }, [folder.color]);

  // 이름 수정 상태 진입 시 텍스트 선택 처리
  useEffect(() => {
    if (isRenaming && titleRef.current) {
      titleRef.current.focus();
      requestAnimationFrame(() => {
        const range = document.createRange();
        if (titleRef.current) {
          range.selectNodeContents(titleRef.current);
          const sel = window.getSelection();
          sel?.removeAllRanges();
          sel?.addRange(range);
        }
      });
    }
  }, [isRenaming]);

  // 소속되지 않은 채널 목록 fetch
  const fetchUnaffiliated = async () => {
    const section = utils?.findFollowingSection ? utils.findFollowingSection() : null;
    const allSidebarItems = section ? Array.from(section.querySelectorAll(SELECTORS.SIDEBAR_NAV_LINK || 'a[href^="/live/"]')).map(a => a.closest('li')) : [];
    
    const list: any[] = [];
    for (const li of allSidebarItems) {
      if (!li) continue;
      const a = li.querySelector(SELECTORS.SIDEBAR_NAV_LINK || 'a');
      const chId = utils?.extractChannelId ? utils.extractChannelId(a?.getAttribute('href')) : null;
      if (!chId || store.folderOf(chId)) continue;
      if (list.some(x => x.id === chId)) continue;

      const fiber = await send('GET_CHANNEL_DATA', { channelId: chId });
      list.push({
        id: chId,
        name: fiber?.channelName || chId,
        icon: fiber?.channelImageUrl || 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_opacity2.png?type=f120_120',
        live: !!fiber?.isLive
      });
    }
    setUnaffiliated(list);
  };

  useEffect(() => {
    if (addOpen) {
      fetchUnaffiliated();
    }
  }, [addOpen]);

  // 설정 핸들러들
  const handleRename = () => {
    setSettingsOpen(false);
    setIsRenaming(true);
  };

  const handleRenameBlur = async () => {
    setIsRenaming(false);
    const text = titleRef.current?.textContent?.trim() || folder.name;
    if (text !== folder.name) {
      folder.name = text;
      await store.save();
      fetchEntries();
      onChanged?.();
    }
  };

  const handleColorChange = async (color: string) => {
    folder.color = color;
    await store.save();
    fetchEntries();
    onChanged?.();
  };

  const handleIconUrlChange = async (url: string) => {
    folder.iconUrl = url.trim() || undefined;
    await store.save();
    fetchEntries();
    onChanged?.();
  };

  const handleIconFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      folder.iconUrl = reader.result as string;
      await store.save();
      fetchEntries();
      onChanged?.();
    };
    reader.readAsDataURL(file);
  };

  const handleIconReset = async () => {
    folder.iconUrl = undefined;
    await store.save();
    fetchEntries();
    onChanged?.();
  };

  const handleDeleteFolder = async () => {
    if (confirm(`'${folder.name}' 폴더를 삭제할까요?`)) {
      store.deleteFolder(folder.id);
      await store.save();
      onChanged?.();
      onClose();
    }
  };

  const handleSortChange = async (key: string) => {
    let dir: 'asc' | 'desc' = 'asc';
    if (sortPref.key === key && sortPref.dir === 'asc') {
      dir = 'desc';
    } else if (key === 'viewers' && sortPref.key !== key) {
      dir = 'desc';
    }
    const nextPref = { key, dir } as SortPref;
    setSortPref(nextPref);
    await setKV('folderPopoverSort', nextPref);
    setSortOpen(false);
  };

  const handleItemDrop = async (src: string, dst: string) => {
    await onDrop(src, dst);
    fetchEntries();
  };

  // 드롭다운 외부 클릭 감지 및 닫기
  useEffect(() => {
    const handleOutsideClickDropdown = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (settingsOpen && !target.closest('.cqc-fph-settings') && !target.closest('.cqc-settings-dropdown')) {
        setSettingsOpen(false);
        setSubOpen(null);
      }
      if (sortOpen && !target.closest('.cqc-sort-btn') && !target.closest('.cqc-sort-dropdown')) {
        setSortOpen(false);
      }
      if (addOpen && !target.closest('.cqc-fph-add') && !target.closest('.cqc-add-panel')) {
        setAddOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClickDropdown);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClickDropdown);
    };
  }, [settingsOpen, sortOpen, addOpen]);

  // 마운트 후 페이드인 효과 활성화
  useEffect(() => {
    const timer = setTimeout(() => setAnimate(true), 50);
    return () => clearTimeout(timer);
  }, []);

  // 외부 영역 클릭 시 모달 닫기
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (popoverRef.current && !popoverRef.current.contains(target) && !target.closest('.cqc-ctx-menu')) {
        onClose();
      }
    };
    const timer = setTimeout(() => {
      document.addEventListener('mousedown', handleOutsideClick);
    }, 50);
    return () => {
      clearTimeout(timer);
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [onClose]);

  const fetchEntries = async () => {
    setLoading(true);
    const data = await Promise.all(folder.items.map(async id => {
      const li = allItems.find(it => it.dataset.channelId === id);
      const a = li?.querySelector('a');
      let fiberData = li ? getChannelData(li) : null;
      if (!fiberData) {
        fiberData = await send('GET_CHANNEL_DATA', { channelId: id });
      }
      return {
        id,
        icon: fiberData?.channelImageUrl || 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_opacity2.png?type=f120_120',
        name: fiberData?.channelName || id,
        isLive: !!fiberData?.isLive,
        href: a?.getAttribute('href') || `/live/${id}`,
        liveTitle: fiberData?.liveTitle || '',
        viewers: fiberData?.viewers || 0,
        category: fiberData?.category || '',
        thumbSrc: (fiberData?.thumbnailUrl || (fiberData as any)?.liveImageUrl || '').replace('{type}', '480'),
      };
    }));
    setEntries(data);
    setLoading(false);
  };

  useEffect(() => {
    const init = async () => {
      const sw = await getKV('folderPopoverWidth') || 480;
      const sh = await getKV('folderPopoverHeight') || 600;
      const sx = await getKV('folderPopoverX');
      const sy = await getKV('folderPopoverY');
      const pref = await getKV('folderPopoverSort') || { key: 'custom', dir: 'asc' };
      
      setWidth(sw);
      setHeight(sh);
      if (sx !== undefined && sy !== undefined) {
        setPosX(sx);
        setPosY(sy);
      } else {
        const anchor = document.querySelector('.cqc-sidebar-resize-handle') ||
          document.querySelector(SELECTORS.SIDEBAR_ASIDE_WRAPPER) ||
          document.querySelector(SELECTORS.SIDEBAR_ASIDE);
        const rect = anchor?.getBoundingClientRect();
        let fx = (rect?.right ?? 80) + 6;
        let fy = y - 40;
        setPosX(Math.max(10, Math.min(window.innerWidth - sw - 20, fx)));
        setPosY(Math.max(10, Math.min(window.innerHeight - 200, fy)));
      }
      setSortPref(pref);
      fetchEntries();
    };
    init();
  }, [folder]);

  // Handle Drag Move
  const handleHeaderMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button, .cqc-fph-icon, .cqc-fph-name')) return;
    const startX = e.clientX, startY = e.clientY;
    const initX = posX, initY = posY;
    
    const onMove = (m: MouseEvent) => {
      const maxX = window.innerWidth - width - 10;
      const maxY = window.innerHeight - height - 10;
      setPosX(Math.max(10, Math.min(maxX, Math.round(initX + m.clientX - startX))));
      setPosY(Math.max(10, Math.min(maxY, Math.round(initY + m.clientY - startY))));
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      setKV('folderPopoverX', posX);
      setKV('folderPopoverY', posY);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  };

  // Handle Resizing
  const handleResize = (e: React.MouseEvent, type: 'h' | 'v') => {
    e.preventDefault(); e.stopPropagation();
    const start = type === 'h' ? e.clientX : e.clientY;
    const startSize = type === 'h' ? width : height;

    const onMove = (m: MouseEvent) => {
      if (type === 'h') {
        const maxW = window.innerWidth - posX - 20;
        setWidth(Math.round(Math.max(380, Math.min(maxW, startSize + (m.clientX - start)))));
      } else {
        const maxH = window.innerHeight - posY - 20;
        setHeight(Math.round(Math.max(300, Math.min(maxH, startSize + (m.clientY - start)))));
      }
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      setKV(type === 'h' ? 'folderPopoverWidth' : 'folderPopoverHeight', type === 'h' ? width : height);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  };

  const sortedEntries = useMemo(() => {
    let arr = [...entries];
    if (search) {
      const q = search.toLowerCase();
      arr = arr.filter(a => a.name.toLowerCase().includes(q) || a.liveTitle.toLowerCase().includes(q));
    }
    arr.sort((a, b) => {
      let res = 0;
      if (sortPref.key === 'name') res = a.name.localeCompare(b.name, 'ko');
      else if (sortPref.key === 'viewers') res = a.viewers - b.viewers;
      return sortPref.dir === 'asc' ? res : -res;
    });
    return arr;
  }, [entries, sortPref, search]);

  const live = useMemo(() => sortedEntries.filter(it => it.isLive), [sortedEntries]);
  const offline = useMemo(() => sortedEntries.filter(it => !it.isLive), [sortedEntries]);

  return (
    <div 
      className={`cqc-folder-popover ${animate ? 'is-visible' : ''} ${addOpen ? 'cqc-panel-add-active' : ''}`}
      ref={popoverRef}
      style={{
        '--cqc-pop-x': `${posX}px`,
        '--cqc-pop-y': `${posY}px`,
        '--cqc-pop-w': `${width}px`,
        '--cqc-pop-h': `${height}px`,
        '--folder-color': tempColor
      } as React.CSSProperties}
    >
      <div className="cqc-folder-popover-header" onMouseDown={handleHeaderMouseDown}>
        <div className="cqc-fph-left">
          <div className="cqc-fph-icon">
            {folder.iconUrl 
              ? <img src={folder.iconUrl} draggable={false} alt=""/>
              : <div className="cqc-fph-icon-svg" dangerouslySetInnerHTML={{__html: SVG.folder}} />}
          </div>
          <div className="cqc-fph-title-group">
            <div className="cqc-fph-name-row">
              <span
                ref={titleRef}
                className="cqc-fph-name"
                contentEditable={isRenaming}
                suppressContentEditableWarning
                onBlur={handleRenameBlur}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') { e.preventDefault(); e.currentTarget.blur(); }
                  if (e.key === 'Escape') { e.preventDefault(); e.currentTarget.textContent = folder.name; e.currentTarget.blur(); }
                }}
                onDoubleClick={() => setIsRenaming(true)}
              >
                {folder.name}
              </span>
              <span className="cqc-fph-count">{entries.length}</span>
            </div>
          </div>
        </div>
        <div className="cqc-fph-actions">
          <button className="cqc-fph-settings" title="폴더 설정" onClick={() => {
            if (settingsOpen) {
              setSubOpen(null);
            }
            setSettingsOpen(!settingsOpen);
            setSortOpen(false);
            setAddOpen(false);
          }} dangerouslySetInnerHTML={{__html: SVG.settings}} />
          <button className={`cqc-fph-refresh ${loading ? 'is-loading' : ''}`} title="새로고침" onClick={fetchEntries} dangerouslySetInnerHTML={{__html: SVG.reset}} />
          <button className="cqc-fph-close" title="닫기" onClick={onClose} dangerouslySetInnerHTML={{__html: SVG.remove}} />
        </div>
      </div>

      {/* 설정 드롭다운 */}
      <div className={`cqc-settings-dropdown ${settingsOpen ? 'is-open' : ''}`}>
        <div className="cqc-set-item" onClick={handleRename}>
          <span dangerouslySetInnerHTML={{ __html: SVG.rename }} />
          <span>이름 변경</span>
        </div>
        <div className="cqc-set-item" onClick={() => setSubOpen(subOpen === 'color' ? null : 'color')}>
          <span dangerouslySetInnerHTML={{ __html: SVG.color }} />
          <span>색상 변경</span>
        </div>
        {subOpen === 'color' && (
          <div className="cqc-set-sub cqc-set-color-wrap">
            <div className="cqc-set-color-grid">
              {PRESET_COLORS.map(c => (
                <button
                  key={c}
                  className={`cqc-set-color-btn ${c.toLowerCase() === tempColor.toLowerCase() ? 'active' : ''}`}
                  style={{ '--preset-color': c } as React.CSSProperties}
                  onClick={() => {
                    setTempColor(c);
                    handleColorChange(c);
                  }}
                />
              ))}
            </div>
            <div className="cqc-set-custom-color-wrap" style={{ display: 'flex', alignItems: 'center', gap: '6px', flex: 1, marginTop: '10px', minWidth: 0 }}>
              <div className="cqc-set-custom-color">
                <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none', color: '#fff' }} dangerouslySetInnerHTML={{ __html: SVG.dropper }} />
                <input
                  type="color"
                  className="cqc-set-custom-color-input"
                  style={{ position: 'absolute', top: '-5px', left: '-5px', width: '40px', height: '40px', cursor: 'pointer', border: 'none', padding: 0 }}
                  value={(tempColor && tempColor.startsWith('#')) ? tempColor : DEFAULT_COLOR}
                  onChange={(e) => setTempColor(e.target.value)}
                  onBlur={(e) => handleColorChange(e.target.value)}
                />
              </div>
              <input
                type="text"
                className="cqc-set-custom-color-text"
                style={{
                  flex: 1,
                  minWidth: 0,
                  boxSizing: 'border-box',
                  height: '28px',
                  padding: '0 8px',
                  borderRadius: '6px',
                  border: '1px solid var(--border, rgba(255,255,255,0.15))',
                  background: 'var(--input-bg, rgba(0,0,0,0.2))',
                  color: 'var(--text, #fff)',
                  fontSize: '11px',
                  outline: 'none'
                }}
                placeholder="HEX, oklch(), oklab() 등"
                value={tempColor}
                onChange={(e) => setTempColor(e.target.value)}
                onBlur={(e) => handleColorChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleColorChange(tempColor);
                    e.currentTarget.blur();
                  }
                }}
              />
            </div>
          </div>
        )}
        <div className="cqc-set-item" onClick={() => setSubOpen(subOpen === 'icon' ? null : 'icon')}>
          <span dangerouslySetInnerHTML={{ __html: SVG.icon }} />
          <span>아이콘 변경</span>
        </div>
        {subOpen === 'icon' && (
          <div className="cqc-set-sub cqc-set-icon-wrap">
            <input
              type="text"
              className="cqc-set-icon-url"
              placeholder="이미지 URL"
              value={iconUrl}
              onChange={(e) => setIconUrl(e.target.value)}
              onBlur={() => handleIconUrlChange(iconUrl)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleIconUrlChange(iconUrl); }}
            />
            <div className="cqc-set-icon-btns">
              <label className="cqc-set-file-label">
                <span dangerouslySetInnerHTML={{ __html: SVG.upload }} /> 파일 선택
                <input type="file" className="cqc-set-file-input" accept="image/*" hidden onChange={handleIconFileChange} />
              </label>
              <button className="cqc-set-icon-reset" onClick={handleIconReset}>
                <span dangerouslySetInnerHTML={{ __html: SVG.reset }} /> 초기화
              </button>
            </div>
          </div>
        )}
        <div className="cqc-set-divider" />
        <div className="cqc-set-item danger" onClick={handleDeleteFolder}>
          <span dangerouslySetInnerHTML={{ __html: SVG.delete }} />
          <span>폴더 삭제</span>
        </div>
      </div>

      <div className="cqc-folder-popover-toolbar">
        <div className="cqc-fpop-search-box">
          <div className="cqc-fpop-search-icon">
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          </div>
          <input type="text" className="cqc-folder-popover-search" placeholder="채널 검색..." spellCheck={false} value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="cqc-pop-tools">
          <div className="cqc-sort-wrap">
            <button className="cqc-sort-btn" title="정렬 기준" onClick={() => {
              setSortOpen(!sortOpen);
              setSettingsOpen(false);
              setAddOpen(false);
            }}>
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18M6 12h12M9 18h6"/></svg>
            </button>
            <div className={`cqc-sort-dropdown ${sortOpen ? 'is-open' : ''}`}>
              {[
                { key: 'custom', label: '추가순' },
                { key: 'name', label: '이름순' },
                { key: 'viewers', label: '시청자순' },
              ].map(o => {
                const isActive = sortPref.key === o.key;
                return (
                  <button
                    key={o.key}
                    className={`cqc-sort-option ${isActive ? 'is-active' : ''}`}
                    onClick={() => handleSortChange(o.key)}
                  >
                    <span>{o.label}</span>
                    <span className="cqc-sort-dir-icon">
                      {isActive && (sortPref.dir === 'asc' ? '▲' : '▼')}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="cqc-fph-add-wrap">
            <button className="cqc-fph-add" title="채널 추가" onClick={() => {
              setAddOpen(!addOpen);
              setSettingsOpen(false);
              setSortOpen(false);
            }}>
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </button>
          </div>
        </div>
      </div>

      <div className="cqc-folder-popover-list">
        {entries.length === 0 && !addOpen ? (
          <div className="cqc-folder-popover-empty">
            <div className="cqc-fpop-empty-icon-wrap">
              <div className="cqc-fpop-empty-icon" dangerouslySetInnerHTML={{__html: SVG.folder}} />
              <div className="cqc-fpop-empty-glow"></div>
            </div>
            <div className="cqc-fpop-empty-text">폴더가 비어있습니다</div>
            <div className="cqc-fpop-empty-hint">+ 버튼으로 채널을 추가하거나<br/>사이드바에서 채널을 드래그해 오세요</div>
          </div>
        ) : (
          <>
            {live.length > 0 && (
              <div id="cqc-section-live-root">
                <div className="cqc-section-header">
                  <span className="cqc-section-live-dot"></span>
                  <span className="cqc-section-label cqc-section-label--live">LIVE</span>
                  <span className="cqc-section-live-count">{live.length}</span>
                  <div className="cqc-section-divider"></div>
                </div>
                <div className="cqc-section-items-live">
                  {live.map((it, idx) => (
                    <ChannelItem
                      key={it.id}
                      it={it}
                      totalIdx={idx}
                      allItems={allItems}
                      ddManager={ddManager}
                      onDrop={handleItemDrop}
                      folder={folder}
                      store={store}
                      ctxMenu={ctxMenu}
                      onRefresh={fetchEntries}
                      onChanged={onChanged}
                    />
                  ))}
                </div>
              </div>
            )}
            {addOpen && (
              <AddChannelPanel
                folder={folder}
                store={store}
                unaffiliated={unaffiliated}
                onClose={() => setAddOpen(false)}
                onAdded={() => {
                  fetchEntries();
                  onChanged?.();
                }}
                fetchUnaffiliated={fetchUnaffiliated}
                search={search}
              />
            )}
            {offline.length > 0 && (
              <div id="cqc-section-offline-root">
                <div className="cqc-section-header">
                  <span className="cqc-section-label cqc-section-label--offline">OFFLINE</span>
                  <span className="cqc-section-offline-count">{offline.length}</span>
                  <div className="cqc-section-divider"></div>
                </div>
                <div className="cqc-section-items-offline">
                  {offline.map((it, idx) => (
                    <ChannelItem
                      key={it.id}
                      it={it}
                      totalIdx={live.length + idx}
                      allItems={allItems}
                      ddManager={ddManager}
                      onDrop={handleItemDrop}
                      folder={folder}
                      store={store}
                      ctxMenu={ctxMenu}
                      onRefresh={fetchEntries}
                      onChanged={onChanged}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <div className="cqc-folder-popover-resize-handle" onMouseDown={e => handleResize(e, 'h')}></div>
      <div className="cqc-folder-popover-resize-handle-v" onMouseDown={e => handleResize(e, 'v')}></div>
    </div>
  );
};

const ChannelItem: React.FC<{
  it: EntryData;
  totalIdx: number;
  allItems: HTMLElement[];
  ddManager: DragDropManager;
  onDrop: Function;
  folder: FolderData;
  store: FolderStore;
  ctxMenu: ContextMenu;
  onRefresh: () => void;
  onChanged?: () => void;
}> = ({ it, totalIdx, allItems, ddManager, onDrop, folder, store, ctxMenu, onRefresh, onChanged }) => {
  const [isLive, setIsLive] = useState(it.isLive);
  const [thumbSrc, setThumbSrc] = useState(it.thumbSrc);
  const [viewers, setViewers] = useState(it.viewers);
  const [liveTitle, setLiveTitle] = useState(it.liveTitle);
  const [category, setCategory] = useState(it.category);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isVideoLoading, setIsVideoLoading] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [volIcon, setVolIcon] = useState(SVG_MUTE);

  const anchorRef = useRef<HTMLAnchorElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // 실시간 API를 통한 항목 상태 업데이트 (API status polling)
  useEffect(() => {
    let active = true;
    const updateLiveStatus = async () => {
      try {
        const resp = await fetch(`https://api.chzzk.naver.com/service/v2/channels/${it.id}/live-detail`);
        const json = await resp.json();
        if (!active) return;
        if (json.code === 200 && json.content) {
          const c = json.content;
          const isLiveNow = c.status === 'OPEN';
          setIsLive(isLiveNow);
          if (isLiveNow) {
            if (c.liveImageUrl) {
              setThumbSrc(c.liveImageUrl.replace('{type}', '480'));
            }
            if (c.concurrentUserCount !== undefined) {
              setViewers(c.concurrentUserCount);
            }
            if (c.liveTitle) {
              setLiveTitle(c.liveTitle);
            }
            if (c.liveCategoryValue) {
              setCategory(c.liveCategoryValue);
            }
          }
        }
      } catch (err) {
        console.warn(`[CQC] '${it.id}' API 업데이트 실패:`, err);
      }
    };

    updateLiveStatus();
    return () => {
      active = false;
    };
  }, [it.id]);

  // 드래그 앤 드롭 부착
  useEffect(() => {
    if (anchorRef.current) {
      ddManager.attach(anchorRef.current, it.id, (src, dst) => {
        onDrop(src, dst);
      });
    }
  }, [ddManager, it.id, onDrop]);

  // 음소거 상태 로드
  useEffect(() => {
    const loadMuteState = async () => {
      const muted = (await getKV('hoverPreviewMuted')) !== false;
      setIsMuted(muted);
      setVolIcon(muted ? SVG_MUTE : SVG_UNMUTE);
    };
    if (isLive) {
      loadMuteState();
    }
  }, [isLive]);

  // 호버 시 비디오 예약 및 재생 제어
  useEffect(() => {
    if (!isLive) return;

    if (isHovered) {
      setIsVideoLoading(true);
      timerRef.current = setTimeout(async () => {
        const videoEnabled = (await getKV('hoverPreviewVideoEnabled')) !== false;
        if (!videoEnabled) {
          setIsVideoLoading(false);
          return;
        }

        let liveData = null;
        try {
          const resp = await fetch(`https://api.chzzk.naver.com/service/v3/channels/${it.id}/live-detail`, { credentials: 'include' });
          const json = await resp.json();
          if (json.code === 200 && json.content) {
            liveData = json.content;
          }
        } catch (e) {
          console.warn('[CQC] live-detail fetch error:', e);
        }

        if (!liveData || !liveData.livePlaybackJson || !videoRef.current) {
          setIsVideoLoading(false);
          return;
        }

        let playbackJson;
        try {
          playbackJson = JSON.parse(liveData.livePlaybackJson);
        } catch (e) {
          setIsVideoLoading(false);
          return;
        }

        let hlsUrl = '';
        const mediaList = playbackJson.media || [];
        const preferredMedia = mediaList.find((m: any) => m.mediaId === 'LLHLS') || mediaList.find((m: any) => m.mediaId === 'HLS');

        if (preferredMedia) {
          const masterPath = preferredMedia.path || '';
          const track720 = preferredMedia.encodingTrack?.find((t: any) => t.encodingTrackId === '720p');
          if (track720 && track720.path) hlsUrl = track720.path;
          else if (track720 && masterPath) {
            if (masterPath.includes('_playlist.m3u8')) hlsUrl = masterPath.replace('_playlist.m3u8', '_720p_playlist.m3u8');
            else if (masterPath.includes('.m3u8')) hlsUrl = masterPath.replace('.m3u8', '_720p.m3u8');
            else hlsUrl = masterPath;
          } else hlsUrl = masterPath;
        }
        if (!hlsUrl && mediaList.length > 0) hlsUrl = mediaList[0].path;
        if (!hlsUrl) {
          setIsVideoLoading(false);
          return;
        }

        const video = videoRef.current;
        video.muted = isMuted;

        if (Hls && Hls.isSupported()) {
          if (hlsRef.current) hlsRef.current.destroy();

          const hls = new Hls({
            capLevelToPlayerSize: true,
            autoStartLoad: false,
            enableWorker: true,
            lowLatencyMode: false,
            liveSyncDurationCount: 3,
            liveMaxLatencyDurationCount: 10,
            maxBufferLength: 10,
            maxMaxBufferLength: 20,
            backBufferLength: 0
          });
          hlsRef.current = hls;

          hls.on(Hls.Events.ERROR, (event, eventData) => {
            if (eventData.fatal) {
              if (eventData.type === Hls.ErrorTypes.NETWORK_ERROR) {
                hls.startLoad();
              } else if (eventData.type === Hls.ErrorTypes.MEDIA_ERROR) {
                hls.recoverMediaError();
              } else {
                hls.destroy();
                hlsRef.current = null;
                setIsVideoLoading(false);
              }
            }
          });

          hls.on(Hls.Events.MEDIA_ATTACHED, () => {
            hls.loadSource(hlsUrl);
          });

          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            const level720 = hls.levels.findIndex(l => l.height === 720);
            if (level720 !== -1) {
              hls.currentLevel = level720;
              hls.startLevel = level720;
            }
            hls.startLoad();
            video.play()
              .then(() => {
                setIsPlaying(true);
              })
              .catch(() => {
                setIsVideoLoading(false);
              });
          });

          hls.attachMedia(video);
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = hlsUrl;
          const onLoadedMetadata = () => {
            video.play()
              .then(() => {
                setIsPlaying(isPlaying);
              })
              .catch(() => {
                setIsVideoLoading(false);
              });
          };
          video.addEventListener('loadedmetadata', onLoadedMetadata, { once: true });
        }
      }, 1200);
    } else {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
        timerRef.current = null;
      }
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      if (videoRef.current) {
        const video = videoRef.current;
        video.pause();
        video.removeAttribute('src');
        video.load();
      }
      setIsPlaying(false);
      setIsVideoLoading(false);
    }

    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (hlsRef.current) hlsRef.current.destroy();
    };
  }, [isHovered, it.id, isLive]);

  const handleMuteToggle = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    setVolIcon(nextMute ? SVG_MUTE : SVG_UNMUTE);
    await setKV('hoverPreviewMuted', nextMute);
    if (videoRef.current) {
      videoRef.current.muted = nextMute;
    }
  };

  const handleItemClick = (e: React.MouseEvent) => {
    if (e.ctrlKey || e.metaKey || e.button !== 0) return;
    const originalLi = allItems.find(li => li.dataset.channelId === it.id);
    const anchor = originalLi?.querySelector('a');
    if (anchor) {
      e.preventDefault();
      if (!triggerReact(anchor)) anchor.click();
      onCloseHelper();
    }
  };

  const onCloseHelper = () => {
    const closeBtn = document.querySelector('.cqc-fph-close') as HTMLButtonElement;
    closeBtn?.click();
  };

  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    ctxMenu.show({
      folder,
      x: e.clientX,
      y: e.clientY,
      triggerEl: e.currentTarget as HTMLElement,
      store,
      channelId: it.id,
      onChanged: () => {
        onRefresh();
        onChanged?.();
      }
    });
  };

  return (
    <a
      ref={anchorRef}
      href={it.href}
      className={`cqc-popover-item ${!isLive ? 'cqc-offline-focus' : ''}`}
      data-id={it.id}
      onClick={handleItemClick}
      onContextMenu={handleContextMenu}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="cqc-folder-popover-card">
        {isLive ? (
          <div className="cqc-thumb-box">
            <video
              ref={videoRef}
              className={`cqc-folder-popover-video ${isPlaying ? 'is-playing' : ''}`}
              muted
              playsInline
              onPlaying={() => setIsVideoLoading(false)}
            ></video>
            <img
              className={`cqc-folder-popover-thumb ${imgLoaded ? 'loaded' : ''}`}
              src={thumbSrc}
              onLoad={() => setImgLoaded(true)}
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_opacity2.png?type=f120_120';
              }}
              alt=""
            />
            {isHovered && (
              <div
                className="cqc-folder-popover-vol-btn"
                title="음소거 토글"
                onClick={handleMuteToggle}
                dangerouslySetInnerHTML={{ __html: volIcon }}
              ></div>
            )}
            {isHovered && isVideoLoading && (
              <div className="cqc-video-loading-overlay">
                <div className="cqc-spinner"></div>
              </div>
            )}
            <div className="cqc-thumb-live-badge">LIVE</div>
            <div className="cqc-thumb-viewers-wrap">
              <span className="cqc-folder-popover-viewers">{viewers.toLocaleString()}명</span>
            </div>
          </div>
        ) : (
          <div className="cqc-prof-box">
            <img
              className="cqc-fpi-profile-img"
              src={it.icon}
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_opacity2.png?type=f120_120';
              }}
              alt=""
            />
          </div>
        )}
        <div className="cqc-info-box">
          <div className="cqc-info-name-row">
            {isLive && (
              <img
                className="cqc-info-mini-profile"
                src={it.icon}
                onError={(e) => {
                  (e.target as HTMLImageElement).src = 'https://ssl.pstatic.net/cmstatic/nng/img/img_anonymous_square_gray_opacity2.png?type=f120_120';
                }}
                alt=""
              />
            )}
            <span className="cqc-folder-popover-name">{it.name}</span>
            {!isLive && <span className="cqc-offline-badge">OFFLINE</span>}
          </div>
          <span className="cqc-folder-popover-title">{isLive ? (liveTitle || '방송 중') : '오프라인'}</span>
          {isLive && (
            <div className="cqc-category-wrap is-visible">
              <span className="cqc-folder-popover-category">{category}</span>
            </div>
          )}
        </div>
      </div>
    </a>
  );
};

export class FolderModal {
  private _el: HTMLElement | null = null;
  private _root: Root | null = null;
  private _ctxMenu: ContextMenu;
  private _store: FolderStore;
  private _send: Function;
  private _utils: FolderModalUtils;
  private _onChanged: (() => void) | null = null;
  private _closeTimeout: any = null;

  constructor(ctxMenu: ContextMenu, store: FolderStore, send?: Function, utils?: FolderModalUtils, onChanged?: () => void) {
    this._ctxMenu = ctxMenu;
    this._store = store;
    this._send = send || (() => Promise.resolve(null));
    this._utils = utils || {};
    this._onChanged = onChanged || null;
  }

  close() {
    if (this._closeTimeout) {
      clearTimeout(this._closeTimeout);
      this._closeTimeout = null;
    }

    if (this._el) {
      this._el.classList.remove('is-visible');
      const pop = this._el.querySelector('.cqc-folder-popover');
      if (pop) pop.classList.remove('is-visible');

      const el = this._el;
      const r = this._root;

      this._closeTimeout = setTimeout(() => {
        if (r) {
          try { r.unmount(); } catch (e) {}
        }
        el.remove();
        if (this._el === el) {
          this._el = null;
        }
        if (this._root === r) {
          this._root = null;
        }
        this._closeTimeout = null;
      }, 400);
    }
  }

  async show(folder: FolderData, allItems: HTMLElement[], x: number, y: number, ddManager: DragDropManager, onDrop: Function, isRefresh = false) {
    if (this._closeTimeout) {
      clearTimeout(this._closeTimeout);
      this._closeTimeout = null;
    }

    let isNew = false;
    if (!this._el) {
      this._el = document.createElement('div');
      this._el.className = 'cqc-folder-popover-overlay';
      document.body.appendChild(this._el);
      isNew = true;
    }

    if (!this._el.classList.contains('is-visible')) {
      this._el.classList.add('is-visible');
      const pop = this._el.querySelector('.cqc-folder-popover');
      if (pop) pop.classList.add('is-visible');
    }

    if (!this._root) {
      this._root = createRoot(this._el);
    }

    this._root.render(
      <FolderModalComponent 
        folder={folder} 
        allItems={allItems} 
        x={x} y={y} 
        ddManager={ddManager} 
        onDrop={onDrop}
        store={this._store}
        ctxMenu={this._ctxMenu}
        send={this._send}
        utils={this._utils}
        onClose={() => this.close()}
        onChanged={() => this._onChanged?.()}
      />
    );

    if (isNew) {
      requestAnimationFrame(() => {
        if (this._el) {
          this._el.classList.add('is-visible');
        }
      });
    }
  }
}

