// @ts-nocheck
import Browser from 'webextension-polyfill';
import { initSidebarFolders, applyRefreshFoldersState } from './SidebarFolderManager';
import { SELECTORS, triggerReact, isSidebarCollapsed, log as cqcLog, getReactProps } from '../../../dom-utils';

const log = (...args: any[]) => cqcLog('FolderModule', ...args);

export class FolderModule {
  settings?: any;
  send?: Function;
  runtime?: any;
  _followingRefreshStarted?: boolean;
  tryRefreshFn?: Function;
  stopFollowingRefresh?: Function;
  onStorageChangeOffline?: any;
  manualCollapseCleanup?: Function;

  mount(settings: any, sendFn: any) {
    this.settings = settings;
    this.send = sendFn;

    // 초기 오프라인 채널 접힘/펼침 세팅 (사용자 옵션 반영)
    const offlineDefault = this.settings?.sidebarOfflineGroupDefaultState || 'collapsed';
    if (offlineDefault === 'collapsed') {
      this.settings.offlineGroupCollapsed = true;
    } else if (offlineDefault === 'expanded') {
      this.settings.offlineGroupCollapsed = false;
    }

    this.initHideOfflineFollowing();
    this.initFollowingRefresh();
    initSidebarFolders(this.settings, this.send);

    this.runtime.eventBus?.on('SETTINGS_UPDATED', this._onSettingsUpdated);
  }

  cleanup() {
    this.stopFollowingRefresh?.();
    if (this.onStorageChangeOffline) {
      Browser.storage.onChanged.removeListener(this.onStorageChangeOffline);
      this.onStorageChangeOffline = null;
    }
    initSidebarFolders({ sidebarFoldersEnabled: false }, this.send);
    this.runtime.eventBus?.off('SETTINGS_UPDATED', this._onSettingsUpdated);
  }

  onRouteChange(routeInfo: any, settings: any) {
    this.settings = settings || this.settings;
  }

  _onSettingsUpdated = (newSettings: any) => {
    const wasEnabled = this.settings?.followingRefreshEnabled || this.settings?.followingExpandEnabled;
    this.settings = newSettings;
    const isEnabled = this.settings?.followingRefreshEnabled || this.settings?.followingExpandEnabled;

    if (!wasEnabled && isEnabled) {
      if (!this._followingRefreshStarted) {
        this.initFollowingRefresh();
      } else if (this.tryRefreshFn) {
        this.initFollowingRefresh();
      }
      // 토글을 켰을 때 피드백을 위해 즉시 1회 실행
      if (this.tryRefreshFn && this.settings?.followingRefreshEnabled) this.tryRefreshFn();
    } else if (wasEnabled && !isEnabled) {
      this.stopFollowingRefresh?.();
      this._followingRefreshStarted = false;
    }

    initSidebarFolders(this.settings, this.send);
  }

  initHideOfflineFollowing = (e?: any) => {
    const update = () => {
      if (this.settings?.hideOfflineFollowing) {
        document.body.classList.add('cqc-hide-offline');
      } else {
        document.body.classList.remove('cqc-hide-offline');
      }
    };
    update();
    this.onStorageChangeOffline = () => update();
    Browser.storage.onChanged.addListener(this.onStorageChangeOffline);
  }

  initFollowingRefresh() {
    this._followingRefreshStarted = true;
    let timer = null;
    let secondsRemaining = 30;
    let userCollapsed = false;

    const findFollowingSection = () => {
      let sections = Array.from(document.querySelectorAll(SELECTORS.NAV_SECTION as string));

      if (!sections.length) return null;

      for (const sec of sections) {
        const titleEl = sec.querySelector(SELECTORS.NAV_TITLE as string);
        const title = titleEl?.textContent || '';
        if (title.includes('팔로잉')) {
            return sec;
        }
      }

      const isNavSection = (sec: any) => {
        const links = Array.from(sec.querySelectorAll('a')).map(a => a.getAttribute('href') || '');
        return links.some(h => h === '/lives' || h === '/clips' || h === '/category' || h === '/following');
      };
      for (let i = 0; i < sections.length; i++) {
        if (!isNavSection(sections[i])) {
          if (sections[i].querySelector(SELECTORS.LIVE_LINK)) return sections[i];
        }
      }
      return sections.length >= 2 ? sections[1] : sections[0];
    };

    const findRefreshBtn = () => {
      const section = findFollowingSection();
      if (!section) return null;
      const btn = section.querySelector(SELECTORS.SIDEBAR_REFRESH_BTN);
      return btn ? (btn.tagName === 'BUTTON' ? btn : btn.closest('button')) : null;
    };

    const startManualCollapseDetect = () => {
      const sidebar = document.querySelector(SELECTORS.SIDEBAR_ASIDE) || document.body;
      const onSidebarClick = (e) => {
        const target = e.target;
        
        const anyBtn = target.closest?.('button');
        if (anyBtn && (anyBtn.getAttribute('aria-label') === '새로고침' || anyBtn.closest(SELECTORS.SIDEBAR_REFRESH_BTN))) {
          if (!isSidebarCollapsed()) {
            applyRefreshFoldersState();
          }
        }

        const btn = target.closest?.('button[aria-expanded]');
        if (!btn) return;
        const section = btn.closest(SELECTORS.NAV_SECTION);
        if (!section) return;
        const title = section.querySelector(SELECTORS.NAV_TITLE)?.textContent || '';
        if (!title.includes('팔로잉')) return;
        if (btn.getAttribute('aria-label') === '새로고침') return;
        
        const isExpanded = btn.getAttribute('aria-expanded') === 'true';
        if (isExpanded) {
          log('팔로잉 목록 사용자에 의해 접힘');
          userCollapsed = true;
          this.send?.('SET_USER_COLLAPSED', true).catch(() => { });
        } else {
          log('팔로잉 목록 사용자에 의해 펼쳐짐');
          userCollapsed = false;
          this.send?.('SET_USER_COLLAPSED', false).catch(() => { });
        }
      };
      sidebar.addEventListener('click', onSidebarClick);
      this.manualCollapseCleanup = () => sidebar.removeEventListener('click', onSidebarClick);
    };

    const tryRefresh = async (immediate = false) => {
      if (!this.settings?.followingRefreshEnabled) return;
      if (immediate) secondsRemaining = 30;

      if (this.settings?.followingExpandEnabled) {
        try {
          await this.send?.('EXPAND_FOLLOWING');
          await new Promise(resolve => setTimeout(resolve, 150));
        } catch (e) {
          log('더보기 확장 메시지 실패', e);
        }
      }

      const refreshBtn = findRefreshBtn();
      if (refreshBtn) {
        if (!triggerReact(refreshBtn)) {
          refreshBtn.click();
        }
      }
    };

    this.tryRefreshFn = tryRefresh;

    const tick = () => {
      if (!this.settings?.followingRefreshEnabled) return;
      // 모든 페이지(예: /lives)에서 자동 갱신이 동작하도록 라우트 제한을 제거합니다.

      const refreshBtn = findRefreshBtn();
      if (refreshBtn) {
        secondsRemaining--;
        refreshBtn.title = `자동 갱신까지 ${secondsRemaining}초 남음`;
        if (secondsRemaining <= 0) {
          tryRefresh();
          secondsRemaining = 30;
        }
      } else {
        secondsRemaining = 30;
      }
    };

    const start = () => {
      if (timer) this.runtime.timerManager.clearInterval(timer);
      secondsRemaining = 30;
      timer = this.runtime.timerManager.setInterval(tick, 1000);
      
      startManualCollapseDetect();
    };

    this.stopFollowingRefresh = () => {
      if (timer) this.runtime.timerManager.clearInterval(timer);
      if (this.manualCollapseCleanup) this.manualCollapseCleanup();
      const refreshBtn = findRefreshBtn();
      if (refreshBtn) refreshBtn.removeAttribute('title');
    };

    if (this.settings?.followingRefreshEnabled || this.settings?.followingExpandEnabled) start();
  }
}
