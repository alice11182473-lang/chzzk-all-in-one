// @ts-nocheck
import Browser from 'webextension-polyfill';
import { isSidebarCollapsed, triggerReact } from '../../../dom-utils';
import { SelectorRegistry } from '../../utils/SelectorRegistry';

const SIDEBAR_WIDTH_KEY = 'sidebarWidth';
const SIDEBAR_LOCK_KEY = 'sidebarResizeLocked';
const SIDEBAR_MIN_WIDTH = 80;
const SIDEBAR_COLLAPSE_THRESHOLD = 150;
const SIDEBAR_EXPAND_THRESHOLD = 200;
const SIDEBAR_HANDLE_CLASS = 'cqc-sidebar-resize-handle';
const SIDEBAR_HANDLE_LOCKED_CLASS = SIDEBAR_HANDLE_CLASS + '--locked';

const CHEEZEFARM_SVG = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.54671 8.31941C7.79368 8.122 8.12469 8.07586 8.42464 8.17586L13.5047 9.87019C13.7995 9.96868 14.0314 10.2003 14.1297 10.4952L15.8221 15.5743C15.9221 15.8742 15.8759 16.2043 15.6785 16.4512C13.8267 18.7678 9.40527 22.2398 4.03303 20.5518C3.78937 20.4751 3.59078 20.2973 3.48616 20.0675L3.4471 19.9659C1.75912 14.5937 5.23024 10.1714 7.54671 8.31941ZM8.28303 9.92098C6.29355 11.6585 3.92805 15.0765 4.951 19.047C8.92227 20.0708 12.3394 17.7039 14.077 15.7139L12.6287 11.3692L8.28303 9.92098Z" fill="currentColor"></path><path d="M17.3371 3.28879C17.7228 2.90341 18.3478 2.90341 18.7335 3.28879L20.7101 5.26535C21.0959 5.65118 21.0959 6.27698 20.7101 6.66281L17.047 10.3259C16.6612 10.7117 16.0354 10.7117 15.6496 10.3259L13.673 8.34934C13.2876 7.96359 13.2876 7.3386 13.673 6.95285L17.3371 3.28879ZM15.379 7.6511L16.3478 8.61985L19.004 5.9636L18.0353 4.99485L15.379 7.6511Z" fill="currentColor"></path><path d="M15.9171 9.28511L9.30776 15.8925C8.97575 16.224 8.4374 16.2234 8.10561 15.8916C7.77417 15.5595 7.77479 15.0221 8.10659 14.6904L14.715 8.08198L15.9171 9.28511Z" fill="currentColor"></path></svg>';

const getValue = async (key: string, def: any) => {
  try {
    const res = await Browser.storage.sync.get({ [key]: def });
    return res[key];
  } catch {
    return def;
  }
};

const setValue = async (key: string, val: any) => {
  try {
    await Browser.storage.sync.set({ [key]: val });
  } catch {
    // ignore
  }
};

const findSidebar = () => {
  const SELECTORS = SelectorRegistry.getInstance().getProxy();
  return document.querySelector(SELECTORS.SIDEBAR_ASIDE) as HTMLElement | null;
};

const findLayoutBody = () => {
  const SELECTORS = SelectorRegistry.getInstance().getProxy();
  return document.querySelector(SELECTORS.LAYOUT_BODY) as HTMLElement | null;
};

const replaceCheezeFarmBanner = () => {
  const SELECTORS = SelectorRegistry.getInstance().getProxy();
  const banner = document.querySelector('a[class*="aside_banner"]:not([data-cqc-cheeze])') as HTMLElement;
  if (!banner) return;

  const existingMenu = document.querySelector(SELECTORS.SIDEBAR_MENU_LINK);
  if (!existingMenu) return;

  banner.className = existingMenu.className;
  banner.removeAttribute('role');
  banner.setAttribute('data-cqc-cheeze', '1');
  banner.innerHTML = `${CHEEZEFARM_SVG}치즈팜`;
};

export class SidebarResizer {
  static #instance: SidebarResizer | null = null;

  #savedWidth = 0;
  #isDragging = false;
  #isLocked = false;
  #dragVisualCollapsed = false;
  #sidebarEl: HTMLElement | null = null;
  #handle: HTMLDivElement | null = null;
  #toastEl: HTMLDivElement | null = null;
  #isEnabled = true;
  #layoutCleanEnabled = true;
  #sidebarCollapsedState = false;

  #applyingLayout = false;
  #applyRetryTimer = 0;
  #injectInterval = 0;
  #collapseObserver: MutationObserver | null = null;
  #contentObserver: MutationObserver | null = null;

  #boundOnMouseDown: any;
  #boundOnMiddleClick: any;
  #boundOnMouseMove: any;
  #boundOnMouseUp: any;
  #boundOnResize: any;

  constructor() {
    if (SidebarResizer.#instance) return SidebarResizer.#instance;

    this.#boundOnMouseDown = this.#onMouseDown.bind(this);
    this.#boundOnMiddleClick = this.#onMiddleClick.bind(this);
    this.#boundOnMouseMove = this.#onMouseMove.bind(this);
    this.#boundOnMouseUp = this.#onMouseUp.bind(this);
    this.#boundOnResize = this.#onResize.bind(this);

    SidebarResizer.#instance = this;
  }

  static getInstance() {
    if (!SidebarResizer.#instance) {
      SidebarResizer.#instance = new SidebarResizer();
    }
    return SidebarResizer.#instance;
  }

  async start(forcedSettings?: any) {
    await this.#tryAttach(forcedSettings);

    this.#observeSidebarCollapse();
    this.#observeSidebarContent();

    if (!this.#injectInterval) {
      this.#injectInterval = window.setInterval(() => this.#trySetup(), 1000);
    }

    window.removeEventListener('resize', this.#boundOnResize);
    window.addEventListener('resize', this.#boundOnResize);
  }

  stop() {
    if (this.#injectInterval) {
      clearInterval(this.#injectInterval);
      this.#injectInterval = 0;
    }

    this.#collapseObserver?.disconnect();
    this.#collapseObserver = null;

    this.#contentObserver?.disconnect();
    this.#contentObserver = null;

    window.removeEventListener('resize', this.#boundOnResize);

    this.#hideCollapseToast();

    if (this.#sidebarEl) {
      this.#clearWidth(this.#sidebarEl);
      this.#sidebarEl.querySelector('.' + SIDEBAR_HANDLE_CLASS)?.remove();
    }
    this.#sidebarEl = null;
    this.#handle = null;
  }

  updateSettings(settings: any) {
    const cleanBtn = settings.layoutCleanEnabled ?? true;
    if (cleanBtn !== this.#layoutCleanEnabled) {
      this.#layoutCleanEnabled = cleanBtn;
      const isPlayerRoute = document.body.classList.contains('cqc-is-player-route');
      document.body.classList.toggle('cqc-sidebar-collapsed', this.#sidebarCollapsedState && this.#layoutCleanEnabled && isPlayerRoute);
    }

    const resizeBtn = settings.sidebarResizeEnabled ?? true;
    this.#isEnabled = resizeBtn;

    if (resizeBtn === false) {
      this.stop();
    } else {
      this.start(settings);
    }
  }

  async #tryAttach(forcedSettings?: any) {
    const settings = forcedSettings || (await getValue('settings', {}));
    this.#isEnabled = settings?.sidebarResizeEnabled ?? true;
    this.#layoutCleanEnabled = settings?.layoutCleanEnabled ?? true;

    this.#sidebarEl = findSidebar();
    if (!this.#sidebarEl) return;

    if (!this.#savedWidth) {
      this.#savedWidth = await getValue(SIDEBAR_WIDTH_KEY, 0);
      this.#isLocked = await getValue(SIDEBAR_LOCK_KEY, false);
    }

    replaceCheezeFarmBanner();
    if (isSidebarCollapsed()) {
      this.#applySidebarCollapsedLayout(true);
    } else {
      this.#applySidebarCollapsedLayout(false);
    }

    if (this.#isEnabled === false) {
      this.#clearWidth(this.#sidebarEl);
      this.#sidebarEl.querySelector('.' + SIDEBAR_HANDLE_CLASS)?.remove();
      return;
    }

    this.#attachHandle(this.#sidebarEl);
    if (this.#isLocked && this.#handle) {
      this.#handle.classList.add(SIDEBAR_HANDLE_LOCKED_CLASS);
    }

    if (this.#savedWidth > 0 && !isSidebarCollapsed()) {
      this.#applyWidth(this.#sidebarEl, this.#savedWidth);
    }
  }

  #applySidebarCollapsedLayout(collapsed: boolean) {
    this.#sidebarCollapsedState = collapsed;
    document.body.classList.toggle('cqc-sidebar-collapsed', collapsed && this.#layoutCleanEnabled);
    replaceCheezeFarmBanner();
  }

  #reapplySidebarLayout() {
    if (this.#applyingLayout) return;
    this.#applyingLayout = true;
    const applied = (() => {
      if (!document.querySelector('a[class*="aside_banner"]:not([data-cqc-cheeze])')) return false;
      replaceCheezeFarmBanner();
      return true;
    })();
    this.#applyingLayout = false;
    if (!applied && !this.#applyRetryTimer) {
      this.#applyRetryTimer = window.setTimeout(() => {
        this.#applyRetryTimer = 0;
        if (document.querySelector('a[class*="aside_banner"]:not([data-cqc-cheeze])')) {
          replaceCheezeFarmBanner();
        }
      }, 300);
    }
  }

  #clickToggleSidebar(expand: boolean) {
    const SELECTORS = SelectorRegistry.getInstance().getProxy();
    const btn = document.querySelector(SELECTORS.SIDEBAR_TOGGLE_BTN) as HTMLElement | null;
    if (!btn) return;

    const currentlyCollapsed = btn.getAttribute('aria-expanded') === 'false';
    if (expand && !currentlyCollapsed) return;
    if (!expand && currentlyCollapsed) return;

    if (!triggerReact(btn)) btn.click();
  }

  #showCollapseToast() {
    if (this.#toastEl) return;
    this.#toastEl = document.createElement('div');
    this.#toastEl.className = 'cqc-collapse-toast';
    this.#toastEl.textContent = '← 150px 이하로 밀면 완전히 접힘';
    document.body.appendChild(this.#toastEl);
    const right = this.#sidebarEl ? this.#sidebarEl.getBoundingClientRect().right : SIDEBAR_MIN_WIDTH;
    this.#toastEl.style.left = (right + 12) + 'px';
    this.#toastEl.style.top = Math.round(window.innerHeight * 0.3) + 'px';
    requestAnimationFrame(() => this.#toastEl?.classList.add('cqc-collapse-toast--visible'));
  }

  #hideCollapseToast() {
    if (!this.#toastEl) return;
    const el = this.#toastEl;
    this.#toastEl = null;
    el.classList.remove('cqc-collapse-toast--visible');
    document.body.classList.remove('cqc-sidebar-alert');
    setTimeout(() => el.remove(), 200);
  }

  #getMaxWidth() {
    return Math.floor(window.innerWidth * 0.5);
  }

  #syncContentPadding(w: number) {
    const body = findLayoutBody();
    if (!body) return;
    body.style.setProperty('padding-left', w + 'px', 'important');
    window.dispatchEvent(new Event('resize'));
  }

  #clearContentPadding() {
    const body = findLayoutBody();
    if (!body) return;
    body.style.removeProperty('padding-left');
    window.dispatchEvent(new Event('resize'));
  }

  #applyWidth(el: HTMLElement, w: number) {
    const clamped = Math.max(SIDEBAR_MIN_WIDTH, Math.min(w, this.#getMaxWidth()));
    el.style.setProperty('width', clamped + 'px', 'important');
    el.style.setProperty('flex-basis', clamped + 'px', 'important');
    this.#syncContentPadding(clamped);
  }

  #clearWidth(el: HTMLElement) {
    el.style.width = '';
    el.style.flexBasis = '';
    el.style.removeProperty('width');
    el.style.removeProperty('flex-basis');
    this.#clearContentPadding();
  }

  #attachHandle(el: HTMLElement) {
    if (el.querySelector('.' + SIDEBAR_HANDLE_CLASS)) return;
    this.#handle = document.createElement('div');
    this.#handle.className = SIDEBAR_HANDLE_CLASS;
    el.appendChild(this.#handle);

    this.#handle.addEventListener('mousedown', this.#boundOnMouseDown);
    this.#handle.addEventListener('mousedown', this.#boundOnMiddleClick);
  }

  #onMiddleClick(e: MouseEvent) {
    if (e.button !== 1) return;
    e.preventDefault();
    e.stopPropagation();
    this.#isLocked = !this.#isLocked;
    this.#handle?.classList.toggle(SIDEBAR_HANDLE_LOCKED_CLASS, this.#isLocked);
    setValue(SIDEBAR_LOCK_KEY, this.#isLocked);
  }

  #onMouseDown(e: MouseEvent) {
    if (e.button !== 0) return;
    if (this.#isLocked) return;
    e.preventDefault();
    e.stopPropagation();
    this.#isDragging = true;
    this.#dragVisualCollapsed = isSidebarCollapsed();
    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'col-resize';
    document.body.classList.add('cqc-sidebar-dragging');
    document.addEventListener('mousemove', this.#boundOnMouseMove);
    document.addEventListener('mouseup', this.#boundOnMouseUp);
  }

  #onMouseMove(e: MouseEvent) {
    if (!this.#isDragging || !this.#sidebarEl) return;
    const rect = this.#sidebarEl.getBoundingClientRect();
    const newWidth = e.clientX - rect.left;
    const clamped = Math.max(SIDEBAR_MIN_WIDTH, Math.min(newWidth, this.#getMaxWidth()));

    if (!this.#dragVisualCollapsed && clamped <= SIDEBAR_COLLAPSE_THRESHOLD) {
      this.#dragVisualCollapsed = true;
      this.#hideCollapseToast();
      document.body.classList.remove('cqc-sidebar-dragging');
      this.#clickToggleSidebar(false);
      setTimeout(() => {
        this.#applySidebarCollapsedLayout(true);
        if (this.#sidebarEl) this.#clearWidth(this.#sidebarEl);
        if (this.#isDragging) document.body.classList.add('cqc-sidebar-dragging');
      }, 300);
      return;
    }

    if (!this.#dragVisualCollapsed && clamped > SIDEBAR_COLLAPSE_THRESHOLD && clamped <= SIDEBAR_COLLAPSE_THRESHOLD + 20) {
      this.#showCollapseToast();
      document.body.classList.add('cqc-sidebar-alert');
    } else {
      this.#hideCollapseToast();
    }

    if (this.#dragVisualCollapsed && clamped >= SIDEBAR_EXPAND_THRESHOLD) {
      this.#dragVisualCollapsed = false;
      this.#applySidebarCollapsedLayout(false);
      this.#clickToggleSidebar(true);
      setTimeout(() => {
        this.#applySidebarCollapsedLayout(false);
        if (this.#sidebarEl && this.#isDragging) {
          document.body.classList.add('cqc-sidebar-dragging');
          this.#applyWidth(this.#sidebarEl, clamped);
        }
      }, 300);
      return;
    }

    if (!this.#dragVisualCollapsed) {
      this.#applyWidth(this.#sidebarEl, clamped);
    }
  }

  #onMouseUp() {
    if (!this.#isDragging || !this.#sidebarEl) return;
    this.#isDragging = false;
    document.body.style.userSelect = '';
    document.body.style.cursor = '';
    document.removeEventListener('mousemove', this.#boundOnMouseMove);
    document.removeEventListener('mouseup', this.#boundOnMouseUp);
    document.body.classList.remove('cqc-sidebar-dragging');

    if (this.#dragVisualCollapsed) {
      this.#hideCollapseToast();
      this.#clearWidth(this.#sidebarEl);
      this.#savedWidth = 0;
      setValue(SIDEBAR_WIDTH_KEY, 0);
      return;
    }

    this.#hideCollapseToast();

    const finalWidth = this.#sidebarEl.offsetWidth;
    this.#savedWidth = finalWidth;
    setValue(SIDEBAR_WIDTH_KEY, finalWidth);
    this.#syncContentPadding(finalWidth);
  }

  #observeSidebarCollapse() {
    const sidebar = findSidebar();
    if (!sidebar) return;

    let prevCollapsed = isSidebarCollapsed();

    const onCollapseChange = () => {
      if (this.#isDragging) return;
      const collapsed = isSidebarCollapsed();
      if (collapsed === prevCollapsed) return;
      prevCollapsed = collapsed;

      if (!collapsed) {
        this.#applySidebarCollapsedLayout(false);
        setTimeout(() => this.#applySidebarCollapsedLayout(false), 100);
        if (this.#isEnabled && this.#savedWidth > 0) {
          this.#applyWidth(sidebar, this.#savedWidth);
        } else {
          this.#clearWidth(sidebar);
        }
      } else {
        this.#applySidebarCollapsedLayout(true);
        setTimeout(() => this.#applySidebarCollapsedLayout(true), 100);
        this.#clearWidth(sidebar);
        this.#savedWidth = 0;
        setValue(SIDEBAR_WIDTH_KEY, 0);
      }
    };

    const SELECTORS = SelectorRegistry.getInstance().getProxy();
    const toggleBtn = document.querySelector(SELECTORS.SIDEBAR_TOGGLE_BTN);
    this.#collapseObserver?.disconnect();

    if (toggleBtn) {
      this.#collapseObserver = new MutationObserver(() => onCollapseChange());
      this.#collapseObserver.observe(toggleBtn, { attributes: true, attributeFilter: ['aria-expanded'] });
    } else if (sidebar) {
      this.#collapseObserver = new MutationObserver(() => onCollapseChange());
      this.#collapseObserver.observe(sidebar, { attributes: true, attributeFilter: ['class', 'aria-expanded'] });
    }
  }

  #observeSidebarContent() {
    this.#contentObserver?.disconnect();
    const sidebar = findSidebar();
    if (!sidebar) return;
    this.#contentObserver = new MutationObserver(() => this.#reapplySidebarLayout());
    this.#contentObserver.observe(sidebar, { childList: true, subtree: true });
  }

  #trySetup() {
    if (!this.#isEnabled) return;
    const el = findSidebar();
    if (el && !el.querySelector('.' + SIDEBAR_HANDLE_CLASS)) {
      this.#sidebarEl = el;
      this.#tryAttach();
      this.#observeSidebarContent();
    }
    this.#reapplySidebarLayout();
  }

  #onResize() {
    if (!this.#isEnabled || !this.#sidebarEl || !this.#savedWidth) return;
    const max = this.#getMaxWidth();
    if (this.#savedWidth > max) {
      this.#applyWidth(this.#sidebarEl, max);
    }
  }
}

export function initSidebarResize(settings?: any) {
  const resizer = SidebarResizer.getInstance();
  resizer.start(settings);
  (window as any).cqcSidebarUpdate = (s: any) => resizer.updateSettings(s);
}
