/**
 * 사이드바 폴더 — 드래그 앤 드롭 관리자
 * 채널 및 폴더의 드래그 앤 드롭 이벤트를 처리합니다.
 */

/**
 * dragover 이벤트에서 호출: 커서가 스크롤 컨테이너 상하 엣지에 가까우면 자동 스크롤.
 * HTML5 DnD는 기본적으로 드래그 중 스크롤을 막으므로 수동으로 처리.
 * @param e
 */
export const autoScrollNearEdge = (e: DragEvent): void => {
  const ZONE = 60;   // 엣지에서 이 픽셀 이내일 때 스크롤 시작
  const SPEED = 10;  // 1회 스크롤 픽셀
  const scrollable = (e.target as Element).closest(
    '[class*="aside_content__"], [class*="navigation_bar_section__"], aside, nav'
  ) as Element | null;
  
  if (!scrollable) return;
  const rect = scrollable.getBoundingClientRect();
  if (e.clientY - rect.top < ZONE) scrollable.scrollTop -= SPEED;
  else if (rect.bottom - e.clientY < ZONE) scrollable.scrollTop += SPEED;
};

/* ═══════════════════════════════════════════
   DragDropManager — 드래그 앤 드롭 관리
   ═══════════════════════════════════════════ */

export class DragDropManager {
  private _draggedId: string | null = null;
  private _draggedFolderId: string | null = null;
  private _active: boolean = false;
  private _folderDragActive: boolean = false;

  get draggedId(): string | null { return this._draggedId; }
  get isActive(): boolean { return this._active; }
  get isFolderDragActive(): boolean { return this._folderDragActive; }

  /**
   * 채널 아이템에 드래그 앤 드롭을 부착합니다.
   * @param li - 대상 리스트 아이템
   * @param channelId - 채널 고유 ID
   * @param onDrop - 드롭 콜백
   */
  attach(
    li: HTMLElement, 
    channelId: string, 
    onDrop: (src: string, dst: string) => void
  ): void {
    li.setAttribute('draggable', 'true');
    // Firefox: <a>, <img> 자식 요소가 독자 드래그를 시작하면 li의 dragstart를 가로챔 → 차단
    li.querySelectorAll('a, img').forEach(child => child.setAttribute('draggable', 'false'));

    li.addEventListener('dragstart', (e: DragEvent) => {
      const currentId = li.dataset.channelId || channelId;
      this._draggedId = currentId;
      this._active = true;
      if (e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', currentId);
      }
      li.classList.add('cqc-dragging');
    });

    li.addEventListener('dragend', () => {
      this._draggedId = null;
      this._active = false;
      li.classList.remove('cqc-dragging');
      document.querySelectorAll('.cqc-drag-over').forEach(el => el.classList.remove('cqc-drag-over'));
    });

    li.addEventListener('dragover', (e: DragEvent) => {
      const currentId = li.dataset.channelId || channelId;
      if (!this._active || this._draggedId === currentId) return;
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
      li.classList.add('cqc-drag-over');
      autoScrollNearEdge(e);
    });

    li.addEventListener('dragleave', () => li.classList.remove('cqc-drag-over'));

    li.addEventListener('drop', (e: DragEvent) => {
      e.preventDefault();
      li.classList.remove('cqc-drag-over');
      const currentId = li.dataset.channelId || channelId;
      if (!this._active || !this._draggedId || this._draggedId === currentId) return;
      onDrop(this._draggedId, currentId);
    });
  }

  /**
   * 폴더 헤더에 드래그 앤 드롭 타겟을 부착합니다.
   * @param el - 폴더 헤더 요소
   * @param folderId - 폴더 고유 ID
   * @param onDropToFolder - 채널→폴더 드롭 콜백
   * @param onFolderReorder - 폴더 순서 변경 콜백
   */
  attachFolderTarget(
    el: HTMLElement, 
    folderId: string, 
    onDropToFolder: (channelId: string, folderId: string) => void, 
    onFolderReorder: (srcFolderId: string, dstFolderId: string) => void
  ): void {
    el.setAttribute('draggable', 'true');

    el.addEventListener('dragstart', (e: DragEvent) => {
      this._draggedFolderId = folderId;
      this._folderDragActive = true;
      if (e.dataTransfer) {
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', folderId);
      }
      el.classList.add('cqc-dragging');
    });

    el.addEventListener('dragend', () => {
      this._draggedFolderId = null;
      this._folderDragActive = false;
      el.classList.remove('cqc-dragging');
      document.querySelectorAll('.cqc-drag-over').forEach(el => el.classList.remove('cqc-drag-over'));
    });

    el.addEventListener('dragover', (e: DragEvent) => {
      if (!this._active && !this._folderDragActive) return;
      if (this._draggedFolderId === folderId) return;
      e.preventDefault();
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'move';
      el.classList.add('cqc-drag-over');
    });

    el.addEventListener('dragleave', () => el.classList.remove('cqc-drag-over'));

    el.addEventListener('drop', (e: DragEvent) => {
      e.preventDefault();
      el.classList.remove('cqc-drag-over');

      if (this._active && this._draggedId) {
        onDropToFolder(this._draggedId, folderId);
      } else if (this._folderDragActive && this._draggedFolderId && this._draggedFolderId !== folderId) {
        onFolderReorder(this._draggedFolderId, folderId);
      }
    });
  }
}
