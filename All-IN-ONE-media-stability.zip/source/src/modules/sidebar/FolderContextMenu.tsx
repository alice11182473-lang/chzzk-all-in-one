import React, { useEffect, useState, useRef, useMemo } from 'react';
import { createRoot, Root } from 'react-dom/client';
import { DEFAULT_COLOR, PRESET_COLORS, SVG } from './FolderConstants';
import { FolderData, FolderStore } from './FolderStore';

export interface ContextMenuProps {
  folder: FolderData;
  x: number;
  y: number;
  triggerEl: HTMLElement;
  store: FolderStore;
  onChanged: () => void;
  onRename?: (folder: FolderData, nameEl: HTMLElement) => void;
  channelId?: string;
  isPopover?: boolean;
  onClose: () => void;
}

const ContextMenuComponent: React.FC<ContextMenuProps> = ({
  folder, x, y, triggerEl, store, onChanged, onRename, channelId, isPopover, onClose
}) => {
  const [openSub, setOpenSub] = useState<'color' | 'icon' | 'sort' | null>(null);
  const [iconUrl, setIconUrl] = useState(folder.iconUrl && !folder.iconUrl.startsWith('data:') ? folder.iconUrl : '');
  const [tempColor, setTempColor] = useState(folder.color || DEFAULT_COLOR);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setTempColor(folder.color || DEFAULT_COLOR);
  }, [folder.color]);

  const isDark = document.documentElement.classList.contains('theme_dark') || getComputedStyle(document.documentElement).colorScheme === 'dark';

  const theme = useMemo(() => ({
    bg: isDark ? 'rgba(20, 20, 26, 0.94)' : 'rgba(255, 255, 255, 0.96)',
    border: isDark ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.08)',
    text: isDark ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.85)',
    textStrong: isDark ? '#fff' : '#141517',
    subBg: isDark ? 'rgba(0, 0, 0, 0.2)' : 'rgba(0, 0, 0, 0.04)',
    itemHover: isDark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)',
    divider: isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.08)',
    shadow: isDark ? '0 12px 32px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.05)'
      : '0 12px 32px rgba(0, 0, 0, 0.1), 0 4px 12px rgba(0, 0, 0, 0.05)',
    inputBg: isDark ? 'rgba(255, 255, 255, 0.05)' : '#fff',
    inputBorder: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.12)'
  }), [isDark]);

  const col = folder.color || DEFAULT_COLOR;
  const isCustomActive = !PRESET_COLORS.map(c => c.toLowerCase()).includes(col.toLowerCase());

  useEffect(() => {
    if (menuRef.current) {
      const r = menuRef.current.getBoundingClientRect();
      let fx = x, fy = y;
      if (fx + r.width > window.innerWidth) fx = window.innerWidth - r.width - 8;
      if (fy + r.height > window.innerHeight) fy = y - r.height;
      if (fx < 4) fx = 4;
      if (fy < 4) fy = 4;
      menuRef.current.style.left = `${fx}px`;
      menuRef.current.style.top = `${fy}px`;
      menuRef.current.style.visibility = 'visible';
    }
  }, [x, y, openSub]);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };
    const handleContextClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    setTimeout(() => {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('contextmenu', handleContextClick);
    }, 0);

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('contextmenu', handleContextClick);
    };
  }, [onClose]);

  const safeClose = () => {
    setTimeout(() => {
      onClose();
    }, 50);
  };

  const commitAndClose = async () => {
    await store.save();
    safeClose();
    onChanged();
  };

  const handleAction = async (act: string) => {
    switch (act) {
      case 'rename':
        safeClose();
        const nameEl = triggerEl.querySelector('.cqc-folder-name');
        if (nameEl && onRename) onRename(folder, nameEl as HTMLElement);
        break;
      case 'color':
        setOpenSub(openSub === 'color' ? null : 'color');
        break;
      case 'icon':
        setOpenSub(openSub === 'icon' ? null : 'icon');
        break;
      case 'sort':
        setOpenSub(openSub === 'sort' ? null : 'sort');
        break;
      case 'delete':
        store.deleteFolder(folder.id);
        await commitAndClose();
        break;
      case 'remove-channel':
        if (channelId) {
          store.removeChannel(channelId);
          await commitAndClose();
        }
        break;
    }
  };

  const handleSortChange = async (key: 'custom' | 'name' | 'viewers') => {
    const currentSort = folder.sortBy || 'viewers';
    const currentDir = folder.sortDir || 'desc';

    let nextDir: 'asc' | 'desc' = 'asc';
    if (currentSort === key || (key === 'viewers' && currentSort === 'viewer')) {
      nextDir = currentDir === 'asc' ? 'desc' : 'asc';
    } else if (key === 'viewers') {
      nextDir = 'desc';
    }

    folder.sortBy = key;
    folder.sortDir = nextDir;
    await commitAndClose();
  };

  const setFolderColor = async (color: string) => {
    folder.color = color;
    await commitAndClose();
  };

  const applyIconUrl = async (url: string) => {
    folder.iconUrl = url.trim() || undefined;
    await commitAndClose();
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      folder.iconUrl = reader.result as string;
      await commitAndClose();
    };
    reader.readAsDataURL(file);
  };

  const resetIcon = async () => {
    folder.iconUrl = undefined;
    await commitAndClose();
  };

  // CSS 클래스 적용으로 인한 인라인 스타일 선언 제거

  return (
    <div
      ref={menuRef}
      className="cqc-ctx-menu"
      style={{
        left: 0,
        top: 0,
        visibility: 'hidden'
      }}
      onContextMenu={(e) => e.preventDefault()}
      onMouseDown={(e) => e.stopPropagation()}
      onMouseUp={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      {channelId ? (
        <div 
          onClick={() => handleAction('remove-channel')}
          className="cqc-ctx-item danger"
        >
          <span dangerouslySetInnerHTML={{ __html: SVG.remove }} />
          <span>폴더에서 삭제</span>
        </div>
      ) : (
        <>
          {!isPopover && (
            <div 
              onClick={() => handleAction('rename')}
              className="cqc-ctx-item"
            >
              <span dangerouslySetInnerHTML={{ __html: SVG.rename }} />
              <span>이름 변경</span>
            </div>
          )}
          <div 
            onClick={() => handleAction('color')}
            className="cqc-ctx-item"
          >
            <span dangerouslySetInnerHTML={{ __html: SVG.color }} />
            <span>색상 변경</span>
            <span className="cqc-ctx-arrow">{openSub === 'color' ? '⌄' : '›'}</span>
          </div>
          {openSub === 'color' && (
            <div className="cqc-ctx-sub" onMouseDown={(e) => e.stopPropagation()}>
              <div className="cqc-ctx-colors">
                {PRESET_COLORS.map(c => {
                  const isActive = c.toLowerCase() === tempColor.toLowerCase();
                  return (
                    <button
                      key={c}
                      onClick={(e) => { e.stopPropagation(); setTempColor(c); setFolderColor(c); }}
                      className={`cqc-ctx-color-btn ${isActive ? 'active' : ''}`}
                      style={{ '--preset-color': c } as React.CSSProperties}
                    />
                  );
                })}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '4px 10px 10px', marginTop: '6px', borderTop: '1px solid var(--cqc-border-faint)', minWidth: 0, boxSizing: 'border-box' }}>
                <div style={{ position: 'relative', width: '24px', height: '24px', borderRadius: '4px', overflow: 'hidden', flexShrink: 0, border: '1px solid rgba(255,255,255,0.1)' }}>
                  <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none', color: '#fff', padding: '4px' }} dangerouslySetInnerHTML={{ __html: SVG.dropper }} />
                  <input
                    type="color"
                    className="cqc-ctx-color-input"
                    style={{ position: 'absolute', top: '-5px', left: '-5px', width: '34px', height: '34px', cursor: 'pointer', border: 'none', padding: 0 }}
                    value={(tempColor && tempColor.startsWith('#')) ? tempColor : DEFAULT_COLOR}
                    onChange={(e) => setTempColor(e.target.value)}
                    onBlur={(e) => setFolderColor(e.target.value)}
                    onMouseDown={(e) => e.stopPropagation()}
                  />
                </div>
                <input
                  type="text"
                  className="cqc-ctx-custom-color-text"
                  style={{
                    flex: 1,
                    minWidth: 0,
                    boxSizing: 'border-box',
                    height: '24px',
                    padding: '0 6px',
                    borderRadius: '4px',
                    border: `1px solid ${theme.inputBorder}`,
                    background: theme.inputBg,
                    color: theme.text,
                    fontSize: '11px',
                    outline: 'none'
                  }}
                  placeholder="HEX, oklch() 등"
                  value={tempColor}
                  onChange={(e) => setTempColor(e.target.value)}
                  onBlur={(e) => setFolderColor(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      setFolderColor(tempColor);
                    }
                  }}
                  onMouseDown={(e) => e.stopPropagation()}
                />
              </div>
            </div>
          )}

          <div 
            onClick={() => handleAction('icon')}
            className="cqc-ctx-item"
          >
            <span dangerouslySetInnerHTML={{ __html: SVG.icon }} />
            <span>아이콘 변경</span>
            <span className="cqc-ctx-arrow">{openSub === 'icon' ? '⌄' : '›'}</span>
          </div>
          {openSub === 'icon' && (
            <div className="cqc-ctx-sub" onMouseDown={(e) => e.stopPropagation()}>
              <div className="cqc-ctx-icon-section">
                <input
                  type="text" placeholder="이미지 URL 입력" className="cqc-ctx-icon-url" value={iconUrl}
                  onChange={(e) => setIconUrl(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') applyIconUrl(iconUrl);
                  }}
                />
                <div className="cqc-ctx-icon-actions">
                  <label className="cqc-ctx-upload-btn">
                    <span dangerouslySetInnerHTML={{ __html: SVG.upload }} />
                    파일 선택
                    <input type="file" accept="image/*" className="cqc-ctx-hidden-input" onChange={handleFileUpload} />
                  </label>
                  {folder.iconUrl && (
                    <button className="cqc-ctx-reset-btn" onClick={resetIcon}>
                      <span dangerouslySetInnerHTML={{ __html: SVG.reset }} />
                      초기화
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="cqc-ctx-divider" />
          <div className="cqc-ctx-section-title" style={{ padding: '6px 10px 4px', fontSize: '10px', color: isDark ? 'rgba(255, 255, 255, 0.4)' : 'rgba(0, 0, 0, 0.4)', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: '0.5px' }}>정렬 기준</div>
          
          {[
            { key: 'custom', label: '추가순' },
            { key: 'name', label: '이름순' },
            { key: 'viewers', label: '시청자순' },
          ].map(o => {
            const currentSort = folder.sortBy || 'viewers';
            const currentDir = folder.sortDir || 'desc';
            const isActive = currentSort === o.key || (o.key === 'viewers' && currentSort === 'viewer');
            return (
              <div
                key={o.key}
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onMouseUp={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleSortChange(o.key as 'custom' | 'name' | 'viewers');
                }}
                className={`cqc-ctx-item ${isActive ? 'is-active' : ''}`}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingRight: '14px',
                  fontWeight: isActive ? '700' : 'normal',
                  backgroundColor: isActive ? theme.itemHover : 'transparent'
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <span dangerouslySetInnerHTML={{ __html: SVG.sort }} style={{ opacity: isActive ? 1 : 0.6 }} />
                  <span>{o.label}</span>
                </div>
                {isActive && (
                  <span className="cqc-sort-dir-icon" style={{ fontSize: '10px', opacity: 0.8 }}>
                    {currentDir === 'asc' ? '▲' : '▼'}
                  </span>
                )}
              </div>
            );
          })}

          <div className="cqc-ctx-divider" />
          <div 
            onClick={() => handleAction('delete')}
            className="cqc-ctx-item danger"
          >
            <span dangerouslySetInnerHTML={{ __html: SVG.delete }} />
            <span>폴더 삭제</span>
          </div>
        </>
      )}
    </div>
  );
};

export class ContextMenu {
  private _el: HTMLDivElement | null = null;
  private _root: Root | null = null;
  private _open = false;

  get isOpen() { return this._open; }

  close() {
    if (this._root) {
      this._root.unmount();
      this._root = null;
    }
    if (this._el) {
      this._el.remove();
      this._el = null;
    }
    this._open = false;
  }

  show(opts: Omit<ContextMenuProps, 'onClose'>) {
    this.close();
    this._open = true;

    this._el = document.createElement('div');
    document.body.appendChild(this._el);

    this._root = createRoot(this._el);
    this._root.render(<ContextMenuComponent {...opts} onClose={() => this.close()} />);
  }
}
