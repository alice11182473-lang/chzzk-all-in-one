// @ts-nocheck
/**
 * 사이드바 폴더 — 메인 컨트롤러 (SidebarFolderManager)
 * 분리된 모듈을 조립하여 사이드바 폴더 기능을 관리합니다.
 */

import React, { useState, useEffect, useRef } from 'react';
import { createRoot, Root } from 'react-dom/client';
import Browser from 'webextension-polyfill';
import { SELECTORS, isSidebarCollapsed, getChannelData, getReactProps } from '../../../dom-utils';
import { DEFAULT_COLOR, SVG, LOG } from './FolderConstants';
import { FolderStore } from './FolderStore';
import { ContextMenu } from './FolderContextMenu';
import { DragDropManager, autoScrollNearEdge } from './FolderDragDrop';
import { FolderModal } from './FolderModal';

interface FolderHeaderComponentProps {
    folder: any;
    collapsed: boolean;
    theme: any;
    isDark: boolean;
    liveCount: number;
    isOfflineGroup: boolean;
    onContextMenu: (e: React.MouseEvent) => void;
    onRename: (newName: string) => void;
    headerEl: HTMLElement;
}

const FolderHeaderComponent: React.FC<FolderHeaderComponentProps> = ({
    folder,
    collapsed,
    theme,
    isDark,
    liveCount,
    isOfflineGroup,
    onContextMenu,
    onRename,
    headerEl
}) => {
    const [isHovered, setIsHovered] = useState(false);
    const [isMouseDown, setIsMouseDown] = useState(false);
    const [isRenaming, setIsRenaming] = useState(false);
    const nameRef = useRef<HTMLSpanElement>(null);

    const col = folder.color || DEFAULT_COLOR;

    // 외부 컨텍스트 메뉴 등에서 이름을 변경하기 위해 메서드 노출
    useEffect(() => {
        if (headerEl) {
            (headerEl as any).cqcStartRename = () => {
                setIsRenaming(true);
            };
        }
        return () => {
            if (headerEl) {
                delete (headerEl as any).cqcStartRename;
            }
        };
    }, [headerEl]);

    // 이름 수정 상태일 때 포커스 및 텍스트 전체 선택
    useEffect(() => {
        if (isRenaming && nameRef.current) {
            nameRef.current.focus();
            requestAnimationFrame(() => {
                const range = document.createRange();
                range.selectNodeContents(nameRef.current!);
                const sel = window.getSelection();
                sel?.removeAllRanges();
                sel?.addRange(range);
            });
        }
    }, [isRenaming]);

    const handleBlur = () => {
        setIsRenaming(false);
        const newName = nameRef.current?.textContent?.trim();
        if (newName && newName !== folder.name) {
            onRename(newName);
        } else {
            if (nameRef.current) {
                nameRef.current.textContent = folder.name;
            }
        }
        window.getSelection()?.removeAllRanges();
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        e.stopPropagation();
        if (e.key === 'Enter') {
            e.preventDefault();
            nameRef.current?.blur();
        }
        if (e.key === 'Escape') {
            e.preventDefault();
            if (nameRef.current) {
                nameRef.current.textContent = folder.name;
            }
            nameRef.current?.blur();
        }
    };

    // 호버/마우스다운 상태에 따른 동적 스타일 설정
    const scale = isMouseDown ? (collapsed ? 0.95 : 0.98) : (isHovered && collapsed ? 1.08 : 1.0);
    const iconBorderColor = isHovered && collapsed ? col : (isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.08)');
    const iconBoxShadow = isHovered && collapsed ? `0 0 10px ${col}60` : 'none';
    const iconBg = isDark
        ? (isHovered && collapsed
            ? `linear-gradient(135deg, #292936 0%, color-mix(in srgb, ${col} 12%, #1e1e28) 100%)`
            : `linear-gradient(135deg, #1e1e28 0%, color-mix(in srgb, ${col} 8%, #14141d) 100%)`)
        : (isHovered && collapsed
            ? `linear-gradient(135deg, #ffffff 0%, color-mix(in srgb, ${col} 10%, #f0f0f5) 100%)`
            : `linear-gradient(135deg, #ffffff 0%, color-mix(in srgb, ${col} 5%, #fafafa) 100%)`);
    const chevronOpacity = isHovered && !collapsed ? '1' : '0.4';

    const iconHtml = folder.iconUrl
        ? `<img src="${folder.iconUrl}" draggable="false" style="width: 18px; height: 18px; border-radius: 4px; object-fit: cover; transition: all 0.3s ease;"/>`
        : SVG.folder;

    return (
        <div
            className="cqc-folder-header-inner"
            style={{
                display: 'flex',
                alignItems: 'center',
                width: '100%',
                height: '100%',
                cursor: 'pointer',
                transform: `scale(${scale})`,
                transition: 'transform 0.15s ease-out',
                justifyContent: collapsed ? 'center' : 'flex-start',
                paddingLeft: collapsed ? '0' : '0px'
            }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => {
                setIsHovered(false);
                setIsMouseDown(false);
            }}
            onMouseDown={() => setIsMouseDown(true)}
            onMouseUp={() => setIsMouseDown(false)}
            onContextMenu={onContextMenu}
            onDoubleClick={(e) => {
                if (collapsed || isOfflineGroup) return;
                e.stopPropagation();
                setIsRenaming(true);
            }}
        >
            <div
                className="cqc-folder-icon-wrap"
                style={{
                    width: collapsed ? '32px' : '26px',
                    height: collapsed ? '32px' : '26px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: collapsed ? '8px' : '6px',
                    background: iconBg,
                    border: collapsed ? `1.5px solid ${iconBorderColor}` : 'none',
                    boxShadow: iconBoxShadow,
                    color: col,
                    flexShrink: 0,
                    marginLeft: collapsed ? '0' : '10px',
                    transition: 'all 0.25s cubic-bezier(0.2, 0.8, 0.2, 1)',
                    pointerEvents: 'none'
                }}
                dangerouslySetInnerHTML={{ __html: iconHtml }}
            />

            {!collapsed && (
                <>
                    <span
                        ref={nameRef}
                        className="cqc-folder-name"
                        contentEditable={isRenaming}
                        suppressContentEditableWarning
                        onBlur={handleBlur}
                        onKeyDown={handleKeyDown}
                        onKeyPress={(e) => e.stopPropagation()}
                        onKeyUp={(e) => e.stopPropagation()}
                        style={{
                            display: 'block',
                            flex: '1',
                            minWidth: '0',
                            fontSize: '13.5px',
                            fontWeight: '700',
                            color: theme.textColor,
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            letterSpacing: '-0.3px',
                            transition: 'all 0.3s ease',
                            outline: 'none',
                            paddingLeft: '8px',
                            userSelect: 'none',
                            pointerEvents: isRenaming ? 'auto' : 'none'
                        }}
                    >
                        {folder.name}
                    </span>

                    {liveCount > 0 && (
                        <span
                            className="cqc-folder-live-bubble"
                            style={{
                                display: 'block',
                                fontSize: '10px',
                                fontWeight: '800',
                                padding: '2px 7px',
                                background: `${col}20`,
                                color: col,
                                borderRadius: '10px',
                                flexShrink: 0,
                                boxShadow: `0 0 10px ${col}15`,
                                transition: 'all 0.3s ease',
                                marginRight: '8px',
                                pointerEvents: 'none'
                            }}
                        >
                            {liveCount}
                        </span>
                    )}

                    <span
                        className={`cqc-folder-chevron ${folder.isExpanded ? 'open' : ''}`}
                        style={{
                            display: 'flex',
                            opacity: chevronOpacity,
                            transition: 'all 0.3s ease, transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)',
                            transform: `rotate(${folder.isExpanded ? '0deg' : '-90deg'})`,
                            marginLeft: 'auto',
                            marginRight: '8px',
                            pointerEvents: 'none'
                        }}
                        dangerouslySetInnerHTML={{ __html: SVG.chevron }}
                    />
                </>
            )}
        </div>
    );
};

/* ═══════════════════════════════════════════
   SidebarFolderManager — 메인 컨트롤러 (싱글톤)
   ═══════════════════════════════════════════ */

class SidebarFolderManager {
    static #instance = null;
    #store = new FolderStore();
    #ctxMenu = new ContextMenu();
    #modal;
    #dragDrop = new DragDropManager();
    #send;
    #enabled = false;
    #applying = false;
    #lastKey = '';
    #pollId = 0;
    #observer = null;
    #themeObserver = null;
    #debounceId = 0;
    #rafId = 0;
    #settings: any = {};

    /** @param {Function} [send] */
    constructor(send) {
        if (SidebarFolderManager.#instance) return SidebarFolderManager.#instance;
        this.#send = send;
        this.#modal = new FolderModal(this.#ctxMenu, this.#store, this.#send, {
            findFollowingSection: () => this.#findFollowingSection(),
            isSidebarCollapsed: () => this.#isSidebarCollapsed(),
            extractChannelId: (href) => this.#extractChannelId(href),
            isLiveChannel: (el) => this.#isLiveChannel(el)
        }, () => {
            this.#lastKey = '';
            this.#apply();
        });
        SidebarFolderManager.#instance = this;
    }

    /** @returns {SidebarFolderManager} */
    static getInstance(send) {
        if (!SidebarFolderManager.#instance) SidebarFolderManager.#instance = new SidebarFolderManager(send);
        return SidebarFolderManager.#instance;
    }

    get enabled() { return this.#enabled; }

    /** 
     * @description 사이드바 폴더 기능을 시작합니다.
     * @returns {Promise<void>} 
     */
    async start(settings = {}) {
        this.#settings = settings;
        if (this.#enabled) return;
        this.#enabled = true;
        document.body.classList.add('cqc-folders-enabled');
        if (!this.#store.isReady) {
            await this.#store.init();

            // 일반 폴더 초기 접힘/펼침 설정 반영 (메모리 상에서만 일시 적용)
            const foldersDefault = this.#settings?.sidebarFoldersDefaultState || 'remember';
            if (foldersDefault === 'collapsed') {
                this.#store.folders.forEach(f => f.isExpanded = false);
            } else if (foldersDefault === 'expanded') {
                this.#store.folders.forEach(f => f.isExpanded = true);
            }
        }
        this.#startPolling();
        this.#startThemeObserver();
        LOG('시작');
    }

    /** @description 사이드바 폴더 기능을 정지합니다. */
    stop() {
        if (!this.#enabled) return;
        this.#enabled = false;
        document.body.classList.remove('cqc-folders-enabled');
        this.#stopPolling();
        this.#observer?.disconnect();
        this.#observer = null;
        this.#themeObserver?.disconnect();
        this.#themeObserver = null;
        this.#ctxMenu.close();
        this.#modal.close();
        this.#cleanup();

        LOG('정지');
    }

    /** @description 모든 채널 폴더를 접습니다. */
    async collapseAllFolders() {
        if (!this.#store.isReady) return;
        let changed = false;
        for (const folder of this.#store.folders) {
            if (folder.isExpanded) {
                folder.isExpanded = false;
                changed = true;
            }
        }
        if (this.#settings && typeof this.#settings.offlineGroupCollapsed !== 'undefined' && !this.#settings.offlineGroupCollapsed) {
            this.#settings.offlineGroupCollapsed = true;
            Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: this.#settings }).catch(() => { });
            changed = true;
        }
        if (changed) {
            await this.#store.save();
            this.#lastKey = '';
            this.#scheduleApply();
        }
    }

    /** @description 새로고침 시 설정된 기본 폴더 상태를 반영합니다. */
    async applyRefreshState() {
        if (!this.#store.isReady) return;
        let changed = false;

        const foldersDefault = this.#settings?.sidebarFoldersDefaultState || 'remember';
        if (foldersDefault === 'collapsed') {
            for (const folder of this.#store.folders) {
                if (folder.isExpanded) {
                    folder.isExpanded = false;
                    changed = true;
                }
            }
        } else if (foldersDefault === 'expanded') {
            for (const folder of this.#store.folders) {
                if (!folder.isExpanded) {
                    folder.isExpanded = true;
                    changed = true;
                }
            }
        }

        const offlineDefault = this.#settings?.sidebarOfflineGroupDefaultState || 'collapsed';
        if (offlineDefault === 'collapsed') {
            if (this.#settings && !this.#settings.offlineGroupCollapsed) {
                this.#settings.offlineGroupCollapsed = true;
                Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: this.#settings }).catch(() => { });
                changed = true;
            }
        } else if (offlineDefault === 'expanded') {
            if (this.#settings && this.#settings.offlineGroupCollapsed) {
                this.#settings.offlineGroupCollapsed = false;
                Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: this.#settings }).catch(() => { });
                changed = true;
            }
        }

        if (changed) {
            await this.#store.save();
            this.#lastKey = '';
            this.#scheduleApply();
        }
    }


    /** @param {any} settings */
    updateSettings(settings) {
        this.#settings = settings;
        this.#scheduleApply();
    }

    /* ═══════════════════════════════════════════
       Internal Helpers (Static or Private)
       ═══════════════════════════════════════════ */

    /** @returns {HTMLElement|null} 팔로잉 섹션 탐지 */
    #findFollowingSection() {
        let sections = Array.from(document.querySelectorAll(SELECTORS.NAV_SECTION as string));

        if (!sections.length) return null;

        for (const sec of sections) {
            const titleEl = sec.querySelector(SELECTORS.NAV_TITLE as string);
            if (titleEl && (titleEl.textContent?.includes('팔로잉') || titleEl.innerText?.includes('팔로잉'))) {
                return sec;
            }
        }

        const isNavSection = (sec) => {
            const links = Array.from(sec.querySelectorAll('a')).map(a => a.getAttribute('href') || '');
            return links.some(h => h === '/lives' || h === '/clips' || h === '/category' || h === '/following');
        };

        for (let i = 0; i < sections.length; i++) {
            if (!isNavSection(sections[i])) {
                if (sections[i].querySelector(SELECTORS.LIVE_LINK)) return sections[i];
            }
        }
        return sections.length >= 2 ? sections[1] : sections[0];
    }

    /** @returns {boolean} 사이드바가 접힌 상태인지 판별 */
    #isSidebarCollapsed() {
        return isSidebarCollapsed();
    }

    /** @param {string|null|undefined} href */
    #extractChannelId(href) {
        if (!href) return null;
        const match = href.split(/[?#]/)[0].match(/\/(?:live\/)?([a-f0-9]+|[0-9]+)\/?$/);
        return match ? match[1] : null;
    }

    /** @param {HTMLElement} el */
    #isLiveChannel(el) {
        return !!el.querySelector(SELECTORS.SIDEBAR_LIVE_INDICATOR);
    }

    /* ═══════════════════════════════════════════
       Polling & Observers
       ═══════════════════════════════════════════ */

    #startPolling() {
        this.#stopPolling();
        this.#pollId = window.setInterval(() => {
            if (!this.#enabled || this.#applying) return;
            this.#apply();
        }, 2000);
        setTimeout(() => this.#apply(), 200);
        setTimeout(() => this.#apply(), 1200);
    }

    #stopPolling() {
        if (this.#pollId) { clearInterval(this.#pollId); this.#pollId = 0; }
    }

    #scheduleApply() {
        if (!this.#rafId) {
            this.#rafId = window.requestAnimationFrame(() => {
                this.#rafId = 0;
                if (this.#enabled && !this.#applying) this.#apply();
            });
        }
        window.clearTimeout(this.#debounceId);
        this.#debounceId = window.setTimeout(() => {
            this.#debounceId = 0;
            if (this.#enabled && !this.#applying) this.#apply();
        }, 150);
    }

    #quickHideFolderChannels() {
        if (!this.#store.isReady) return;
        const section = this.#findFollowingSection();
        if (!section) return;
        const lc = section.querySelector(SELECTORS.SIDEBAR_LIST_CONTAINER as HTMLElement | null);
        if (!lc) return;

        const collapsed = this.#isSidebarCollapsed();
        const hideOffline = document.body.classList.contains('cqc-hide-offline');
        let nonFolderIdx = 0;

        for (const li of lc.querySelectorAll(SELECTORS.SIDEBAR_ITEM)) {
            const elLi = li as HTMLElement;
            if (elLi.classList.contains('cqc-folder-header')) continue;

            const a = elLi.querySelector(SELECTORS.SIDEBAR_NAV_LINK);
            const chId = this.#extractChannelId(a?.getAttribute('href'));
            if (!chId) continue;

            const folder = this.#store.folderOf(chId);
            const isLive = this.#isLiveChannel(elLi);
            if (folder) {
                const visible = !collapsed && folder.isExpanded && (isLive || !hideOffline);
                elLi.style.display = visible ? '' : 'none';
            } else {
                elLi.style.order = String(isLive ? -20000 + nonFolderIdx : 10001 + nonFolderIdx);
                nonFolderIdx++;
            }
        }
    }

    #observeSection(section) {
        this.#observer?.disconnect();
        const observer = new MutationObserver(() => {
            this.#quickHideFolderChannels();
            this.#scheduleApply();
        });
        observer.observe(section, {
            childList: true,
            subtree: false,
            attributes: true,
            attributeFilter: ['class']
        });

        // aside 감시 강화 (closest가 실패할 수 있으므로 querySelector 사용)
        const aside = document.querySelector(SELECTORS.SIDEBAR_ASIDE);
        if (aside) {
            observer.observe(aside, {
                attributes: true,
                attributeFilter: ['class', 'style', 'aria-expanded']
            });
        }

        // 토글 버튼 감시 추가
        const toggleBtn = document.querySelector(SELECTORS.SIDEBAR_TOGGLE_BTN);
        if (toggleBtn) {
            observer.observe(toggleBtn, {
                attributes: true,
                attributeFilter: ['aria-expanded', 'class']
            });
        }

        this.#observer = observer;
    }

    #startThemeObserver() {
        this.#themeObserver?.disconnect();
        this.#themeObserver = new MutationObserver((mutations) => {
            let shouldApply = false;
            for (const m of mutations) {
                if (m.target === document.documentElement) {
                    this.#lastKey = '';
                    shouldApply = true;
                    break;
                }
                if (m.target === document.body && m.attributeName === 'class') {
                    const cl = document.body.classList;
                    const isDark = cl.contains('theme_dark') || cl.contains('cqc-dark-theme');
                    const wasDark = document.body.dataset.cqcLastIsDark === 'true';
                    if (isDark !== wasDark) {
                        document.body.dataset.cqcLastIsDark = String(isDark);
                        shouldApply = true;
                        break;
                    }
                }
            }
            if (shouldApply) this.#scheduleApply();
        });

        this.#themeObserver.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['class', 'style']
        });

        this.#themeObserver.observe(document.body, {
            attributes: true,
            attributeFilter: ['class']
        });
    }

    /* ═══════════════════════════════════════════
       Core Logic
       ═══════════════════════════════════════════ */

    #apply() {
        if (this.#applying) return;
        if (!this.#store.isReady) return;
        this.#applying = true;
        try {
            const section = this.#findFollowingSection();
            if (!section) return;

            if (this.#ctxMenu.isOpen || section.querySelector('.cqc-folder-name[contenteditable="true"]')) return;

            const isDark = document.documentElement.classList.contains('theme_dark') ||
                getComputedStyle(document.documentElement).colorScheme === 'dark';
            document.body.classList.toggle('cqc-dark-theme', isDark);
            document.body.classList.toggle('cqc-light-theme', !isDark);

            if (!this.#observer) this.#observeSection(section);

            const collapsed = this.#isSidebarCollapsed();

            const rawItems = Array.from(section.querySelectorAll(SELECTORS.SIDEBAR_NAV_LINK as HTMLElement[])).map(a => {
                const el = a as HTMLElement;
                return el.closest(SELECTORS.SIDEBAR_ITEM as HTMLElement) || el.parentElement || el;
            });
            const seen = new Set();
            const items = [];
            for (const it of rawItems) {
                if (!seen.has(it)) { seen.add(it); items.push(it); }
            }

            const lc = items.length > 0
                ? items[0].parentElement
                : section.querySelector(SELECTORS.SIDEBAR_LIST_CONTAINER as HTMLElement | null);
            if (!lc) return;

            lc.style.display = 'flex';
            lc.style.flexDirection = 'column';

            if (!lc.dataset.cqcCtxDelegated) {
                lc.dataset.cqcCtxDelegated = '1';
                lc.addEventListener('contextmenu', (e) => {
                    const target = e.target as HTMLElement;
                    const li = target.closest('li[data-channel-id]' as HTMLElement | null);
                    if (!li) return;
                    const chId = li.dataset.channelId;
                    if (!chId) return;
                    const folder = this.#store.folderOf(chId);
                    if (!folder) return;
                    e.preventDefault();
                    e.stopPropagation();
                    this.#ctxMenu.show({
                        folder, x: e.clientX, y: e.clientY, triggerEl: li,
                        store: this.#store, channelId: chId,
                        onChanged: () => { this.#lastKey = ''; this.#apply(); },
                    });
                });
            }

            let needsFullRender = false;

            for (const li of items) {
                const a = li.querySelector(SELECTORS.SIDEBAR_NAV_LINK);
                let chId = this.#extractChannelId(a?.getAttribute('href'));
                if (!chId) {
                    const fiberData = getChannelData(li as HTMLElement);
                    if (fiberData?.channelId) chId = fiberData.channelId;
                }
                if (!chId) continue;
                li.dataset.channelId = chId;

                if (!li.dataset.cqcFolderBound) {
                    this.#dragDrop.attach(li as HTMLElement, chId, (src, dst) => this.#handleChannelDrop(src, dst));
                    li.dataset.cqcFolderBound = '1';
                    needsFullRender = true;
                }

                if (!li.style.order) {
                    needsFullRender = true;
                }
            }

            const folders = this.#store.folders;
            const itemMap = new Map<string, HTMLElement>();
            for (const li of items) {
                if (li.dataset.channelId) {
                    itemMap.set(li.dataset.channelId, li);
                }
            }

            const channelsInFolders = new Set<string>();
            for (const f of folders) {
                for (const item of f.items) {
                    channelsInFolders.add(item);
                }
            }

            const channelStates = items.map(it => {
                const id = it.dataset.channelId || '';
                const live = this.#isLiveChannel(it) ? '1' : '0';
                return `${id}:${live}`;
            }).join(',');

            const stateKey = JSON.stringify({
                folders,
                collapsed,
                states: channelStates,
                theme: isDark ? 'dark' : 'light',
                offlineFolded: !!this.#settings?.offlineGroupCollapsed,
                offlineFoldEnabled: this.#settings?.sidebarOfflineFoldEnabled !== false
            });
            if (!needsFullRender && this.#lastKey === stateKey && lc.querySelector('.cqc-folder-header')) return;
            this.#lastKey = stateKey;

            this.#render(lc, items, itemMap, channelsInFolders, collapsed, isDark);
        } finally {
            this.#applying = false;
        }
    }

    async #handleChannelDrop(srcChannel, dstChannel) {
        const srcFolder = this.#store.folderOf(srcChannel);
        const dstFolder = this.#store.folderOf(dstChannel);

        if (srcFolder && dstFolder && srcFolder.id === dstFolder.id) return;

        if (dstFolder) {
            this.#store.moveToFolder(srcChannel, dstFolder.id);
        } else if (srcFolder) {
            this.#store.removeChannel(srcChannel);
        } else {
            this.#store.createFolder(srcChannel, dstChannel);
        }
        await this.#store.save();
        this.#lastKey = '';
        this.#apply();
    }

    #render(lc: HTMLElement, items: HTMLElement[], itemMap: Map<string, HTMLElement>, channelsInFolders: Set<string>, collapsed: boolean, isDark: boolean) {
        const folders = this.#store.folders;
        const currentFolderIds = new Set(folders.map(f => f.id));

        lc.querySelectorAll('.cqc-folder-header').forEach((el: any) => {
            const fid = el.getAttribute('data-folder-id');
            if (!fid || (!currentFolderIds.has(fid) && fid !== 'cqc-offline-group')) {
                if (el._reactRoot) {
                    try { el._reactRoot.unmount(); } catch (e) { }
                    delete el._reactRoot;
                }
                el.remove();
            }
        });

        lc.classList.add('cqc-folder-enabled-list');
        lc.style.display = 'flex';
        lc.style.flexDirection = 'column';

        const theme = {
            bg: isDark ? 'transparent' : 'rgba(0, 0, 0, 0.02)',
            hoverBg: isDark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)',
            activeBg: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)',
            border: isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 0, 0, 0.12)',
            get iconBg() { return isDark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.07)'; },
            shadow: isDark ? '0 4px 12px rgba(0, 0, 0, 0.2)' : '0 2px 8px rgba(0, 0, 0, 0.05)',
            textColor: isDark ? 'rgba(255, 255, 255, 0.95)' : 'rgba(20, 21, 23, 0.95)',
        };

        folders.forEach((folder, fi) => {
            const ord = -30000 + fi * 200;
            const col = folder.color || DEFAULT_COLOR;

            let header = lc.querySelector(`.cqc-folder-header[data-folder-id="${folder.id}"]`) as HTMLElement | null;
            const isNew = !header;

            if (isNew) {
                header = document.createElement('li');
                header.className = 'cqc-folder-header';
                header.setAttribute('data-folder-id', folder.id);
                if (folder.id !== 'cqc-offline-group') {
                    this.#dragDrop.attachFolderTarget(header, folder.id, async (chId, fId) => {
                        this.#store.moveToFolder(chId, fId);
                        await this.#store.save(); this.#lastKey = ''; this.#apply();
                    }, async (srcF, dstF) => {
                        this.#store.reorderFolders(srcF, dstF);
                        await this.#store.save(); this.#lastKey = ''; this.#apply();
                    });
                }

                header.addEventListener('click', (e) => {
                    if ((e.target as HTMLElement).closest('.cqc-folder-name[contenteditable="true"]')) return;
                    e.stopPropagation();
                    const isCollapsed = this.#isSidebarCollapsed();
                    if (isCollapsed) {
                        const target = e.target as HTMLElement;
                        if (!target.closest('.cqc-folder-header-inner, .cqc-folder-icon-wrap')) return;
                        this.#modal.show(folder, items, e.clientX, e.clientY, this.#dragDrop, (src: string, dst: string) => this.#handleChannelDrop(src, dst));
                    } else {
                        folder.isExpanded = !folder.isExpanded;
                        this.#lastKey = '';
                        this.#apply();
                        this.#store.save();
                    }
                });
            }

            if (!header) return;

            this.#updateHeaderStyles(header, collapsed, ord, col, theme);

            const liveCount = folder.items.filter((id: string) => {
                const el = itemMap.get(id);
                return el ? this.#isLiveChannel(el) : false;
            }).length;

            const renderState = JSON.stringify({
                folderName: folder.name,
                folderExpanded: folder.isExpanded,
                folderColor: folder.color,
                folderIconUrl: folder.iconUrl,
                collapsed,
                isDark,
                liveCount
            });

            let root = (header as any)._reactRoot as Root | undefined;
            if (!root) {
                root = createRoot(header);
                (header as any)._reactRoot = root;
            }

            if ((header as any)._lastRenderState !== renderState) {
                (header as any)._lastRenderState = renderState;
                root.render(
                    <FolderHeaderComponent
                        folder={folder}
                        collapsed={collapsed}
                        theme={theme}
                        isDark={isDark}
                        liveCount={liveCount}
                        isOfflineGroup={false}
                        onContextMenu={(e) => {
                            e.preventDefault(); e.stopPropagation();
                            this.#ctxMenu.show({
                                folder, x: e.clientX, y: e.clientY, triggerEl: header!,
                                store: this.#store,
                                onChanged: () => { this.#lastKey = ''; this.#apply(); },
                                onRename: (f: any) => {
                                    if (header && (header as any).cqcStartRename) {
                                        (header as any).cqcStartRename();
                                    }
                                },
                            });
                        }}
                        onRename={async (newName) => {
                            folder.name = newName;
                            await this.#store.save();
                            this.#lastKey = '';
                            this.#apply();
                        }}
                        headerEl={header}
                    />
                );
            }

            if (isNew) {
                lc.appendChild(header);
            }

            this.#updateFolderItems(folder, itemMap, collapsed, ord, col);
        });

        let idx = 0;
        const offlineNonFolderItems: HTMLElement[] = [];

        for (const li of items) {
            let chId = li.dataset.channelId || this.#extractChannelId(li.querySelector(SELECTORS.SIDEBAR_NAV_LINK)?.getAttribute('href'));
            if (!chId) {
                const fiberData = getChannelData(li as HTMLElement);
                if (fiberData?.channelId) chId = fiberData.channelId;
            }
            if (chId) li.dataset.channelId = chId;
            if (chId && channelsInFolders.has(chId)) continue;
            const online = this.#isLiveChannel(li);
            if (online) {
                li.style.order = String(-20000 + idx);
                li.style.display = '';
            } else {
                offlineNonFolderItems.push(li);
            }
            li.style.flexShrink = '0';
            idx++;
            li.style.removeProperty('margin-top');
            li.classList.remove('cqc-in-folder', 'cqc-in-folder--first', 'cqc-in-folder--last');
            li.style.removeProperty('--folder-color');
        }

        const offlineFoldEnabled = this.#settings?.sidebarOfflineFoldEnabled !== false;
        const offlineFolded = !!this.#settings?.offlineGroupCollapsed;
        const hideOffline = document.body.classList.contains('cqc-hide-offline');

        if (offlineFoldEnabled && offlineNonFolderItems.length > 0 && !hideOffline) {
            let offlineHeader = lc.querySelector('.cqc-folder-header[data-folder-id="cqc-offline-group"]') as HTMLElement | null;
            const isNew = !offlineHeader;

            if (isNew) {
                offlineHeader = document.createElement('li');
                offlineHeader.className = 'cqc-folder-header cqc-offline-group-header';
                offlineHeader.setAttribute('data-folder-id', 'cqc-offline-group');

                offlineHeader.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const isCollapsed = this.#isSidebarCollapsed();
                    if (isCollapsed) {
                        const target = e.target as HTMLElement;
                        if (!target.closest('.cqc-folder-header-inner, .cqc-folder-icon-wrap')) return;
                    }

                    const section = this.#findFollowingSection();
                    const rawItems = Array.from(section?.querySelectorAll(SELECTORS.SIDEBAR_NAV_LINK) || []).map(a => {
                        const el = a as HTMLElement;
                        return el.closest(SELECTORS.SIDEBAR_ITEM) || el.parentElement || el;
                    });
                    const seen = new Set();
                    const allItems = [];
                    for (const it of rawItems) {
                        if (!seen.has(it)) { seen.add(it); allItems.push(it); }
                    }
                    const channelsInFolders = new Set<string>();
                    for (const f of this.#store.folders) {
                        for (const item of f.items) {
                            channelsInFolders.add(item);
                        }
                    }
                    const offlineItems = allItems.filter(li => {
                        const chId = li.dataset.channelId;
                        return chId && !channelsInFolders.has(chId) && !this.#isLiveChannel(li);
                    });

                    const currentOfflineFolder: any = {
                        id: 'cqc-offline-group',
                        name: '오프라인 (그룹)',
                        isExpanded: !this.#settings.offlineGroupCollapsed,
                        items: offlineItems.map(li => li.dataset.channelId).filter(Boolean),
                        color: '#adb5bd'
                    };

                    if (isCollapsed) {
                        this.#modal.show(currentOfflineFolder, items, e.clientX, e.clientY, this.#dragDrop, (src: string, dst: string) => this.#handleChannelDrop(src, dst));
                    } else {
                        this.#settings.offlineGroupCollapsed = !this.#settings.offlineGroupCollapsed;
                        Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: this.#settings }).catch(() => { });
                        this.#lastKey = '';
                        this.#apply();
                    }
                });
            }

            if (offlineHeader) {
                const virtualOfflineFolder: any = {
                    id: 'cqc-offline-group',
                    name: '오프라인 (그룹)',
                    isExpanded: !offlineFolded,
                    items: offlineNonFolderItems.map(li => li.dataset.channelId).filter(Boolean),
                    color: '#adb5bd'
                };

                const offCol = virtualOfflineFolder.color || DEFAULT_COLOR;
                this.#updateHeaderStyles(offlineHeader, collapsed, 10000, offCol, theme, true);

                const offRenderState = JSON.stringify({
                    folderName: virtualOfflineFolder.name,
                    folderExpanded: virtualOfflineFolder.isExpanded,
                    folderColor: virtualOfflineFolder.color,
                    itemsCount: virtualOfflineFolder.items.length,
                    collapsed,
                    isDark
                });

                let root = (offlineHeader as any)._reactRoot as Root | undefined;
                if (!root) {
                    root = createRoot(offlineHeader);
                    (offlineHeader as any)._reactRoot = root;
                }

                if ((offlineHeader as any)._lastRenderState !== offRenderState) {
                    (offlineHeader as any)._lastRenderState = offRenderState;
                    root.render(
                        <FolderHeaderComponent
                            folder={virtualOfflineFolder}
                            collapsed={collapsed}
                            theme={theme}
                            isDark={isDark}
                            liveCount={0}
                            isOfflineGroup={true}
                            onContextMenu={(e) => {
                                e.preventDefault(); e.stopPropagation();
                            }}
                            onRename={() => { }}
                            headerEl={offlineHeader}
                        />
                    );
                }

                if (isNew) {
                    lc.appendChild(offlineHeader);
                }

                offlineNonFolderItems.forEach((li, i) => {
                    li.style.order = String(10001 + i);
                    const shouldShow = virtualOfflineFolder.isExpanded && !collapsed;
                    li.style.display = shouldShow ? 'flex' : 'none';
                    li.classList.toggle('cqc-item-visible', shouldShow);

                    if (shouldShow) {
                        li.classList.add('cqc-in-folder');
                        li.classList.toggle('cqc-in-folder--offline', true);
                        li.style.setProperty('--folder-color', offCol);
                        li.classList.toggle('cqc-in-folder--first', i === 0);
                        li.classList.toggle('cqc-in-folder--last', i === offlineNonFolderItems.length - 1);
                    } else {
                        li.classList.remove('cqc-in-folder', 'cqc-in-folder--first', 'cqc-in-folder--last');
                        li.style.removeProperty('--folder-color');
                    }
                });
            }
        } else {
            const oh = lc.querySelector('.cqc-folder-header[data-folder-id="cqc-offline-group"]') as any;
            if (oh) {
                if (oh._reactRoot) {
                    try { oh._reactRoot.unmount(); } catch (e) { }
                    delete oh._reactRoot;
                }
                oh.remove();
            }
            offlineNonFolderItems.forEach((li, i) => {
                li.style.order = String(10001 + i);
                li.style.display = (collapsed || hideOffline) ? 'none' : '';
            });
        }
    }

    #updateHeaderStyles(header: HTMLElement, collapsed: boolean, ord: number, col: string, theme: any, isOfflineGroup = false) {
        header.style.order = String(ord);
        header.style.borderLeft = `2px solid ${col}`;
        header.style.setProperty('--folder-color', col);
        header.classList.toggle('is-collapsed', collapsed);

        // 하드코딩: 기본 폴더는 하단 10px(접힘)/4px(펼침) 여백. 오프라인 그룹은 추가로 상단 10px 여백.
        // 수정: 접힘 상태일 때 네이티브 margin과 중복되는 것을 막기 위해 0px로 설정.
        if (isOfflineGroup) {
            header.style.marginTop = '10px';
            header.style.marginBottom = collapsed ? '0px' : '4px';
        } else {
            header.style.marginTop = '0px';
            header.style.marginBottom = collapsed ? '0px' : '4px';
        }

        if (collapsed) {
            header.style.justifyContent = 'center';
            header.style.paddingLeft = '0';
        } else {
            header.style.removeProperty('justify-content');
            header.style.removeProperty('padding-left');
        }
    }

    #updateFolderItems(folder: any, itemMap: Map<string, HTMLElement>, collapsed: boolean, ord: number, col: string) {
        const folderItems: HTMLElement[] = [];
        folder.items.forEach((id: string) => {
            const el = itemMap.get(id);
            if (el) folderItems.push(el);
        });

        const sortBy = folder.sortBy || 'viewers';
        const sortDir = folder.sortDir || ((sortBy === 'viewers' || sortBy === 'viewer') ? 'desc' : 'asc');

        const parseViewersText = (text: string): number => {
            if (!text) return 0;
            let clean = text.replace(/[^0-9.만천kK]/g, '').trim();
            if (clean.includes('만')) {
                const num = parseFloat(clean.replace('만', ''));
                return isNaN(num) ? 0 : Math.round(num * 10000);
            }
            if (clean.includes('천')) {
                const num = parseFloat(clean.replace('천', ''));
                return isNaN(num) ? 0 : Math.round(num * 1000);
            }
            if (/[kK]$/.test(clean)) {
                const num = parseFloat(clean.replace(/[kK]$/, ''));
                return isNaN(num) ? 0 : Math.round(num * 1000);
            }
            const num = parseInt(clean, 10);
            return isNaN(num) ? 0 : num;
        };

        // React Props 트리 재귀 탐색 헬퍼들
        const findPropsValue = (node: any, checkFn: (n: any) => boolean, key: string, visited = new WeakSet()): any => {
            if (!node || typeof node !== 'object') return null;
            if (visited.has(node)) return null;
            visited.add(node);

            if (checkFn(node)) {
                return node[key];
            }

            if (node.props) {
                const res = findPropsValue(node.props, checkFn, key, visited);
                if (res !== null && res !== undefined) return res;
            }

            if (node.children) {
                if (Array.isArray(node.children)) {
                    for (const child of node.children) {
                        const res = findPropsValue(child, checkFn, key, visited);
                        if (res !== null && res !== undefined) return res;
                    }
                } else {
                    const res = findPropsValue(node.children, checkFn, key, visited);
                    if (res !== null && res !== undefined) return res;
                }
            }

            if (Array.isArray(node)) {
                for (const item of node) {
                    const res = findPropsValue(item, checkFn, key, visited);
                    if (res !== null && res !== undefined) return res;
                }
            }

            return null;
        };

        const extractText = (val: any): string => {
            if (!val) return '';
            if (typeof val === 'string') return val;
            if (typeof val === 'number') return String(val);
            if (Array.isArray(val)) {
                return val.map(item => extractText(item)).join('');
            }
            if (typeof val === 'object') {
                if (val.props && val.props.children !== undefined) {
                    return extractText(val.props.children);
                }
                if (val.children !== undefined) {
                    return extractText(val.children);
                }
            }
            return '';
        };

        const itemInfoMap = new Map<HTMLElement, { isLive: boolean, viewers: number, name: string }>();
        folderItems.forEach(el => {
            const isLive = this.#isLiveChannel(el);
            let viewers = 0;
            let name = el.dataset.channelId || '';

            // 1. React Props 직접 탐색 시도
            const targetEl = (el.matches(SELECTORS.SIDEBAR_NAV_ITEM) ? el : null) || el.querySelector(SELECTORS.SIDEBAR_NAV_ITEM) as HTMLElement | null || el;
            const props = getReactProps(targetEl);
            if (props) {
                // 스트리머명 탐색
                const nameVal = findPropsValue(
                    props,
                    (n) => n && n.className && (n.className.includes('navigator_name') || n.className.includes('name__')),
                    'children'
                );
                const extractedName = extractText(nameVal);
                if (extractedName) {
                    name = extractedName;
                }

                // 시청자수 탐색
                const countVal = findPropsValue(
                    props,
                    (n) => n && (n.type === 'em' || (n.className && (n.className.includes('navigator_count') || n.className.includes('count__') || n.className.includes('viewer_count')))),
                    'children'
                );
                const extractedCountText = extractText(countVal);
                if (extractedCountText) {
                    viewers = parseViewersText(extractedCountText);
                }
            }

            // 2. getChannelData Fallback
            if (!viewers || name === el.dataset.channelId) {
                const data = getChannelData(el);
                if (data) {
                    if (!viewers) viewers = data.viewers || 0;
                    if (name === el.dataset.channelId && data.channelName) {
                        name = data.channelName;
                    }
                }
            }

            // 3. DOM Fallback
            if (!viewers || viewers === 0) {
                const viewerEl = el.querySelector(`${SELECTORS.SIDEBAR_NAV_COUNT}, [class*="viewer_count"], [class*="viewer_num"], [class*="live_indicator"], [class*="state_live"]`) as HTMLElement | null;
                if (viewerEl && viewerEl.textContent) {
                    viewers = parseViewersText(viewerEl.textContent);
                }
            }
            if (name === el.dataset.channelId) {
                const nameEl = el.querySelector(`${SELECTORS.SIDEBAR_NAV_NAME}, [class*="name__"], [class*="nickname__"], [class*="navigator_name"]`) as HTMLElement | null;
                if (nameEl && nameEl.textContent) {
                    name = nameEl.textContent.trim();
                } else {
                    const imgEl = el.querySelector('img') as HTMLImageElement | null;
                    if (imgEl && imgEl.alt) {
                        name = imgEl.alt.trim();
                    }
                }
            }
            itemInfoMap.set(el, { isLive, viewers, name });
        });

        // 온라인 채널을 항상 상위에 오도록 정렬 & 시청자순/이름순/사용자지정순 기준 적용
        const sortedItems = [...folderItems].sort((a, b) => {
            const infoA = itemInfoMap.get(a)!;
            const infoB = itemInfoMap.get(b)!;

            const aLive = infoA.isLive ? 1 : 0;
            const bLive = infoB.isLive ? 1 : 0;

            if (aLive !== bLive) {
                return bLive - aLive;
            }

            let res = 0;
            if (sortBy === 'viewers' || sortBy === 'viewer') {
                if (infoA.isLive) {
                    res = infoA.viewers - infoB.viewers;
                }
            } else if (sortBy === 'name') {
                res = infoA.name.localeCompare(infoB.name, 'ko');
            }

            if (res !== 0) {
                return sortDir === 'desc' ? -res : res;
            }

            const idxA = folder.items.indexOf(a.dataset.channelId);
            const idxB = folder.items.indexOf(b.dataset.channelId);
            const idxRes = idxA - idxB;
            if (sortBy === 'custom') {
                return sortDir === 'desc' ? -idxRes : idxRes;
            }
            return idxRes;
        });

        const visibleItems = sortedItems.filter(li => {
            const online = this.#isLiveChannel(li);
            return !collapsed && folder.isExpanded && (online || !document.body.classList.contains('cqc-hide-offline'));
        });

        sortedItems.forEach((li, idx) => {
            const online = this.#isLiveChannel(li);
            li.style.order = String(ord + idx + 1);
            li.style.flexShrink = '0';
            const isVisible = !collapsed && folder.isExpanded && (online || !document.body.classList.contains('cqc-hide-offline'));
            li.style.display = isVisible ? '' : 'none';
            li.classList.add('cqc-in-folder');
            li.classList.toggle('cqc-in-folder--offline', !online);
            li.style.setProperty('--folder-color', col);

            const vIdx = visibleItems.indexOf(li);
            li.classList.toggle('cqc-in-folder--first', vIdx === 0);
            li.classList.toggle('cqc-in-folder--last', vIdx === visibleItems.length - 1 && vIdx !== -1);
        });
    }

    #cleanup() {
        const section = this.#findFollowingSection();
        if (!section) return;

        section.querySelectorAll('.cqc-folder-header').forEach((el: any) => {
            if (el._reactRoot) {
                try { el._reactRoot.unmount(); } catch (e) { }
                delete el._reactRoot;
            }
            el.remove();
        });
        section.querySelectorAll('.cqc-offline-group-header').forEach((el: any) => {
            if (el._reactRoot) {
                try { el._reactRoot.unmount(); } catch (e) { }
                delete el._reactRoot;
            }
            el.remove();
        });
        for (const li of (Array.from(section.querySelectorAll('li' as string)) as HTMLElement[])) {
            li.style.removeProperty('order');
            li.style.removeProperty('display');
            li.style.removeProperty('flex-shrink');
            li.classList.remove('cqc-in-folder', 'cqc-in-folder--first', 'cqc-in-folder--last');
            li.style.removeProperty('--folder-color');
            delete li.dataset.cqcFolderBound;
        }

        const lc = section.querySelector(SELECTORS.SIDEBAR_LIST_CONTAINER);
        if (lc) {
            (lc as HTMLElement).classList.remove('cqc-folder-enabled-list');
            (lc as HTMLElement).style.removeProperty('display');
            (lc as HTMLElement).style.removeProperty('flex-direction');
        }
    }
}

/* ═══════════════════════════════════════════
   Export — content.js 연동
   ═══════════════════════════════════════════ */

/** @type {SidebarFolderManager|null} */
let sidebarFolderManagerInstance = null;

/** 
 * @param {any} [settings] 
 * @param {Function} [send]
 */
export const initSidebarFolders = (settings = {}, send) => {
    if (!sidebarFolderManagerInstance) sidebarFolderManagerInstance = new SidebarFolderManager(send);

    const shouldEnable = settings?.sidebarFoldersEnabled !== false;

    if (shouldEnable) {
        sidebarFolderManagerInstance.updateSettings(settings);
        sidebarFolderManagerInstance.start(settings);
    } else {
        sidebarFolderManagerInstance.stop();
    }
};

/** @description 모든 사이드바 폴더를 접습니다. (외부 모듈용) */
export const collapseAllSidebarFolders = async () => {
    if (sidebarFolderManagerInstance) {
        await sidebarFolderManagerInstance.collapseAllFolders();
    }
};

/** @description 새로고침 시 설정된 기본 폴더 상태를 반영합니다. (외부 모듈용) */
export const applyRefreshFoldersState = async () => {
    if (sidebarFolderManagerInstance) {
        await sidebarFolderManagerInstance.applyRefreshState();
    }
};

