// @ts-nocheck
/**
 * 사이드바 폴더 — 메인 컨트롤러 (SidebarFolderManager)
 * 분리된 모듈을 조립하여 사이드바 폴더 기능을 관리합니다.
 */

import React from 'react';
import { SELECTORS, isSidebarCollapsed, getChannelData } from '../../../dom-utils';
import { DEFAULT_COLOR, SVG, LOG } from './FolderConstants';
import { FolderStore } from './FolderStore';
import { ContextMenu } from './FolderContextMenu';
import { DragDropManager, autoScrollNearEdge } from './FolderDragDrop';
import { FolderModal } from './FolderModal';

/* ═══════════════════════════════════════════
   SidebarFolderManager — 메인 컨트롤러 (싱글톤)
   ═══════════════════════════════════════════ */

class SidebarFolderManager {
    static #instance = null;
    #store = new FolderStore();
    #ctxMenu = new ContextMenu();
    #modal;
    #dragDrop = new DragDropManager();
    #send;
    #enabled = false;
    #applying = false;
    #lastKey = '';
    #pollId = 0;
    #observer = null;
    #themeObserver = null;
    #debounceId = 0;
    #rafId = 0;
    #settings: any = {};

    /** @param {Function} [send] */
    constructor(send) {
        if (SidebarFolderManager.#instance) return SidebarFolderManager.#instance;
        this.#send = send;
        this.#modal = new FolderModal(this.#ctxMenu, this.#store, this.#send, {
            findFollowingSection: () => this.#findFollowingSection(),
            isSidebarCollapsed: () => this.#isSidebarCollapsed(),
            extractChannelId: (href) => this.#extractChannelId(href),
            isLiveChannel: (el) => this.#isLiveChannel(el)
        }, () => {
            this.#lastKey = '';
            this.#apply();
        });
        SidebarFolderManager.#instance = this;
    }

    /** @returns {SidebarFolderManager} */
    static getInstance(send) {
        if (!SidebarFolderManager.#instance) SidebarFolderManager.#instance = new SidebarFolderManager(send);
        return SidebarFolderManager.#instance;
    }

    get enabled() { return this.#enabled; }

    /** 
     * @description 사이드바 폴더 기능을 시작합니다.
     * @returns {Promise<void>} 
     */
    async start(settings = {}) {
        this.#settings = settings;
        if (this.#enabled) return;
        this.#enabled = true;
        if (!this.#store.isReady) await this.#store.init();
        this.#startPolling();
        this.#startThemeObserver();
        LOG('시작');
    }

    /** @description 사이드바 폴더 기능을 정지합니다. */
    stop() {
        if (!this.#enabled) return;
        this.#enabled = false;
        this.#stopPolling();
        this.#observer?.disconnect();
        this.#observer = null;
        this.#themeObserver?.disconnect();
        this.#themeObserver = null;
        this.#ctxMenu.close();
        this.#modal.close();
        this.#cleanup();

        LOG('정지');
    }

    /** @param {any} settings */
    updateSettings(settings) {
        this.#settings = settings;
        this.#scheduleApply();
    }

    /* ═══════════════════════════════════════════
       Internal Helpers (Static or Private)
       ═══════════════════════════════════════════ */

    /** @returns {HTMLElement|null} 팔로잉 섹션 탐지 */
    #findFollowingSection() {
        const sections = Array.from(document.querySelectorAll(SELECTORS.NAV_SECTION as HTMLElement[]));
        if (!sections.length) return null;

        for (const sec of sections) {
            const titleEl = sec.querySelector(SELECTORS.NAV_TITLE);
            if (titleEl && (titleEl.textContent?.includes('팔로잉') || titleEl.innerText?.includes('팔로잉'))) {
                return sec;
            }
        }

        const isNavSection = (sec) => {
            const links = Array.from(sec.querySelectorAll('a')).map(a => a.getAttribute('href') || '');
            return links.some(h => h === '/lives' || h === '/clips' || h === '/category' || h === '/following');
        };

        for (let i = 0; i < sections.length; i++) {
            if (!isNavSection(sections[i])) {
                if (sections[i].querySelector(SELECTORS.LIVE_LINK)) return sections[i];
            }
        }
        return sections.length >= 2 ? sections[1] : sections[0];
    }

    /** @returns {boolean} 사이드바가 접힌 상태인지 판별 */
    #isSidebarCollapsed() {
        return isSidebarCollapsed();
    }

    /** @param {string|null|undefined} href */
    #extractChannelId(href) {
        if (!href) return null;
        const match = href.split(/[?#]/)[0].match(/\/(?:live\/)?([a-f0-9]+|[0-9]+)\/?$/);
        return match ? match[1] : null;
    }

    /** @param {HTMLElement} el */
    #isLiveChannel(el) {
        return !!el.querySelector(SELECTORS.SIDEBAR_LIVE_INDICATOR);
    }

    /* ═══════════════════════════════════════════
       Polling & Observers
       ═══════════════════════════════════════════ */

    #startPolling() {
        this.#stopPolling();
        this.#pollId = window.setInterval(() => {
            if (!this.#enabled || this.#applying) return;
            this.#apply();
        }, 2000);
        setTimeout(() => this.#apply(), 200);
        setTimeout(() => this.#apply(), 1200);
    }

    #stopPolling() {
        if (this.#pollId) { clearInterval(this.#pollId); this.#pollId = 0; }
    }

    #scheduleApply() {
        if (!this.#rafId) {
            this.#rafId = window.requestAnimationFrame(() => {
                this.#rafId = 0;
                if (this.#enabled && !this.#applying) this.#apply();
            });
        }
        window.clearTimeout(this.#debounceId);
        this.#debounceId = window.setTimeout(() => {
            this.#debounceId = 0;
            if (this.#enabled && !this.#applying) this.#apply();
        }, 150);
    }

    #quickHideFolderChannels() {
        if (!this.#store.isReady) return;
        const section = this.#findFollowingSection();
        if (!section) return;
        const lc = section.querySelector(SELECTORS.SIDEBAR_LIST_CONTAINER as HTMLElement | null);
        if (!lc) return;

        const collapsed = this.#isSidebarCollapsed();
        const hideOffline = document.body.classList.contains('cqc-hide-offline');
        let nonFolderIdx = 0;

        for (const li of lc.querySelectorAll(SELECTORS.SIDEBAR_ITEM)) {
            const elLi = li as HTMLElement;
            if (elLi.classList.contains('cqc-folder-header')) continue;

            const a = elLi.querySelector(SELECTORS.SIDEBAR_NAV_LINK);
            const chId = this.#extractChannelId(a?.getAttribute('href'));
            if (!chId) continue;

            const folder = this.#store.folderOf(chId);
            const isLive = this.#isLiveChannel(elLi);
            if (folder) {
                const visible = !collapsed && folder.isExpanded && (isLive || !hideOffline);
                elLi.style.display = visible ? '' : 'none';
            } else {
                elLi.style.order = String(isLive ? -20000 + nonFolderIdx : 10001 + nonFolderIdx);
                nonFolderIdx++;
            }
        }
    }

    #observeSection(section) {
        this.#observer?.disconnect();
        const observer = new MutationObserver(() => {
            this.#quickHideFolderChannels();
            this.#scheduleApply();
        });
        observer.observe(section, {
            childList: true,
            subtree: false,
            attributes: true,
            attributeFilter: ['class']
        });
        
        // aside 감시 강화 (closest가 실패할 수 있으므로 querySelector 사용)
        const aside = document.querySelector(SELECTORS.SIDEBAR_ASIDE);
        if (aside) {
            observer.observe(aside, {
                attributes: true,
                attributeFilter: ['class', 'style', 'aria-expanded']
            });
        }

        // 토글 버튼 감시 추가
        const toggleBtn = document.querySelector(SELECTORS.SIDEBAR_TOGGLE_BTN);
        if (toggleBtn) {
            observer.observe(toggleBtn, {
                attributes: true,
                attributeFilter: ['aria-expanded', 'class']
            });
        }
        
        this.#observer = observer;
    }

    #startThemeObserver() {
        this.#themeObserver?.disconnect();
        this.#themeObserver = new MutationObserver((mutations) => {
            let shouldApply = false;
            for (const m of mutations) {
                if (m.target === document.documentElement) {
                    this.#lastKey = '';
                    shouldApply = true;
                    break;
                }
                if (m.target === document.body && m.attributeName === 'class') {
                    const cl = document.body.classList;
                    const isDark = cl.contains('theme_dark') || cl.contains('cqc-dark-theme');
                    const wasDark = document.body.dataset.cqcLastIsDark === 'true';
                    if (isDark !== wasDark) {
                        document.body.dataset.cqcLastIsDark = String(isDark);
                        shouldApply = true;
                        break;
                    }
                }
            }
            if (shouldApply) this.#scheduleApply();
        });

        this.#themeObserver.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['class', 'style']
        });

        this.#themeObserver.observe(document.body, {
            attributes: true,
            attributeFilter: ['class']
        });
    }

    /* ═══════════════════════════════════════════
       Core Logic
       ═══════════════════════════════════════════ */

    #apply() {
        if (this.#applying) return;
        if (!this.#store.isReady) return;
        this.#applying = true;
        try {
            const section = this.#findFollowingSection();
            if (!section) return;

            if (this.#ctxMenu.isOpen || section.querySelector('.cqc-folder-name[contenteditable="true"]')) return;

            const isDark = document.documentElement.classList.contains('theme_dark') ||
                getComputedStyle(document.documentElement).colorScheme === 'dark';
            document.body.classList.toggle('cqc-dark-theme', isDark);
            document.body.classList.toggle('cqc-light-theme', !isDark);

            if (!this.#observer) this.#observeSection(section);

            const collapsed = this.#isSidebarCollapsed();

            const rawItems = Array.from(section.querySelectorAll(SELECTORS.SIDEBAR_NAV_LINK as HTMLElement[])).map(a => {
                const el = a as HTMLElement;
                return el.closest(SELECTORS.SIDEBAR_ITEM as HTMLElement) || el.parentElement || el;
            });
            const seen = new Set();
            const items = [];
            for (const it of rawItems) {
                if (!seen.has(it)) { seen.add(it); items.push(it); }
            }

            const lc = items.length > 0
                ? items[0].parentElement
                : section.querySelector(SELECTORS.SIDEBAR_LIST_CONTAINER as HTMLElement | null);
            if (!lc) return;

            lc.style.display = 'flex';
            lc.style.flexDirection = 'column';

            if (!lc.dataset.cqcCtxDelegated) {
                lc.dataset.cqcCtxDelegated = '1';
                lc.addEventListener('contextmenu', (e) => {
                    const target = e.target as HTMLElement;
                    const li = target.closest('li[data-channel-id]' as HTMLElement | null);
                    if (!li) return;
                    const chId = li.dataset.channelId;
                    if (!chId) return;
                    const folder = this.#store.folderOf(chId);
                    if (!folder) return;
                    e.preventDefault();
                    e.stopPropagation();
                    this.#ctxMenu.show({
                        folder, x: e.clientX, y: e.clientY, triggerEl: li,
                        store: this.#store, channelId: chId,
                        onChanged: () => { this.#lastKey = ''; this.#apply(); },
                    });
                });
            }

            let needsFullRender = false;

            for (const li of items) {
                const a = li.querySelector(SELECTORS.SIDEBAR_NAV_LINK);
                let chId = this.#extractChannelId(a?.getAttribute('href'));
                if (!chId) {
                    const fiberData = getChannelData(li as HTMLElement);
                    if (fiberData?.channelId) chId = fiberData.channelId;
                }
                if (!chId) continue;
                li.dataset.channelId = chId;
                
                if (!li.dataset.cqcFolderBound) {
                    this.#dragDrop.attach(li as HTMLElement, chId, (src, dst) => this.#handleChannelDrop(src, dst));
                    li.dataset.cqcFolderBound = '1';
                    needsFullRender = true;
                }
                
                if (!li.style.order) {
                    needsFullRender = true;
                }
            }

            const channelStates = items.map(it => {
                const id = it.dataset.channelId || '';
                const live = this.#isLiveChannel(it) ? '1' : '0';
                return `${id}:${live}`;
            }).join(',');

            const stateKey = JSON.stringify({
                folders: this.#store.folders,
                collapsed,
                states: channelStates,
                theme: isDark ? 'dark' : 'light',
                offlineFolded: !!this.#settings?.offlineGroupCollapsed,
                offlineFoldEnabled: this.#settings?.sidebarOfflineFoldEnabled !== false
            });
            if (!needsFullRender && this.#lastKey === stateKey && lc.querySelector('.cqc-folder-header')) return;
            this.#lastKey = stateKey;

            this.#render(lc, items, collapsed, isDark);
        } finally {
            this.#applying = false;
        }
    }

    async #handleChannelDrop(srcChannel, dstChannel) {
        const srcFolder = this.#store.folderOf(srcChannel);
        const dstFolder = this.#store.folderOf(dstChannel);

        if (srcFolder && dstFolder && srcFolder.id === dstFolder.id) return;

        if (dstFolder) {
            this.#store.moveToFolder(srcChannel, dstFolder.id);
        } else if (srcFolder) {
            this.#store.removeChannel(srcChannel);
        } else {
            this.#store.createFolder(srcChannel, dstChannel);
        }
        await this.#store.save();
        this.#lastKey = '';
        this.#apply();
    }

    #render(lc: HTMLElement, items: HTMLElement[], collapsed: boolean, isDark: boolean) {
        const folders = this.#store.folders;
        const currentFolderIds = new Set(folders.map(f => f.id));

        lc.querySelectorAll('.cqc-folder-header').forEach(el => {
            const fid = el.getAttribute('data-folder-id');
            if (!fid || (!currentFolderIds.has(fid) && fid !== 'cqc-offline-group')) el.remove();
        });

        lc.style.display = 'flex';
        lc.style.flexDirection = 'column';

        const theme = {
            bg: isDark ? 'transparent' : 'rgba(0, 0, 0, 0.02)',
            hoverBg: isDark ? 'rgba(255, 255, 255, 0.06)' : 'rgba(0, 0, 0, 0.05)',
            activeBg: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)',
            border: isDark ? 'rgba(255, 255, 255, 0.12)' : 'rgba(0, 0, 0, 0.12)',
            get iconBg() { return isDark ? 'rgba(255, 255, 255, 0.04)' : 'rgba(0, 0, 0, 0.07)'; },
            shadow: isDark ? '0 4px 12px rgba(0, 0, 0, 0.2)' : '0 2px 8px rgba(0, 0, 0, 0.05)',
            textColor: isDark ? 'rgba(255, 255, 255, 0.95)' : 'rgba(20, 21, 23, 0.95)',
        };

        folders.forEach((folder, fi) => {
            const ord = -30000 + fi * 200;
            const col = folder.color || DEFAULT_COLOR;

            let header = lc.querySelector(`.cqc-folder-header[data-folder-id="${folder.id}"]`) as HTMLElement | null;
            const isNew = !header;

            if (isNew) {
                header = document.createElement('li');
                header.className = 'cqc-folder-header';
                header.setAttribute('data-folder-id', folder.id);
            }

            if (!header) return;

            this.#updateHeaderStyles(header, collapsed, ord, col, theme);
            this.#updateHeaderContent(header, folder, items, collapsed, col, theme);

            if (isNew) {
                this.#attachHeaderEvents(header, folder, items, col, theme, isDark);
                lc.appendChild(header);
            }

            this.#updateFolderItems(folder, items, collapsed, ord, col);
        });

        let idx = 0;
        const offlineNonFolderItems: HTMLElement[] = [];

        for (const li of items) {
            let chId = li.dataset.channelId || this.#extractChannelId(li.querySelector(SELECTORS.SIDEBAR_NAV_LINK)?.getAttribute('href'));
            if (!chId) {
                const fiberData = getChannelData(li as HTMLElement);
                if (fiberData?.channelId) chId = fiberData.channelId;
            }
            if (chId) li.dataset.channelId = chId;
            if (chId && this.#store.folderOf(chId)) continue;
            const online = this.#isLiveChannel(li);
            if (online) {
                li.style.order = String(-20000 + idx);
                li.style.display = '';
            } else {
                offlineNonFolderItems.push(li);
            }
            li.style.flexShrink = '0';
            idx++;
            if (online) {
                if (collapsed) {
                    li.style.marginTop = '4px';
                } else {
                    li.style.removeProperty('margin-top');
                }
            }
            li.classList.remove('cqc-in-folder', 'cqc-in-folder--first', 'cqc-in-folder--last');
            li.style.removeProperty('--folder-color');
        }

        const offlineFoldEnabled = this.#settings?.sidebarOfflineFoldEnabled !== false;
        const offlineFolded = !!this.#settings?.offlineGroupCollapsed;
        const hideOffline = document.body.classList.contains('cqc-hide-offline');

        if (offlineFoldEnabled && offlineNonFolderItems.length > 0 && !hideOffline) {
            let offlineHeader = lc.querySelector('.cqc-folder-header[data-folder-id="cqc-offline-group"]') as HTMLElement | null;
            const isNew = !offlineHeader;

            if (isNew) {
                offlineHeader = document.createElement('li');
                offlineHeader.className = 'cqc-folder-header cqc-offline-group-header';
                offlineHeader.setAttribute('data-folder-id', 'cqc-offline-group');
            }

            if (offlineHeader) {
                const virtualOfflineFolder: any = {
                    id: 'cqc-offline-group',
                    name: '오프라인 (그룹)',
                    isExpanded: !offlineFolded,
                    items: offlineNonFolderItems.map(li => li.dataset.channelId).filter(Boolean),
                    color: '#adb5bd'
                };

                const offCol = virtualOfflineFolder.color || DEFAULT_COLOR;
                this.#updateHeaderStyles(offlineHeader, collapsed, 10000, offCol, theme);
                this.#updateHeaderContent(offlineHeader, virtualOfflineFolder, items, collapsed, offCol, theme);

                if (isNew) {
                    this.#attachHeaderEvents(offlineHeader, virtualOfflineFolder, items, offCol, theme, isDark);
                    lc.appendChild(offlineHeader);
                }

                offlineNonFolderItems.forEach((li, i) => {
                    li.style.order = String(10001 + i);
                    const shouldShow = virtualOfflineFolder.isExpanded && !collapsed;
                    li.style.display = shouldShow ? 'flex' : 'none';
                    li.classList.toggle('cqc-item-visible', shouldShow);
                });
            }
        } else {
            lc.querySelector('.cqc-folder-header[data-folder-id="cqc-offline-group"]')?.remove();
            offlineNonFolderItems.forEach((li, i) => {
                li.style.order = String(10001 + i);
                li.style.display = (collapsed || hideOffline) ? 'none' : '';
            });
        }
    }

    #updateHeaderStyles(header: HTMLElement, collapsed: boolean, ord: number, col: string, theme: any) {
        Object.assign(header.style, {
            order: String(ord),
            borderLeft: `2.5px solid ${col}`,
            display: 'flex',
            alignItems: 'center',
            cursor: 'pointer',
            padding: collapsed ? '4px 0' : '8px 12px 8px 8px',
            margin: collapsed ? '0' : '4px 0',
            borderRadius: '8px',
            transition: 'all 0.3s ease',
            position: 'relative',
            userSelect: 'none'
        });
        header.style.setProperty('--folder-color', col);
    }

    #updateHeaderContent(header: HTMLElement, folder: any, items: HTMLElement[], collapsed: boolean, col: string, theme: any) {
        if (!header.querySelector('.cqc-folder-icon-wrap')) {
            header.innerHTML = `
                <div class="cqc-folder-icon-wrap"></div>
                <span class="cqc-folder-name" style="display: none;"></span>
                <span class="cqc-folder-live-bubble" style="display: none;"></span>
                <span class="cqc-folder-chevron" style="display: none;"></span>
            `;
        }

        const iconWrap = header.querySelector('.cqc-folder-icon-wrap') as HTMLElement;
        const nameEl = header.querySelector('.cqc-folder-name') as HTMLElement;
        const bubbleEl = header.querySelector('.cqc-folder-live-bubble') as HTMLElement;
        const chevron = header.querySelector('.cqc-folder-chevron') as HTMLElement;

        const iconHtml = folder.iconUrl
            ? `<img src="${folder.iconUrl}" draggable="false" style="width: 18px; height: 18px; border-radius: 4px; object-fit: cover; transition: all 0.3s ease;"/>`
            : SVG.folder;
        if (iconWrap.innerHTML !== iconHtml) iconWrap.innerHTML = iconHtml;

        Object.assign(iconWrap.style, {
            width: collapsed ? '36px' : '26px',
            height: collapsed ? '36px' : '26px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            borderRadius: collapsed ? '12px' : '6px',
            background: theme.iconBg,
            border: collapsed ? `1px solid ${theme.border}` : 'none',
            color: col,
            flexShrink: '0',
            transition: 'all 0.3s ease, transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
        });

        if (collapsed) {
            nameEl.style.display = 'none';
            bubbleEl.style.display = 'none';
            chevron.style.display = 'none';
            header.style.justifyContent = 'center';
            header.style.paddingLeft = '0';
        } else {
            nameEl.style.display = 'block';
            if (nameEl.textContent !== folder.name) nameEl.textContent = folder.name;
            Object.assign(nameEl.style, {
                flex: '1',
                minWidth: '0',
                fontSize: '13.5px',
                fontWeight: '700',
                color: theme.textColor,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                letterSpacing: '-0.3px',
                marginLeft: '8px',
                transition: 'all 0.3s ease'
            });

            const liveCount = folder.items.filter((id: string) => {
                const el = items.find(it => it.dataset.channelId === id);
                return el ? this.#isLiveChannel(el) : false;
            }).length;

            if (liveCount > 0) {
                bubbleEl.textContent = String(liveCount);
                if (bubbleEl.style.display !== 'block') bubbleEl.style.display = 'block';
                Object.assign(bubbleEl.style, {
                    fontSize: '10px',
                    fontWeight: '800',
                    padding: '2px 7px',
                    background: `${col}20`,
                    color: col,
                    borderRadius: '10px',
                    flexShrink: '0',
                    boxShadow: `0 0 10px ${col}15`,
                    transition: 'all 0.3s ease'
                });
            } else {
                if (bubbleEl.style.display !== 'none') bubbleEl.style.display = 'none';
            }

            if (chevron.style.display !== 'flex') chevron.style.display = 'flex';
            if (chevron.innerHTML !== SVG.chevron) chevron.innerHTML = SVG.chevron;
            chevron.className = `cqc-folder-chevron ${folder.isExpanded ? 'open' : ''}`;
            Object.assign(chevron.style, {
                opacity: '0.4',
                transition: 'all 0.3s ease, transform 0.3s cubic-bezier(0.2, 0.8, 0.2, 1)',
                transform: `rotate(${folder.isExpanded ? '0deg' : '-90deg'})`,
                marginLeft: 'auto'
            });
        }
    }

    #attachHeaderEvents(header: HTMLElement, folder: any, items: HTMLElement[], col: string, theme: any, isDark: boolean) {
        header.addEventListener('mouseenter', () => {
            const isNowCollapsed = this.#isSidebarCollapsed();
            if (!isNowCollapsed) {
                header.style.background = theme.hoverBg;
                header.style.boxShadow = theme.shadow;
                const chevron = header.querySelector('.cqc-folder-chevron') as HTMLElement;
                if (chevron) chevron.style.opacity = '1';
            } else {
                const iconWrap = header.querySelector('.cqc-folder-icon-wrap') as HTMLElement;
                if (iconWrap) {
                    iconWrap.style.transform = 'scale(1.1)';
                    iconWrap.style.borderColor = col;
                    iconWrap.style.boxShadow = `0 4px 15px ${col}30`;
                    iconWrap.style.background = isDark ? 'rgba(255,255,255,0.08)' : '#fff';
                }
            }
        });

        header.addEventListener('mouseleave', () => {
            const isNowCollapsed = this.#isSidebarCollapsed();
            header.style.background = isNowCollapsed ? 'transparent' : theme.bg;
            header.style.boxShadow = 'none';
            if (isNowCollapsed) {
                const iconWrap = header.querySelector('.cqc-folder-icon-wrap') as HTMLElement;
                if (iconWrap) {
                    iconWrap.style.transform = 'scale(1)';
                    iconWrap.style.borderColor = theme.border;
                    iconWrap.style.boxShadow = 'none';
                    iconWrap.style.background = theme.iconBg;
                }
            } else {
                const chevron = header.querySelector('.cqc-folder-chevron') as HTMLElement;
                if (chevron) chevron.style.opacity = '0.4';
            }
        });

        header.addEventListener('mousedown', () => {
            const isNowCollapsed = this.#isSidebarCollapsed();
            if (!isNowCollapsed) {
                header.style.background = theme.activeBg;
                header.style.transform = 'scale(0.98)';
            } else {
                const iconWrap = header.querySelector('.cqc-folder-icon-wrap') as HTMLElement;
                if (iconWrap) iconWrap.style.transform = 'scale(0.95)';
            }
        });
        
        header.addEventListener('mouseup', () => {
            const isNowCollapsed = this.#isSidebarCollapsed();
            header.style.transform = 'scale(1)';
            if (isNowCollapsed) {
                const iconWrap = header.querySelector('.cqc-folder-icon-wrap') as HTMLElement;
                if (iconWrap) iconWrap.style.transform = 'scale(1.1)';
            }
        });

        header.addEventListener('click', async (e) => {
            if ((e.target as HTMLElement).closest('.cqc-folder-name[contenteditable="true"]')) return;
            e.stopPropagation();
            const isOfflineGroup = header.getAttribute('data-folder-id') === 'cqc-offline-group';
            const isNowCollapsed = this.#isSidebarCollapsed();

            if (isNowCollapsed) {
                this.#modal.show(folder, items, e.clientX, e.clientY, this.#dragDrop, (src: string, dst: string) => this.#handleChannelDrop(src, dst));
            } else {
                if (isOfflineGroup) {
                    this.#settings.offlineGroupCollapsed = !this.#settings.offlineGroupCollapsed;
                    if (this.#send) {
                        this.#send('SAVE_SETTINGS', this.#settings);
                    }
                    this.#lastKey = '';
                    this.#apply();
                } else {
                    folder.isExpanded = !folder.isExpanded;
                    await this.#store.save();
                    this.#lastKey = '';
                    this.#apply();
                }
            }
        });

        header.addEventListener('contextmenu', (e) => {
            if (folder.id === 'cqc-offline-group') return;
            e.preventDefault(); e.stopPropagation();
            this.#ctxMenu.show({
                folder, x: e.clientX, y: e.clientY, triggerEl: header,
                store: this.#store,
                onChanged: () => { this.#lastKey = ''; this.#apply(); },
                onRename: (f: any, el: HTMLElement) => {
                    const headerEl = el.closest('.cqc-folder-header') as any;
                    if (headerEl && typeof headerEl.cqcStartRename === 'function') {
                        headerEl.cqcStartRename();
                    } else {
                        this.#startRename(f, el);
                    }
                },
            });
        });

        if (folder.id !== 'cqc-offline-group') {
            this.#dragDrop.attachFolderTarget(header, folder.id, async (chId, fId) => {
                this.#store.moveToFolder(chId, fId);
                await this.#store.save(); this.#lastKey = ''; this.#apply();
            }, async (srcF, dstF) => {
                this.#store.reorderFolders(srcF, dstF);
                await this.#store.save(); this.#lastKey = ''; this.#apply();
            });
        }

        const nameEl = header.querySelector('.cqc-folder-name') as HTMLElement | null;
        if (nameEl && folder.id !== 'cqc-offline-group') {
            nameEl.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                this.#startRename(folder, nameEl);
            });
        }
        
        // 헬퍼: 컨텍스트 메뉴에서 쓸 수 있도록 메소드 노출
        (header as any).cqcStartRename = () => {
            if (nameEl) this.#startRename(folder, nameEl);
        };
    }

    #updateFolderItems(folder: any, items: HTMLElement[], collapsed: boolean, ord: number, col: string) {
        const folderItems = items.filter(li => {
            const chId = li.dataset.channelId;
            return chId && folder.items.includes(chId);
        });

        const visibleItems = folderItems.filter(li => {
            const online = this.#isLiveChannel(li);
            return !collapsed && folder.isExpanded && (online || !document.body.classList.contains('cqc-hide-offline'));
        });

        folderItems.forEach((li, idx) => {
            const online = this.#isLiveChannel(li);
            li.style.order = String(ord + idx + 1);
            li.style.flexShrink = '0';
            const isVisible = !collapsed && folder.isExpanded && (online || !document.body.classList.contains('cqc-hide-offline'));
            li.style.display = isVisible ? '' : 'none';
            li.classList.add('cqc-in-folder');
            li.classList.toggle('cqc-in-folder--offline', !online);
            li.style.setProperty('--folder-color', col);

            const vIdx = visibleItems.indexOf(li);
            li.classList.toggle('cqc-in-folder--first', vIdx === 0);
            li.classList.toggle('cqc-in-folder--last', vIdx === visibleItems.length - 1 && vIdx !== -1);
        });
    }

    #startRename(folder: any, nameEl: HTMLElement) {
        nameEl.setAttribute('contenteditable', 'true');
        nameEl.focus();

        const ac = new AbortController();
        const signal = ac.signal;

        requestAnimationFrame(() => {
            const range = document.createRange();
            range.selectNodeContents(nameEl);
            const sel = window.getSelection();
            sel?.removeAllRanges();
            sel?.addRange(range);
        });

        nameEl.addEventListener('blur', async () => {
            ac.abort();
            nameEl.removeAttribute('contenteditable');
            const newName = nameEl.textContent?.trim();
            if (newName && newName !== folder.name) {
                folder.name = newName;
                await this.#store.save();
                this.#lastKey = '';
                this.#apply();
            } else {
                nameEl.textContent = folder.name;
            }
            window.getSelection()?.removeAllRanges();
        }, { signal });

        nameEl.addEventListener('keydown', (e) => {
            e.stopPropagation();
            if (e.key === 'Enter') { e.preventDefault(); nameEl.blur(); }
            if (e.key === 'Escape') { e.preventDefault(); nameEl.textContent = folder.name; nameEl.blur(); }
        }, { signal });
        nameEl.addEventListener('keypress', (e) => e.stopPropagation(), { signal });
        nameEl.addEventListener('keyup', (e) => e.stopPropagation(), { signal });
    }

    #cleanup() {
        const section = this.#findFollowingSection();
        if (!section) return;

        section.querySelectorAll('.cqc-folder-header').forEach(el => el.remove());
        section.querySelectorAll('.cqc-offline-group-header').forEach(el => el.remove());
        for (const li of (Array.from(section.querySelectorAll('li' as string)) as HTMLElement[])) {
            li.style.removeProperty('order');
            li.style.removeProperty('display');
            li.style.removeProperty('flex-shrink');
            li.classList.remove('cqc-in-folder', 'cqc-in-folder--first', 'cqc-in-folder--last');
            li.style.removeProperty('--folder-color');
            delete li.dataset.cqcFolderBound;
        }

        const lc = section.querySelector(SELECTORS.SIDEBAR_LIST_CONTAINER);
        if (lc) {
            (lc as HTMLElement).style.removeProperty('display');
            (lc as HTMLElement).style.removeProperty('flex-direction');
        }
    }
}

/* ═══════════════════════════════════════════
   Export — content.js 연동
   ═══════════════════════════════════════════ */

/** @type {SidebarFolderManager|null} */
let sidebarFolderManagerInstance = null;

/** 
 * @param {any} [settings] 
 * @param {Function} [send]
 */
export const initSidebarFolders = (settings = {}, send) => {
    if (!sidebarFolderManagerInstance) sidebarFolderManagerInstance = new SidebarFolderManager(send);

    const shouldEnable = settings?.sidebarFoldersEnabled !== false;

    if (shouldEnable) {
        sidebarFolderManagerInstance.updateSettings(settings);
        sidebarFolderManagerInstance.start(settings);
    } else {
        sidebarFolderManagerInstance.stop();
    }
};
