// @ts-nocheck
import { SELECTORS, getFiberNode, getReactProps, ConsoleLogger } from '../../../dom-utils';

// Browser 폴리필 대신 직접 래퍼 구현 (injected.js 번들링 시 에러 방지)
const storage = {
  sync: {
    get: (/** @type {any} */ keys) => new Promise(r => {
      // @ts-ignore
      if (typeof browser !== 'undefined' && browser.storage && browser.storage.sync) {
        try {
          const res = browser.storage.sync.get(keys);
          if (res && typeof res.then === 'function') {
            res.then(r).catch(() => r({}));
          } else {
            // It might have succeeded but returned undefined in MV2, which we can't easily catch
            r({});
          }
        } catch (e) {
          r({});
        }
      } else {
        r({});
      }
    })
  },
  onChanged: {
    addListener: (/** @type {any} */ cb) => {
      // @ts-ignore
      if (typeof browser !== 'undefined' && browser.storage && browser.storage.onChanged) {
        // @ts-ignore
        browser.storage.onChanged.addListener(cb);
      }
    }
  }
};

const log = (...a: any[]) => { };
export const extractChatClassNames = (el: HTMLElement) => {
  if (!el) return null;

  const getSafeClassName = (targetEl: Element | null): string => {
    if (!targetEl) return '';
    const cn = targetEl.className;
    if (typeof cn === 'string') return cn;
    if (cn && typeof cn === 'object' && 'baseVal' in cn) {
      return cn.baseVal || '';
    }
    return '';
  };

  const className = getSafeClassName(el);
  const itemClass = className.split(' ').find(c => c.startsWith('_item_')) || className.split(' ')[0] || '';

  // 1. 닉네임 영역 클래스 추출
  const nicknameEl = el.querySelector('[class*="nickname"], [class*="_nickname_"]');
  const nicknameClass = nicknameEl ? getSafeClassName(nicknameEl).split(' ')[0] : '';

  // 2. 메시지 텍스트 영역 클래스 추출
  // 부모 chatting_message 직계 자식인 text 요소를 정확히 타겟팅 (닉네임 내부 text 방지)
  const messageEl = el.querySelector('[class*="chatting_message_"] > [class*="text"], [class*="_chatting_message_"] > [class*="_text_"]');
  const messageClass = messageEl ? getSafeClassName(messageEl).split(' ')[0] : '';

  // 3. 뱃지/아이콘 영역 클래스 추출
  const badgeEl = el.querySelector('[class*="badge"], [class*="_badge_"], [class*="icon"], [class*="_icon_"]');
  const badgeClass = badgeEl ? getSafeClassName(badgeEl).split(' ')[0] : '';

  // 4. 이모티콘 영역 클래스 추출
  const emojiEl = el.querySelector('[class*="emoji"], [class*="_emoji_"]');
  const emojiClass = emojiEl ? getSafeClassName(emojiEl).split(' ')[0] : '';

  return {
    itemClass,
    nicknameClass,
    messageClass,
    emojiClass,
    badgeClass
  };
};

class ChatUtilityManager {
  #rankingHideEnabled = true;
  #chatFontSize = 0;
  #chatStampEnabled = false;
  #chatStampSize = 10;
  #chatStampSizeLinked = false;
  #layoutCleanEnabled = true;
  #hideChatNickname = false;
  #hideChatBadge = false;
  #keepAnyBadge = false;

  /** @type {ChatUtilityManager|null} */
  static #instance = null;

  constructor() {
    if (ChatUtilityManager.#instance) return ChatUtilityManager.#instance;
    ChatUtilityManager.#instance = this;

    window.addEventListener('cqc-chat-classes-found', () => {
      this.#applyFontSizeCSS();
    });
  }

  static getInstance() {
    if (!ChatUtilityManager.#instance) ChatUtilityManager.#instance = new ChatUtilityManager();
    return ChatUtilityManager.#instance;
  }

  async boot() {
    log('Booting chat utilities...');
    await this.#loadSettings();
    this.#applyAll();
    this.#listenChanges();
    log('Chat utilities booted.', {
      rankingHide: this.#rankingHideEnabled,
      fontSize: this.#chatFontSize,
      stamps: this.#chatStampEnabled,
      stampSize: this.#chatStampSize,
      stampSizeLinked: this.#chatStampSizeLinked,
      hideChatNickname: this.#hideChatNickname,
      hideChatBadge: this.#hideChatBadge
    });
  }

  async #loadSettings() {
    const res = await storage.sync.get(['settings']);
    const data = /** @type {any} */ (res).settings ?? {};
    this.#rankingHideEnabled = data.rankingHideEnabled ?? true;
    this.#chatFontSize = data.chatFontSize ?? 0;
    this.#chatStampEnabled = data.chatStampEnabled ?? false;
    this.#chatStampSize = data.chatStampSize ?? 10;
    this.#chatStampSizeLinked = data.chatStampSizeLinked ?? false;
    this.#layoutCleanEnabled = data.layoutCleanEnabled ?? true;
    this.#hideChatNickname = data.hideChatNickname ?? false;
    this.#hideChatBadge = data.hideChatBadge ?? false;
    this.#keepAnyBadge = data.keepBadgeSubscription || data.keepBadgeActivity || data.keepBadgeCheatkey || data.keepBadgeRole;
  }

  #applyAll() {
    this.#applyFontSizeCSS();
    if (this.#rankingHideEnabled) {
      this.#hideRankingCSS();
    } else {
      this.#restoreRanking();
    }
    this.#applyLayoutClean(); // 레이아웃 정리 적용
    this.#applyNicknameCSS(); // 닉네임 숨김 적용
    this.#applyBadgeCSS(); // 뱃지 숨김 적용
  }

  #applyFontSizeCSS() {
    // 폰트 크기 조절 로직은 메인 월드(ChatFilterModule.ts)에서 처리하므로 여기선 빈 함수 처리
  }

  #hideRankingCSS() {
    if (this.#rankingHideEnabled) {
      document.documentElement.classList.add('cqc-chat-ranking-hide-active');
    } else {
      document.documentElement.classList.remove('cqc-chat-ranking-hide-active');
    }
  }

  #restoreRanking() {
    document.documentElement.classList.remove('cqc-chat-ranking-hide-active');
  }

  #applyLayoutClean() {
    if (this.#layoutCleanEnabled) {
      document.documentElement.classList.add('cqc-chat-layout-clean-active');
    } else {
      document.documentElement.classList.remove('cqc-chat-layout-clean-active');
    }
  }

  #applyNicknameCSS() {
    if (this.#hideChatNickname) {
      document.documentElement.classList.add('cqc-chat-nickname-hide-active');
    } else {
      document.documentElement.classList.remove('cqc-chat-nickname-hide-active');
    }
  }

  #applyBadgeCSS() {
    // 선택 유지가 켜져 있으면 컨테이너 통째 숨김(overlay.css)을 끄고,
    // 메인월드(ChatFilterModule)의 img 단위 숨김/예외에 맡긴다. (부모가 죽으면 유지 img도 안 보이므로)
    if (this.#hideChatBadge && !this.#keepAnyBadge) {
      document.documentElement.classList.add('cqc-chat-badge-hide-active');
    } else {
      document.documentElement.classList.remove('cqc-chat-badge-hide-active');
    }
  }

  #listenChanges() {
    storage.onChanged.addListener((/** @type {any} */ changes) => {
      if (changes.settings) {
        const data = /** @type {any} */ (changes.settings.newValue) || {};
        this.#rankingHideEnabled = data.rankingHideEnabled ?? true;
        this.#chatFontSize = data.chatFontSize ?? 0;
        this.#chatStampEnabled = data.chatStampEnabled ?? false;
        this.#chatStampSize = data.chatStampSize ?? 10;
        this.#chatStampSizeLinked = data.chatStampSizeLinked ?? false;
        this.#layoutCleanEnabled = data.layoutCleanEnabled ?? true;
        this.#hideChatNickname = data.hideChatNickname ?? false;
        this.#hideChatBadge = data.hideChatBadge ?? false;
        this.#keepAnyBadge = data.keepBadgeSubscription || data.keepBadgeActivity || data.keepBadgeCheatkey || data.keepBadgeRole;
        this.#applyAll();
        log('Chat utilities updated.', {
          rankingHide: this.#rankingHideEnabled,
          fontSize: this.#chatFontSize,
          stamps: this.#chatStampEnabled,
          stampSize: this.#chatStampSize,
          stampSizeLinked: this.#chatStampSizeLinked,
          layoutClean: this.#layoutCleanEnabled,
          hideChatNickname: this.#hideChatNickname,
          hideChatBadge: this.#hideChatBadge
        });
      }
    });
  }
}

/** 실시간 참여자 수집 (자동완성용) */
let activeSettings: any = null;

export const activeChatters = new Map();
const unfilteredMap = new WeakMap();

/**
 * 전역 설정된 리액트 dispatch 가로채기
 * @param {any} settings 
 */
export const initChatStateInterceptor = (settings, observer) => {
  activeSettings = settings;

  if (!observer) {
    ConsoleLogger.log('warn', 'Chat', 'StateObserver가 유효하지 않아 인터셉터를 부착할 수 없습니다.');
    return;
  }

  observer.poller.waitFor(
    'chatInterceptorWait',
    SELECTORS.CHAT_CONTAINER,
    (container) => {
      // 새 컨테이너 연결 시 훅 및 백업 상태 초기화
      (window as any).cqcCurrentChatHooks = new Set();
      (window as any).cqcCurrentChatHook = null;

      // DOM 기반 클래스명 동적 분석 및 캐싱 (VOD/다시보기 및 라이브 공통)
      const tryExtractDOMClasses = () => {
        const firstItem = container.querySelector(SELECTORS.CHAT_ITEM);
        if (firstItem) {
          const classes = extractChatClassNames(firstItem as HTMLElement);
          if (classes && classes.itemClass && classes.messageClass && classes.nicknameClass) {
            (window as any).cqcChatClassNames = classes;
            window.dispatchEvent(new CustomEvent('cqc-chat-classes-found'));
            return true;
          }
        }
        return false;
      };

      if (!tryExtractDOMClasses()) {
        const classObserver = new MutationObserver(() => {
          if (tryExtractDOMClasses()) {
            classObserver.disconnect();
          }
        });
        classObserver.observe(container, { childList: true, subtree: true });
        // 15초 후 관찰 자동 중지 (불필요 리소스 방지)
        setTimeout(() => classObserver.disconnect(), 15000);
      }

      let retryCount = 0;
      const maxRetries = 20;

      const tryIntercept = () => {
        const result = observer.hooks.intercept(
          'chatInterceptor',
          container,
          (state) => Array.isArray(state),
          (action, hookState, hookNode) => {
            // Hook #11(전체 채팅 데이터 훅) 판별 로직
            const checkIsChatArray = (arr) => {
              if (!Array.isArray(arr)) return false;
              if (arr.length === 0) return true; // 초기화 시점 빈 배열 매칭 허용
              const first = arr[0];
              return first && typeof first === 'object' && ('profile' in first || 'time' in first);
            };

            const isChatList = checkIsChatArray(hookNode.memoizedState);
            const isNextChatList = hookNode.next && checkIsChatArray(hookNode.next.memoizedState);
            const isFullChatHook = isChatList && isNextChatList;

            if (!isFullChatHook) {
              // Hook #12(화면 제한용) 및 기타 훅은 일절 간섭하지 않고 오리지널 통과
              return { action };
            }

            // 첫 채팅 렌더링 시점에 클래스명을 분석하여 동적 스타일링으로 적용
            const currentClasses = (window as any).cqcChatClassNames;
            if (!currentClasses || !currentClasses.messageClass || !currentClasses.nicknameClass) {
              setTimeout(() => {
                const firstItem = container.querySelector(SELECTORS.CHAT_ITEM);
                if (firstItem) {
                  const classes = extractChatClassNames(firstItem);
                  if (classes && classes.itemClass && classes.messageClass && classes.nicknameClass) {
                    (window as any).cqcChatClassNames = classes;
                    window.dispatchEvent(new CustomEvent('cqc-chat-classes-found'));
                  }
                }
              }, 200);
            }

            // Hook #11만 전역 노드 및 셋에 등록
            (window as any).cqcCurrentChatHook = hookNode;
            (window as any).cqcCurrentChatHooks = (window as any).cqcCurrentChatHooks || new Set();
            (window as any).cqcCurrentChatHooks.add(hookNode);

            const currentSettings = activeSettings || settings;
            const hasFilter = currentSettings?.chatFilterEnabled;
            const hasKeywords = currentSettings?.chatFilterKeywords?.length > 0;
            const hasUsers = currentSettings?.chatFilterUsers?.length > 0;
            const hasRoles = currentSettings?.chatFilterRoles?.length > 0;
            const hasOS = currentSettings?.chatFilterOS?.length > 0;
            const isFilterEffective = hasFilter && (hasKeywords || hasUsers || hasRoles || hasOS);
            const isCollectorEffective = !!(window as any).cqcChatCollectorActive;
            const hideNick = currentSettings?.hideChatNickname === true;
            const maxNickLen = currentSettings?.chatNicknameMaxLength || 0;
            const isNicknameCustomEffect = hideNick || maxNickLen > 0;

            // 메시지 필터링 보조 함수
            const filterMessages = (msgs) => {
              if (!Array.isArray(msgs)) return msgs;

              let processed = msgs;

              // 1. 참여자 명단 수집 및 채팅 필터링
              if (isFilterEffective) {
                processed = processed.filter(msg => {
                  const nickname = msg.profile?.nickname || '';

                  // 참여자 명단 수집 (최대 100명)
                  if (nickname && nickname !== 'unknown') {
                    const img = msg.profile?.profileImageUrl || msg.profile?.imageUrl || msg.profile?.profileImage || '';
                    if (img) activeChatters.set(nickname, img);
                    else if (!activeChatters.has(nickname)) activeChatters.set(nickname, '');

                    if (activeChatters.size > 100) {
                      const first = activeChatters.keys().next().value;
                      activeChatters.delete(first);
                    }
                  }

                  // 필터링 평가
                  const evalRes = evaluateMessageFilter(msg, currentSettings);
                  msg._cqcHidden = evalRes.hidden;
                  msg._cqcBlurred = evalRes.blurred;

                  // 필터링 조건에 부합(숨김)하는 경우 리액트 상태(배열)에서 완전히 제외
                  if (evalRes.hidden) {
                    return false;
                  }
                  return true;
                });
              }

              // 2. 채팅 모아보기 필터링
              if (isCollectorEffective) {
                const splitMode = currentSettings?.chatCollectorSplitMode === true;
                const collectorRoles = currentSettings?.chatCollectorRoles || ['streamer', 'manager'];
                const collectorUsers = (currentSettings?.chatCollectorTargetUsers || []).map(u => u.toLowerCase().trim());

                if (!splitMode) {
                  processed = processed.filter(msg => {
                    const role = (msg.profile?.userRoleCode || '').toLowerCase(); // 'streamer', 'manager' 등
                    const nickname = (msg.profile?.nickname || '').toLowerCase().trim();
                    const matchedRole = collectorRoles.includes(role);
                    const matchedUser = collectorUsers.includes(nickname);

                    let isDonation = false;
                    if (collectorRoles.includes('donation')) {
                      const payAmount = msg.extras?.payAmount ?? msg._cqcParsedExtras?.payAmount;
                      if (typeof payAmount === 'number') {
                        isDonation = true;
                      }
                    }

                    return matchedRole || matchedUser || isDonation;
                  });
                }
              }
              // 3. 닉네임 커스텀 (숨김 또는 글자수 제한) 및 복구
              processed = processed.map(msg => {
                if (msg.profile) {
                  if (msg._cqcOriginalNickname === undefined) {
                    msg._cqcOriginalNickname = msg.profile.nickname || '';
                  }

                  if (isNicknameCustomEffect) {
                    let targetNickname = msg._cqcOriginalNickname;
                    if (hideNick) {
                      targetNickname = '';
                    } else if (maxNickLen > 0 && msg._cqcOriginalNickname.length > maxNickLen) {
                      targetNickname = msg._cqcOriginalNickname.slice(0, maxNickLen) + '...';
                    }

                    if (msg.profile.nickname !== targetNickname) {
                      const profile = { ...msg.profile, nickname: targetNickname };
                      return { ...msg, profile };
                    }
                  } else if (msg.profile.nickname !== msg._cqcOriginalNickname) {
                    const profile = { ...msg.profile, nickname: msg._cqcOriginalNickname };
                    return { ...msg, profile };
                  }
                }
                return msg;
              });

              return processed;
            };

            const hasModifiedNickname = (arr) => {
              if (!Array.isArray(arr)) return false;
              for (let i = 0; i < arr.length; i++) {
                const m = arr[i];
                if (m.profile && m._cqcOriginalNickname !== undefined && m.profile.nickname !== m._cqcOriginalNickname) {
                  return true;
                }
              }
              return false;
            };

            const getUnfiltered = (node: any) => {
              if (!unfilteredMap.has(node)) {
                unfilteredMap.set(node, Array.isArray(node.memoizedState) ? [...node.memoizedState] : []);
              }
              return unfilteredMap.get(node) || [];
            };

            if (Array.isArray(action)) {
              unfilteredMap.set(hookNode, action);
            } else if (action && Array.isArray(action.payload)) {
              unfilteredMap.set(hookNode, action.payload);
            }

            const checkNeedFilter = () => {
              if (isFilterEffective || isCollectorEffective || isNicknameCustomEffect) return true;
              if (Array.isArray(action) && hasModifiedNickname(action)) return true;
              if (action && Array.isArray(action.payload) && hasModifiedNickname(action.payload)) return true;
              return false;
            };

            if (typeof action === 'function') {
              const wrappedAction = (prevState) => {
                const prevUnfiltered = getUnfiltered(hookNode);
                let nextUnfiltered;
                try {
                  nextUnfiltered = action(prevUnfiltered);
                } catch (e) {
                  nextUnfiltered = action(prevState);
                }
                unfilteredMap.set(hookNode, nextUnfiltered);
                return filterMessages(nextUnfiltered);
              };
              return { action: wrappedAction };
            }

            // 필터/모아보기/닉네임 커스텀 모두 비활성이고 변조된 메시지도 없으면 원본 그대로 전달 (불필요한 복제 방지)
            if (!checkNeedFilter()) {
              if (Array.isArray(action)) {
                //ConsoleLogger.log('info', 'Chat', `실시간 채팅 감지: ${action.length}개 메시지 수신 (필터 비활성)`);
                if (action.length > 0) {
                  const lastMsg = action[action.length - 1];
                  //ConsoleLogger.log('info', 'Chat', `최신 채팅: [${lastMsg.profile?.nickname || 'unknown'}] ${lastMsg.content || ''}`);
                }
              } else if (action && Array.isArray(action.payload)) {
                //ConsoleLogger.log('info', 'Chat', `실시간 채팅 감지: ${action.payload.length}개 메시지 수신 (필터 비활성)`);
                if (action.payload.length > 0) {
                  const lastMsg = action.payload[action.payload.length - 1];
                  //ConsoleLogger.log('info', 'Chat', `최신 채팅: [${lastMsg.profile?.nickname || 'unknown'}] ${lastMsg.content || ''}`);
                }
              }
              return { action };
            }

            // 1. 액션이 배열인 경우
            if (Array.isArray(action)) {
              return { action: filterMessages(action) };
            }

            // 2. 액션에 payload(배열)가 포함된 경우
            if (action && Array.isArray(action.payload)) {
              const nextPayload = filterMessages(action.payload);
              if (nextPayload.length === 0) return { action, blocked: true };
              const nextAction = { ...action, payload: nextPayload };
              return { action: nextAction };
            }

            return { action };
          }
        );

        if (result) {
          if (result.hooks) {
            (window as any).cqcCurrentChatHooks = (window as any).cqcCurrentChatHooks || new Set();
            result.hooks.forEach(h => {
              (window as any).cqcCurrentChatHooks.add(h);
            });

            // 초기 메시지 목록 강제 리렌더링 트리거
            try {
              result.hooks.forEach(h => {
                if (typeof h.queue?.dispatch === 'function') {
                  h.queue.dispatch(prev => {
                    if (!Array.isArray(prev)) return prev;
                    return [...prev];
                  });
                }
              });
            } catch (e) {
              console.error('[ChatFilter] 초기 메시지 필터 적용 실패:', e);
            }
          }
        } else if (retryCount < maxRetries) {
          retryCount++;
          setTimeout(tryIntercept, 200);
        } else {
          ConsoleLogger.log('error', 'Chat', '인터셉터 부착 실패: React Hook 탐색 타임아웃');
        }
      };

      tryIntercept();
    },
    { interval: 500, timeout: 30000, persistent: true }
  );
};

/**
 * 성능 필터용 전역 캐시
 */
let messageFilterCache = new WeakMap(); // 메시지 객체별 필터링 결과 캐시
let emojiBlockSet = new Set(); // 차단된 이모티콘 Set
let lastEmojiFilterList = /** @type {any[]|null} */ (null); // 최신화 확인용 참조
let lastFilterConfigKey = ''; // 필터링 설정 변경 감지용 키

// 채널 ID 캐시
let cachedChannelId = '';
let cachedChannelIdPathname = '';

// 키워드 정규식 캐시
let cachedKeywordRegExps = /** @type {RegExp[]} */ ([]);
let lastKeywordsList = /** @type {any[]|null} */ (null);

/**
 * 필터 설정 내용의 변화를 감지하기 위한 키 생성기
 * (settings 객체의 참조만 바뀌고 설정 값은 그대로일 때 캐시가 무효화되는 것을 방지)
 * @param {any} s 설정 객체
 * @returns {string}
 */
const getFilterConfigKey = (s) => {
  if (!s) return '';
  return [
    s.chatFilterEnabled ? '1' : '0',
    (s.chatFilterKeywords || []).map((/** @type {any} */ k) => `${k.text}_${k.isRegex ? 'r' : 's'}`).join(','),
    (s.chatFilterUsers || []).map((/** @type {any} */ u) => typeof u === 'string' ? u : `${u.user}_${u.channelId}`).join(','),
    (s.chatFilterRoles || []).join(','),
    (s.chatFilterOS || []).join(','),
    (s.chatFilterEmojis || []).join(',')
  ].join('|');
};

/**
 * 메시지가 필터링 대상인지 평가하여 상세 결과 반환 (고도로 최적화됨)
 * @param {any} msg 채팅 메시지 객체
 * @param {any} settings 현재 설정
 * @returns {{hidden: boolean, blurred: boolean}}
 */
export const evaluateMessageFilter = (msg, settings) => {
  if (!msg || !settings || !settings.chatFilterEnabled) return { hidden: false, blurred: false };

  // 0. 캐시 무효화 및 확인
  const configKey = getFilterConfigKey(settings);
  if (lastFilterConfigKey !== configKey) {
    messageFilterCache = new WeakMap();
    lastFilterConfigKey = configKey;
    lastKeywordsList = null; // 키워드 정규식 캐시 초기화
    lastEmojiFilterList = null; // 이모티콘 Set 초기화
  }

  const cachedResult = messageFilterCache.get(msg);
  if (cachedResult) return cachedResult;

  const getResult = () => {
    const mode = settings.chatFilterMode || 'hide';
    const res = {
      hidden: mode === 'hide',
      blurred: mode === 'blur'
    };
    messageFilterCache.set(msg, res);
    return res;
  };

  const keywords = settings.chatFilterKeywords || [];
  const blockedUsers = settings.chatFilterUsers || [];
  const fRoles = settings.chatFilterRoles || [];
  const fOS = settings.chatFilterOS || [];
  const fEmojis = settings.chatFilterEmojis || [];

  const content = msg.originalContent || msg.content || '';
  const nickname = msg.profile?.nickname || '';

  // originalExtras JSON 파싱 결과 캐싱
  if (msg.originalExtras && !msg._cqcParsedExtras) {
    try {
      msg._cqcParsedExtras = typeof msg.originalExtras === 'string'
        ? JSON.parse(msg.originalExtras)
        : msg.originalExtras;
    } catch (e) {
      msg._cqcParsedExtras = {};
    }
  }
  const extras = msg._cqcParsedExtras || {};

  // 1. 유저 차단 (채널 ID 캐싱 적용)
  const currentPathname = location.pathname;
  if (cachedChannelIdPathname !== currentPathname) {
    cachedChannelId = currentPathname.match(/^\/live\/([a-z0-9_]+)/i)?.[1] || '';
    cachedChannelIdPathname = currentPathname;
  }
  const currentChannelId = cachedChannelId;

  const isBlockedUser = blockedUsers.some((/** @type {any} */ entry) => {
    const u = typeof entry === 'string' ? entry : entry.user;
    const cid = typeof entry === 'string' ? 'all' : entry.channelId;
    if ((u || '').trim() !== (nickname || '').trim()) return false;
    return cid === 'all' || cid === currentChannelId;
  });
  if (isBlockedUser) return getResult();

  // 2. 키워드 차단 (정규식 캐싱 및 일괄 test 검사 적용)
  if (lastKeywordsList !== keywords) {
    cachedKeywordRegExps = keywords.map((/** @type {any} */ k) => {
      if (!k.text) return null;
      try {
        const pattern = k.isRegex ? k.text : k.text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // eslint-disable-next-line security/detect-non-literal-regexp
        return new RegExp(pattern, 'i');
      } catch (e) {
        return null;
      }
    }).filter(Boolean);
    lastKeywordsList = keywords;
  }

  const isBadKeyword = cachedKeywordRegExps.some(regex => regex.test(content));
  if (isBadKeyword) return getResult();

  // 3. 역할 및 기기 정보 추출
  const profile = msg.profile || {};
  const badges = msg.displayBadgeList || [];
  const roleCode = profile.userRoleCode || '';

  let messageOS = (msg.osType || '').toUpperCase();
  if (!messageOS && msg.originalExtras) {
    if (extras.osType) messageOS = extras.osType.toUpperCase();
  }
  if (messageOS === 'WEB') messageOS = 'PC';

  const rolesInMsg = new Set();
  if (roleCode) {
    const r = roleCode.toUpperCase();
    if (r.includes('MANAGER')) rolesInMsg.add('MANAGER');
    else if (r === 'STREAMER') rolesInMsg.add('STREAMER');
    else rolesInMsg.add(r);
  }
  badges.forEach((/** @type {any} */ b) => {
    const type = (b.type || '').toUpperCase();
    if (type === 'SUBSCRIPTION') rolesInMsg.add('SUBSCRIBER');
    else if (type === 'ACTIVITY') rolesInMsg.add('FAN');
    else if (type) rolesInMsg.add(type);
  });

  // 4. 역할 필터
  if (fRoles.length > 0) {
    for (const r of rolesInMsg) {
      if (fRoles.includes(r)) return getResult();
    }
  }

  // 5. 기기 필터
  if (fOS.length > 0 && fOS.includes(messageOS)) {
    return getResult();
  }

  // 6. 이모티콘 필터 (Set 최적화 및 캐싱된 extras 사용)
  if (fEmojis.length > 0 && msg.originalExtras) {
    if (lastEmojiFilterList !== fEmojis) {
      emojiBlockSet = new Set(fEmojis);
      lastEmojiFilterList = fEmojis;
    }

    const emojis = extras.emojis || {};
    for (const eid of Object.keys(emojis)) {
      if (emojiBlockSet.has(eid)) return getResult();
    }
  }

  const finalRes = { hidden: false, blurred: false };
  messageFilterCache.set(msg, finalRes);
  return finalRes;
};

export function initChatFilter() {
  ChatUtilityManager.getInstance().boot();
}
