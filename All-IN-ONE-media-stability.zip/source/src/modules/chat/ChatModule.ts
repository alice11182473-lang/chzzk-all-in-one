// @ts-nocheck
import { initChatFilter } from './ChatFilter';
import { initChatResize } from './ChatResize';
import { initChatLatency } from './ChatLatency';
import { initSidebarResize } from '../sidebar/SidebarResize';
import { log as cqcLog } from '../../../dom-utils';

const log = (...args) => cqcLog('ChatModule', ...args);

export class ChatModule {
  mount(settings, sendFn) {
    this.settings = settings;
    this.send = sendFn;

    // 초기 라우트에 맞춰 로드
    const isChatOnlyPage = /^\/live\/[^/]+\/chat\/?$/.test(window.location.pathname);
    
    // 채팅 필터는 라이브/채팅 페이지 등에서 활성화
    initChatFilter();
    initChatLatency();

    if (!isChatOnlyPage) {
      initChatResize();
      initSidebarResize();
    }
  }

  cleanup() {
    // chatfilter와 chat-resize 내부 구현에 따라 cleanup이 추가될 수 있음.
    // 기존 content.js의 cleanups 배열에 등록되던 방식을 향후 이관 가능.
  }

  onRouteChange(routeInfo, settings) {
    this.settings = settings || this.settings;
    
    // 라우트가 라이브 페이지로 바뀔 때마다 채팅 필터 재초기화
    if (routeInfo.isLive) {
      if (typeof initChatFilter === 'function') {
        initChatFilter();
      }
    }
  }
}
