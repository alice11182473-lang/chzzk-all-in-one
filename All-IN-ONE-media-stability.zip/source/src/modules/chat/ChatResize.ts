// @ts-nocheck
import browser from 'webextension-polyfill';
import { triggerReact, isLargeMode, SELECTORS } from '../../../dom-utils';

/**
 * 채팅창 리사이즈 기능을 관리하는 클래스
 */
class ChatResizer {
  #STORAGE_KEY = 'chatWidth';
  #LOCK_KEY = 'chatResizeLocked';
  #MIN_WIDTH = 50;
  #MOBILE_THRESHOLD = 918;
  #FIREFOX_MOBILE_THRESHOLD = 942;
  #COLLAPSE_THRESHOLD = 200;
  #EXPAND_THRESHOLD = 230;
  #HANDLE_CLASS = 'cqc-chat-resize-handle';
  #HANDLE_LOCKED_CLASS = 'cqc-chat-resize-handle--locked';

  #IS_FIREFOX = /Firefox/i.test(navigator.userAgent);

  /** @type {number} */
  #savedWidth = 0;
  /** @type {boolean} */
  #isDragging = false;
  /** @type {boolean} */
  #isLocked = false;
  /** @type {boolean} */
  #dragCollapsed = false;
  /** @type {boolean} */
  #isEnabled = true;

  /** @type {HTMLElement|null} */
  #chatEl = null;
  /** @type {HTMLElement|null} */
  #recommendEl = null;
  /** @type {HTMLDivElement|null} */
  #handle = null;
  /** @type {HTMLDivElement|null} */
  #toastEl = null;

  /** @type {MutationObserver|null} */
  #playerObserver = null;
  /** @type {number} */
  #playerCheckInterval = 0;

  constructor() {
    this.#init();
  }

  /**
   * 초기화 및 설정 로드
   */
  #init = async () => {
    const settings = await this.#getValue('settings', {});
    this.#isEnabled = settings?.chatResizeEnabled ?? true;

    if (!this.#isEnabled) {
      this.#cleanup();
      return;
    }

    this.#savedWidth = await this.#getValue(this.#STORAGE_KEY, 0);
    this.#isLocked = await this.#getValue(this.#LOCK_KEY, false);

    this.#attach();
    this.#setupObservers();
  };

  /**
   * DOM 요소 연결 및 초기 레이아웃 적용
   */
  #attach = () => {
    this.#chatEl = this.#findChatAside();
    this.#recommendEl = this.#findVodRecommend();

    if (this.#chatEl) {
      this.#observePlayerLayout();
      this.#updateLayout();
    }
  };

  /**
   * 이벤트 및 옵저버 설정
   */
  #setupObservers = () => {
    // SPA 네비게이션 대응
    let attachDebounce = 0;
    new MutationObserver(() => {
      if (attachDebounce) return;
      attachDebounce = window.setTimeout(() => {
        attachDebounce = 0;
        if (!this.#isEnabled) return;
        const el = this.#findChatAside();
        const rec = this.#findVodRecommend();
        if ((el && !el.querySelector('.' + this.#HANDLE_CLASS)) || (rec && !this.#recommendEl)) {
          this.#attach();
        }
      }, 500);
    }).observe(document.body, { childList: true, subtree: true });

    // 윈도우 리사이즈 대응
    window.addEventListener('resize', () => this.#updateLayout());

    // 주기적 체크 (안전장치)
    window.setInterval(() => {
      if (!this.#isEnabled) return;
      const el = this.#findChatAside();
      if (el && !el.querySelector('.' + this.#HANDLE_CLASS)) {
        this.#attach();
      }
    }, 1000);
  };

  /**
   * 레이아웃 상태 업데이트 및 핸들 노출 여부 결정
   */
  #updateLayout = () => {
    if (!this.#isEnabled) return;
    if (!this.#chatEl) return;

    if (this.#isBottomLayout()) {
      this.#clearWidth(this.#chatEl);
      this.#removeHandle();
    } else {
      this.#attachHandle(this.#chatEl);
      if (this.#isLocked && this.#handle) {
        this.#handle.classList.add(this.#HANDLE_LOCKED_CLASS);
      }

      if (this.#savedWidth > 0) {
        const max = this.#getMaxWidth();
        this.#applyWidth(this.#chatEl, Math.min(this.#savedWidth, max));
      } else {
        this.#clearWidth(this.#chatEl);
      }
    }
  };

  /**
   * 하단 레이아웃(모바일/작은 창) 여부 확인
   * @returns {boolean}
   */
  #isBottomLayout = () => {
    if (!this.#chatEl) return false;

    // 1. 너비 기반 임계값 체크 (모바일 및 작은 창)
    const threshold = this.#IS_FIREFOX ? this.#FIREFOX_MOBILE_THRESHOLD : this.#MOBILE_THRESHOLD;
    if (window.innerWidth <= threshold) return true;

    if (isLargeMode()) {
      if (window.innerWidth <= 870) return true;
    }

    // 2. Computed Style의 flex-grow 기반 체크 (사용자 제보: 하단 배치 시 1)
    try {
      const style = window.getComputedStyle(this.#chatEl);
      if (style.flexGrow === "1") return true;
    } catch (e) {
      // ignore
    }

    // 3. 요소 너비 비율 기반 체크 (안전장치)
    return this.#chatEl.offsetWidth > window.innerWidth * 0.8;
  };

  /**
   * 리사이즈 핸들 생성 및 부착
   * @param {HTMLElement} el 
   */
  #attachHandle = (el) => {
    if (el.querySelector('.' + this.#HANDLE_CLASS)) return;

    this.#handle = document.createElement('div');
    this.#handle.className = this.#HANDLE_CLASS;
    el.style.position = 'relative';
    el.appendChild(this.#handle);

    this.#handle.addEventListener('mousedown', this.#onMouseDown);
    this.#handle.addEventListener('mousedown', this.#onMiddleClick);
  };

  /**
   * 리사이즈 핸들 제거
   */
  #removeHandle = () => {
    this.#handle?.remove();
    this.#chatEl?.querySelector('.' + this.#HANDLE_CLASS)?.remove();
    this.#handle = null;
  };

  /**
   * 마우스 드래그 시작 핸들러
   * @param {MouseEvent} e 
   */
  #onMouseDown = (e) => {
    if (this.#isBottomLayout() || this.#isLocked) return;

    e.preventDefault();
    e.stopPropagation();

    this.#isDragging = true;
    this.#dragCollapsed = false;

    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'col-resize';
    document.body.classList.add('cqc-chat-dragging');

    document.addEventListener('mousemove', this.#onMouseMove);
    document.addEventListener('mouseup', this.#onMouseUp);
  };

  /**
   * 마우스 드래그 중 핸들러
   * @param {MouseEvent} e 
   */
  #onMouseMove = (e) => {
    if (!this.#isDragging || !this.#chatEl || this.#dragCollapsed) return;

    if (this.#isBottomLayout()) {
      this.#onMouseUp();
      return;
    }

    const isLeftChat = document.documentElement.classList.contains('cqc-left-chat');
    const newWidth = isLeftChat ? e.clientX : window.innerWidth - e.clientX;
    const clamped = Math.max(this.#MIN_WIDTH, Math.min(newWidth, this.#getMaxWidth()));

    // 완전 접힘 처리
    if (!this.#dragCollapsed && clamped <= this.#COLLAPSE_THRESHOLD) {
      this.#handleCollapse(e.clientX);
      return;
    }

    // 안내 토스트 노출
    if (!this.#dragCollapsed && clamped > this.#COLLAPSE_THRESHOLD && clamped <= this.#COLLAPSE_THRESHOLD + 20) {
      this.#showCollapseToast();
      document.body.classList.add('cqc-chat-alert');
    } else {
      this.#hideCollapseToast();
    }

    // 완전 접힘에서 펼침 처리
    if (this.#dragCollapsed && clamped >= this.#EXPAND_THRESHOLD) {
      this.#handleExpand(clamped, e.clientX);
      return;
    }

    if (!this.#dragCollapsed) {
      this.#applyWidth(this.#chatEl, clamped);
    }
  };

  /**
   * 마우스 드래그 종료 핸들러
   */
  #onMouseUp = () => {
    if (!this.#isDragging) return;

    this.#isDragging = false;
    document.body.style.userSelect = '';
    document.body.style.cursor = '';
    document.body.classList.remove('cqc-chat-dragging');
    document.removeEventListener('mousemove', this.#onMouseMove);
    document.removeEventListener('mouseup', this.#onMouseUp);

    this.#hideCollapseToast();

    if (!this.#chatEl || this.#dragCollapsed) return;

    const finalWidth = this.#chatEl.offsetWidth;
    this.#savedWidth = finalWidth;
    this.#setValue(this.#STORAGE_KEY, finalWidth);
    this.#log('Chat width saved:', finalWidth);
  };

  /**
   * 휠/중앙 클릭 시 잠금 설정
   * @param {MouseEvent} e 
   */
  #onMiddleClick = (e) => {
    if (e.button !== 1) return;
    e.preventDefault();
    e.stopPropagation();

    this.#isLocked = !this.#isLocked;
    this.#handle?.classList.toggle(this.#HANDLE_LOCKED_CLASS, this.#isLocked);
    this.#setValue(this.#LOCK_KEY, this.#isLocked);
    this.#log('Chat resize lock:', this.#isLocked ? 'ON' : 'OFF');
  };

  /**
   * 접힘 상태 처리
   * @param {number} clientX 
   */
  #handleCollapse = (clientX) => {
    this.#dragCollapsed = true;
    this.#hideCollapseToast();
    document.body.classList.remove('cqc-chat-dragging');

    if (this.#chatEl) {
      this.#chatEl.style.width = '0px';
      this.#chatEl.style.flexBasis = '0px';
      this.#chatEl.style.overflow = 'hidden';
    }

    this.#savedWidth = 0;
    this.#setValue(this.#STORAGE_KEY, 0);

    setTimeout(() => {
      if (this.#chatEl) this.#clearWidth(this.#chatEl);
      this.#clickChatCollapseButton();
      if (this.#isDragging) document.body.classList.add('cqc-chat-dragging');
    }, 250);

    this.#log('Chat: Collapsed at clientX', clientX);
  };

  /**
   * 펼침 상태 처리
   * @param {number} width 
   * @param {number} clientX 
   */
  #handleExpand = (width, clientX) => {
    this.#dragCollapsed = false;
    if (this.#chatEl) this.#applyWidth(this.#chatEl, width);
    this.#clickChatCollapseButton();

    setTimeout(() => {
      if (this.#isDragging) document.body.classList.add('cqc-chat-dragging');
    }, 250);

    this.#log('Chat: Expanded at clientX', clientX);
  };

  /**
   * 너비 적용
   * @param {HTMLElement} el 
   * @param {number} w 
   */
  #applyWidth = (el, w) => {
    const clamped = Math.max(this.#MIN_WIDTH, Math.min(w, this.#getMaxWidth()));
    el.style.setProperty('width', clamped + 'px', 'important');
    el.style.minWidth = '';
    el.style.maxWidth = '';
    el.style.setProperty('flex-basis', clamped + 'px', 'important');

    if (this.#recommendEl && el !== this.#recommendEl) {
      this.#recommendEl.style.setProperty('width', clamped + 'px', 'important');
      this.#recommendEl.style.setProperty('flex-basis', clamped + 'px', 'important');

      const parent = /** @type {HTMLElement|null} */ (this.#recommendEl.closest('div[class*="vod_content_right"]'));
      if (parent) {
        parent.style.setProperty('width', clamped + 'px', 'important');
        parent.style.setProperty('flex-basis', clamped + 'px', 'important');
      }
    }
  };

  /**
   * 너비 초기화
   * @param {HTMLElement} el 
   */
  #clearWidth = (el) => {
    el.style.width = '';
    el.style.height = '';
    el.style.minWidth = '';
    el.style.maxWidth = '';
    el.style.flexBasis = '';
    el.style.overflow = '';
    el.style.removeProperty('width');
    el.style.removeProperty('height');
    el.style.removeProperty('flex-basis');

    if (this.#recommendEl) {
      this.#recommendEl.style.width = '';
      this.#recommendEl.style.flexBasis = '';
      this.#recommendEl.style.removeProperty('width');
      this.#recommendEl.style.removeProperty('flex-basis');

      const parent = /** @type {HTMLElement|null} */ (this.#recommendEl.closest('div[class*="vod_content_right"]'));
      if (parent) {
        parent.style.width = '';
        parent.style.flexBasis = '';
        parent.style.removeProperty('width');
        parent.style.removeProperty('flex-basis');
      }
    }
  };

  /**
   * 플레이어 레이아웃 감시
   */
  #observePlayerLayout = () => {
    if (this.#playerObserver) this.#playerObserver.disconnect();
    if (this.#playerCheckInterval) clearInterval(this.#playerCheckInterval);

    const startObserve = (/** @type {Element} */ layout) => {
      this.#playerObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          if (mutation.attributeName === 'class') {
            this.#updateLayout();
            break;
          }
        }
      });
      this.#playerObserver.observe(layout, { attributes: true, attributeFilter: ['class'] });
      this.#updateLayout();
    };

    /** @type {HTMLElement|null} */
    const playerLayout = document.querySelector(SELECTORS.PLAYER_LAYOUT) || document.querySelector('.chzzk_player');
    if (playerLayout) {
      startObserve(playerLayout);
    } else {
      this.#playerCheckInterval = window.setInterval(() => {
        /** @type {HTMLElement|null} */
        const layout = document.querySelector(SELECTORS.PLAYER_LAYOUT) || document.querySelector('.chzzk_player');
        if (layout) {
          clearInterval(this.#playerCheckInterval);
          startObserve(layout);
        }
      }, 1000);
    }
  };

  /**
   * 토스트 알림 표시
   */
  #showCollapseToast = () => {
    if (this.#toastEl) return;
    this.#toastEl = document.createElement('div');
    this.#toastEl.className = 'cqc-collapse-toast';
    this.#toastEl.textContent = '더 밀면 완전히 접힘 (200px) →';
    document.body.appendChild(this.#toastEl);

    const left = this.#chatEl ? this.#chatEl.getBoundingClientRect().left : window.innerWidth - this.#MIN_WIDTH;
    this.#toastEl.style.left = (left - this.#toastEl.offsetWidth - 12) + 'px';
    this.#toastEl.style.top = Math.round(window.innerHeight * 0.3) + 'px';

    const rect = this.#toastEl.getBoundingClientRect();
    this.#toastEl.style.left = (left - rect.width - 12) + 'px';
    requestAnimationFrame(() => this.#toastEl?.classList.add('cqc-collapse-toast--visible'));
  };

  /**
   * 토스트 알림 숨김
   */
  #hideCollapseToast = () => {
    if (!this.#toastEl) return;
    const el = this.#toastEl;
    this.#toastEl = null;
    el.classList.remove('cqc-collapse-toast--visible');
    document.body.classList.remove('cqc-chat-alert');
    setTimeout(() => el.remove(), 200);
  };

  /**
   * 설정 변경 시 외부에서 호출
   * @param {any} settings 
   */
  updateSettings = (settings) => {
    this.#isEnabled = settings.chatResizeEnabled ?? true;
    if (!this.#isEnabled) {
      this.#cleanup();
    } else {
      this.#attach();
    }
  };

  /**
   * 정리 및 초기화
   */
  #cleanup = () => {
    const chat = this.#findChatAside();
    if (chat) {
      this.#clearWidth(chat);
      this.#removeHandle();
    }
  };

  // --- 유틸리티 함수들 ---

  #findChatAside = () => /** @type {HTMLElement|null} */(
    document.querySelector(SELECTORS.CHAT_ASIDE) ??
    document.querySelector('section[class*="vod_container"] aside')
  );

  #findVodRecommend = () => /** @type {HTMLElement|null} */(document.querySelector(SELECTORS.VOD_RECOMMEND));

  #getMaxWidth = () => Math.floor(window.innerWidth * 0.5);

  #clickChatCollapseButton = () => {
    /** @type {HTMLElement|null} */
    const btn =
      document.querySelector(SELECTORS.CHAT_FOLD_BTN) ??
      document.querySelector('button[class*="live_chatting_header_button"]') ??
      document.querySelector('button[class*="vod_chatting_close_button"]') ??
      document.querySelector('button[class*="vod_player_header_folded_button"]');
    if (!btn) return;
    if (!triggerReact(btn)) btn.click();
  };

  /**
   * @param {string} key
   * @param {any} def
   * @returns {Promise<any>}
   */
  #getValue = async (key, def) => {
    try {
      const res = await browser.storage.sync.get({ [key]: def });
      return res[key];
    } catch { return def; }
  };

  /**
   * @param {string} key
   * @param {any} val
   * @returns {Promise<void>}
   */
  #setValue = async (key, val) => {
    try { await browser.storage.sync.set({ [key]: val }); }
    catch { /* ignore */ }
  };

  /** @param {any[]} a */
  #log = (...a) => console.log('%c[CQC:ChatResizer]', 'color:#00ffa3;font-weight:bold', ...a);
}

// 싱글톤 인스턴스 생성 및 익스포트
/** @type {ChatResizer|null} */
let instance = null;
export const initChatResize = () => {
  if (!instance) instance = new ChatResizer();
  /** @type {any} */(window).cqcChatUpdate = (/** @type {any} */ settings) => instance?.updateSettings(settings);
};
