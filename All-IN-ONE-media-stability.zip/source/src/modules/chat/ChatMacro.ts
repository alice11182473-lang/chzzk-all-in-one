import { SELECTORS } from '../../../dom-utils';

/**
 * 이모티콘 매크로 관리 모듈
 */
export class ChatMacro {
  #enabled = true;
  #macros: { keyword: string, emojiId: string, emojiUrl: string }[] = [];
  #channelCache: Record<string, { subEmojiIds: Set<string>; isEmojiPackLocked: boolean }> = {};

  constructor() {
    this.#init();
  }

  updateSettings(settings: any) {
    this.#macros = settings.chatEmojiMacros || [];
  }

  #init() {
    // 채팅 입력창 이벤트 위임
    document.body.addEventListener('keydown', this.#handleKeydown.bind(this), true);
  }

  async #getChannelEmojiPermission(channelId: string) {
    if (this.#channelCache[channelId]) {
      return this.#channelCache[channelId];
    }

    try {
      const packsRes = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${channelId}/emoji-packs`);
      const packsData = await packsRes.json();

      const subEmojiIds = new Set<string>();
      const globalLocked = packsData?.content?.emojiPackLocked ?? true;
      
      const processPacks = (packs: any[]) => {
        if (!Array.isArray(packs)) return;
        packs.forEach(pack => {
          const isLocked = pack.emojiPackLocked ?? pack.locked ?? globalLocked;
          if (isLocked) {
            if (pack.emojis) {
              pack.emojis.forEach((emoji: any) => subEmojiIds.add(emoji.emojiId));
            }
            if (pack.tier1Emojis) {
              pack.tier1Emojis.forEach((emoji: any) => subEmojiIds.add(emoji.emojiId));
            }
            if (pack.tier2Emojis) {
              pack.tier2Emojis.forEach((emoji: any) => subEmojiIds.add(emoji.emojiId));
            }
          } else if (pack.emojiTier2Locked && pack.tier2Emojis) {
            pack.tier2Emojis.forEach((emoji: any) => subEmojiIds.add(emoji.emojiId));
          }
        });
      };

      processPacks(packsData?.content?.subscriptionEmojiPacks);
      processPacks(packsData?.content?.emojiPacks);

      // subEmojiIds에는 현재 사용자에게 '잠긴' 이모티콘 ID만 수집됨.
      const perm = { subEmojiIds, isEmojiPackLocked: true };
      
      this.#channelCache[channelId] = perm;
      return perm;
    } catch (e) {
      console.error('[CQC] Failed to fetch emoji permission', e);
      return null;
    }
  }

  #handleKeydown(e: KeyboardEvent) {
    if (!this.#enabled || this.#macros.length === 0) return;
    if (e.key !== 'Tab') return;

    const target = e.target as HTMLTextAreaElement | HTMLDivElement;
    if (!target) return;
    
    // 치지직 채팅 입력창인지 확인 (SelectorRegistry 활용)
    if (!target.matches(SELECTORS.CHAT_INPUT)) {
      return;
    }

    let text = '';
    let isTextarea = false;

    if (target instanceof HTMLTextAreaElement || target instanceof HTMLInputElement) {
      text = target.value;
      isTextarea = true;
    } else if (target.isContentEditable) {
      text = target.innerText;
    } else {
      return;
    }

    if (!text) return;

    // 현재 커서 앞의 마지막 단어 추출
    let cursorPosition = text.length;
    if (isTextarea && typeof (target as any).selectionStart === 'number') {
      cursorPosition = (target as any).selectionStart;
    }

    const textBeforeCursor = text.substring(0, cursorPosition);
    // 마지막 단어 (공백 기준 분리)
    const match = textBeforeCursor.match(/(\S+)$/);
    if (!match) return;

    const lastWord = match[1];

    // 등록된 매크로 찾기
    const macro = this.#macros.find(m => m.keyword === lastWord);
    if (!macro) return;

    // 매크로 동작 실행: 단어를 {:emojiId:} 로 변환
    e.preventDefault();
    e.stopPropagation();

    this.#executeMacroAsync(macro, target, text, cursorPosition, lastWord, isTextarea);
  }

  async #executeMacroAsync(
    macro: { keyword: string, emojiId: string, emojiUrl: string },
    target: HTMLElement,
    text: string,
    cursorPosition: number,
    lastWord: string,
    isTextarea: boolean
  ) {
    // 1. 현재 채널 구독 권한 확인
    const match = window.location.pathname.match(/\/(?:live|video)\/([a-zA-Z0-9_]+)/);
    if (match) {
      const channelId = match[1];
      const perm = await this.#getChannelEmojiPermission(channelId);
      
      if (perm) {
        // 매크로 이모티콘이 현재 채널의 구독 전용 이모티콘인데 사용자가 권한이 없는 경우 차단
        if (perm.subEmojiIds.has(macro.emojiId) && perm.isEmojiPackLocked) {
          console.warn(`[CQC] 구독자 전용 이모티콘 사용 권한이 없습니다: ${macro.keyword}`);
          // 치지직 내부 토스트 메시지가 있다면 띄워줄 수 있지만, 일단 콘솔로 대체하고 무시
          return;
        }
      }
    }

    if (isTextarea) {
      const textarea = target as HTMLTextAreaElement;
      const replacement = `{:${macro.emojiId}:}`;
      const newText = text.substring(0, cursorPosition - lastWord.length) + replacement + text.substring(cursorPosition);
      
      // React 상태 업데이트 유도
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set;
      if (nativeInputValueSetter) {
        nativeInputValueSetter.call(textarea, newText);
      } else {
        textarea.value = newText;
      }
      
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      
      // 커서 위치 조정
      const newCursorPos = cursorPosition - lastWord.length + replacement.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    } else {
      // ContentEditable의 경우 (치지직 신규 채팅 입력창 - <pre contenteditable="true">)
      const selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) return;

      const range = selection.getRangeAt(0);
      
      if (range.endContainer.nodeType === Node.TEXT_NODE) {
        // 타이핑한 단어(키워드) 범위 선택
        range.setStart(range.endContainer, range.endOffset - lastWord.length);
        selection.removeAllRanges();
        selection.addRange(range);

        // 💡 핵심: 치지직 내부 전역 변수 해킹
        const winAny = window as any;
        winAny.__workingEmoticon = winAny.__workingEmoticon || {};
        winAny.__workingEmoticon[macro.emojiId] = macro.emojiUrl;

        const imgHtml = `<img src="${macro.emojiUrl}" alt="{:${macro.emojiId}:}" width="24" height="24">`;
        document.execCommand('insertHTML', false, imgHtml);
      } else {
        // 예외 상황
        const winAny = window as any;
        winAny.__workingEmoticon = winAny.__workingEmoticon || {};
        winAny.__workingEmoticon[macro.emojiId] = macro.emojiUrl;

        const imgHtml = `<img src="${macro.emojiUrl}" alt="{:${macro.emojiId}:}" width="24" height="24">`;
        document.execCommand('insertHTML', false, imgHtml);
      }
    }
  }
}
