// @ts-nocheck
import Browser from 'webextension-polyfill';
import { log as cqcLog } from '../../../dom-utils';

import { SELECTORS } from '../../../dom-utils';

const log = (...args: any[]) => cqcLog('ChatLatency', ...args);

let isEnabled = true;
let currentState = { latency: -1, buffer: 0 };
let uiInterval: any = null;

// Browser 폴리필 대체
const storage = {
  sync: {
    get: (keys: any) => new Promise(r => {
      if (typeof Browser !== 'undefined' && Browser.storage && Browser.storage.sync) {
        try {
          const res = Browser.storage.sync.get(keys);
          if (res && typeof res.then === 'function') {
            res.then(r).catch(() => r({}));
          } else {
            r({});
          }
        } catch (e) {
          r({});
        }
      } else {
        r({});
      }
    })
  },
  onChanged: {
    addListener: (cb: any) => {
      if (typeof Browser !== 'undefined' && Browser.storage && Browser.storage.onChanged) {
        Browser.storage.onChanged.addListener(cb);
      }
    }
  }
};

let lastUpdate = Date.now();

const updateUI = () => {
  if (!isEnabled) {
    const el = document.getElementById('cqc-chat-latency');
    if (el) el.remove();
    return;
  }

  const container = document.querySelector(SELECTORS.CHAT_INPUT_BOX);
  if (!container) return;

  if (getComputedStyle(container).position === 'static') {
    (container as HTMLElement).style.position = 'relative';
  }

  let el = document.getElementById('cqc-chat-latency');
  if (!el) {
    el = document.createElement('span');
    el.id = 'cqc-chat-latency';
    el.style.cssText = `
        position: absolute;
        top: -20px;
        right: 0;
        font-size: 11px;
        color: rgba(255, 255, 255, 0.4);
        font-weight: 600;
        user-select: none;
        pointer-events: none;
        white-space: nowrap;
        letter-spacing: -0.02em;
      `;
    container.appendChild(el);
  }

  const isStale = Date.now() - lastUpdate > 3000;

  if (isStale) {
    el.textContent = '지연: 측정 불가 (비디오 없음)';
    el.style.color = 'rgba(255, 255, 255, 0.4)';
  } else if (currentState.latency >= 0) {
    el.textContent = `지연: ${currentState.latency.toFixed(2)}s (버퍼 ${currentState.buffer.toFixed(2)}s)`;
    el.style.color = currentState.latency >= 3
      ? 'rgba(229, 115, 115, 0.85)'
      : 'rgba(255, 255, 255, 0.4)';
  } else {
    el.textContent = '지연: 측정중...';
    el.style.color = 'rgba(255, 255, 255, 0.4)';
  }
};

export const initChatLatency = () => {
  storage.sync.get(['settings']).then((res: any) => {
    isEnabled = res?.settings?.chatLatencyDisplayEnabled ?? true;
  });

  storage.onChanged.addListener((changes: any) => {
    if (changes.settings) {
      isEnabled = changes.settings.newValue?.chatLatencyDisplayEnabled ?? true;
      updateUI();
    }
  });

  // 메시지 이벤트 리스너로 플레이어 상태 수신 (동일 탭 메인 플레이어용)
  window.addEventListener('message', (e) => {
    if (e.source !== window || e.data?.direction !== 'CQC_TO_CONTENT') return;
    if (e.data.type === 'PLAYER_STATE' && e.data.payload) {
      const p = e.data.payload;
      currentState.latency = p.currentLatency ?? -1;
      currentState.buffer = p.bufferLength ?? 0;
      lastUpdate = Date.now();
      updateUI();
    }
  });

  // 팝업 채팅창을 위해 동일 출처 내 다른 탭(메인 플레이어)에서 보내는 상태 수신
  let currentChannelId = location.pathname.split('/')[2];
  let bc: BroadcastChannel | null = null;

  const setupBroadcastChannel = () => {
    try {
      if (bc) {
        bc.close();
        bc = null;
      }
      if (currentChannelId) {
        bc = new BroadcastChannel(`cqc_player_state_${currentChannelId}`);
        bc.addEventListener('message', (e) => {
          if (e.data) {
            currentState.latency = e.data.currentLatency ?? -1;
            currentState.buffer = e.data.bufferLength ?? 0;
            lastUpdate = Date.now();
            updateUI();
          }
        });
      }
    } catch (e) {
      console.error('[CQC:ChatLatency] BroadcastChannel 생성 실패', e);
    }
  };

  setupBroadcastChannel();

  // UI 폴링 (채팅창 DOM 동적 생성 및 SPA 라우팅 대비)
  if (uiInterval) clearInterval(uiInterval);
  uiInterval = setInterval(() => {
    const newChannelId = location.pathname.split('/')[2];
    if (newChannelId !== currentChannelId) {
      currentChannelId = newChannelId;
      setupBroadcastChannel();
    }
    updateUI();
  }, 1000);
};
