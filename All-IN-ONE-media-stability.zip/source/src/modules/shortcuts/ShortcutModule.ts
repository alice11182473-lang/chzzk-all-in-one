// @ts-nocheck
import { SELECTORS, isShortcutMatched } from '../../../dom-utils';

export class ShortcutModule {
  mount(settings) {
    this.settings = settings;
    
    // 글로벌 단축키
    this.onKeyDown = this.onKeyDownGlobal.bind(this);
    document.addEventListener('keydown', this.onKeyDown, true);
    
    // 라이브 바로가기 탭
    this.initLiveShortcut();

    // 설정 업데이트 수신
    this._onSettingsUpdated = (newSettings) => {
      this.settings = newSettings;
    };
    this.runtime?.eventBus?.on('SETTINGS_UPDATED', this._onSettingsUpdated);
  }

  cleanup() {
    document.removeEventListener('keydown', this.onKeyDown, true);
    
    // 라이브 바로가기 탭 제거
    if (this.shortcutObserver) {
        this.runtime.observerManager.disconnect(this.shortcutObserver);
        this.shortcutObserver = null;
    }
    if (this.shortcutInterval) {
        this.runtime.timerManager.clearInterval(this.shortcutInterval);
        this.shortcutInterval = null;
    }
    
    const btn = document.getElementById('cqc-live-shortcut');
    if (btn) btn.remove();
    const chatBtn = document.getElementById('cqc-live-shortcut-chat');
    if (chatBtn) chatBtn.remove();

    if (this._onSettingsUpdated) {
      this.runtime?.eventBus?.off('SETTINGS_UPDATED', this._onSettingsUpdated);
    }
  }

  onKeyDownGlobal(e) {
    const ssShortcut = this.settings?.customShortcuts?.screenshot;
    const recShortcut = this.settings?.customShortcuts?.record;

    // 단축키가 null(해제됨)이면 무시 — 브라우저에 이벤트 전달
    if (ssShortcut && isShortcutMatched(e, ssShortcut) && this.settings?.screenshotEnabled === false) {
      // 기능 OFF → 브라우저에 이벤트 전달 (preventDefault 하지 않음)
      return;
    }
    if (recShortcut && isShortcutMatched(e, recShortcut) && this.settings?.recorderEnabled === false) {
      // 기능 OFF → 브라우저에 이벤트 전달 (preventDefault 하지 않음)
      return;
    }
  }

  initLiveShortcut() {
    const TAB_LIST_SELECTOR = SELECTORS.CHANNEL_TAB_LIST;
    const TAB_ITEM_CLASS = SELECTORS.CHANNEL_TAB_ITEM;
    const BUTTON_ID = 'cqc-live-shortcut';

    const injectButton = () => {
      const tabLists = document.querySelectorAll(TAB_LIST_SELECTOR);
      let tabList = null;
      for (let i = 0; i < tabLists.length; i++) {
        const tl = tabLists[i];
        if (!tl.closest('#popup_contents') && !tl.closest('[class*="popup"]') && !tl.closest('[class*="modal"]') && !tl.closest('[role="dialog"]')) {
          const tabTexts = Array.from(tl.querySelectorAll('button, a')).map(el => el.textContent?.trim());
          const isMainTabList = tabTexts.some(txt => txt === '홈' || txt === '동영상' || txt === '클립' || txt === '라이브' || txt === '정보');
          if (isMainTabList) {
            tabList = tl;
            break;
          }
        }
      }
      if (!tabList) return;

      const pathParts = window.location.pathname.split('/');
      let channelId = '';

      const reserved = ['live', 'video', 'clips', 'profile', 'u', 'home'];
      if (reserved.includes(pathParts[1])) {
        if (pathParts.length >= 3) channelId = pathParts[2];
      } else {
        channelId = pathParts[1];
      }

      if (!channelId || channelId.length < 10) return;

      // 네이티브 탭 아이템의 실제 클래스명을 획득해서 대입 (obfuscated class)
      let nativeClass = '';
      const firstTab = tabList.querySelector('button[role="tab"]');
      if (firstTab) {
        nativeClass = firstTab.className;
      }

      if (!document.getElementById(BUTTON_ID)) {
        const btn = document.createElement('button');
        btn.id = BUTTON_ID;
        btn.type = 'button';
        btn.className = nativeClass || 'tab_item';
        btn.style.cssText = 'color:var(--accent, #00ffa3) !important; font-weight:800 !important; cursor:pointer;';
        btn.textContent = '방송';
        btn.title = '방송 페이지로 바로 이동합니다.';
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-selected', 'false');

        btn.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          window.location.href = `https://chzzk.naver.com/live/${channelId}`;
        };
        tabList.appendChild(btn);
      }

      if (!document.getElementById(BUTTON_ID + '-chat')) {
        const chatBtn = document.createElement('button');
        chatBtn.id = BUTTON_ID + '-chat';
        chatBtn.type = 'button';
        chatBtn.className = nativeClass || 'tab_item';
        chatBtn.style.cssText = 'color:var(--accent, #00ffa3) !important; font-weight:800 !important; cursor:pointer;';
        chatBtn.textContent = '채팅';
        chatBtn.title = '채팅창을 별도 팝업으로 엽니다.';
        chatBtn.setAttribute('role', 'tab');
        chatBtn.setAttribute('aria-selected', 'false');

        chatBtn.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          window.open(
            `https://chzzk.naver.com/live/${channelId}/chat`,
            `chzzk-chat-${channelId}`,
            'width=360,height=680,menubar=no,toolbar=no,location=no,status=no'
          );
        };
        tabList.appendChild(chatBtn);
      }
    };

    injectButton();

    this.shortcutObserver = this.runtime.observerManager.create((mutations) => {
      for (const m of mutations) {
        if (m.addedNodes.length > 0) {
          injectButton();
          break;
        }
      }
    });
    this.runtime.observerManager.observe(this.shortcutObserver, document.documentElement, { childList: true, subtree: true });

    this.shortcutInterval = this.runtime.timerManager.setInterval(injectButton, 2000);
  }
}
