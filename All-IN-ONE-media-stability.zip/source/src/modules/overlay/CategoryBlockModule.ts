import { SELECTORS, getChannelData, getChannelProps, getComponentFiber, log as cqcLog } from '../../../dom-utils';
import { InjectedModule } from '../../injected/core/InjectedRuntime';

const log = (...args: any[]) => cqcLog('CategoryBlockModule', ...args);

export class CategoryBlockModule implements InjectedModule {
  name = 'CategoryBlockModule';
  runtime: any;
  settings: any = null;
  intervalId: any = null;

  mount(settings: any) {
    this.settings = settings;
    this.runFilter();

    this.intervalId = setInterval(() => {
      this.runFilter();
    }, 800);
  }

  lastTotalVideoCount: number = 0;
  isLoadingMore: boolean = false;

  cleanup() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    // 숨김 처리된 모든 요소 복구
    document.querySelectorAll('[data-cqc-category-blocked="true"]').forEach((el: any) => {
      el.style.display = '';
      el.removeAttribute('data-cqc-category-blocked');
    });

    this.lastTotalVideoCount = 0;
    this.isLoadingMore = false;
  }

  onRouteChange(routeInfo: any, settings: any) {
    this.settings = settings || this.settings;
    this.lastTotalVideoCount = 0;
    this.isLoadingMore = false;
    this.runFilter();
  }

  runFilter() {
    const isEnabled = this.settings?.categoryBlockEnabled ?? true;
    const blockedTags = this.settings?.blockedCategoryTags || [];
    const blockedStreamers = this.settings?.blockedStreamers || [];

    if (!isEnabled || (blockedTags.length === 0 && blockedStreamers.length === 0)) {
      // 비활성화 시 기존 숨김 복구
      document.querySelectorAll('[data-cqc-category-blocked="true"]').forEach((el: any) => {
        el.style.display = '';
        el.removeAttribute('data-cqc-category-blocked');
      });
      return;
    }

    let totalVideoCount = 0;
    let visibleVideoCount = 0;

    let settingsUpdated = false;
    let newBlockedStreamers = [...blockedStreamers];

    // 정규식 파싱을 루프 밖으로 빼서 1번만 수행
    const parsedBlockers = newBlockedStreamers.map((val, idx) => {
      const match = val.match(/^(.+?)\s*\(([a-f0-9]{32})\)$/i);
      const isJustId = !match && /^[a-f0-9]{32}$/i.test(val);
      return {
        idx,
        id: match ? match[2].toLowerCase() : (isJustId ? val.toLowerCase() : ''),
        name: match ? match[1].replace(/\s+/g, '').toLowerCase() : val.replace(/\s+/g, '').toLowerCase(),
        isJustId
      };
    });

    const processCard = (el: HTMLElement, isSidebar: boolean) => {
      const data = getChannelData(el);
      const categoryFromFiber = (data?.category || '').trim().toLowerCase();

      const textElements = el.querySelectorAll('a[href*="/category/"], a[href*="tags="], [class*="category"], [class*="tag"]');
      const categories = Array.from(textElements).map((te: any) => te.textContent?.trim().toLowerCase()).filter(Boolean);
      if (categoryFromFiber) {
        categories.push(categoryFromFiber);
      }

      const channelName = (data?.channelName || '').trim().toLowerCase();
      const channelId = (data?.channelId || '').trim().toLowerCase();
      const streamerTexts = [channelName, channelId].filter(Boolean);

      const matchesCategory = blockedTags.some((tag: string) => {
        const cleanTag = tag.replace(/\s+/g, '').toLowerCase();
        return categories.some((text: string) => text.replace(/\s+/g, '').toLowerCase().includes(cleanTag));
      });

      const matchesStreamer = parsedBlockers.some(b => {
        if (b.id && channelId === b.id) {
          if (b.isJustId && channelName) {
            newBlockedStreamers[b.idx] = `${data?.channelName}(${b.id})`;
            b.isJustId = false; // 중복 업데이트 방지
            settingsUpdated = true;
          }
          return true;
        }
        return b.name && streamerTexts.some(text => text.replace(/\s+/g, '').toLowerCase().includes(b.name));
      });

      const props = getChannelProps(el);
      const isNaverBlocked = (props && props.privateUserBlock) || (el.innerText?.replace(/\s+/g, '').includes('차단한유저') || false);

      if (matchesCategory || matchesStreamer || isNaverBlocked) {
        if (el.style.display !== 'none') {
          el.style.setProperty('display', 'none', 'important');
          el.setAttribute('data-cqc-category-blocked', 'true');
          log(`${isSidebar ? '사이드바' : '방송'} 카드 차단: 카테고리=[${categories.join(', ')}] 스트리머=[${streamerTexts.join(', ')}]`);
        }
        return false;
      } else if (el.getAttribute('data-cqc-category-blocked') === 'true') {
        el.style.display = '';
        el.removeAttribute('data-cqc-category-blocked');
      }
      return true;
    };

    // 1. 방송 카드 필터링
    document.querySelectorAll(SELECTORS.VIDEO_ITEM).forEach((el: any) => {
      totalVideoCount++;
      if (processCard(el, false)) visibleVideoCount++;
    });

    if (totalVideoCount !== this.lastTotalVideoCount) {
      this.lastTotalVideoCount = totalVideoCount;
      this.isLoadingMore = false;
    }

    // 차단으로 인해 화면에 보이는 영상이 너무 적으면 리스트 추가 로드 트리거
    const blockedCount = totalVideoCount - visibleVideoCount;
    const scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    const scrollY = window.scrollY || window.pageYOffset;
    const isNearBottom = window.innerHeight + scrollY >= scrollHeight - 1000;

    if (totalVideoCount > 0 && totalVideoCount < 1000 && !this.isLoadingMore) {
      if (visibleVideoCount < 24) {
        const missingCount = 24 - visibleVideoCount;
        const visibleRatio = visibleVideoCount > 0 ? (visibleVideoCount / totalVideoCount) : 0.1;
        const estimatedNeeded = missingCount / visibleRatio;
        const pagesToLoad = Math.max(1, Math.min(5, Math.ceil(estimatedNeeded / 20)));
        log(`화면 비디오 부족 (${visibleVideoCount}/24). 필요한 개수: ${missingCount}, 페이지 수: ${pagesToLoad} 추가 로드 트리거`);
        this.loadMoreChannels(pagesToLoad);
        this.isLoadingMore = true;
      } else if (isNearBottom && blockedCount > 0) {
        log(`스크롤 하단 및 차단된 비디오 존재. 1페이지 추가 로드 트리거`);
        this.loadMoreChannels(1);
        this.isLoadingMore = true;
      }
    }

    // 2. 사이드바 채널 필터링
    document.querySelectorAll(SELECTORS.SIDEBAR_NAV_LINK).forEach((link: any) => {
      const li = link.closest(SELECTORS.SIDEBAR_ITEM) || link.parentElement || link;
      processCard(li, true);
    });

    if (settingsUpdated && this.runtime) {
      this.settings.blockedStreamers = newBlockedStreamers;
      this.runtime.post('CHZZK_SAVE_SETTINGS', { settings: { blockedStreamers: newBlockedStreamers } });
    }
  }

  loadMoreChannels(count: number = 1) {
    const chatFilter = this.runtime?.getModule('ChatFilterModule');
    if (chatFilter) {
      chatFilter.loadMoreChannels(count);
    } else if (this.runtime) {
      this.runtime.post('LOAD_MORE_CHANNELS', { count });
    }
  }
}
