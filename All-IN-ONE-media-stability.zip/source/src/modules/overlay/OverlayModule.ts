// @ts-nocheck
import Browser from 'webextension-polyfill';
import { SELECTORS, isLivePage, isPlayerPage, isHomePage, triggerReact, log as cqcLog } from '../../../dom-utils';

const log = (...args) => cqcLog('OverlayModule', ...args);

export class OverlayModule {
  mount(settings, sendFn) {
    this.settings = settings;

    this.fontStyleEl = null;
    this.fontLinkEl = null;
    this.cachedStaticLogoData = null;

    this.initUICleanup();
    this.startAdPopupWatch();
    this.fixLogoStatic();
    this.initCustomFont();

    // 설정 업데이트 수신
    this._onSettingsUpdated = (newSettings) => {
      this.settings = newSettings;
      this.applyUICleanup();
      this.applyCustomFont();
    };
    this.runtime?.eventBus?.on('SETTINGS_UPDATED', this._onSettingsUpdated);
  }

  cleanup() {
    if (this.fontStyleEl) { this.fontStyleEl.remove(); this.fontStyleEl = null; }
    if (this.fontLinkEl) { this.fontLinkEl.remove(); this.fontLinkEl = null; }

    if (this.uiCleanupObserver) {
      this.runtime.observerManager.disconnect(this.uiCleanupObserver);
      this.uiCleanupObserver = null;
    }
    if (this.uiCleanupInterval) {
      this.runtime.timerManager.clearInterval(this.uiCleanupInterval);
      this.uiCleanupInterval = null;
    }

    if (this.adPopupObserver) {
      this.runtime.observerManager.disconnect(this.adPopupObserver);
      this.adPopupObserver = null;
    }

    if (this.onStorageChangeFont) {
      Browser.storage.onChanged.removeListener(this.onStorageChangeFont);
      this.onStorageChangeFont = null;
    }

    if (this.fontObserver) {
      this.fontObserver.disconnect();
      this.fontObserver = null;
    }

    if (this._onSettingsUpdated) {
      this.runtime?.eventBus?.off('SETTINGS_UPDATED', this._onSettingsUpdated);
    }
  }

  onRouteChange(routeInfo, settings) {
    this.settings = settings || this.settings;
    this.tryHideInstallPopup();
  }

  applyUICleanup() {
    if (!this.settings) return;

    // 1. 홈 상단 배너 (광고 배너)
    const bannerSelector = SELECTORS.HOME_BANNER || '.home_banner_container__XXXX';
    const banners = document.querySelectorAll(`${bannerSelector}, #home_banner, section:has(#home_banner)`);
    banners.forEach(banner => {
      if (this.settings.hideHomeBannerEnabled && isHomePage()) {
        if (banner.style.display !== 'none') {
          banner.style.display = 'none';
          log('UI', '홈 배너 숨김');
        }
      } else if (banner.style.display === 'none') {
        banner.style.display = '';
      }
    });

    // 1-1. 홈 추천 캐러셀 (메인 캐러셀)
    const recommendSelector = SELECTORS.HOME_RECOMMEND_CAROUSEL;
    if (recommendSelector) {
      const recommends = document.querySelectorAll(recommendSelector);
      recommends.forEach(rec => {
        if (this.settings.hideHomeRecommendEnabled && isHomePage()) {
          if (rec.style.display !== 'none') {
            rec.style.display = 'none';
            log('UI', '홈 추천 캐러셀 숨김');
          }
        } else if (rec.style.display === 'none') {
          rec.style.display = '';
        }
      });
    }

    // 1-2. 홈 중간 띠 배너
    const midBannerSelector = SELECTORS.HOME_MID_BANNER;
    if (midBannerSelector) {
      const midBanners = document.querySelectorAll(midBannerSelector);
      midBanners.forEach(mb => {
        if (this.settings.hideHomeMidBannerEnabled && isHomePage()) {
          if (mb.style.display !== 'none') {
            mb.style.display = 'none';
            log('UI', '홈 중간 띠 배너 숨김');
          }
        } else if (mb.style.display === 'none') {
          mb.style.display = '';
        }
      });
    }

    // 2. 스트리머 숍
    const shop = document.querySelector(SELECTORS.STREAMER_SHOP || '.streamer_shop_container__XXXX');
    if (shop) {
      if (this.settings.hideStreamerShopEnabled && (isLivePage() || isPlayerPage())) {
        if (shop.style.display !== 'none') {
          shop.style.display = 'none';
          log('UI', '스트리머 숍 숨김');
        }
      } else if (shop.style.display === 'none') {
        shop.style.display = '';
      }
    }

    // 3. 이벤트 브랜딩 배너 (월드컵 등 전 페이지 상단 고정 배너)
    if (SELECTORS.EVENT_BANNER) {
      const eventBanners = document.querySelectorAll(SELECTORS.EVENT_BANNER);
      eventBanners.forEach(eb => {
        if (this.settings.layoutCleanEnabled) {
          if (eb.style.display !== 'none') {
            eb.style.display = 'none';
            log('UI', '이벤트 브랜딩 배너 숨김');
          }
        } else if (eb.style.display === 'none') {
          eb.style.display = '';
        }
      });
    }
  }

  initUICleanup() {
    this.applyUICleanup();

    this.uiCleanupObserver = this.runtime.observerManager.create(() => {
      this.applyUICleanup();
    });

    const target = document.getElementById('root') || document.body;
    if (target) {
      this.runtime.observerManager.observe(this.uiCleanupObserver, target, { childList: true, subtree: true });
    }

    this.uiCleanupInterval = this.runtime.timerManager.setInterval(() => this.applyUICleanup(), 3000);
  }

  fixLogoStatic() {
    if (!this.settings?.staticLogoEnabled) return;

    const logo = document.querySelector(SELECTORS.LOGO_IMG);

    if (!logo || logo.dataset.cqcFixed) return;

    if (this.cachedStaticLogoData) {
      logo.src = this.cachedStaticLogoData;
      if (logo.srcset) logo.srcset = this.cachedStaticLogoData;
      logo.dataset.cqcFixed = 'true';
      return;
    }

    logo.dataset.cqcFixed = 'processing';
    const tempImg = new Image();
    tempImg.crossOrigin = 'anonymous';

    tempImg.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = tempImg.naturalWidth;
        canvas.height = tempImg.naturalHeight;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(tempImg, 0, 0);
          this.cachedStaticLogoData = canvas.toDataURL('image/png');
          if (logo) {
            logo.src = this.cachedStaticLogoData;
            if (logo.srcset) logo.srcset = this.cachedStaticLogoData;
            logo.dataset.cqcFixed = 'true';
          }
        }
      } catch (e) {
        log('로고 데이터 추출 실패:', e);
        if (logo) logo.dataset.cqcFixed = 'fail';
      }
    };

    tempImg.onerror = () => {
      if (logo) logo.dataset.cqcFixed = 'fail';
    };
    tempImg.src = logo.src;
  }

  tryHideInstallPopup() {
    if (!this.settings?.enabled || !this.settings?.hideInstallPopupEnabled) return;
    const layers = document.querySelectorAll(`${SELECTORS.LIVE_INFO_LAYER || '.live_info_layer__XXXX'}:not([data-cqc-install-handled])`);
    layers.forEach(layer => {
      layer.dataset.cqcInstallHandled = 'true';
      const normalQualityBtn = Array.from(layer.querySelectorAll('button')).find(btn =>
        btn.textContent?.includes('일반 화질')
      );
      if (normalQualityBtn) {
        // 일단 팝업을 숨긴뒤, 내부적으로 Click 처리.
        layer.style.display = 'none';
        const handled = triggerReact(normalQualityBtn, 'onClick');
        if (!handled) normalQualityBtn.click();
      }
    });
  }

  startAdPopupWatch() {
    this.adPopupObserver = this.runtime.observerManager.create((mutations) => {
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (this.settings?.hideInstallPopupEnabled && (node.matches?.(SELECTORS.LIVE_INFO_LAYER) || node.querySelector?.(SELECTORS.LIVE_INFO_LAYER))) {
            this.tryHideInstallPopup();
          }
        }
      }
      this.fixLogoStatic(); // 기존 DOM watch 로직 병합
    });

    if (document.body) {
      this.runtime.observerManager.observe(this.adPopupObserver, document.body, { childList: true, subtree: true });
    }

    this.tryHideInstallPopup();
  }

  initCustomFont() {
    this.applyCustomFont();
    this.onStorageChangeFont = () => this.applyCustomFont();
    Browser.storage.onChanged.addListener(this.onStorageChangeFont);

    if (this.fontObserver) {
      this.fontObserver.disconnect();
    }
    this.fontObserver = new MutationObserver((mutations) => {
      let needsReapply = false;
      for (const mutation of mutations) {
        for (const removedNode of mutation.removedNodes) {
          if (removedNode instanceof Element && (removedNode.id === 'cqc-custom-font' || removedNode.id === 'cqc-font-import')) {
            needsReapply = true;
            break;
          }
        }
        if (needsReapply) break;
      }
      if (needsReapply) {
        this.fontObserver.disconnect();
        this.applyCustomFont();
        this.fontObserver.observe(document.documentElement, { childList: true, subtree: true });
      }
    });
    this.fontObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  applyCustomFont() {
    const font = this.settings?.customFont;
    const importUrl = this.settings?.customFontImport;

    if (importUrl) {
      if (!this.fontLinkEl) {
        this.fontLinkEl = document.createElement('link');
        this.fontLinkEl.id = 'cqc-font-import';
        this.fontLinkEl.rel = 'stylesheet';
        document.documentElement.appendChild(this.fontLinkEl);
      }
      if (this.fontLinkEl.href !== importUrl) {
        this.fontLinkEl.href = importUrl;
      }
    } else if (this.fontLinkEl) {
      this.fontLinkEl.remove();
      this.fontLinkEl = null;
    }

    if (!font) {
      if (this.fontStyleEl) { this.fontStyleEl.remove(); this.fontStyleEl = null; }
      return;
    }
    if (!this.fontStyleEl) {
      this.fontStyleEl = document.createElement('style');
      this.fontStyleEl.id = 'cqc-custom-font';
      document.documentElement.appendChild(this.fontStyleEl);
    }
    const weight = this.settings?.customFontWeight || 400;
    this.fontStyleEl.textContent = `*:not([class*="icon"]):not(svg):not(path):not(use) { 
      font-family: "${font}", -apple-system, BlinkMacSystemFont, "Malgun Gothic", sans-serif !important; 
      font-weight: ${weight} !important;
    }`;
  }
}
