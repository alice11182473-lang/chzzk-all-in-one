// @ts-nocheck
import Browser from 'webextension-polyfill';
import { log as cqcLog, SELECTORS } from '../../../dom-utils';
import dayjs from 'dayjs';

const log = (...args) => cqcLog('NoticeModule', ...args);

export class NoticeModule {
  constructor() {
    this.modal = null;
    this.iconWrapper = null;
    this.notices = [];
    this.isLoading = false;
    this.observer = null;
  }

  mount(settings, sendFn, eventBus) {
    const IS_FIREFOX = navigator.userAgent.toLowerCase().includes('firefox');
    if (!IS_FIREFOX) return;

    this.settings = settings;
    this.send = sendFn;
    this.eventBus = eventBus;

    this.injectIcon();
    
    this.observer = new MutationObserver(() => {
      this.injectIcon();
    });
    this.observer.observe(document.body, { childList: true, subtree: true });

    // 설정 변경 리스너 등록
    this.onSettingsUpdated = (newSettings) => {
      this.settings = newSettings;
      this.injectIcon();
    };
    if (this.eventBus) {
      this.eventBus.on('SETTINGS_UPDATED', this.onSettingsUpdated);
    }
  }

  cleanup() {
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    if (this.eventBus && this.onSettingsUpdated) {
      this.eventBus.off('SETTINGS_UPDATED', this.onSettingsUpdated);
    }
    if (this.iconWrapper) {
      this.iconWrapper.remove();
      this.iconWrapper = null;
    }
    if (this.modal) {
      this.modal.remove();
      this.modal = null;
    }
  }

  onRouteChange(routeInfo, settings) {
    const IS_FIREFOX = navigator.userAgent.toLowerCase().includes('firefox');
    if (!IS_FIREFOX) return;
    this.settings = settings;
    this.injectIcon();
  }

  injectIcon() {
    if (!this.settings?.noticeIconEnabled) {
      if (this.iconWrapper) {
        this.iconWrapper.remove();
        this.iconWrapper = null;
      }
      document.querySelectorAll('.cqc-notice-icon-wrapper').forEach(el => el.remove());
      return;
    }

    // 네비게이션 우측 프로필/알림 아이콘 영역 또는 툴바 영역 찾기
    const navRight = document.querySelector(SELECTORS.TOOLBAR_BOX) || document.querySelector(SELECTORS.TOOLBAR_BOX_ALT) || document.querySelector(SELECTORS.NOTI_BTN)?.parentElement;
    if (!navRight) return;

    // 이미 주입되었는지 확인
    const existing = navRight.querySelector('.cqc-notice-icon-wrapper');
    if (existing) {
      this.iconWrapper = existing as HTMLDivElement;
      document.querySelectorAll('.cqc-notice-icon-wrapper').forEach(el => {
        if (el !== existing) el.remove();
      });
      return;
    }

    // 다른 곳에 남아있을 수 있는 모든 중복 아이콘 사전 제거
    document.querySelectorAll('.cqc-notice-icon-wrapper').forEach(el => el.remove());

    this.iconWrapper = document.createElement('div');
    this.iconWrapper.className = 'cqc-notice-icon-wrapper';
    this.iconWrapper.title = '치지직 공지사항';
    this.iconWrapper.style.display = 'flex';
    this.iconWrapper.style.alignItems = 'center';
    this.iconWrapper.style.marginRight = '8px';
    this.iconWrapper.style.cursor = 'pointer';

    // 문서 SVG (공지사항)
    this.iconWrapper.innerHTML = `
      <button class="cqc-notice-btn" style="background:transparent; border:none; padding:8px; cursor:pointer; color:var(--color-content-1, #fff); display:flex; align-items:center; justify-content:center; border-radius:50%;">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <line x1="10" y1="9" x2="8" y2="9"></line>
        </svg>
      </button>
    `;

    // 툴바의 테마 버튼이나 통나무 벌목중 옆에 삽입
    const themeBtn = navRight.querySelector(SELECTORS.THEME_BTN)?.closest(SELECTORS.TOOLBAR_ITEM);
    if (themeBtn) themeBtn.classList.add('cqc-theme-btn-wrapper');
    const profileBtn = navRight.querySelector(SELECTORS.TOOLBAR_PROFILE_BTN)?.closest(SELECTORS.TOOLBAR_ITEM);
    if (profileBtn) profileBtn.classList.add('cqc-profile-btn-wrapper');

    const powerStatus = document.getElementById('cqc-power-status-toolbar');
    const notiBtn = navRight.querySelector(SELECTORS.NOTI_BTN) || navRight.querySelector('button[aria-label="알림"]');
    
    if (powerStatus && powerStatus.parentElement === navRight) {
      navRight.insertBefore(this.iconWrapper, powerStatus);
    } else if (themeBtn && themeBtn.parentElement === navRight) {
      navRight.insertBefore(this.iconWrapper, themeBtn);
    } else if (notiBtn && notiBtn.parentElement === navRight) {
      navRight.insertBefore(this.iconWrapper, notiBtn);
    } else {
      navRight.appendChild(this.iconWrapper);
    }

    this.iconWrapper.querySelector('.cqc-notice-btn').addEventListener('click', async (e) => {
      e.stopPropagation();
      
      try {
        const hasPermission = await Browser.permissions.contains({
          origins: ['https://comm-api.game.naver.com/*']
        });
        if (!hasPermission) {
          const granted = await Browser.permissions.request({
            origins: ['https://comm-api.game.naver.com/*']
          });
          if (!granted) {
            log('Naver Lounge API host permission denied by user.');
            return;
          }
        }
      } catch (err) {
        log('Failed to check/request host permission:', err);
      }

      this.toggleModal();
    });

    // 호버 효과
    const btn = this.iconWrapper.querySelector('.cqc-notice-btn');
    btn.addEventListener('mouseenter', () => {
      btn.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.backgroundColor = 'transparent';
    });
  }

  async toggleModal() {
    if (this.modal && document.body.contains(this.modal)) {
      this.closeModal();
      return;
    }

    this.createModal();
    await this.fetchAndRenderNotices();
  }

  createModal() {
    this.modal = document.createElement('div');
    this.modal.className = 'cqc-notice-modal cqc-glass-modal';
    
    // 모달 위치: 아이콘 아래
    const rect = this.iconWrapper.getBoundingClientRect();
    this.modal.style.position = 'fixed';
    this.modal.style.top = `${rect.bottom + 10}px`;
    this.modal.style.left = `${rect.left - 300 + rect.width / 2}px`; // 아이콘 중앙 기준으로 왼쪽으로 펼쳐짐
    if (parseInt(this.modal.style.left) < 10) {
        this.modal.style.left = '10px';
    }

    this.modal.innerHTML = `
      <div class="cqc-notice-header">
        <h3 style="display:flex; align-items:center; gap:6px;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
            <polyline points="14 2 14 8 20 8"></polyline>
            <line x1="16" y1="13" x2="8" y2="13"></line>
            <line x1="16" y1="17" x2="8" y2="17"></line>
            <line x1="10" y1="9" x2="8" y2="9"></line>
          </svg>
          치지직 공지사항
        </h3>
        <button class="cqc-notice-close">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"></path></svg>
        </button>
      </div>
      <div class="cqc-notice-content">
        <div class="cqc-notice-loading">
          <svg class="cqc-spin" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path></svg>
          불러오는 중...
        </div>
      </div>
    `;

    document.body.appendChild(this.modal);

    this.modal.querySelector('.cqc-notice-close').addEventListener('click', () => this.closeModal());
    
    // 외부 클릭 시 닫기
    this.outsideClickHandler = (e) => {
      if (this.modal && !this.modal.contains(e.target) && !this.iconWrapper.contains(e.target)) {
        this.closeModal();
      }
    };
    document.addEventListener('click', this.outsideClickHandler);
  }

  closeModal() {
    if (this.modal) {
      this.modal.remove();
      this.modal = null;
    }
    if (this.outsideClickHandler) {
      document.removeEventListener('click', this.outsideClickHandler);
      this.outsideClickHandler = null;
    }
  }

  async fetchAndRenderNotices() {
    this.isLoading = true;
    try {
      const res = await Browser.runtime.sendMessage({ type: 'FETCH_NOTICES' });
      if (res && res.success && res.data && res.data.feeds) {
        this.notices = res.data.feeds;
        this.renderNotices();
      } else {
        throw new Error(res?.error || '데이터를 불러올 수 없습니다.');
      }
    } catch (err) {
      log('Failed to fetch notices:', err);
      const content = this.modal?.querySelector('.cqc-notice-content');
      if (content) {
        content.innerHTML = `<div class="cqc-notice-error">공지사항을 불러오는데 실패했습니다.</div>`;
      }
    } finally {
      this.isLoading = false;
    }
  }

  renderNotices() {
    if (!this.modal) return;
    const content = this.modal.querySelector('.cqc-notice-content');
    if (!content) return;

    if (this.notices.length === 0) {
      content.innerHTML = `<div class="cqc-notice-empty">공지사항이 없습니다.</div>`;
      return;
    }

    let html = '';
    this.notices.forEach(item => {
      const feed = item.feed;
      let dateStr = feed.createdDate;
      let date = dateStr;
      let isNew = false;
      if (dateStr && dateStr.length >= 8) {
        const year = parseInt(dateStr.substring(0, 4));
        const month = parseInt(dateStr.substring(4, 6)) - 1;
        const day = parseInt(dateStr.substring(6, 8));
        date = `${dateStr.substring(0, 4)}.${dateStr.substring(4, 6)}.${dateStr.substring(6, 8)}`;
        
        const feedDate = new Date(year, month, day);
        const now = new Date();
        const diffTime = Math.abs(now - feedDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        isNew = diffDays < 3;
      }
      
      html += `
        <a href="https://game.naver.com/lounge/chzzk/board/detail/${feed.feedId}" target="_blank" class="cqc-notice-item">
          <div class="cqc-notice-item-text">
            <div class="cqc-notice-title">
              ${isNew ? '<span class="cqc-notice-badge">N</span>' : ''}
              ${feed.title}
            </div>
            <div class="cqc-notice-date">${date}</div>
          </div>
          ${feed.repImageUrl ? `<div class="cqc-notice-thumb"><img src="${feed.repImageUrl}" alt="thumbnail"></div>` : ''}
        </a>
      `;
    });

    content.innerHTML = html;
  }
}
