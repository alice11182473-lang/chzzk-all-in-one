// @ts-nocheck
import { log as cqcLog, isLivePage, isVideoPage, isClipPage } from '../../../dom-utils';
import { runtime } from '../../core/RuntimeManager';

const log = (...args) => cqcLog('RouterModule', ...args);

export class RouterModule {
  constructor() {
    this.lastUrl = null;
    this.checkTimer = null;
  }

  mount(settings, sendFn, eventBus) {
    this.settings = settings;
    this.eventBus = eventBus || runtime.eventBus;

    // 1. popstate 이벤트 (SPA 기본 라우팅 감지)
    this.onPopState = () => this.handleRouteUpdate(false);
    window.addEventListener('popstate', this.onPopState);

    // 2. 타이머 기반 감시 (history API 조작으로 인한 URL 변경 감지 폴백)
    this.checkTimer = setInterval(() => this.handleRouteUpdate(true), 1000);

    // 3. Injected 스크립트의 URL_CHANGED 이벤트를 연동하여 비동기 처리 (기존 MutationObserver 제거)
    this.onUrlChanged = () => this.handleRouteUpdate(false);
    this.eventBus?.on('URL_CHANGED', this.onUrlChanged);

    // 4. 설정 업데이트 수신
    this._onSettingsUpdated = (newSettings) => {
      this.settings = newSettings;
    };
    this.eventBus?.on('SETTINGS_UPDATED', this._onSettingsUpdated);
  }

  cleanup() {
    if (this.onPopState) window.removeEventListener('popstate', this.onPopState);
    if (this.checkTimer) clearInterval(this.checkTimer);
    if (this.eventBus && this.onUrlChanged) {
      this.eventBus.off('URL_CHANGED', this.onUrlChanged);
    }
    if (this.eventBus && this._onSettingsUpdated) {
      this.eventBus.off('SETTINGS_UPDATED', this._onSettingsUpdated);
    }
  }

  handleRouteUpdate(isTimerPolled = false) {
    if (this.lastUrl !== location.href) {
      if (!isTimerPolled) {
        log(`Route change detected: ${this.lastUrl} -> ${location.href}`);
      }
      this.lastUrl = location.href;
      
      const routeInfo = {
        isLive: isLivePage(),
        isVideo: isVideoPage(),
        isClip: isClipPage(),
        url: location.href
      };

      // 런타임에 통지하여 등록된 모든 모듈의 onRouteChange 트리거
      if (runtime) {
        runtime.onRouteChange(routeInfo, this.settings);
      }
      // 이벤트 버스로도 알림
      this.eventBus?.emit('ROUTE_CHANGED', routeInfo);
    }
  }

  onRouteChange(routeInfo, settings) {
    this.settings = settings || this.settings;
    // RouterModule 자신이 라우트를 감시하므로 여기서 할 일은 많지 않음
  }
}
