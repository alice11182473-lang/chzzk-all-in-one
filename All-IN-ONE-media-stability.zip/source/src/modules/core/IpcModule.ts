// @ts-nocheck
import Browser from 'webextension-polyfill';
import { log as cqcLog, showToast as cqcShowToast, SELECTORS, isLivePage, isVideoPage, isClipPage, initSelectors } from '../../../dom-utils';
import { SelectorInspector } from '../inspector/SelectorInspector';
import { runtime } from '../../core/RuntimeManager';
import { safeParseSettings } from '../../../settings-schema';

const log = (...args) => cqcLog('IpcModule', ...args);

export class IpcModule {
  constructor() {
    this.pending = new Map();
    this.msgId = 0;
    this.cachedState = null;
    this.userCollapsed = false;
    this.settings = null;

    // 외부에 제공할 send 함수 바인딩
    this.send = this.send.bind(this);
  }
  mount(settings, sendFn, eventBus) {
    this.settings = settings;
    this.eventBus = eventBus || runtime.eventBus;

    // 1. Injected -> Content 메시지 수신
    this.onWindowMessage = this.handleWindowMessage.bind(this);
    window.addEventListener('message', this.onWindowMessage);

    // 2. Background -> Content 메시지 수신
    this.onBackgroundMessage = this.handleBackgroundMessage.bind(this);
    Browser.runtime.onMessage.addListener(this.onBackgroundMessage);
  }

  cleanup() {
    if (this.onWindowMessage) {
      window.removeEventListener('message', this.onWindowMessage);
    }
    if (this.onBackgroundMessage) {
      Browser.runtime.onMessage.removeListener(this.onBackgroundMessage);
    }
    this.pending.clear();
  }

  onRouteChange(routeInfo, settings) {
    this.settings = settings || this.settings;
  }

  send(type, payload) {
    return new Promise((resolve) => {
      const id = ++this.msgId;
      this.pending.set(id, resolve);
      window.postMessage({ direction: 'CQC_TO_INJECTED', id, type, payload }, '*');
      setTimeout(() => {
        if (this.pending.has(id)) {
          log(`메시지 타임아웃: ${type}`);
          this.pending.delete(id);
          resolve(null);
        }
      }, 2000);
    });
  }

  showToast(text) {
    if (this.settings?.showNotification === false) return;
    cqcShowToast(text, document.querySelector(SELECTORS.PLAYER));
  }

  async syncState() {
    try {
      if (isLivePage() || isVideoPage() || isClipPage()) {
        const state = await this.send('REQUEST_STATE');
        if (state) this.cachedState = state;
      }
    } catch (e) {
      // 무시
    }
  }

  handleWindowMessage(e) {
    if (e.source !== window || e.data?.direction !== 'CQC_TO_CONTENT') return;
    const { type, id, payload } = e.data;

    if (this.eventBus) {
      this.eventBus.emit(type, payload);
    }

    if (type === 'RESPONSE' && id && this.pending.has(id)) {
      const p = this.pending.get(id);
      if (p) p(payload);
      this.pending.delete(id);
      return;
    }

    switch (type) {
      case 'PLAYER_READY':
        this.cachedState = payload;
        if (window.cqcWatchTimer) window.cqcWatchTimer.start();
        break;
      case 'PLAYER_LOST':
        this.cachedState = null;
        if (window.cqcWatchTimer) window.cqcWatchTimer.stop();
        break;
      case 'QUALITY_CHANGED':
        if (this.cachedState) {
          this.cachedState.currentTrack = { label: payload.track, id: payload.id, height: payload.height };
          this.cachedState.gridBypassed = payload.gridBypassed;
        }
        const qualityText = payload.height ? `${payload.height}p` : payload.track;
        this.showToast(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00ffa3" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:2px;"><polyline points="20 6 9 17 4 12"/></svg> ${qualityText} 적용됨`);
        this.syncState();
        break;
      case 'TRACK_CHANGED':
        this.cachedState = payload;
        break;
      case 'PLAYER_STATE':
        this.cachedState = payload;
        this.eventBus?.emit('PLAYER_STATE_UPDATE', payload);
        try {
          const channelId = location.pathname.split('/')[2];
          if (channelId && this._latencyBcId !== channelId) {
            if (this._latencyBc) {
              this._latencyBc.close();
            }
            this._latencyBcId = channelId;
            this._latencyBc = new BroadcastChannel(`cqc_player_state_${channelId}`);
          }
          if (this._latencyBc) {
            this._latencyBc.postMessage(payload);
          }
        } catch (e) { }
        break;
      case 'URL_CHANGED':
        log('URL change detected in Injected', payload);
        if (!payload.isLive) {
          this.cachedState = null;
          if (window.cqcWatchTimer) window.cqcWatchTimer.stop();
        }
        break;
      case 'AD_SKIPPED':
        if (this.settings?.hideAdSkipMessage) break;
        const methodMap = { 'dispatch': '내부', 'dom': '버튼', 'css': '강제' };
        const skipMethod = payload?.method ? ` (${methodMap[payload.method] || payload.method})` : '';
        this.showToast(`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ffaa00" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:2px;"><polygon points="5 3 19 12 5 21 5 3"/></svg> 광고 자동 스킵${skipMethod}`);
        break;
      case 'TOGGLE_FOCUS_MODE':
        if (this.settings) {
          this.settings.focusModeEnabled = payload;
          Browser.storage.sync.set({ settings: this.settings });
        }
        break;
      case 'CHZZK_SAVE_SETTINGS':
        if (payload?.settings) {
          Browser.storage.sync.get('settings').then((res) => {
            const current = res?.settings || {};
            const updated = safeParseSettings({ ...current, ...payload.settings });
            Browser.storage.sync.set({ settings: updated }).then(() => {
              this.settings = updated;
              log('Injected Script로부터 설정 업데이트 수신 및 저장 완료:', payload.settings);
            });
          });
        }
        break;
      case 'CHZZK_FETCH_NOTICES':
        Browser.runtime.sendMessage({ type: 'FETCH_NOTICES' }).then((res) => {
          window.postMessage({ direction: 'CQC_TO_INJECTED', id, type: 'RESPONSE', payload: res }, '*');
        }).catch((err) => {
          window.postMessage({ direction: 'CQC_TO_INJECTED', id, type: 'RESPONSE', payload: { success: false, error: err.message } }, '*');
        });
        break;
    }
  }

  handleBackgroundMessage(msg, sender, sendResponse) {
    if (msg.type === 'REQUEST_STATE') {
      this.send('REQUEST_STATE').then(state => {
        if (state) this.cachedState = state;
        sendResponse(state || this.cachedState);
      }).catch(() => sendResponse(this.cachedState));
      return true;
    }

    // 비동기 응답 처리용 감싸기 함수
    const handleAsync = async () => {
      try {
        switch (msg.type) {
          case 'REQUEST_STATS':
            const stats = await this.send('REQUEST_STATS');
            return stats;

          case 'SETTINGS_UPDATED':
            this.settings = msg.payload || msg.settings || this.settings;
            // 바디 클래스 및 UI 상태 업데이트
            const isClean = this.settings?.layoutCleanEnabled ?? true;
            document.body.classList.toggle('cqc-layout-clean', isClean);
            document.body.classList.toggle('cqc-hide-offline', !!this.settings?.hideOfflineFollowing);

            const isActive = !!(this.settings?.playbackBarEnabled && isLivePage());
            document.documentElement.classList.toggle('cqc-playback-bar-active', isActive);

            if (this.settings?.followingExpandEnabled) {
              this.userCollapsed = false;
              await this.send('SET_USER_COLLAPSED', false);
            }

            // Injected Script(Main World)로 최신 설정 전달
            await this.send('SETTINGS_UPDATED', this.settings);

            // 모듈별 업데이트
            const updateModules = [window.cqcSidebarUpdate, window.cqcChatUpdate, window.cqcPowerUpdate];
            updateModules.forEach(m => m?.(this.settings));

            this.eventBus?.emit('SETTINGS_UPDATED', this.settings);
            return { success: true };

          case 'CHANGE_QUALITY':
            const changeRes = await this.send('CHANGE_QUALITY', msg.payload);
            setTimeout(() => this.syncState(), 300);
            return changeRes;

          case 'FORCE_REAPPLY':
            const forceRes = await this.send('FORCE_REAPPLY');
            setTimeout(() => this.syncState(), 300);
            return forceRes;

          case 'POWER_RESET_CHANNELS':
            return await this.send('POWER_RESET_CHANNELS', msg.payload);

          case 'GET_POWER_CHANNELS':
            const powerRes = await this.send('GET_POWER_CHANNELS');
            return powerRes ?? [];

          case 'GET_ACTIVE_CHATTERS':
            const chatters = await this.send('GET_ACTIVE_CHATTERS');
            return chatters ?? [];

          case 'RESET_PLAYBACK_SPEED':
            this.eventBus?.emit('RESET_PLAYBACK_SPEED');
            return { ok: true };

          case 'START_SELECTOR_INSPECTOR': {
            SelectorInspector.getInstance().start();
            return { success: true };
          }

          case 'CQC_SELECTORS_UPDATED': {
            initSelectors(msg.payload);
            return { success: true };
          }

          default:
            return { error: 'Unknown command' };
        }
      } catch (err) {
        log('Background Message Handler Error:', err);
        return { error: err.message };
      }
    };

    handleAsync().then(sendResponse);
    return true; // 비동기 응답 대기
  }
}
