// @ts-nocheck
import Browser from 'webextension-polyfill';
import { log as cqcLog, SELECTORS, isLivePage, isPlayerPage, getFiberNode } from '../../../dom-utils';
import { runtime } from '../../core/RuntimeManager';

const log = (...args) => cqcLog('LayoutModule', ...args);

export class LayoutModule {
  constructor() {
    this.EARLY_HIDE_STYLE_ID = 'cqc-early-hide-spa';
    this.EARLY_HIDE_CSS = `${SELECTORS.SIDEBAR_CONTENT} > ${SELECTORS.NAV_SECTION}:nth-child(n+3){display:none!important}${SELECTORS.RS_BANNER}{display:none!important}`;
  }

  mount(settings, sendFn, eventBus) {
    this.settings = settings;
    this.send = sendFn;
    this.eventBus = eventBus || runtime.eventBus;

    this.checkAndWarnHwAccel();

    // 글로벌 스타일 요소 주입
    this.injectGlobalStyles();

    if (this.eventBus) {
      if (this._onSettingsUpdated) {
        this.eventBus.off?.('SETTINGS_UPDATED', this._onSettingsUpdated);
      }
      this._onSettingsUpdated = (newSettings) => {
        this.settings = newSettings;
        this.runLayoutCleanup(this.settings?.layoutCleanupKeywords);
        this.updateLeftChatClass();
      };
      this.eventBus.on('SETTINGS_UPDATED', this._onSettingsUpdated);
    }

    if (this._cleanupInterval) {
      clearInterval(this._cleanupInterval);
    }
    this._cleanupInterval = setInterval(() => {
      this.runLayoutCleanup(this.settings?.layoutCleanupKeywords);
    }, 1500);
  }

  cleanup() {
    this.removeEarlyHideStyle();
    document.getElementById('cqc-scrollbar-style')?.remove();
    document.getElementById('cqc-media-btn-style')?.remove();
    document.body.classList.remove('cqc-is-player-route', 'cqc-route-lives', 'cqc-route-schedule', 'cqc-route-category', 'cqc-route-channel', 'cqc-layout-clean');
    if (this._cleanupInterval) {
      clearInterval(this._cleanupInterval);
      this._cleanupInterval = null;
    }
    if (this.eventBus && this._onSettingsUpdated) {
      this.eventBus.off?.('SETTINGS_UPDATED', this._onSettingsUpdated);
      this._onSettingsUpdated = null;
    }
  }

  onRouteChange(routeInfo, settings) {
    this.settings = settings || this.settings;

    const isLives = window.location.pathname.startsWith('/lives');
    const isPlayerRoute = isLivePage() || isPlayerPage();
    const isClean = this.settings?.layoutCleanEnabled ?? true;

    if (isPlayerRoute && isClean) {
      document.body.classList.add('cqc-is-player-route');
    } else {
      document.body.classList.remove('cqc-is-player-route');
    }

    if (isLives && isClean) {
      document.body.classList.add('cqc-route-lives');
    } else {
      document.body.classList.remove('cqc-route-lives');
    }

    const isSchedule = window.location.pathname.startsWith('/schedule');
    const isCategory = window.location.pathname.startsWith('/category');
    const isChannel = /^\/[0-9a-fA-F]{32}/.test(window.location.pathname);

    if (isSchedule && isClean) {
      document.body.classList.add('cqc-route-schedule');
    } else {
      document.body.classList.remove('cqc-route-schedule');
    }

    if (isCategory && isClean) {
      document.body.classList.add('cqc-route-category');
    } else {
      document.body.classList.remove('cqc-route-category');
    }

    if (isChannel && isClean) {
      document.body.classList.add('cqc-route-channel');
    } else {
      document.body.classList.remove('cqc-route-channel');
    }

    if (isClean) {
      document.body.classList.add('cqc-layout-clean');
    } else {
      document.body.classList.remove('cqc-layout-clean');
    }

    if (isPlayerRoute && isClean && this.settings?.layoutCleanupKeywords?.length) {
      this.injectEarlyHideStyle();
    } else {
      this.removeEarlyHideStyle();
    }

    if (!isClean || !this.settings?.layoutCleanupKeywords?.length) {
      document.documentElement.classList.add('cqc-layout-clean-off');
    } else {
      document.documentElement.classList.remove('cqc-layout-clean-off');
    }

    this.runLayoutCleanup(this.settings?.layoutCleanupKeywords);
    this.updateLeftChatClass();
  }

  updateLeftChatClass() {
    const isLeftChat = !!this.settings?.leftChatEnabled;
    document.documentElement.classList.toggle('cqc-left-chat', isLeftChat);
  }

  injectGlobalStyles() {
    if (!document.getElementById('cqc-scrollbar-style')) {
      const scrollbarStyle = document.createElement('style');
      scrollbarStyle.id = 'cqc-scrollbar-style';
      scrollbarStyle.textContent = `
        ${SELECTORS.LIVE_INFO_CONTAINER} {
          overflow-x: clip !important;
          overscroll-behavior-x: none !important;
          scrollbar-width: none !important;
        }
        ${SELECTORS.LIVE_INFO_CONTAINER}::-webkit-scrollbar {
          display: none !important;
          width: 0 !important;
          height: 0 !important;
        }
      `;
      document.documentElement.appendChild(scrollbarStyle);
    }

    if (!document.getElementById('cqc-left-chat-style')) {
      const leftChatStyle = document.createElement('style');
      leftChatStyle.id = 'cqc-left-chat-style';
      leftChatStyle.textContent = `
        /* 좌측 채팅 모드 */
        .cqc-left-chat :is([class^="live_layout_container__"], [class*="_layout_container_"]) {
          display: flex !important;
        }
        
        .cqc-left-chat :is(aside#aside-chatting, aside[class*="live_chatting_container"], [class*="_chatting_container_"]) {
          order: -1 !important;
        }
        
        /* 극장 모드 등에서 영상 영역이 왼쪽에 붙는 이슈 보정 */
        .cqc-left-chat :is([class^="live_layout_section__"], [class*="_layout_section_"]) {
          margin-right: auto !important;
          margin-left: unset !important;
          order: 1 !important;
        }

        /* 좌측 채팅일 경우 리사이즈 핸들을 우측으로 이동 */
        .cqc-left-chat .cqc-chat-resize-handle {
          left: auto !important;
          right: 0 !important;
          transform: translateX(50%) !important;
        }

        /* 닉네임 클릭 시 뜨는 프로필 모달을 좌측 채팅창 내부 위치(left: 10px)로 고정 (뱃지에 따른 _is_large 등 우측 강제 배치 무력화) */
        .cqc-left-chat :is(aside#aside-chatting, aside[class*="live_chatting_container"], [class*="_chatting_container_"]) [role="alertdialog"] {
          left: 10px !important;
          right: auto !important;
          transform: none !important;
        }
      `;
      document.documentElement.appendChild(leftChatStyle);
    }

    if (!document.getElementById('cqc-media-btn-style')) {
      const mediaBtnStyle = document.createElement('style');
      mediaBtnStyle.id = 'cqc-media-btn-style';
      mediaBtnStyle.textContent = `
        body:not(.cqc-screenshot-on) #cqc-screenshot-btn { display: none !important; }
        body:not(.cqc-recorder-on) #cqc-record-btn { display: none !important; }
      `;
      document.documentElement.appendChild(mediaBtnStyle);
    }
  }

  injectEarlyHideStyle() {
    if (document.getElementById(this.EARLY_HIDE_STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = this.EARLY_HIDE_STYLE_ID;
    s.textContent = this.EARLY_HIDE_CSS;
    document.head.appendChild(s);
  }

  removeEarlyHideStyle() {
    document.getElementById(this.EARLY_HIDE_STYLE_ID)?.remove();
  }

  toggleEventBannerFix(isEnabled) {
    const styleId = 'cqc-event-banner-fix';
    let styleEl = document.getElementById(styleId);

    // 라이브/플레이어 페이지에서는 이벤트 배너 fix 미적용 (사이드바/채팅 보호)
    if (isLivePage() || isPlayerPage()) {
      styleEl?.remove();
      return;
    }

    // 이벤트 배너가 실제 DOM에 존재하는지 확인 (숨겨진 상태 포함)
    const eventBannerExists = !!(
      document.querySelector(SELECTORS.EVENT_BANNER) ||
      document.querySelector('div[class*="_container_55vbw_"]') ||
      document.querySelector('#header[style*="translateY"]')
    );

    if (isEnabled && eventBannerExists) {
      if (!styleEl) {
        styleEl = document.createElement('style');
        styleEl.id = styleId;
        document.head.appendChild(styleEl);
      }
      styleEl.textContent = `
        #header,
        :is([class*="header_container__"], header[class*="_container_"]) {
          transform: translateY(0px) !important;
        }
        :is([class*="navigation_component_tab__"], [class*="_tab_"]) {
          top: 60px !important;
        }
        :is([class*="navigation_component_filter__"], [class*="_filter_"]) {
          top: 60px !important;
        }
        :is([class*="navigation_component_tab__"], [class*="_tab_"]) + :is([class*="navigation_component_filter__"], [class*="_filter_"]) {
          top: 103px !important;
        }
        #layout-body {
          padding-top: unset !important;
        }
        .cqc-route-schedule :is([class*="schedule_wrapper__"], [class*="_wrapper_"]) {
          top: 143px !important;
        }
        .cqc-route-channel :is([class*="channel_tab__"], [class*="_tab_"]) {
          top: calc(60px) !important;
        }
        .cqc-route-category :is([class*="category_tab__"], [class*="_tab_"]) {
          top: calc(60px) !important;
        }
        ._container_zi67z_21:not(:first-child) {
          margin-top: 0 !important;
        }
      `;
    } else {
      styleEl?.remove();
    }
  }

  runLayoutCleanup(keywords) {
    const isEnabled = this.settings?.layoutCleanEnabled ?? true;

    this.toggleEventBannerFix(isEnabled);

    // 개별 메뉴 숨김 로직 (첫번째 네비게이션 섹션)
    const firstSection = document.querySelector(SELECTORS.NAV_SECTION);
    const hiddenMenus = this.settings?.hiddenSidebarMenus || [];

    if (firstSection) {
      const items = firstSection.querySelectorAll(SELECTORS.NAV_ITEM);
      items.forEach(item => {
        const text = item.textContent || '';
        if (text.includes('전체 방송')) return; // 전체 방송은 항상 유지

        const shouldHide = isEnabled && hiddenMenus.some(menu => text.includes(menu));
        if (shouldHide) {
          item.style.setProperty('display', 'none', 'important');
          item.setAttribute('data-cqc-menu-hidden', 'true');
        } else if (item.getAttribute('data-cqc-menu-hidden') === 'true') {
          item.style.display = '';
          item.removeAttribute('data-cqc-menu-hidden');
        }
      });
    }

    // 헤더 탭 및 배너 동적 수집 및 숨김 로직 (React 구조 기반, Injected Script에 위임)
    const tabContainer = document.querySelector(SELECTORS.TOPIC_TAB_CONTAINER);
    const hiddenTabs = this.settings?.hiddenHeaderTabs || [];

    if (tabContainer) {
      this.send('GET_HEADER_TAB_TITLES').then(titles => {
        if (!titles || !Array.isArray(titles)) return;

        const tabElements = tabContainer.querySelectorAll(SELECTORS.TOPIC_TAB_ELEMENTS);
        const discoveredList = [];

        tabElements.forEach((el, idx) => {
          const title = titles[idx];
          if (title) {
            discoveredList.push(title);
          }
          const shouldHide = isEnabled && title && hiddenTabs.includes(title);
          //console.log(`[LayoutModule] Tab: ${title}, shouldHide: ${shouldHide}, isEnabled: ${isEnabled}, hiddenTabs: ${hiddenTabs}`);
          if (shouldHide) {
            el.style.setProperty('display', 'none', 'important');
          } else {
            el.style.display = '';
          }
        });

        if (discoveredList.length > 0) {
          const currentDiscovered = this.settings?.discoveredHeaderTabs || [];
          const newTabs = discoveredList.filter(tab => !currentDiscovered.includes(tab));
          if (newTabs.length > 0) {
            const merged = [...currentDiscovered, ...newTabs];
            this.settings.discoveredHeaderTabs = merged;
            Browser.runtime.sendMessage({ type: 'SAVE_SETTINGS', payload: this.settings }).catch(err => {
              log('동적 탭 목록 저장 실패:', err);
            });
          }
        }
      }).catch(err => {
        log('GET_HEADER_TAB_TITLES 메시지 전송 실패:', err);
      });
    }

    const hideStudio = this.settings?.hideStudioButton ?? false;
    let studioBtn = document.querySelector(SELECTORS.STUDIO_BUTTON as string) as HTMLElement | null;
    if (studioBtn) {
      if (hideStudio) {
        studioBtn.style.setProperty('display', 'none', 'important');
        studioBtn.setAttribute('data-cqc-studio-hidden', 'true');
      } else if (studioBtn.getAttribute('data-cqc-studio-hidden') === 'true') {
        studioBtn.style.display = '';
        studioBtn.removeAttribute('data-cqc-studio-hidden');
      }
    }

    const hideCheese = this.settings?.hideCheeseButton ?? false;
    let cheeseContainer = null;
    const cheeseBtn = document.querySelector(SELECTORS.CHEESE_BTN as string);
    cheeseContainer = cheeseBtn ? (cheeseBtn.closest(SELECTORS.TOOLBAR_ITEM as string) || cheeseBtn) as HTMLElement : null;

    if (cheeseContainer) {
      if (hideCheese) {
        cheeseContainer.style.setProperty('display', 'none', 'important');
        cheeseContainer.setAttribute('data-cqc-cheese-hidden', 'true');
      } else if (cheeseContainer.getAttribute('data-cqc-cheese-hidden') === 'true') {
        cheeseContainer.style.display = '';
        cheeseContainer.removeAttribute('data-cqc-cheese-hidden');
      }
    }

    const hideNoti = this.settings?.hideNotiButton ?? false;
    let notiContainer = null;
    const notiBtn = document.querySelector(SELECTORS.NOTI_BTN as string);
    notiContainer = notiBtn ? (notiBtn.closest(SELECTORS.TOOLBAR_ITEM as string) || notiBtn) as HTMLElement : null;

    if (notiContainer) {
      if (hideNoti) {
        notiContainer.style.setProperty('display', 'none', 'important');
        notiContainer.setAttribute('data-cqc-noti-hidden', 'true');
      } else if (notiContainer.getAttribute('data-cqc-noti-hidden') === 'true') {
        notiContainer.style.display = '';
        notiContainer.removeAttribute('data-cqc-noti-hidden');
      }
    }

    const hideCheatKey = this.settings?.hideCheatKeyButton ?? false;
    let cheatKeyContainer = null;
    const cheatKeyBtn = document.querySelector(SELECTORS.CHEAT_KEY_BTN as string);
    cheatKeyContainer = cheatKeyBtn ? (cheatKeyBtn.closest(SELECTORS.TOOLBAR_ITEM as string) || cheatKeyBtn) as HTMLElement : null;

    if (cheatKeyContainer) {
      if (hideCheatKey) {
        cheatKeyContainer.style.setProperty('display', 'none', 'important');
        cheatKeyContainer.setAttribute('data-cqc-cheatkey-hidden', 'true');
      } else if (cheatKeyContainer.getAttribute('data-cqc-cheatkey-hidden') === 'true') {
        cheatKeyContainer.style.display = '';
        cheatKeyContainer.removeAttribute('data-cqc-cheatkey-hidden');
      }
    }

    const hideStore = this.settings?.hideStoreButton ?? false;
    let boxes = Array.from(document.querySelectorAll(SELECTORS.TOOLBAR_BOX_ALT as string));

    boxes.forEach(box => {
      const items = Array.from(box.children);
      if (items.length > 0) {
        const allHidden = items.every(item => item.style.display === 'none' || getComputedStyle(item).display === 'none');
        if (allHidden) {
          box.style.setProperty('display', 'none', 'important');
          box.setAttribute('data-cqc-box-hidden', 'true');
        } else if (box.getAttribute('data-cqc-box-hidden') === 'true') {
          box.style.display = '';
          box.removeAttribute('data-cqc-box-hidden');
        }
      }
    });

    if (!isEnabled || !keywords || !keywords.length) {
      this.removeEarlyHideStyle();
      document.querySelectorAll('[data-cqc-layout-hidden="true"]').forEach(el => {
        el.style.display = '';
        el.removeAttribute('data-cqc-layout-hidden');
      });
      return;
    }
    const keywordsStr = keywords.join('|');
    if (this._lastKeywordsStr !== keywordsStr) {
      this._lastKeywordsStr = keywordsStr;
      this._cachedRegexes = keywords.map(kw => {
        const escaped = kw.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        const pattern = escaped.replace(/\s+/g, '\\s*');
        return new RegExp(pattern, 'i');
      });
    }

    const regexes = this._cachedRegexes;

    const sections = document.querySelectorAll(SELECTORS.NAV_SECTION);
    sections.forEach(sec => {
      const titleEl = sec.querySelector(SELECTORS.NAV_TITLE) || sec.querySelector('strong');
      const text = titleEl ? (titleEl.textContent || '') : (sec.textContent || '');
      const shouldHide = regexes.some(re => re.test(text));

      if (shouldHide) {
        sec.style.setProperty('display', 'none', 'important');
        sec.setAttribute('data-cqc-layout-hidden', 'true');
      } else {
        // early hide CSS의 nth-child(n+3) !important 규칙을 이기기 위해 명시적 복구
        if (sec.getAttribute('data-cqc-layout-hidden') === 'true' || sec.style.display === 'none') {
          sec.style.display = '';
          sec.removeAttribute('data-cqc-layout-hidden');
        }
      }
    });

    // 개별 섹션 처리 완료 후 early hide CSS 제거 (더 이상 불필요)
    this.removeEarlyHideStyle();
  }

  async checkAndWarnHwAccel() {
    const storage = await Browser.storage.local.get({ hwAccelWarnDismissed: false });
    if (storage.hwAccelWarnDismissed) {
      log('Hardware acceleration warning suppressed by user.');
      return;
    }

    let hwAccelOff = false;
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl', { failIfMajorPerformanceCaveat: true });
      if (!gl) {
        hwAccelOff = true;
      } else {
        const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
        const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : '';
        if (renderer.toLowerCase().includes('swiftshader') || renderer.toLowerCase().includes('llvmpipe')) {
          hwAccelOff = true;
        }
      }
    } catch (e) {
      // 측정불가 무시
    }

    if (hwAccelOff) {
      const ua = navigator.userAgent.toLowerCase();
      let isFirefox = ua.includes('firefox');

      const popup = document.createElement('div');
      popup.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.6);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(4px);
        font-family: Pretendard, -apple-system, 'Malgun Gothic', sans-serif;
      `;

      let settingDesc = '<span style="color:#00ffa3;">브라우저 설정</span>에서 <b>"가능한 경우 그래픽 가속 사용"</b>을 켜주세요.';
      if (isFirefox) {
        settingDesc = '<span style="color:#00ffa3;">Firefox 설정</span>에서 <b>"권장 성능 설정 사용"</b>을 끄고 <b>"가능한 경우 그래픽 가속 사용"</b>을 켜주세요.';
      }

      popup.innerHTML = `
        <div style="
          background: #1a1a1e;
          border: 1px solid rgba(255, 68, 68, 0.3);
          border-radius: 16px;
          width: 480px;
          max-width: 90vw;
          box-shadow: 0 20px 40px rgba(0,0,0,0.8);
          overflow: hidden;
        ">
          <!-- Header -->
          <div style="
            background: rgba(255, 68, 68, 0.1);
            padding: 20px 24px;
            border-bottom: 1px solid rgba(255, 68, 68, 0.2);
            display: flex;
            align-items: center;
            gap: 12px;
          ">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#ff4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
              <line x1="12" y1="9" x2="12" y2="13"></line>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            <h3 style="margin:0; font-size:18px; font-weight:700; color:#ff6b6b; letter-spacing:-0.5px;">그래픽 가속이 꺼져 있습니다</h3>
          </div>
          
          <!-- Body -->
          <div style="padding: 24px; color: #e0e0e0; font-size: 14px; line-height: 1.6;">
            <p style="margin:0 0 16px;">
              원활한 방송 시청 및 치지직 올인원의 <b>화질 향상, 시네마틱 앰비언트 등 그래픽 리소스를 활용하는 모든 기능</b>을 정상적으로 사용하기 위해 그래픽 가속이 필요합니다.
            </p>
            <div style="
              background: rgba(255, 255, 255, 0.05);
              border-radius: 8px;
              padding: 14px 16px;
              margin-bottom: 20px;
              border-left: 3px solid #ffaa00;
              display: flex;
              align-items: flex-start;
              gap: 10px;
            ">
              <p style="margin:0; color:#ddd;">
                그래픽 가속 없이 시청은 가능하지만, <b>심각한 성능 저하 및 화면 끊김(렉)</b>이 발생할 수 있습니다.
              </p>
            </div>
            <p style="margin:0; color:#bbb; font-size:13px;">
              ${settingDesc}
            </p>
          </div>

          <!-- Footer -->
          <div style="
            padding: 16px 24px;
            background: rgba(0,0,0,0.2);
            border-top: 1px solid rgba(255,255,255,0.05);
            display: flex;
            align-items: center;
            justify-content: space-between;
          ">
            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; color: #888; font-size: 13px;">
              <input type="checkbox" id="cqc-hw-dismiss" style="margin: 0; cursor: pointer; accent-color: #ff4444;">
              다시 보지 않기
            </label>
            <button id="cqc-hw-close" style="
              background: #ff4444;
              border: none;
              color: #fff;
              padding: 10px 24px;
              border-radius: 8px;
              cursor: pointer;
              font-size: 14px;
              font-weight: 700;
              transition: all 0.2s;
              box-shadow: 0 4px 12px rgba(255, 68, 68, 0.3);
            " onmouseover="this.style.background='#ff6666'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='#ff4444'; this.style.transform='none';">
              확인했어요
            </button>
          </div>
        </div>
      `;

      document.body.appendChild(popup);
      const closeBtn = popup.querySelector('#cqc-hw-close');
      const dismissCheck = popup.querySelector('#cqc-hw-dismiss');

      if (closeBtn) {
        closeBtn.addEventListener('click', async () => {
          if (dismissCheck && dismissCheck.checked) {
            await Browser.storage.local.set({ hwAccelWarnDismissed: true });
            log('하드웨어 가속 경고팝업 영구 닫기 설정됨.');
          }
          popup.remove();
        });
      }
    }
  }
}
