import { installSidebarImmediate, cleanupSidebarImmediate } from '../../../compatibility/sidebar-immediate.js';
// @ts-nocheck
/**
 * @fileoverview DOM 기반으로 사이드바 메뉴 및 섹션을 동적으로 숨기는 모듈
 * VDOM 가로채기로 인한 렌더링 폭주(API 사용량 급증)를 방지하기 위해 CSS(display: none) 방식으로 수정
 */
import { SELECTORS } from '../../../dom-utils';

export const initSidebarHider = (settings) => {
    if (!settings) return;

    const hiddenMenus = settings.hiddenSidebarMenus || [];
    const hiddenSections = settings.layoutCleanupKeywords || [];

    const patchSidebar = () => {
        const sidebarEl = document;
        if (!sidebarEl) return;

        // Menu items (links)
        const links = sidebarEl.querySelectorAll(`:is(${SELECTORS.SIDEBAR_ASIDE}, #sidebar) a`);
        links.forEach(link => {
            const href = link.getAttribute('href') || '';
            const className = link.className || '';
            let identifier = null;

            if (href === '/lives') identifier = '전체 방송';
            else if (href === '/category') identifier = '카테고리';
            else if (href === '/schedule') identifier = '편성표';
            else if (href === '/following') identifier = '팔로잉';
            else if (href === '/clips') identifier = '인기 클립';
            else if (href === '/cheezefarm' || className.includes('aside_banner') || className.includes('banner')) identifier = '치즈팜';

            if (identifier) {
                const li = link.closest('li');
                if (hiddenMenus.includes(identifier)) {
                    if (li) li.style.display = 'none';
                    else link.style.display = 'none';
                } else {
                    if (li) li.style.display = '';
                    else link.style.display = '';
                }
            }
        });

        // Sections
        const sections = Array.from(document.querySelectorAll(SELECTORS.NAV_SECTION as string));

        sections.forEach((section: any) => {
            const titleEl = section.querySelector(SELECTORS.NAV_TITLE as string) || section.querySelector('strong');
            if (!titleEl) return;
            const text = titleEl.textContent || '';
            let identifier = null;

            if (text.includes('인기 카테고리')) identifier = '인기 카테고리';
            else if (text.includes('방송 일정')) identifier = '방송 일정';
            else if (text.includes('파트너')) identifier = '파트너';
            else if (text.includes('서비스 바로가기')) identifier = '서비스 바로가기';

            if (identifier) {
                if (hiddenSections.includes(identifier)) {
                    section.style.display = 'none';
                } else {
                    section.style.display = '';
                }
            }
        });
    };

    installSidebarImmediate(settings, patchSidebar);
    if (window.__cqc_sidebarHiderInterval) {
        clearInterval(window.__cqc_sidebarHiderInterval);
    }
    // Persistent CSS and DOM observation replace the delayed timer.
};

export const cleanupSidebarHider = () => {
    cleanupSidebarImmediate();
    if (window.__cqc_sidebarHiderInterval) {
        clearInterval(window.__cqc_sidebarHiderInterval);
        delete window.__cqc_sidebarHiderInterval;
    }
};
