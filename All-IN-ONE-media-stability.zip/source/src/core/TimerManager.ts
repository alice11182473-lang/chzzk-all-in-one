// @ts-nocheck
export class TimerManager {
  constructor() {
    this.intervals = new Set();
    this.timeouts = new Set();
  }
  setInterval(callback, delay) {
    const id = window.setInterval(callback, delay);
    this.intervals.add(id);
    return id;
  }
  clearInterval(id) {
    window.clearInterval(id);
    this.intervals.delete(id);
  }
  setTimeout(callback, delay) {
    const id = window.setTimeout(callback, delay);
    this.timeouts.add(id);
    return id;
  }
  clearTimeout(id) {
    window.clearTimeout(id);
    this.timeouts.delete(id);
  }
  cleanup() {
    this.intervals.forEach(id => window.clearInterval(id));
    this.timeouts.forEach(id => window.clearTimeout(id));
    this.intervals.clear();
    this.timeouts.clear();
  }
}
