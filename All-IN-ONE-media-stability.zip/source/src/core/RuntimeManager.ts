// @ts-nocheck
import { EventBus } from './EventBus';
import { ObserverManager } from './ObserverManager';
import { TimerManager } from './TimerManager';
import { DomManager } from './DomManager';

export class RuntimeManager {
  eventBus: any;
  observerManager: any;
  timerManager: any;
  dom: any;
  modules: any[];
  perfInterval: any;
  isMounted: boolean;
  cleanups: any[];
  observers: any[];

  constructor() {
    this.eventBus = new EventBus();
    this.observerManager = new ObserverManager();
    this.timerManager = new TimerManager();
    this.dom = new DomManager();
    this.modules = [];
    this.perfInterval = null;
    this.isMounted = false;
    this.cleanups = [];
    this.observers = [];
  }

  register(module) {
    module.runtime = this;
    this.modules.push(module);
  }

  mount(settings, sendFn) {
    if (this.isMounted) return;
    this.isMounted = true;
    this.modules.forEach(m => {
      try {
        if (typeof m.mount === 'function') m.mount(settings, sendFn);
      } catch (e) {
        console.error('[RuntimeManager] Mount error for', m.constructor.name, e);
      }
    });
    this.startPerformanceMonitoring();
  }

  cleanup() {
    this.modules.forEach(m => {
      try {
        if (typeof m.cleanup === 'function') m.cleanup();
      } catch (e) {
        console.error('[RuntimeManager] Cleanup error for', m.constructor.name, e);
      }
    });
    this.observerManager.cleanup();
    this.timerManager.cleanup();
    if (this.perfInterval) {
      window.clearInterval(this.perfInterval);
      this.perfInterval = null;
    }
    this.isMounted = false;
    this.cleanups.forEach(cb => { try { cb(); } catch (e) { } });
    this.cleanups = [];
    this.observers.forEach(ob => { try { ob.disconnect(); } catch (e) { } });
    this.observers = [];
  }

  onRouteChange(routeInfo, settings, sendFn) {
    this.modules.forEach(m => {
      if (typeof m.onRouteChange === 'function') {
        try {
          m.onRouteChange(routeInfo, settings, sendFn);
        } catch (e) {
          console.error('[RuntimeManager] onRouteChange error for', m.constructor.name, e);
        }
      }
    });
  }

  startPerformanceMonitoring() {
    if (this.perfInterval) window.clearInterval(this.perfInterval);
    this.perfInterval = window.setInterval(() => {
      const memory = performance.memory;
      const stats = {
        observers: this.observerManager.observers.size,
        intervals: this.timerManager.intervals.size,
        timeouts: this.timerManager.timeouts.size,
        heap: memory ? `${(memory.usedJSHeapSize / 1024 / 1024).toFixed(2)} MB` : 'N/A'
      };
      //console.debug('%c[CQC-PERF]', 'color:#3b82f6;font-weight:bold', stats);
    }, 20000);
  }
}

export const runtime = new RuntimeManager();
