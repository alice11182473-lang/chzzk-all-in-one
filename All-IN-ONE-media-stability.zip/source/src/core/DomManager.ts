// @ts-nocheck
import { SELECTORS } from '../../dom-utils';

export class DomManager {
  player() {
    return document.querySelector(SELECTORS.PLAYER);
  }
  chat() {
    return document.querySelector(SELECTORS.CHAT_CONTAINER || '.live_chatting_container__TsnXM');
  }
  sidebar() {
    return document.querySelector(SELECTORS.SIDEBAR_CONTENT || 'aside');
  }
  body() {
    return document.body;
  }
}
