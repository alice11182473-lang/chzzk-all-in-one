// @ts-nocheck
export class ObserverManager {
  constructor() {
    this.observers = new Set();
  }
  create(callback) {
    const observer = new MutationObserver(callback);
    this.observers.add(observer);
    return observer;
  }
  observe(observer, target, options) {
    if (target) {
      observer.observe(target, options);
    }
  }
  disconnect(observer) {
    if (observer) {
      observer.disconnect();
      this.observers.delete(observer);
    }
  }
  cleanup() {
    this.observers.forEach(o => o.disconnect());
    this.observers.clear();
  }
}
