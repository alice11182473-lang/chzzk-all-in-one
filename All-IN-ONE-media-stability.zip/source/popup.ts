import './compatibility/native-recording-popup.js';
import './compatibility/recording-diagnostics-popup.js';
import './compatibility/recording-path-popup.js';
import { installAutoOpenPicker } from './compatibility/auto-open-picker.js';
import './compatibility/latency-popup.js';
// @ts-nocheck
import './src/utils/StorageBridge';
import Browser from 'webextension-polyfill';
import { safeParseSettings } from './settings-schema';
import { formatFileTimestamp } from './file-timestamp';

/**
 * @param {string} s - CSS 선택자
 * @returns {any}
 */
const $ = (s) => document.querySelector(s);

/**
 * @param {string} s - CSS 선택자
 * @returns {any}
 */
const $$ = (s) => document.querySelectorAll(s);

/**
 * 설정 키와 엘리먼트 ID 매핑 (background settings 객체 경유)
 */
const OPT_MAP_POPUP = {
  'opt-enabled': 'enabled',
  'opt-grid-bypass': 'gridBypassEnabled',
  'opt-grid-visible': 'gridVisible',
  'opt-auto': 'autoQuality',
  'opt-ll': 'preferLowLatency',
  'opt-reapply': 'autoReapplyOnRerender',
  'opt-noti': 'showNotification',
  'opt-layout-clean': 'layoutCleanEnabled',
  'opt-sidebar-folders': 'sidebarFoldersEnabled',
  'opt-ambient': 'ambientEnabled',
  'opt-power': 'powerClickEnabled',
  'opt-following-refresh': 'followingRefreshEnabled',
  'opt-following-expand': 'followingExpandEnabled',
  'opt-hide-install': 'hideInstallPopupEnabled',
  'opt-hover-preview': 'hoverPreviewEnabled',
  'opt-thumbnail-preview': 'thumbnailPreviewEnabled',
  'opt-hover-uptime-format': 'hoverPreviewUptimeFormat',
  'opt-hover-preview-delay': 'hoverPreviewDelay',
  'opt-hover-preview-video-delay': 'hoverPreviewVideoDelay',
  'opt-hover-preview-interactive': 'hoverPreviewInteractive',
  'opt-hover-preview-video': 'hoverPreviewVideoEnabled',
  'opt-hide-offline': 'hideOfflineFollowing',
  'opt-stream-stats': 'streamStatsEnabled',
  'opt-stats-contextmenu': 'statsContextMenuEnabled',
  'opt-ranking-hide': 'rankingHideEnabled',
  'opt-screenshot': 'screenshotEnabled',
  'opt-recorder-low-load': 'recorderLowLoadEnabled',
  'opt-recorder': 'recorderEnabled',
  'opt-gc-monitor': 'gcMonitorEnabled',
  'opt-watch-timer': 'watchTimerEnabled',
  'opt-sidebar-resize': 'sidebarResizeEnabled',
  'opt-chat-resize': 'chatResizeEnabled',
  'opt-wide-view': 'wideViewEnabled',
  'opt-chat-font-size': 'chatFontSize',
  'opt-chat-stamp': 'chatStampEnabled',
  'opt-playback-speed': 'playbackSpeedEnabled',
  'opt-playback-bar': 'playbackBarEnabled',
  'opt-pb-time-enabled': 'playbackBarTimeEnabled',
  'opt-pb-time-top-right': 'playbackBarTimeTopRight',
  'opt-focus-mode': 'focusModeEnabled',
  'opt-offline-fold': 'sidebarOfflineFoldEnabled',
  'opt-static-logo': 'staticLogoEnabled',
  'opt-live-noti': 'liveNotificationEnabled',
  'opt-live-reload': 'liveAutoReloadEnabled',
  'opt-playback-speed-reset': 'playbackSpeedResetOnLive',
  'opt-chat-filter': 'chatFilterEnabled',
  'opt-custom-video-sort': 'customVideoSortEnabled',
  'opt-hide-home-banner': 'hideHomeBannerEnabled',
  'opt-hide-home-recommend': 'hideHomeRecommendEnabled',
  'opt-hide-home-mid-banner': 'hideHomeMidBannerEnabled',
  'opt-hide-streamer-shop': 'hideStreamerShopEnabled',
  'opt-volume-indicator': 'volumeIndicatorEnabled',
  'opt-wheel-volume': 'wheelVolumeEnabled',
  'opt-blinded-restore': 'blindedRestoreEnabled',
  'opt-blinded-auto-restore': 'blindedAutoRestoreEnabled',
  'opt-chat-collector': 'chatCollectorEnabled',
  'opt-hide-studio-btn': 'hideStudioButton',
  'opt-hide-cheese-btn': 'hideCheeseButton',
  'opt-hide-noti-btn': 'hideNotiButton',
  'opt-hide-cheatkey-btn': 'hideCheatKeyButton',
  'opt-notice-icon': 'noticeIconEnabled',
  'opt-chat-collector-icon': 'chatCollectorIconEnabled',
  'opt-chat-collector-split': 'chatCollectorSplitMode',
  'opt-category-block': 'categoryBlockEnabled',
  'opt-live-auto-open': 'liveAutoOpenEnabled',
  'opt-live-auto-return': 'liveAutoOpenReturnToPrevious',
  'opt-hide-chat-nickname': 'hideChatNickname',
  'opt-hide-chat-badge': 'hideChatBadge',
  'opt-keep-badge-subscription': 'keepBadgeSubscription',
  'opt-keep-badge-activity': 'keepBadgeActivity',
  'opt-keep-badge-cheatkey': 'keepBadgeCheatkey',
  'opt-keep-badge-role': 'keepBadgeRole',
  'opt-restore-transparent-nickname': 'restoreTransparentNickname',
  'opt-chat-device-icon': 'chatDeviceIconEnabled',
  'opt-chat-emoji-copypaste': 'chatEmojiCopyPasteEnabled',
  'opt-chat-message-copypaste': 'chatMessageCopyEnabled',
  'opt-chat-export': 'chatExportEnabled',
  'opt-chat-nickname-max-length': 'chatNicknameMaxLength',
  'opt-playback-seek-time': 'playbackSeekTime',
  'opt-chat-latency-display': 'chatLatencyDisplayEnabled',
  'opt-vod-realtime-tooltip': 'vodRealTimeTooltipEnabled',
  'opt-left-chat': 'leftChatEnabled',
};

const SEARCH_DICTIONARY = {
  'opt-enabled': ['마스터', '온오프', '활성', '비활성', '중단', '켜기', '끄기', 'master', 'enable', 'switch'],
  'opt-grid-bypass': ['그리드', '우회', '1080p', 'grid', 'bypass'],
  'opt-grid-visible': ['화질', '그리드', '버튼', '선택', 'grid', 'visible'],
  'opt-auto': ['자동', '화질', '고정', '최상', '유지', 'auto', 'quality'],
  'opt-preferred': ['선호', '화질', '해상도', 'quality', 'resolution'],
  'opt-ll': ['저지연', '실시간', '소통', '레이턴시', 'latency', 'll'],

  'opt-playback-seek-time': ['탐색 시간', '방향키', '이동 시간', '5초', '시간 조절', 'seek', 'time'],
  'opt-target-latency': ['목표', '레이턴시', '지연', '시간', 'latency'],
  'opt-chaser-mode': ['추격', '배속', '점진적', 'chaser'],
  'opt-reapply': ['자동', '재적용', '화질', '저하', 'reapply'],
  'btn-reapply': ['강제', '재적용', '화질', '전환', 'reapply'],
  'btn-refresh': ['상태', '갱신', '새로고침', 'refresh'],
  'opt-sharpness': ['선명도', '화질', '채도', '밝기', '필터', '보정', 'sharp', 'filter'],
  'opt-sharpness-mode': ['선명도', '모드', '필터', 'sharp', 'mode'],
  'opt-hide-sharp-menu': ['선명도', '숨김', '제거', 'sharp', 'hide'],
  'opt-audio': ['오디오', '사운드', '소리', '음향', '음질', 'eq', '이퀄라이저', '오디오 eq', 'audio', 'sound', 'equalizer'],
  'opt-audio-preset': ['오디오', '음향', '소리', '사운드', '이퀄라이저', '프리셋', 'preset', 'flat', 'bass', 'treble', 'vocal', 'asmr'],
  'opt-hide-audio-menu': ['오디오', '사운드', '소리', '음향', '숨김', '제거', 'audio', 'hide'],
  'opt-playback-speed': ['배속', '속도', '버튼', 'speed'],
  'opt-playback-bar': ['재생바', '커스텀', '타임라인', 'play', 'bar', 'timeline'],
  'opt-pb-time-enabled': ['재생바', '시간', '타임', 'timeline', 'time'],
  'opt-pb-time-top-right': ['재생바', '시간 위치', '우측 상단', 'live', 'time', 'top', 'right'],
  'opt-ambient': ['앰비언트', '시네마틱', '조명', '불끄기', 'ambient', 'glow'],
  'opt-volume-indicator': ['볼륨', '소리', '툴팁', '조절', 'volume', 'tooltip'],
  'opt-screenshot': ['스크린샷', '캡처', '스샷', '저장', '복사', 'screenshot', 'capture'],
  'opt-recorder-low-load': 'recorderLowLoadEnabled',
  'opt-recorder': ['녹화', '캡처', '비디오', '영상', '저장', 'record', 'video'],
  'opt-recorder-format': ['녹화', '포맷', '확장자', 'format', 'webm', 'mp4'],
  'opt-file-timestamp-format': ['파일명', '이름', '시간 포맷', '타임스탬프', 'format', 'timestamp'],
  'opt-file-timestamp-timezone': ['시간대', '기준', 'local', 'utc', 'timezone'],
  'btn-open-shortcut-modal': ['단축키', '커스텀', '할당', '키보드', 'hotkey', 'shortcut'],
  'opt-sidebar-folders': ['사이드바', '폴더', '그룹', '정리', 'sidebar', 'folder'],
  'opt-sidebar-folders-default-state': ['새로고침', '폴더', '접힘', '펼침', 'sidebar', 'folder'],
  'opt-sidebar-offline-group-default-state': ['오프라인', '폴더', '접힘', '펼침', 'sidebar', 'offline'],
  'opt-following-refresh': ['팔로잉', '자동 갱신', '새로고침', 'following', 'refresh'],
  'opt-following-expand': ['팔로잉', '목록 펼치기', '더보기', 'expand'],
  'opt-hide-offline': ['오프라인', '미방송', '숨기기', 'hide', 'offline'],
  'opt-offline-fold': ['오프라인', '접기', '그룹', '헤더', 'fold', 'offline'],
  'opt-sidebar-resize': ['사이드바', '크기', '너비', '조절', '리사이즈', 'resize'],
  'opt-wide-view': ['넓은 화면', '자동 넓은 화면', 'wide', 'view'],
  'opt-static-logo': ['정적 로고', '움직이는 로고', 'static', 'logo'],
  'opt-hover-preview': ['호버', '미리보기', '마우스', 'hover', 'preview'],
  'opt-thumbnail-preview': ['본문 미리보기', '썸네일 미리보기', '홈 미리보기', '팔로잉 미리보기', 'thumbnail', 'preview'],
  'opt-hover-preview-delay': ['미리보기 호버 지연', '딜레이', '지연 시간', '호버 지연', 'delay', 'hover'],
  'opt-hover-preview-video': ['비디오 미리보기', '영상 미리보기', '재생', 'video', 'preview'],
  'opt-hover-preview-volume': ['미리보기 볼륨', '소리 조절', 'volume'],
  'opt-custom-video-sort': ['영상 정렬', '시청자 순', '정렬', 'sort'],
  'opt-watch-timer': ['시청 타이머', '시간', '측정', 'timer'],
  'opt-hide-home-banner': ['홈 상단', '광고 배너', '숨기기', 'banner', 'hide'],
  'opt-hide-home-recommend': ['홈 추천 방송', '추천 영역', '캐러셀', '숨기기', 'recommend', 'hide'],
  'opt-hide-home-mid-banner': ['홈 중간 띠 배너', '중간 광고', '배너', '숨기기', 'mid', 'banner', 'hide'],
  'opt-hide-streamer-shop': ['스트리머 숍', '배너 숨기기', 'shop', 'hide'],
  'opt-font-select': ['글꼴', '폰트', '서체', 'font'],
  'opt-font-weight-seg': ['글꼴 두께', '폰트 굵기', 'weight'],
  'opt-ranking-hide': ['순위권 채팅', '채팅 숨김', 'ranking'],
  'cf-stamp-toggle': ['채팅 타임스탬프', '시간 표시', 'timestamp'],
  'cf-stamp-format': ['타임스탬프 형식', '시간', 'relative', 'format'],
  'cf-stamp-size': ['타임스탬프 크기', '폰트 크기', 'size'],
  'cf-font-size': ['글자 크기', '폰트 크기', 'font size'],
  'opt-hide-chat-nickname': ['시청자 닉네임', '이름 숨기기', 'nickname', 'hide'],
  'opt-hide-chat-badge': ['시청자 뱃지 숨기기', '뱃지 숨김', '구독 뱃지', 'badge', 'hide'],
  'opt-keep-badge-subscription': ['구독 뱃지 유지', '구독뱃지', '구독만 표시', 'subscription', 'keep', 'badge'],
  'opt-keep-badge-activity': ['활동 뱃지 유지', '팬 뱃지', '치즈 뱃지', '활동뱃지', 'activity', 'fan', 'keep', 'badge'],
  'opt-keep-badge-cheatkey': ['치트키 뱃지 유지', '치트키뱃지', 'cheatkey', 'keep', 'badge'],
  'opt-keep-badge-role': ['역할 뱃지 유지', '스트리머 뱃지', '매니저 뱃지', 'role', 'streamer', 'manager', 'keep', 'badge'],
  'opt-restore-transparent-nickname': ['투명 닉네임', '투명화', '닉네임 복구', 'transparent', 'nickname'],
  'opt-chat-device-icon': ['디바이스 아이콘', '기기 표시', 'PC', '모바일', 'device', 'icon', 'mobile'],
  'opt-chat-emoji-copypaste': ['이모티콘 복사', '이모티콘 붙여넣기', '클릭 복사', 'emoji', 'copy', 'paste'],
  'opt-chat-export': ['채팅 내보내기', '채팅 저장', 'txt', 'export', 'download', '다운로드'],
  'opt-chat-nickname-max-length': ['닉네임 글자 수', '글자 수 제한', 'nickname', 'length'],
  'opt-chat-resize': ['채팅창 리사이즈', '채팅 크기', 'resize'],
  'opt-blinded-restore': ['블라인드', '차단 메시지', '복구', 'blind'],
  'opt-blinded-auto-restore': ['블라인드 항상 표시', '차단 메시지', 'blind'],
  'opt-chat-collector-icon': ['채팅 모아보기', '수집기 아이콘', 'collector'],
  'opt-chat-collector-split': ['모아보기 분리', '분리 모드', '상단 표시', 'split', 'collector'],
  'opt-chat-filter': ['채팅 필터', '단어 차단', '유저 차단', 'filter'],
  'chat-filter-keyword': ['차단 단어', '키워드 차단', '필터', 'filter', 'keyword'],
  'chat-filter-user': ['유저 차단', '닉네임 차단', 'filter', 'user'],
  'opt-category-block': ['카테고리 차단', '방송 차단', '태그 차단', 'block', 'category'],
  'category-block-tag': ['카테고리 태그 차단', '방송 차단', 'block', 'category'],
  'btn-mv-start': ['멀티뷰 시작', '멀티뷰 엔진', 'multiview'],
  'btn-mc-open-all': ['채팅 창 모두 열기', '멀티뷰 채팅', 'chat'],
  'opt-power': ['통나무 파워', '자동 수령', '나무', 'power'],
  'opt-power-reset-hours': ['카운트 초기화', '리셋', 'reset', 'power'],
  'opt-focus-mode': ['통나무 집중 모드', '상태 아이콘 숨김', 'focus'],
  'opt-stats-contextmenu': ['우클릭 스트림 통계', '우클릭 통계', 'stats'],
  'opt-live-noti': ['생방송 시작 알림', '방송 알림', '알람', 'notification', 'live', '제외', '차단', '개별 토글'],
  'opt-live-reload': ['방송 시작 새로고침', '자동 갱신', 'reload'],
  'opt-live-auto-open': ['방송 시작 탭 열기', '자동 탭', 'open', 'live'],
  'opt-live-interval': ['알림 체크 주기', '알림 간격', 'interval', 'check'],
  'opt-gc-monitor': ['gc 모니터', '메모리', 'gc', 'monitor', 'memory'],
  'btn-export-settings': ['설정 백업', '설정 내보내기', '설정 저장', 'backup', 'export'],
  'btn-import-settings': ['설정 복원', '설정 불러오기', '설정 로드', 'restore', 'import'],
  'btn-reset-all-settings': ['설정 초기화', '전체 초기화', 'reset'],
  'btn-start-inspector': ['인터랙티브 요소 피커', '셀렉터 편집기', '요소 클릭', 'inspector', 'picker'],
  'btn-reset-selectors': ['커스텀 셀렉터 초기화', '셀렉터 리셋', 'selector', 'reset'],
  'btn-restart-wizard': ['설정 가이드', '설치 가이드', '티켓', 'wizard', 'guide'],
};

/** @type {any} */
let cfg = null;
/** @type {any} */
let ps = null;

/**
 * 백그라운드 서비스 워커로 메시지를 전송합니다.
 * @param {string} type
 * @param {any} [payload]
 * @returns {Promise<any>}
 */
const msg = async (type, payload) => {
  try {
    return await Browser.runtime.sendMessage({ type, payload });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    const noReceiver = message.includes('Receiving end does not exist') ||
      message.includes('Could not establish connection');

    if (type === 'GET_SETTINGS') {
      const { settings } = await Browser.storage.sync.get('settings');
      return safeParseSettings(settings);
    }

    if (type === 'SAVE_SETTINGS') {
      await Browser.storage.sync.set({ settings: payload });
      return { success: true, fallback: true };
    }

    if (!noReceiver) console.error(`[CQC:Popup] Message failed: ${type}`, err);
    return null;
  }
};

/**
 * 하드웨어 가속 및 브라우저 환경을 체크합니다.
 * @returns {string} 확인된 시스템 환경
 */
const checkSystemEnv = () => {
  const ua = navigator.userAgent.toLowerCase();
  let browser = 'Chrome/Edge';
  if (ua.includes('firefox')) browser = 'Firefox';
  else if (ua.includes('whale')) browser = 'Whale';
  else if (ua.includes('opr') || ua.includes('opera')) browser = 'Opera';
  else if (ua.includes('edg/')) browser = 'Edge';
  else if (ua.includes('chrome')) browser = 'Chrome';

  let hwAccel = '알 수 없음';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl', { failIfMajorPerformanceCaveat: true });
    if (!gl) {
      hwAccel = '꺼짐(S/W)';
    } else {
      const debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      const renderer = debugInfo ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) : '';
      if (renderer.toLowerCase().includes('swiftshader') || renderer.toLowerCase().includes('llvmpipe')) {
        hwAccel = '꺼짐(S/W)';
      } else {
        hwAccel = '켜짐(H/W)';
      }
    }
  } catch (e) {
    hwAccel = '측정 불가';
  }

  return `HW 가속: ${hwAccel} · ${browser}`;
};

/**
 * 스크롤 시 헤더를 숨기거나 노출하는 기능을 바인딩합니다.
 */
const bindScrollHeader = () => {
  let lastScrollTop = 0;
  const delta = 5; // 최소 스크롤 감도
  const headerHeight = 53; // 헤더 대략적 높이

  const searchBox = $('.search-box-container');
  const tabs = $('nav.tabs');
  const placeholder = $('#search-placeholder');
  const searchInput = /** @type {HTMLInputElement|null} */ ($('#opt-search'));
  const tabsButtons = $('.tabs__nav');

  const moveToTabs = () => {
    if (searchBox && tabs && searchBox.parentElement !== tabs) {
      tabs.appendChild(searchBox);

      // If search is active, adjust visibility
      if (searchInput && searchInput.value.trim()) {
        if (tabsButtons) tabsButtons.style.display = 'none';
        tabs.style.display = '';
      }
    }
  };

  const moveToPlaceholder = () => {
    if (searchBox && placeholder && searchBox.parentElement !== placeholder.parentElement) {
      placeholder.parentNode.insertBefore(searchBox, placeholder);

      // If search is active, adjust visibility
      if (searchInput && searchInput.value.trim()) {
        tabs.style.display = 'none';
      }
    }
  };

  window.addEventListener('scroll', () => {
    const st = window.scrollY || document.documentElement.scrollTop;

    // 최상단 근접 시(오차 보정 5px) 감도 무관 즉시 복구
    if (st <= 5) {
      document.body.classList.remove('scroll-down');
      moveToPlaceholder();
      lastScrollTop = st;
      return;
    }

    // 미세한 스크롤 변경은 무시
    if (Math.abs(lastScrollTop - st) <= delta) return;

    if (st > lastScrollTop && st > headerHeight) {
      // 스크롤 다운
      document.body.classList.add('scroll-down');
      moveToTabs();
    }

    lastScrollTop = st;
  }, { passive: true });
};

document.addEventListener('DOMContentLoaded', async () => {
  try {
    cfg = await msg('GET_SETTINGS');
    ps = await msg('GET_PLAYER_STATE');

    if (!cfg) {
      console.warn('[CQC:Popup] Settings not loaded, using defaults.');
      cfg = {}; // 기본값으로 진행
    } else {
      const migrate = (arr) => {
        if (!Array.isArray(arr)) return arr;
        return arr.map(k => {
          if (k === '다가오는 방송 일정') return '방송 일정';
          if (k === '파트너 스트리머') return '파트너';
          return k;
        });
      };
      if (cfg.layoutCleanupKeywords) cfg.layoutCleanupKeywords = migrate(cfg.layoutCleanupKeywords);
      if (cfg.discoveredSidebarSections) cfg.discoveredSidebarSections = migrate(cfg.discoveredSidebarSections);
    }

    // 버전 표시
    const versionEl = $('#ext-version');
    if (versionEl) {
      const manifest = Browser.runtime.getManifest();
      const isDev = manifest?.name?.includes('(Dev)');
      versionEl.textContent = 'v' + (isDev ? 'DEV' : (manifest?.version || '1.0.0'));
    }

    // 시스템 환경 표시
    const envEl = $('#st-env');
    if (envEl) {
      const envInfo = checkSystemEnv();
      envEl.textContent = envInfo;
      if (envInfo.includes('꺼짐(S/W)')) {
        envEl.style.color = '#ff6b6b';
      } else {
        envEl.style.color = 'var(--text-dim)';
      }
    }

    render();
    bind();
    bindTabs();
    bindSearch();
    bindSections();
    bindResetSettings();
    bindMedia();
    cfFilterBind();
    cfMacroBind();
    cfBind();
    layoutBind();
    categoryBlockBind();
    liveAutoOpenBind();
    liveNotificationBlockBind();
    chatCollectorBind();
    mvBind();
    mcBind();
    shortcutBind();
    advancedBind();
    renderAdvanced();
    bindScrollHeader();

    setInterval(async () => {
      ps = await msg('GET_PLAYER_STATE');
      renderStatus();
      renderGrid();
    }, 1500);

    if (navigator.userAgent.includes('Firefox')) {
      const sharpSection = $('#opt-sharpness')?.closest('.opt-card');
      if (sharpSection) sharpSection.style.display = 'none';
      const sharpHead = Array.from($$('.sec-head')).find(h => h.textContent?.includes('영상 최적화'));
      if (sharpHead) sharpHead.style.display = 'none';

      // Firefox 비디오 미리보기 토글 강제 비활성화 해제 (디버깅 목적)
      /*
      const hoverVideoToggle = $('#opt-hover-preview-video');
      if (hoverVideoToggle) {
        hoverVideoToggle.setAttribute('disabled', 'true');
        hoverVideoToggle.setAttribute('aria-checked', 'false');
        hoverVideoToggle.style.opacity = '0.35';
        hoverVideoToggle.style.cursor = 'not-allowed';
        hoverVideoToggle.style.pointerEvents = 'none';
        
        const descEl = hoverVideoToggle.parentElement.querySelector('.opt-desc');
        if (descEl) {
          descEl.textContent = '파이어폭스에선 영상 미리보기가 시청 불가능합니다.';
          descEl.style.color = '#ff6b6b';
          descEl.style.fontWeight = '600';
        }
      }
      */
    }
  } catch (err) {
    console.error('[CQC:Popup] Critical initialization error:', err);
  }
});

// ═══════════════════════════════════════════
//  탭 전환
// ═══════════════════════════════════════════

const bindTabs = () => {
  const tabBtns = $$('.tab-btn');
  const tabPanes = $$('.tab-pane');

  tabBtns.forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      tabBtns.forEach((/** @type {any} */ b) => b.setAttribute('aria-selected', 'false'));
      tabPanes.forEach((/** @type {any} */ p) => p.classList.remove('active'));
      btn.setAttribute('aria-selected', 'true');
      const targetPane = $(`#${btn.getAttribute('aria-controls')}`);
      if (targetPane) targetPane.classList.add('active');
    });
  });
};

// ═══════════════════════════════════════════
//  설정 검색, 섹션 접기, 설정 초기화
// ═══════════════════════════════════════════

const bindSections = () => {
  const secHeads = $$('.sec-head');

  secHeads.forEach((/** @type {any} */ sh) => {
    const title = sh.querySelector('.sec-title')?.textContent?.trim() || '';
    const storageKey = `collapsed_sec_${title}`;

    // Restore collapsed state from localStorage
    const isCollapsed = localStorage.getItem(storageKey) === 'true';
    if (isCollapsed && title) {
      sh.classList.add('collapsed');
      toggleSectionSiblings(sh, true);
    }

    sh.addEventListener('click', () => {
      // Bypassed if searching is active
      const searchInput = /** @type {HTMLInputElement|null} */ (document.getElementById('opt-search'));
      if (searchInput && searchInput.value.trim()) return;

      const willCollapse = !sh.classList.contains('collapsed');
      sh.classList.toggle('collapsed', willCollapse);
      toggleSectionSiblings(sh, willCollapse);

      if (title) {
        localStorage.setItem(storageKey, String(willCollapse));
      }
    });
  });
};

const toggleSectionSiblings = (/** @type {HTMLElement} */ sh, /** @type {boolean} */ collapse) => {
  let next = sh.nextElementSibling;
  while (next && !next.classList.contains('sec-head')) {
    if (collapse) {
      next.setAttribute('data-collapsed-by-user', 'true');
      // @ts-ignore
      next.style.display = 'none';
    } else {
      next.removeAttribute('data-collapsed-by-user');
      // @ts-ignore
      next.style.display = '';
    }
    next = next.nextElementSibling;
  }
};

const bindSearch = () => {
  const searchInput = /** @type {HTMLInputElement|null} */ ($('#opt-search'));
  const clearBtn = /** @type {HTMLElement|null} */ ($('#opt-search-clear'));
  const searchStatus = /** @type {HTMLElement|null} */ ($('#search-status'));
  const tabsNav = /** @type {HTMLElement|null} */ ($('nav.tabs'));
  const tabsButtons = /** @type {HTMLElement|null} */ ($('.tabs__nav'));

  if (!searchInput) return;

  const handleSearch = () => {
    const val = searchInput.value.trim().toLowerCase();

    if (!val) {
      if (clearBtn) clearBtn.style.display = 'none';
      if (searchStatus) searchStatus.style.display = 'none';
      if (tabsNav) tabsNav.style.display = '';
      if (tabsButtons) tabsButtons.style.display = '';

      // Restore all normal tab pane visibility & user collapsed states
      const tabPanes = $$('.tab-pane');
      tabPanes.forEach((/** @type {any} */ pane) => {
        pane.style.display = '';
        pane.classList.remove('search-match');

        // Restore tab-pane active status
        const activeTabBtn = $('nav.tabs .tab-btn[aria-selected="true"]');
        const targetPaneId = activeTabBtn?.getAttribute('aria-controls');
        if (pane.id === targetPaneId) {
          pane.classList.add('active');
        } else {
          pane.classList.remove('active');
        }

        // Restore siblings visibility (either collapsed by user or shown)
        pane.querySelectorAll('.sec-head').forEach((/** @type {any} */ sh) => {
          sh.style.display = '';
          const isCollapsed = sh.classList.contains('collapsed');
          let next = sh.nextElementSibling;
          while (next && !next.classList.contains('sec-head')) {
            if (isCollapsed) {
              next.style.display = 'none';
            } else {
              next.style.display = '';
            }
            // Clear highlights
            clearHighlightText(next);

            // Restore opt-items display inside opt-card
            if (next.classList.contains('opt-card')) {
              next.querySelectorAll('.opt-item').forEach((/** @type {any} */ item) => {
                item.style.display = '';
              });
            }

            next = next.nextElementSibling;
          }
        });
      });
      return;
    }

    // Start searching
    if (clearBtn) clearBtn.style.display = 'flex';

    const isSearchInTabs = searchInput.closest('nav.tabs') !== null;
    if (isSearchInTabs) {
      if (tabsButtons) tabsButtons.style.display = 'none';
      if (tabsNav) tabsNav.style.display = '';
    } else {
      if (tabsNav) tabsNav.style.display = 'none';
    }

    let matchCount = 0;
    const tabPanes = $$('.tab-pane');

    tabPanes.forEach((/** @type {any} */ pane) => {
      let paneHasMatch = false;

      // We look at all sec-heads inside this pane
      const secHeads = pane.querySelectorAll('.sec-head');
      secHeads.forEach((/** @type {any} */ sh) => {
        let shHasMatch = false;

        // Find siblings under this sec-head
        let next = sh.nextElementSibling;
        while (next && !next.classList.contains('sec-head')) {
          let itemHasMatch = false;

          // Check if this sibling is an opt-card
          if (next.classList.contains('opt-card')) {
            const items = next.querySelectorAll('.opt-item');
            items.forEach((/** @type {any} */ item) => {
              const label = item.querySelector('.opt-label')?.textContent || '';
              const desc = item.querySelector('.opt-desc')?.textContent || '';

              // Collect all IDs inside this item
              const ids = [];
              if (item.id) ids.push(item.id);
              item.querySelectorAll('[id]').forEach((/** @type {any} */ el) => {
                if (el.id) ids.push(el.id);
              });

              let extraKeywords = '';
              ids.forEach(id => {
                const words = SEARCH_DICTIONARY[id];
                if (words) {
                  extraKeywords += ' ' + words.join(' ');
                }
              });

              const textToSearch = (label + ' ' + desc + ' ' + extraKeywords).toLowerCase();
              const isMatch = textToSearch.includes(val);

              if (isMatch) {
                item.style.display = '';
                itemHasMatch = true;
                shHasMatch = true;
                matchCount++;

                // Highlight label and desc
                highlightTextNode(item.querySelector('.opt-label'), val);
                highlightTextNode(item.querySelector('.opt-desc'), val);
              } else {
                item.style.display = 'none';
                clearHighlightTextNode(item.querySelector('.opt-label'));
                clearHighlightTextNode(item.querySelector('.opt-desc'));
              }
            });

            if (itemHasMatch) {
              next.style.display = '';
            } else {
              next.style.display = 'none';
            }
          } else {
            // Other sibling types (like custom buttons or input fields)
            const ids = [];
            if (next.id) ids.push(next.id);
            next.querySelectorAll('[id]').forEach((/** @type {any} */ el) => {
              if (el.id) ids.push(el.id);
            });

            let extraKeywords = '';
            ids.forEach(id => {
              const words = SEARCH_DICTIONARY[id];
              if (words) {
                extraKeywords += ' ' + words.join(' ');
              }
            });

            const textToSearch = ((next.textContent || '') + ' ' + extraKeywords).toLowerCase();
            const isMatch = textToSearch.includes(val);
            if (isMatch) {
              next.style.display = '';
              shHasMatch = true;
              matchCount++;
              highlightTextNode(next, val);
            } else {
              next.style.display = 'none';
              clearHighlightTextNode(next);
            }
          }

          next = next.nextElementSibling;
        }

        if (shHasMatch) {
          sh.style.display = '';
          paneHasMatch = true;
        } else {
          sh.style.display = 'none';
        }
      });

      if (paneHasMatch) {
        pane.classList.add('search-match');
        pane.style.display = 'block';
        pane.classList.add('active'); // force active class so it displays
      } else {
        pane.classList.remove('search-match');
        pane.style.display = 'none';
        pane.classList.remove('active');
      }
    });

    if (searchStatus) {
      searchStatus.style.display = 'flex';
      searchStatus.innerHTML = `검색 결과: <strong style="margin-left: 2px;">${matchCount}</strong>개 발견`;
    }
  };

  searchInput.addEventListener('input', handleSearch);

  clearBtn?.addEventListener('click', () => {
    searchInput.value = '';
    handleSearch();
  });
};

const highlightTextNode = (/** @type {HTMLElement|null} */ el, /** @type {string} */ val) => {
  if (!el) return;

  // Safe original text caching
  let original = el.getAttribute('data-original-text');
  if (!original) {
    original = el.innerHTML; // Store innerHTML to preserve nested tag elements if any
    el.setAttribute('data-original-text', original);
  }

  if (!val) {
    el.innerHTML = original;
    return;
  }

  // Strip existing highlights if innerHTML was saved during typing
  const cleanOriginal = original.replace(/<mark class="search-highlight">([\s\S]*?)<\/mark>/gi, '$1');

  // Escape regex
  const escaped = val.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(${escaped})`, 'gi');

  const text = el.textContent || '';
  if (text.toLowerCase().includes(val)) {
    el.innerHTML = text.replace(regex, '<mark class="search-highlight">$1</mark>');
  }
};

const clearHighlightTextNode = (/** @type {HTMLElement|null} */ el) => {
  if (!el) return;
  const original = el.getAttribute('data-original-text');
  if (original !== null) {
    el.innerHTML = original;
    el.removeAttribute('data-original-text');
  }
};

const clearHighlightText = (/** @type {Element} */ parent) => {
  parent.querySelectorAll('.opt-label, .opt-desc').forEach((/** @type {any} */ el) => {
    clearHighlightTextNode(el);
  });
};

const bindResetSettings = () => {
  const btn = $('#btn-reset-all-settings');
  btn?.addEventListener('click', async () => {
    if (confirm('정말로 모든 설정을 초기화하시겠습니까?\n단어 필터 및 채널 설정 등 모든 데이터가 기본값으로 복원됩니다.')) {
      try {
        await Browser.storage.sync.remove('settings');
        alert('모든 설정이 초기화되었습니다.');
        window.location.reload();
      } catch (err) {
        console.error('[CQC] Reset settings failed:', err);
        alert('설정 초기화에 실패했습니다.');
      }
    }
  });
};

// ═══════════════════════════════════════════
//  메인 설정 렌더/바인드
// ═══════════════════════════════════════════

const updateGCWarning = (/** @type {boolean} */ _enabled) => {
  const warning = $('#gc-flag-warning');
  const toggle = /** @type {any} */ ($('#opt-gc-monitor'));
  if (!warning || !toggle) return;
  const gcAvailable = typeof window.gc === 'function';
  if (!gcAvailable) {
    warning.style.display = 'flex';
    toggle.setAttribute('disabled', 'true');
    toggle.setAttribute('aria-checked', 'false');
    toggle.style.opacity = '0.35';
    toggle.style.cursor = 'not-allowed';
    toggle.style.pointerEvents = 'none';
  } else {
    warning.style.display = 'none';
  }
};


const updateAutoQualityState = () => {
  const preferredSel = /** @type {HTMLSelectElement|null} */ ($('#opt-preferred'));
  const autoToggle = /** @type {HTMLElement|null} */ ($('#opt-auto'));
  const autoDesc = $('#opt-auto')?.parentElement?.querySelector('.opt-desc');

  if (!preferredSel || !autoToggle) return;

  const isABR = preferredSel.value === 'ABR';

  if (isABR) {
    autoToggle.setAttribute('disabled', 'true');
    autoToggle.setAttribute('aria-checked', 'false');
    autoToggle.style.opacity = '0.4';
    autoToggle.style.cursor = 'not-allowed';
    autoToggle.style.pointerEvents = 'none';
    if (autoDesc) autoDesc.textContent = '선호 화질이 특정 고정 화질(1080p 등)일 때만 작동합니다';
  } else {
    autoToggle.removeAttribute('disabled');
    autoToggle.style.opacity = '';
    autoToggle.style.cursor = '';
    autoToggle.style.pointerEvents = '';
    if (autoDesc) autoDesc.textContent = '방송 연결 시 선호 화질 적용 · 성공 후 반복 변경하지 않음';
    if (cfg) {
      autoToggle.setAttribute('aria-checked', !!cfg.autoQuality ? 'true' : 'false');
    }
  }
};



const renderHeaderTabs = () => {
  const container = $('#layout-hide-header-tabs');
  if (!container || !cfg) return;

  const discovered = cfg.discoveredHeaderTabs || [];
  const hiddenTabs = cfg.hiddenHeaderTabs || [];

  if (discovered.length === 0) {
    container.innerHTML = `
      <div style="color: var(--text-dim, #777); font-size: 11px; padding: 12px 0; text-align: center; grid-column: span 2;">
        치지직 홈에 접속하여 탭 목록을 불러오세요.
      </div>
    `;
    return;
  }

  const allChecked = discovered.every((/** @type {string} */ tab) => hiddenTabs.includes(tab));

  container.innerHTML = `
    <div style="grid-column: span 2; display: flex; justify-content: flex-start; margin-bottom: 2px;">
      <button id="header-tab-toggle-all" style="
        background: none; border: 1px solid var(--border, #444); border-radius: 6px;
        color: var(--text-dim, #aaa); font-size: 11px; padding: 3px 10px; cursor: pointer;
        transition: all 0.15s ease;
      ">${allChecked ? '전체 해제' : '전체 선택'}</button>
    </div>
  ` + discovered.map((/** @type {string} */ tab) => {
    const isChecked = hiddenTabs.includes(tab);
    return `
      <label class="custom-chk">
        <input type="checkbox" value="${tab}" class="cf-header-tab-chk" ${isChecked ? 'checked' : ''}>
        <span class="chk-box"></span>
        <span style="font-size: 12px; font-weight: 600;">${tab}</span>
      </label>
    `;
  }).join('');

  const syncChecks = () => {
    const checkedBoxes = Array.from($$('#layout-hide-header-tabs input[type="checkbox"]:checked'));
    cfg.hiddenHeaderTabs = checkedBoxes.map((/** @type {any} */ b) => b.value);
    save();
  };

  container.querySelectorAll('.cf-header-tab-chk').forEach((/** @type {any} */ el) => {
    const chk = /** @type {HTMLInputElement} */(el);
    chk.addEventListener('change', () => {
      syncChecks();
      renderHeaderTabs();
    });
  });

  const toggleBtn = /** @type {HTMLElement|null} */($('#header-tab-toggle-all'));
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      if (allChecked) {
        cfg.hiddenHeaderTabs = [];
      } else {
        cfg.hiddenHeaderTabs = [...discovered];
      }
      save();
      renderHeaderTabs();
    });
  }
};

const renderSidebarMenus = () => {
  const container = $('#layout-hide-menus');
  if (!container || !cfg) return;

  const discovered = cfg.discoveredSidebarMenus || ['전체 방송', '카테고리', '편성표', '팔로잉', '치즈팜', '인기 클립'];
  const hiddenMenus = cfg.hiddenSidebarMenus || [];

  container.innerHTML = discovered.map((/** @type {string} */ menu) => {
    const isChecked = hiddenMenus.includes(menu);
    return `
      <label class="custom-chk">
        <input type="checkbox" value="${menu}" class="cf-sidebar-menu-chk" ${isChecked ? 'checked' : ''}>
        <span class="chk-box"></span>
        <span style="font-size: 12px; font-weight: 600;">${menu}</span>
      </label>
    `;
  }).join('');

  container.querySelectorAll('.cf-sidebar-menu-chk').forEach((/** @type {any} */ el) => {
    const chk = /** @type {HTMLInputElement} */(el);
    chk.addEventListener('change', () => {
      const checkedBoxes = Array.from($$('#layout-hide-menus input[type="checkbox"]:checked'));
      cfg.hiddenSidebarMenus = checkedBoxes.map((/** @type {any} */ b) => b.value);
      save();
    });
  });
};

const renderSidebarSections = () => {
  const container = $('#layout-hide-sections');
  if (!container || !cfg) return;

  const discovered = cfg.discoveredSidebarSections || ['인기 카테고리', '방송 일정', '파트너', '서비스 바로가기'];
  const hiddenSections = cfg.layoutCleanupKeywords || [];

  container.innerHTML = discovered.map((/** @type {string} */ section) => {
    const isChecked = hiddenSections.includes(section);
    return `
      <label class="custom-chk">
        <input type="checkbox" value="${section}" class="cf-sidebar-section-chk" ${isChecked ? 'checked' : ''}>
        <span class="chk-box"></span>
        <span style="font-size: 12px; font-weight: 600;">${section}</span>
      </label>
    `;
  }).join('');

  container.querySelectorAll('.cf-sidebar-section-chk').forEach((/** @type {any} */ el) => {
    const chk = /** @type {HTMLInputElement} */(el);
    chk.addEventListener('change', () => {
      const checkedBoxes = Array.from($$('#layout-hide-sections input[type="checkbox"]:checked'));
      cfg.layoutCleanupKeywords = checkedBoxes.map((/** @type {any} */ b) => b.value);
      save();
    });
  });
};

const render = () => {
  if (!cfg) return;
  for (const [id, key] of Object.entries(OPT_MAP_POPUP)) {
    const el = $(`#${id}`);
    if (el) {
      if (el.tagName === 'INPUT' && (el.type === 'number' || el.type === 'text')) {
        el.value = String(cfg[key] ?? 0);
      } else {
        el.setAttribute('aria-checked', !!cfg[key] ? 'true' : 'false');
      }
    }
  }
  const preferred = $('#opt-preferred');
  if (preferred) preferred.value = String(cfg.preferredQuality ?? 1080);
  const targetLatency = $('#opt-target-latency');
  if (targetLatency) targetLatency.value = String(cfg.targetLatency ?? 0);
  const chaserMode = $('#opt-chaser-mode');
  if (chaserMode) chaserMode.value = cfg.chaserMode ?? 'gradual';
  const hoverVolume = $('#opt-hover-preview-volume');
  if (hoverVolume) hoverVolume.value = String(cfg.hoverPreviewVolume ?? 0);
  const powerResetHours = $('#opt-power-reset-hours');
  if (powerResetHours) powerResetHours.value = String(cfg.powerCountResetHours ?? 24);
  const liveInterval = $('#opt-live-interval');
  if (liveInterval) liveInterval.value = String(cfg.liveNotificationInterval ?? 3);

  const sidebarFoldersDefaultState = $('#opt-sidebar-folders-default-state');
  if (sidebarFoldersDefaultState) sidebarFoldersDefaultState.value = cfg.sidebarFoldersDefaultState ?? 'remember';
  const sidebarOfflineGroupDefaultState = $('#opt-sidebar-offline-group-default-state');
  if (sidebarOfflineGroupDefaultState) sidebarOfflineGroupDefaultState.value = cfg.sidebarOfflineGroupDefaultState ?? 'collapsed';

  const hoverCardSize = $('#opt-hover-card-size');
  const hoverCardSizeCustom = $('#opt-hover-card-size-custom');
  if (hoverCardSize) {
    const validPresets = ['360', '440', '520'];
    const currentSizeStr = String(cfg.hoverCardSize ?? 440);
    if (validPresets.includes(currentSizeStr)) {
      hoverCardSize.value = currentSizeStr;
      if (hoverCardSizeCustom) hoverCardSizeCustom.style.display = 'none';
    } else {
      hoverCardSize.value = '__custom__';
      if (hoverCardSizeCustom) {
        hoverCardSizeCustom.value = currentSizeStr;
        hoverCardSizeCustom.style.display = 'block';
      }
    }
  }
  const ssToggle = $('#opt-screenshot');
  const ssContainer = $('#opt-screenshot-container');
  if (ssToggle && ssContainer) {
    ssContainer.setAttribute('aria-expanded', ssToggle.getAttribute('aria-checked') === 'true' ? 'true' : 'false');
  }

  const tpToggle = $('#opt-thumbnail-preview');
  const tpContainer = $('#opt-thumbnail-preview-container');
  if (tpToggle && tpContainer) {
    tpContainer.setAttribute('aria-expanded', tpToggle.getAttribute('aria-checked') === 'true' ? 'true' : 'false');
  }

  const hpvToggle = $('#opt-hover-preview-video');
  const hpvContainer = $('#opt-hover-preview-video-container');
  if (hpvToggle && hpvContainer) {
    hpvContainer.setAttribute('aria-expanded', hpvToggle.getAttribute('aria-checked') === 'true' ? 'true' : 'false');
  }

  const blindedToggle = $('#opt-blinded-restore');
  const blindedContainer = $('#opt-blinded-restore-container');
  if (blindedToggle && blindedContainer) {
    blindedContainer.setAttribute('aria-expanded', blindedToggle.getAttribute('aria-checked') === 'true' ? 'true' : 'false');
  }

  const layoutCleanToggle = $('#opt-layout-clean');
  const layoutCleanContainer = $('#opt-layout-clean-container');
  if (layoutCleanToggle && layoutCleanContainer) {
    layoutCleanContainer.setAttribute('aria-expanded', layoutCleanToggle.getAttribute('aria-checked') === 'true' ? 'true' : 'false');
  }


  const hideChatBadgeToggle = $('#opt-hide-chat-badge');
  const hideChatBadgeContainer = $('#opt-hide-chat-badge-container');
  if (hideChatBadgeToggle && hideChatBadgeContainer) {
    hideChatBadgeContainer.setAttribute('aria-expanded', hideChatBadgeToggle.getAttribute('aria-checked') === 'true' ? 'true' : 'false');
  }

  const categoryBlockToggle = $('#opt-category-block');
  const categoryBlockContainer = $('#opt-category-block-container');
  if (categoryBlockToggle && categoryBlockContainer) {
    categoryBlockContainer.style.display = categoryBlockToggle.getAttribute('aria-checked') === 'true' ? 'block' : 'none';
  }

  const liveAutoOpenToggle = $('#opt-live-auto-open');
  const liveAutoOpenSection = $('#auto-open-channels-section');
  if (liveAutoOpenToggle && liveAutoOpenSection) {
    liveAutoOpenSection.style.display = liveAutoOpenToggle.getAttribute('aria-checked') === 'true' ? 'block' : 'none';
  }
  liveAutoOpenRenderChannels();

  const liveNotiToggle = $('#opt-live-noti');
  const liveNotiBlockSection = $('#live-noti-block-section');
  if (liveNotiToggle && liveNotiBlockSection) {
    liveNotiBlockSection.style.display = liveNotiToggle.getAttribute('aria-checked') === 'true' ? 'block' : 'none';
  }
  liveNotificationBlockRenderChannels();

  renderSidebarMenus();
  renderHeaderTabs();
  renderSidebarSections();
  layoutRenderTags();
  categoryBlockRenderTags();

  const recorderFormat = $('#opt-recorder-format');
  if (recorderFormat) recorderFormat.value = cfg.recorderFormat === 'mkv' ? 'mkv' : 'mp4';

  const fileTimestampFormat = $('#opt-file-timestamp-format');
  if (fileTimestampFormat) fileTimestampFormat.value = cfg.fileTimestampFormat ?? 'dash';

  const hoverUptimeFormat = $('#opt-hover-uptime-format');
  if (hoverUptimeFormat) hoverUptimeFormat.value = cfg.hoverPreviewUptimeFormat ?? 'hhmmss';

  const fileTimestampTimezone = $('#opt-file-timestamp-timezone');
  if (fileTimestampTimezone) fileTimestampTimezone.value = cfg.fileTimestampTimezone ?? 'local';

  updateGCWarning(!!cfg?.gcMonitorEnabled);
  renderFontSelect();
  renderFontWeight();
  renderScreenshotAction();
  renderStatus();
  renderGrid();
  renderShortcuts();
  updateAutoQualityState();

  renderChatCollector();
  renderAdvanced();
};

const renderScreenshotAction = () => {
  const action = cfg?.screenshotAction || 'save';
  $$('#opt-screenshot-action-seg .seg-btn').forEach((/** @type {any} */ btn) => {
    btn.setAttribute('aria-selected', btn.dataset.value === action ? 'true' : 'false');
  });
};

const renderFontWeight = () => {
  const weight = cfg?.customFontWeight || 400;
  $$('#opt-font-weight-seg .seg-btn').forEach((/** @type {any} */ btn) => {
    const isMatched = parseInt(btn.dataset.weight, 10) === weight;
    btn.setAttribute('aria-selected', isMatched ? 'true' : 'false');
  });
};

const renderStatus = () => {
  const p = $('#st-player');
  const q = $('#st-quality');
  const g = $('#st-grid');
  const m = $('#st-mode');

  if (!ps?.ready) {
    p.innerHTML = '<span class="st-dot st-dot--off"></span>미감지';
    p.className = 'st-val st-val--dim';
    q.textContent = '—'; q.className = 'st-val st-val--dim';
    if (g) { g.textContent = '—'; g.className = 'st-val st-val--dim'; }
    m.textContent = '—'; m.className = 'st-val st-val--dim';
    const ln = $('#st-native'); if (ln) { ln.textContent = '—'; ln.className = 'st-val st-val--dim'; }
    const ll = $('#st-latency'); if (ll) { ll.textContent = '—'; ll.className = 'st-val st-val--dim'; }
    const lg = $('#st-guard'); if (lg) { lg.textContent = '—'; lg.className = 'st-val st-val--dim'; }
    return;
  }

  p.innerHTML = '<span class="st-dot st-dot--on"></span>연결됨';
  p.className = 'st-val st-val--on';
  if (g) {
    g.textContent = ps.gridBypassed ? '활성' : '비활성';
    g.className = `st-val ${ps.gridBypassed ? 'st-val--on' : 'st-val--dim'}`;
  }
  m.textContent = ps.isLowLatency == null ? '확인 불가' : ps.isLowLatency ? '저지연' : '일반';
  m.className = 'st-val';

  const n = $('#st-native');
  if (n) {
    n.textContent = ps.nativeLLActive == null ? '확인 불가' : ps.nativeLLActive ? '활성화됨' : '비활성';
    n.className = `st-val ${ps.nativeLLActive ? 'st-val--on' : 'st-val--dim'}`;
  }

  const l = $('#st-latency');
  if (l) {
    if (ps.currentLatency >= 0) {
      l.textContent = `${ps.currentLatency.toFixed(2)}초`;
      l.className = 'st-val st-val--on';
      l.title = `종단간 지연(PTS): ${ps.absoluteLatency !== -1 ? ps.absoluteLatency.toFixed(2) : '?'}초`;
    } else if (ps.absoluteLatency !== -1) {
      l.textContent = `${ps.absoluteLatency.toFixed(2)}초`;
      l.className = 'st-val st-val--on';
      l.title = '로컬 버퍼 지연 측정 불가';
    } else {
      l.textContent = '측정 중...';
      l.className = 'st-val st-val--dim';
    }
  }

  if (ps.isQualityRestoring) {
    q.textContent = '화질 복구 중...';
    q.className = 'st-val st-val--on';
  } else {
    const hasRes = ps.resolution && ps.resolution !== '0x0';
    q.textContent = hasRes
      ? `${ps.resolution}${ps.fps > 0 ? ` @ ${ps.fps}fps` : ""}`
      : (ps.currentTrack?.label ?? '—');
    q.className = `st-val ${hasRes || ps.currentTrack ? 'st-val--on' : 'st-val--dim'}`;
  }

  const gv = $('#st-guard');
  if (gv) {
    if (ps.manualQualitySelection) {
      gv.textContent = '수동 선택됨';
      gv.className = 'st-val st-val--dim';
    } else {
      gv.textContent = '자동 감시 중';
      gv.className = 'st-val st-val--on';
    }
  }

  // [수정] 비디오(VOD) 페이지인 경우 선호 화질 드롭다운에서 '자동' 옵션 숨김
  const isLive = ps?.isLive !== false;
  const abrOption = $('#opt-preferred option[value="ABR"]');
  if (abrOption) {
    abrOption.style.display = isLive ? '' : 'none';
  }
};

/**
 * 프리셋 폰트와 CSS import URL 매핑
 * @type {Record<string, string>}
 */
const FONT_PRESETS = {
  'Pretendard': 'https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard-dynamic-subset.min.css',
  'Wanted Sans Variable': 'https://cdn.jsdelivr.net/gh/wanteddev/wanted-sans@v1.0.1/packages/wanted-sans/fonts/webfonts/variable/split/WantedSansVariable.min.css',
  'NanumSquareNeo': 'https://hangeul.pstatic.net/hangeul_static/css/nanum-square-neo.css',
  'Nanum Gothic': 'https://fonts.googleapis.com/css2?family=Nanum+Gothic:wght@400;700;800&display=swap',
  'Nanum Myeongjo': 'https://fonts.googleapis.com/css2?family=Nanum+Myeongjo:wght@400;700;800&display=swap',
  'Noto Sans KR': 'https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@100..900&display=swap',
  'IBM Plex Sans KR': 'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+KR:wght@100..700&display=swap',
  'Hahmlet': 'https://fonts.googleapis.com/css2?family=Hahmlet:wght@100..900&display=swap',
  'Gamja Flower': 'https://fonts.googleapis.com/css2?family=Gamja+Flower&display=swap'
};

const syncFontSelectValue = () => {
  const fontVal = cfg?.customFont ?? '';
  const importVal = cfg?.customFontImport ?? '';
  const sel = $('#opt-font-select');
  const importInput = $('#opt-font-import');
  const customInput = $('#opt-font-custom');
  if (!sel) return;

  // select에 해당 옵션이 있는지 확인 (내장/웹 글꼴 프리셋)
  const knownValues = [...sel.querySelectorAll('option')].map((/** @type {any} */ o) => o.value);
  const isKnown = fontVal && fontVal !== '__custom__' && knownValues.includes(fontVal);

  if (!fontVal) {
    sel.value = '';
    if (importInput) importInput.style.display = 'none';
    if (customInput) customInput.style.display = 'none';
  } else if (isKnown) {
    sel.value = fontVal;
    if (importInput) importInput.style.display = 'none';
    if (customInput) customInput.style.display = 'none';
  } else {
    sel.value = '__custom__';
    if (importInput) { importInput.style.display = ''; importInput.value = importVal; }
    if (customInput) { customInput.style.display = ''; customInput.value = fontVal; }
  }
};

const renderFontSelect = () => {
  syncFontSelectValue();
};

const renderGrid = () => {
  const grid = $('#qgrid');
  if (!grid) return;
  if (ps?.availableQualities?.length) {
    grid.setAttribute('role', 'radiogroup');
    grid.setAttribute('aria-label', '선호 화질 선택');
    grid.innerHTML = (ps.availableQualities || []).map((/** @type {any} */ q) => {
      const cur = q.selected;
      const pref = q.height === cfg?.preferredQuality;
      let cls = 'qb';
      let ariaChecked = 'false';
      if (cur) { cls += ' qb--current'; ariaChecked = 'true'; }

      return `<button type="button" class="${cls}" data-h="${q.height}" title="${pref ? '선호 화질' : ''}" role="radio" aria-checked="${ariaChecked}">${q.label}</button>`;
    }).join('');
  } else {
    grid.innerHTML = '<div style="grid-column: span 3; color:var(--text3); font-size:12px; text-align:center; padding:20px; line-height:1.6; background:rgba(255,255,255,0.02); border:1px dashed rgba(255,255,255,0.08); border-radius:10px; margin:4px 0;">화질 목록이 없습니다.<br>영상 설정에서 화질 메뉴를 연 뒤 다시 확인해 주세요.</div>';
    grid.removeAttribute('role');
    grid.removeAttribute('aria-label');
  }

  $$('.qb').forEach((/** @type {any} */ b) => {
    b.addEventListener('click', async () => {
      const h = b.dataset.h === 'ABR' ? 'ABR' : parseInt(b.dataset.h, 10);
      const cqcResult = await msg('CHANGE_QUALITY', h);
      let cqcNote=document.getElementById("cqc-quality-feedback");if(!cqcNote){cqcNote=document.createElement("div");cqcNote.id="cqc-quality-feedback";cqcNote.setAttribute("role","status");cqcNote.style.cssText="padding:8px;font-size:12px;line-height:1.5";document.getElementById("qgrid")?.insertAdjacentElement("afterend",cqcNote)}cqcNote.textContent=cqcResult?.success?"화질 선택이 반영됐습니다. 영상 전환까지 잠시 기다려 주세요.":(cqcResult?.reason||"확장 응답을 받지 못했습니다. 방송 탭을 새로 열어 주세요.");
      setTimeout(async () => {
        ps = await msg('GET_PLAYER_STATE');
        renderStatus();
        renderGrid();
      }, 400);
    });
    b.addEventListener('keydown', (/** @type {any} */ e) => {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); b.click(); }
    });
  });
};

/**
 * 파워 수동 리셋 UI 상태를 새로고침합니다.
 */
const refreshPowerManualResetUI = async () => {
  const section = $('#power-manual-reset-section');
  if (!section || !cfg) return;

  // 파워 클릭이 켜져 있으면 섹션 표시
  section.style.display = cfg.powerClickEnabled ? '' : 'none';

  if (cfg.powerClickEnabled) {
    await loadPowerChannels();
  }
};

/**
 * 파워 클릭 채널 목록을 렌더링합니다.
 * @param {{ channelId: string, channelName: string, channelImageUrl: string, count: number }[]} channels 
 */
const renderPowerChannels = (channels) => {
  const listEl = $('#power-channel-list');
  if (!listEl) return;

  // 0개인 채널 필터링 및 현재 정렬 순서 적용
  const filtered = (channels ?? [])
    .filter(ch => Number(ch.count) > 0)
    .sort((a, b) => {
      const sortEl = /** @type {HTMLSelectElement|null} */ ($('#opt-power-sort'));
      const order = sortEl?.value || 'desc';
      return order === 'desc' ? b.count - a.count : a.count - b.count;
    });

  if (filtered.length === 0) {
    listEl.innerHTML = '<div style="color:var(--text3); font-size:11px; padding:8px 0; text-align:center;">수집된 데이터가 없습니다.</div>';
    return;
  }

  listEl.innerHTML = filtered.map(ch => {
    const img = ch.channelImageUrl
      ? `<img src="${ch.channelImageUrl}" class="power-ch-img" data-img-fallback="none">`
      : `<span class="power-ch-noimg"></span>`;
    return `<div class="power-ch-item">
      ${img}
      <span class="power-ch-name">${ch.channelName}</span>
      <span class="power-ch-count">${ch.count}개</span>
      <button type="button" class="btn btn--xs" data-channel-id="${ch.channelId}">초기화</button>
    </div>`;
  }).join('');

  // 이미지 로드 에러 처리 (CSP 준수)
  listEl.querySelectorAll('img[data-img-fallback]').forEach((/** @type {any} */ img) => {
    img.addEventListener('error', () => {
      img.removeAttribute('src');
      img.className = 'power-ch-noimg';
    }, { once: true });
  });

  // 개별 채널 리셋 (렌더링 시점에 매번 등록되므로 중복 문제 없음 - 부모가 innerHTML로 갈아치워짐)
  listEl.querySelectorAll('button[data-channel-id]').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', async () => {
      const chId = /** @type {HTMLElement} */(btn).dataset.channelId;
      if (!chId) return;
      btn.textContent = '초기화 중...';
      await msg('POWER_RESET_CHANNELS', { channelIds: [chId] });
      setTimeout(() => loadPowerChannels(), 500);
    });
  });
};

/**
 * 파워 클릭 채널 데이터를 불러옵니다.
 */
const loadPowerChannels = async () => {
  const listEl = $('#power-channel-list');
  if (!listEl) return;
  listEl.innerHTML = '<div style="color:var(--text3);font-size:11px;padding:4px 0">로딩 중...</div>';
  const channels = await msg('GET_POWER_CHANNELS');
  renderPowerChannels(/** @type {any} */(channels) ?? []);
};

/**
 * 파워 수동 리셋 관련 이벤트 리스너를 바인딩합니다. (단 한 번만 호출되어야 함)
 */
const bindPowerManualReset = () => {
  const sortEl = /** @type {HTMLSelectElement|null} */ ($('#opt-power-sort'));
  sortEl?.addEventListener('change', () => {
    loadPowerChannels();
  });

  // 전체 초기화
  $('#btn-power-reset-all')?.addEventListener('click', async () => {
    if (!confirm('모든 채널의 통나무 파워 카운트를 초기화할까요?')) return;
    await msg('POWER_RESET_CHANNELS', { channelIds: 'all' });
    setTimeout(() => loadPowerChannels(), 500);
  });

  // 채널 목록 새로고침
  $('#btn-power-refresh-channels')?.addEventListener('click', () => {
    loadPowerChannels();
  });
};


const bind = () => {
  for (const [id, key] of Object.entries(OPT_MAP_POPUP)) {
    const el = $(`#${id}`);
    if (el) {
      if (el.tagName === 'SELECT' || (el.tagName === 'INPUT' && (el.type === 'number' || el.type === 'text'))) {
        continue;
      }
      el.addEventListener('click', () => {
        if (id === 'opt-gc-monitor' && typeof window.gc !== 'function') return;
        const nextState = el.getAttribute('aria-checked') !== 'true';
        el.setAttribute('aria-checked', nextState ? 'true' : 'false');
        cfg[key] = nextState;

        // 특별 처리: 서브메뉴 토글
        if (id === 'opt-screenshot') {
          const ssContainer = $('#opt-screenshot-container');
          if (ssContainer) ssContainer.setAttribute('aria-expanded', nextState ? 'true' : 'false');
        } else if (id === 'opt-thumbnail-preview') {
          const tpContainer = $('#opt-thumbnail-preview-container');
          if (tpContainer) tpContainer.setAttribute('aria-expanded', nextState ? 'true' : 'false');
        } else if (id === 'opt-layout-clean') {
          const layoutCleanContainer = $('#opt-layout-clean-container');
          if (layoutCleanContainer) layoutCleanContainer.setAttribute('aria-expanded', nextState ? 'true' : 'false');

        } else if (id === 'opt-hide-chat-badge') {
          const hideChatBadgeContainer = $('#opt-hide-chat-badge-container');
          if (hideChatBadgeContainer) hideChatBadgeContainer.setAttribute('aria-expanded', nextState ? 'true' : 'false');
        } else if (id === 'opt-category-block') {
          const categoryBlockContainer = $('#opt-category-block-container');
          if (categoryBlockContainer) categoryBlockContainer.style.display = nextState ? 'block' : 'none';
        } else if (id === 'opt-live-auto-open') {
          const section = $('#auto-open-channels-section');
          if (section) section.style.display = nextState ? 'block' : 'none';
        } else if (id === 'opt-live-noti') {
          const section = $('#live-noti-block-section');
          if (section) section.style.display = nextState ? 'block' : 'none';
        } else if (id === 'opt-hover-preview-video') {
          const hpvContainer = $('#opt-hover-preview-video-container');
          if (hpvContainer) hpvContainer.setAttribute('aria-expanded', nextState ? 'true' : 'false');
        } else if (id === 'opt-blinded-restore') {
          const blindedContainer = $('#opt-blinded-restore-container');
          if (blindedContainer) blindedContainer.setAttribute('aria-expanded', nextState ? 'true' : 'false');
        } else if (id === 'opt-gc-monitor') {
          updateGCWarning(nextState);
        }

        save();
      });
      el.addEventListener('keydown', (/** @type {any} */ e) => {
        if (id === 'opt-gc-monitor' && typeof window.gc !== 'function') return;
        if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); el.click(); }
      });
    }
  }


  $('#opt-preferred')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.preferredQuality = e.target.value === 'ABR' ? 'ABR' : parseInt(e.target.value, 10);
    save();
  });

  $('#opt-recorder-format')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.recorderFormat = e.target.value;
    save();
  });

  $('#opt-file-timestamp-format')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.fileTimestampFormat = e.target.value;
    save();
  });

  $('#opt-file-timestamp-timezone')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.fileTimestampTimezone = e.target.value;
    save();
  });

  $('#opt-target-latency')?.addEventListener('input', (/** @type {any} */ e) => {
    cfg.targetLatency = parseFloat(e.target.value) || 0;
    save();
  });

  $('#opt-hover-preview-volume')?.addEventListener('input', (/** @type {any} */ e) => {
    let val = parseInt(e.target.value, 10);
    if (isNaN(val)) val = 0;
    cfg.hoverPreviewVolume = Math.max(0, Math.min(100, val));
    save();
  });

  $('#opt-chaser-mode')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.chaserMode = e.target.value;
    save();
  });

  $('#opt-power-reset-hours')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.powerCountResetHours = parseInt(e.target.value, 10);
    save();
  });

  $('#opt-live-interval')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.liveNotificationInterval = parseFloat(e.target.value) || 3;
    save();
  });

  $('#opt-chat-nickname-max-length')?.addEventListener('input', (/** @type {any} */ e) => {
    let val = parseInt(e.target.value, 10);
    if (isNaN(val) || val < 0) val = 0;
    cfg.chatNicknameMaxLength = val;
    save();
  });

  $('#opt-playback-seek-time')?.addEventListener('input', (/** @type {any} */ e) => {
    let val = parseInt(e.target.value, 10);
    if (isNaN(val) || val < 1) val = 5;
    if (val > 60) val = 60;
    cfg.playbackSeekTime = val;
    save();
  });

  $('#opt-hover-preview-delay')?.addEventListener('input', (/** @type {any} */ e) => {
    let val = parseInt(e.target.value, 10);
    if (isNaN(val) || val < 0) val = 500;
    if (val > 5000) val = 5000;
    cfg.hoverPreviewDelay = val;
    save();
  });

  $('#opt-hover-uptime-format')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.hoverPreviewUptimeFormat = e.target.value;
    save();
  });

  $('#opt-hover-preview-video-delay')?.addEventListener('input', (/** @type {any} */ e) => {
    let val = parseInt(e.target.value, 10);
    if (isNaN(val) || val < 0) val = 1200;
    if (val > 10000) val = 10000;
    cfg.hoverPreviewVideoDelay = val;
    save();
  });

  $('#opt-sidebar-folders-default-state')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.sidebarFoldersDefaultState = e.target.value;
    save();
  });

  $('#opt-sidebar-offline-group-default-state')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.sidebarOfflineGroupDefaultState = e.target.value;
    save();
  });

  $('#opt-hover-card-size')?.addEventListener('change', (/** @type {any} */ e) => {
    const val = e.target.value;
    const customInput = $('#opt-hover-card-size-custom');
    if (val === '__custom__') {
      if (customInput) customInput.style.display = 'block';
      cfg.hoverCardSize = parseInt(customInput?.value || '440', 10);
    } else {
      if (customInput) customInput.style.display = 'none';
      cfg.hoverCardSize = parseInt(val, 10);
    }
    save();
  });

  $('#opt-hover-card-size-custom')?.addEventListener('input', (/** @type {any} */ e) => {
    let val = parseInt(e.target.value, 10);
    if (isNaN(val) || val < 200) val = 200;
    if (val > 1000) val = 1000;
    cfg.hoverCardSize = val;
    save();
  });

  // 스크린샷 동작 세그먼트
  $$('#opt-screenshot-action-seg .seg-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      cfg.screenshotAction = btn.dataset.value;
      save();
      renderScreenshotAction();
    });
  });

  // 수동 리셋 섹션 초기화
  bindPowerManualReset();
  refreshPowerManualResetUI();


  // 글꼴 선택
  $('#opt-font-select')?.addEventListener('change', (/** @type {any} */ e) => {
    const val = e.target.value;
    const importInput = $('#opt-font-import');
    const customInput = $('#opt-font-custom');

    if (val === '__custom__') {
      if (importInput) { importInput.style.display = ''; }
      if (customInput) { customInput.style.display = ''; customInput.focus(); }
    } else {
      if (importInput) { importInput.style.display = 'none'; }
      if (customInput) { customInput.style.display = 'none'; }
      cfg.customFont = val;
      cfg.customFontImport = FONT_PRESETS[val] ?? '';
      save();
    }
  });

  $('#opt-font-import')?.addEventListener('input', (/** @type {any} */ e) => {
    cfg.customFontImport = e.target.value.trim();
    save();
  });

  $('#opt-font-custom')?.addEventListener('input', (/** @type {any} */ e) => {
    cfg.customFont = e.target.value.trim();
    save();
  });

  // 글꼴 두께 세그먼트
  $$('#opt-font-weight-seg .seg-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      const weight = parseInt(btn.dataset.weight, 10);
      cfg.customFontWeight = weight;
      save();
      renderFontWeight();
    });
  });

  $('#btn-reapply')?.addEventListener('click', async () => {
    await msg('FORCE_REAPPLY');
    setTimeout(async () => {
      ps = await msg('GET_PLAYER_STATE');
      renderStatus();
      renderGrid();
    }, 400);
  });

  $('#btn-refresh')?.addEventListener('click', async () => {
    ps = await msg('GET_PLAYER_STATE');
    renderStatus();
    renderGrid();
  });

  // 설정 백업 및 복원
  $('#btn-export-settings')?.addEventListener('click', exportSettings);
  $('#btn-import-settings')?.addEventListener('click', () => $('#input-import-settings')?.click());
  $('#input-import-settings')?.addEventListener('change', importSettings);

};

const exportSettings = async () => {
  try {
    const allData = await Browser.storage.sync.get(null);
    const localData = await Browser.storage.local.get(['sidebarFolders', 'sidebarFoldersConfig']);

    // storage.local에 저장된 폴더 데이터 병합
    if (localData.sidebarFolders) allData.cqc_sidebar_folders = localData.sidebarFolders;
    if (localData.sidebarFoldersConfig) allData.cqc_sidebar_folders_config = localData.sidebarFoldersConfig;

    const json = JSON.stringify(allData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    const ts = formatFileTimestamp(cfg?.fileTimestampFormat, cfg?.fileTimestampTimezone);
    a.href = url;
    a.download = `chzzk-allinone-settings-${ts}.json`;
    a.click();

    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (e) {
    console.error('[CQC] Export failed:', e);
    alert('설정 내보내기에 실패했습니다.');
  }
};

/** @param {Event} e */
const importSettings = async (e) => {
  const file = /** @type {HTMLInputElement} */(e.target).files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const json = /** @type {string} */(event.target?.result);
      const data = JSON.parse(json);

      if (!confirm('현재 설정을 덮어쓰고 불러온 설정을 적용할까요?\n불러온 후 팝업이 다시 로드됩니다.')) {
        /** @type {HTMLInputElement} */(e.target).value = '';
        return;
      }

      // 이전 버전(1.4.8.2) 마이그레이션: 루트에 settings 키가 없으면 감싸준다.
      let finalData = data;
      if (!data.settings) {
        finalData = { settings: data };
      }

      // 폴더 설정 분리 추출 및 storage.local 복원
      const importedFolders = finalData.cqc_sidebar_folders || data.cqc_sidebar_folders;
      const importedFolderConfig = finalData.cqc_sidebar_folders_config || data.cqc_sidebar_folders_config;

      delete finalData.cqc_sidebar_folders;
      delete finalData.cqc_sidebar_folders_config;
      if (finalData.settings) {
        delete finalData.settings.cqc_sidebar_folders;
        delete finalData.settings.cqc_sidebar_folders_config;
      }

      await Browser.storage.sync.clear();
      await Browser.storage.sync.set(finalData);

      const localUpdates: any = {};
      if (importedFolders) localUpdates.sidebarFolders = importedFolders;
      if (importedFolderConfig) localUpdates.sidebarFoldersConfig = importedFolderConfig;
      if (Object.keys(localUpdates).length > 0) {
        await Browser.storage.local.set(localUpdates);
      }

      // 백그라운드에 변경 알림 전송 (탭 브로드캐스트용)
      await msg('SAVE_SETTINGS', finalData.settings);

      alert('설정을 성공적으로 불러왔습니다. 확장 프로그램 팝업이 새로고침 됩니다.');
      window.location.reload();
    } catch (err) {
      console.error('[CQC] Import failed:', err);
      alert('올바른 설정 파일이 아닙니다.');
    }
  };
  reader.readAsText(file);
};

const save = () => {
  msg('SAVE_SETTINGS', cfg);

  // Power Click 상태 변화에 따른 UI 토글만 수행
  const section = $('#power-manual-reset-section');
  if (section) section.style.display = cfg.powerClickEnabled ? '' : 'none';

  updateAutoQualityState();
};

/**
 * 디바운스(Debounce) 유틸 함수
 * @param {Function} fn 
 * @param {number} delay 
 * @returns {(...args: any[]) => void}
 */
const debounce = (fn, delay) => {
  /** @type {any} */
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
};
// ═══════════════════════════════════════════
//  미디어 탭: 선명도 + 오디오 (chrome.storage.sync 직접)
// ═══════════════════════════════════════════

let sharpnessEnabled = false;
let sharpnessMode = 'default';
let hideSharpMenu = false;
let audioEnabled = false;
let audioPreset = 'flat';
let hideAudioMenu = false;

/**
 * 미디어 설정을 로드하고 바인딩합니다.
 */
const bindMedia = async () => {
  // 로드
  const res = await Browser.storage.sync.get({
    sharpnessEnabled: false,
    sharpnessMode: 'default',
    hideSharpMenu: false,
    audioEnabled: false,
    audioEqPreset: 'flat',
    hideAudioMenu: false,
  });
  // @ts-ignore
  sharpnessEnabled = res.sharpnessEnabled ?? false;
  // @ts-ignore
  sharpnessMode = res.sharpnessMode ?? 'default';
  // @ts-ignore
  hideSharpMenu = res.hideSharpMenu ?? false;
  // @ts-ignore
  audioEnabled = res.audioEnabled ?? false;
  // @ts-ignore
  audioPreset = res.audioEqPreset ?? 'flat';
  // @ts-ignore
  hideAudioMenu = res.hideAudioMenu ?? false;

  // 렌더
  const sharpToggle = $('#opt-sharpness');
  const sharpMode = $('#opt-sharpness-mode');
  const hideSharpToggle = $('#opt-hide-sharp-menu');
  const audioToggle = $('#opt-audio');
  const audioPresetSel = $('#opt-audio-preset');
  const hideAudioToggle = $('#opt-hide-audio-menu');

  if (sharpToggle) sharpToggle.setAttribute('aria-checked', sharpnessEnabled ? 'true' : 'false');
  if (sharpMode) sharpMode.value = sharpnessMode;
  if (hideSharpToggle) hideSharpToggle.setAttribute('aria-checked', hideSharpMenu ? 'true' : 'false');
  if (audioToggle) audioToggle.setAttribute('aria-checked', audioEnabled ? 'true' : 'false');
  if (audioPresetSel) audioPresetSel.value = audioPreset;
  if (hideAudioToggle) hideAudioToggle.setAttribute('aria-checked', hideAudioMenu ? 'true' : 'false');

  // 바인드: 선명도 토글
  if (sharpToggle) {
    sharpToggle.addEventListener('click', () => {
      sharpnessEnabled = sharpToggle.getAttribute('aria-checked') !== 'true';
      sharpToggle.setAttribute('aria-checked', sharpnessEnabled ? 'true' : 'false');
      Browser.storage.sync.set({ sharpnessEnabled });
    });
    sharpToggle.addEventListener('keydown', (/** @type {any} */ e) => {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); sharpToggle.click(); }
    });
  }

  // 바인드: 선명도 메뉴 숨기기
  if (hideSharpToggle) {
    hideSharpToggle.addEventListener('click', () => {
      hideSharpMenu = hideSharpToggle.getAttribute('aria-checked') !== 'true';
      hideSharpToggle.setAttribute('aria-checked', hideSharpMenu ? 'true' : 'false');
      Browser.storage.sync.set({ hideSharpMenu });
    });
    hideSharpToggle.addEventListener('keydown', (/** @type {any} */ e) => {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); hideSharpToggle.click(); }
    });
  }

  // 바인드: 선명도 모드
  sharpMode?.addEventListener('change', () => {
    sharpnessMode = sharpMode.value;
    Browser.storage.sync.set({ sharpnessMode });
  });

  // 바인드: 오디오 토글
  if (audioToggle) {
    audioToggle.addEventListener('click', () => {
      audioEnabled = audioToggle.getAttribute('aria-checked') !== 'true';
      audioToggle.setAttribute('aria-checked', audioEnabled ? 'true' : 'false');
      Browser.storage.sync.set({ audioEnabled });
    });
    audioToggle.addEventListener('keydown', (/** @type {any} */ e) => {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); audioToggle.click(); }
    });
  }

  // 바인드: 오디오 메뉴 숨기기
  if (hideAudioToggle) {
    hideAudioToggle.addEventListener('click', () => {
      hideAudioMenu = hideAudioToggle.getAttribute('aria-checked') !== 'true';
      hideAudioToggle.setAttribute('aria-checked', hideAudioMenu ? 'true' : 'false');
      Browser.storage.sync.set({ hideAudioMenu });
    });
    hideAudioToggle.addEventListener('keydown', (/** @type {any} */ e) => {
      if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); hideAudioToggle.click(); }
    });
  }

  // 바인드: 오디오 프리셋
  audioPresetSel?.addEventListener('change', () => {
    audioPreset = audioPresetSel.value;
    Browser.storage.sync.set({ audioEqPreset: audioPreset });
  });
};

// ═══════════════════════════════════════════
//  채팅 쉴드 (chrome.storage.sync 직접)
// ═══════════════════════════════════════════

let cfFontSize = 0;
let cfStampEnabled = false;
let cfStampFormat = 'hh:mm:ss';
let cfStampSize = 10;
let cfStampSizeLinked = false;

const cfLoad = () => {
  if (!cfg) return;
  cfFontSize = cfg.chatFontSize ?? 0;
  cfStampEnabled = cfg.chatStampEnabled ?? false;
  cfStampFormat = cfg.chatStampFormat ?? 'hh:mm:ss';
  cfStampSize = cfg.chatStampSize ?? 10;
  cfStampSizeLinked = cfg.chatStampSizeLinked ?? false;
};

const cfSave = () => {
  if (!cfg) return;
  cfg.chatFontSize = cfFontSize;
  cfg.chatStampEnabled = cfStampEnabled;
  cfg.chatStampFormat = cfStampFormat;
  cfg.chatStampSize = cfStampSize;
  cfg.chatStampSizeLinked = cfStampSizeLinked;
  msg('SAVE_SETTINGS', cfg);
};

const cfBind = async () => {
  cfLoad();

  const fontSizeInput = $('#cf-font-size');
  const stampToggle = $('#cf-stamp-toggle');
  const stampFormatSelect = /** @type {HTMLSelectElement} */($('#cf-stamp-format'));
  const stampSizeInput = /** @type {HTMLInputElement} */($('#cf-stamp-size'));
  const stampSizeLinkedCheck = /** @type {HTMLInputElement} */($('#cf-stamp-size-linked'));

  if (fontSizeInput) fontSizeInput.value = cfFontSize.toString();
  if (stampToggle) {
    stampToggle.setAttribute('aria-checked', cfStampEnabled ? 'true' : 'false');
    const stampContainer = $('#cf-stamp-toggle-container');
    if (stampContainer) stampContainer.setAttribute('aria-expanded', cfStampEnabled ? 'true' : 'false');
  }
  if (stampFormatSelect) stampFormatSelect.value = cfStampFormat;
  if (stampSizeInput) {
    stampSizeInput.value = cfStampSize.toString();
    stampSizeInput.disabled = cfStampSizeLinked;
  }
  if (stampSizeLinkedCheck) stampSizeLinkedCheck.checked = cfStampSizeLinked;

  fontSizeInput?.addEventListener('input', () => {
    cfFontSize = parseInt(fontSizeInput.value, 10) || 0;
    if (cfStampSizeLinked) {
      cfStampSize = Math.max(10, cfFontSize - 4);
      if (stampSizeInput) stampSizeInput.value = cfStampSize.toString();
    }
    cfSave();
  });

  if (stampToggle) {
    stampToggle.addEventListener('click', () => {
      cfStampEnabled = stampToggle.getAttribute('aria-checked') !== 'true';
      stampToggle.setAttribute('aria-checked', cfStampEnabled ? 'true' : 'false');
      cfSave();
      const stampContainer = $('#cf-stamp-toggle-container');
      if (stampContainer) stampContainer.setAttribute('aria-expanded', cfStampEnabled ? 'true' : 'false');
    });
    stampToggle.addEventListener('keydown', (/** @type {any} */ o) => {
      if (o.key === ' ' || o.key === 'Enter') {
        o.preventDefault();
        stampToggle.click();
      }
    });
  }

  stampFormatSelect?.addEventListener('change', () => {
    cfStampFormat = stampFormatSelect.value;
    cfSave();
  });

  stampSizeInput?.addEventListener('input', () => {
    cfStampSize = parseInt(stampSizeInput.value, 10) || 10;
    cfSave();
  });

  stampSizeLinkedCheck?.addEventListener('change', () => {
    cfStampSizeLinked = stampSizeLinkedCheck.checked;
    if (stampSizeInput) stampSizeInput.disabled = cfStampSizeLinked;
    cfSave();
  });
};


// ═══════════════════════════════════════════
//  레이아웃 키워드 필터
// ═══════════════════════════════════════════

/** @type {string[]} */
let layoutKeywords = [];

const layoutLoad = () => {
  if (!cfg) return;
  layoutKeywords = cfg.layoutCleanupKeywords ?? [];
};

const layoutSave = () => {
  if (!cfg) return;
  cfg.layoutCleanupKeywords = layoutKeywords;
  save();
};

const layoutRenderTags = () => {
  const container = $('#layout-cleanup-tags');
  if (container) {
    container.innerHTML = layoutKeywords.map((kw, i) =>
      `<span class="cf-tag">${kw}<span class="layout-tag__x" data-idx="${i}">&times;</span></span>`
    ).join('');
  }

  document.querySelectorAll('.layout-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      layoutKeywords.splice(idx, 1);
      layoutSave();
      layoutRenderTags();
    });
  });
};

const layoutAddKeyword = () => {
  const input = $('#layout-cleanup-keyword');
  const val = input?.value?.trim();
  if (!val) return;
  val.split(',').map((/** @type {any} */ s) => s.trim()).filter(Boolean).forEach((/** @type {any} */ kw) => {
    if (!layoutKeywords.includes(kw)) layoutKeywords.push(kw);
  });
  input.value = '';
  layoutSave();
  layoutRenderTags();
};

// ═══════════════════════════════════════════
//  채팅 키워드 필터 (React Interceptor 지원)
// ═══════════════════════════════════════════

/** @type {{text:string, isRegex:boolean}[]} */
let chatFilterKeywords = [];
/** @type {{user:string, channelId:string}[]} */
let chatFilterUsers = [];
/** @type {string[]} */
let chatFilterEmojis = [];

const cfFilterLoad = () => {
  if (!cfg) return;
  // 마이그레이션: string[] -> {text, isRegex}[]
  const rawKeywords = cfg.chatFilterKeywords ?? [];
  chatFilterKeywords = rawKeywords.map((/** @type {any} */ k) => typeof k === 'string' ? { text: k, isRegex: false } : k);

  // 마이그레이션: string[] -> {user, channelId}[]
  const rawUsers = cfg.chatFilterUsers ?? [];
  chatFilterUsers = rawUsers.map((/** @type {any} */ u) => typeof u === 'string' ? { user: u, channelId: 'all' } : u);

  // --- 역할/기기 필터 마이그레이션 및 고정 리스트 강제 적용 ---
  const fixedRoles = ['STREAMER', 'MANAGER', 'SUBSCRIBER', 'FAN'];
  const fixedOS = ['PC', 'AOS', 'IOS'];

  // 기존 'chatFilterRoles' 규격 통일
  if (cfg.chatFilterRoles) {
    cfg.chatFilterRoles = cfg.chatFilterRoles.map((/** @type {string} */ r) => {
      if (r === 'SUBSCRIPTION') return 'SUBSCRIBER';
      if (r === 'ACTIVITY') return 'FAN';
      return r.toUpperCase();
    }).filter((/** @type {string} */ r) => fixedRoles.includes(r));
    cfg.chatFilterRoles = [...new Set(cfg.chatFilterRoles)];
  }

  // 기존 'chatFilterOS' 규격 통일
  if (cfg.chatFilterOS) {
    cfg.chatFilterOS = cfg.chatFilterOS.map((/** @type {string} */ o) => {
      if (o === 'WEB') return 'PC';
      return o.toUpperCase();
    }).filter((/** @type {string} */ o) => fixedOS.includes(o));
    cfg.chatFilterOS = [...new Set(cfg.chatFilterOS)];
  }

  // 발견 리스트를 고정 리스트로 덮어쓰기 (기본값 강제)
  cfg.discoveredRoles = fixedRoles;
  cfg.discoveredOS = fixedOS;
  // --------------------------------------------------------

  // 동적 역할 차단 초기화
  cfFilterRenderDynamicRoles();

  // 동적 기기 차단 초기화
  cfFilterRenderDynamicOS();

  // 이모티콘 차단 초기화
  chatFilterEmojis = cfg.chatFilterEmojis || [];
  cfFilterRenderEmojis();

  // 필터링 방식 초기화
  const filterModeSelect = /** @type {HTMLSelectElement|null} */ ($('#opt-chat-filter-mode'));
  if (filterModeSelect) {
    filterModeSelect.value = cfg.chatFilterMode ?? 'black';
  }
};

const cfFilterSave = () => {
  if (!cfg) return;
  cfg.chatFilterKeywords = chatFilterKeywords;
  cfg.chatFilterUsers = chatFilterUsers;
  cfg.chatFilterEmojis = chatFilterEmojis;
  save();
};

function cfFilterRenderDynamicRoles() {
  const container = $('#cf-dynamic-roles');
  if (!container || !cfg) return;

  const discovered = cfg.discoveredRoles || [];
  const selected = cfg.chatFilterRoles || [];

  if (discovered.length === 0) {
    container.innerHTML = '<div class="filter-empty" style="grid-column: 1 / -1;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>채팅에서 역할이 감지되면 자동으로 표시됩니다</div>';
    return;
  }

  // 역할별 CSS modifier 매핑
  const chipClass = (/** @type {string} */ r) => r === 'STREAMER' ? 'filter-chip--streamer' : r === 'MANAGER' ? 'filter-chip--manager' : r === 'SUBSCRIBER' ? 'filter-chip--subscriber' : r === 'FAN' ? 'filter-chip--fan' : '';

  container.innerHTML = discovered.map((/** @type {string} */ role) => {
    const isChecked = selected.includes(role);
    const displayName = role === 'SUBSCRIBER' ? '구독자' :
      role === 'FAN' ? '팬 배지' :
        role === 'STREAMER' ? '스트리머' :
          role === 'MANAGER' ? '매니저' : role;

    return `
      <label class="filter-chip ${chipClass(role)}">
        <input type="checkbox" data-role="${role}" class="cf-role-chk" ${isChecked ? 'checked' : ''}>
        <span class="filter-chip__indicator"></span>
        <span class="filter-chip__label">${displayName}</span>
      </label>
    `;
  }).join('');

  container.querySelectorAll('.cf-role-chk').forEach((/** @type {any} */ el) => {
    const chk = /** @type {HTMLInputElement} */(el);
    chk.addEventListener('change', () => {
      const role = chk.getAttribute('data-role');
      if (!cfg.chatFilterRoles) cfg.chatFilterRoles = [];
      if (chk.checked) {
        if (role && !cfg.chatFilterRoles.includes(role)) cfg.chatFilterRoles.push(role);
      } else {
        cfg.chatFilterRoles = cfg.chatFilterRoles.filter((/** @type {string} */ r) => r !== role);
      }
      save();
    });
  });
}

const cfFilterRenderTags = () => {
  const container = $('#chat-filter-tags');
  const emptyEl = $('#cf-kw-empty');
  const countEl = $('#cf-kw-count');
  if (container) {
    container.innerHTML = chatFilterKeywords.map((kw, i) => {
      const cls = kw.isRegex ? 'tag tag--regex' : 'tag tag--kw';
      return `<span class="${cls}"><span class="tag__text">${kw.isRegex ? '<small>RGX</small> ' : ''}${kw.text}</span><span class="chat-tag__x" data-idx="${i}">&times;</span></span>`;
    }).join('');
  }
  // 카운트 배지 및 엠프티 스테이트 갱신
  if (countEl) countEl.textContent = String(chatFilterKeywords.length);
  if (emptyEl) emptyEl.style.display = chatFilterKeywords.length > 0 ? 'none' : '';

  document.querySelectorAll('#chat-filter-tags .chat-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      chatFilterKeywords.splice(idx, 1);
      cfFilterSave();
      cfFilterRenderTags();
    });
  });
};

const cfFilterUserRenderTags = () => {
  const container = $('#chat-filter-user-tags');
  const emptyEl = $('#cf-user-empty');
  const countEl = $('#cf-user-count');

  if (container) {
    container.innerHTML = chatFilterUsers.map((u, i) => {
      const scopeLabel = u.channelId === 'all' ? '전체' : '특정';
      return `<span class="tag tag--user"><span class="tag__text"><small>[${scopeLabel}]</small> ${u.user}</span><span class="user-tag__x" data-idx="${i}">&times;</span></span>`;
    }).join('');
  }

  // 카운트 배지 및 엠프티 스테이트 갱신
  if (countEl) countEl.textContent = String(chatFilterUsers.length);
  if (emptyEl) emptyEl.style.display = chatFilterUsers.length > 0 ? 'none' : '';

  document.querySelectorAll('#chat-filter-user-tags .user-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      chatFilterUsers.splice(idx, 1);
      cfFilterSave();
      cfFilterUserRenderTags();
    });
  });
};

const cfFilterAddKeyword = () => {
  const input = $('#chat-filter-keyword');
  const isRegex = /** @type {HTMLInputElement} */($('#chat-filter-is-regex'))?.checked;
  const val = input?.value?.trim();
  if (!val) return;
  val.split(',').map((/** @type {any} */ s) => s.trim()).filter(Boolean).forEach((/** @type {any} */ kw) => {
    if (!chatFilterKeywords.some(k => k.text === kw)) {
      chatFilterKeywords.push({ text: kw, isRegex: !!isRegex });
    }
  });
  input.value = '';
  if ($('#chat-filter-is-regex')) (/** @type {HTMLInputElement} */($('#chat-filter-is-regex'))).checked = false;
  cfFilterSave();
  cfFilterRenderTags();
};

const cfFilterAddUser = async () => {
  const input = $('#chat-filter-user');
  const chSelect = /** @type {HTMLSelectElement} */($('#chat-filter-user-channel'));
  const channelMode = chSelect?.value || 'current';
  const val = input?.value?.trim();
  if (!val) return;

  const tabs = await Browser.tabs.query({ active: true, currentWindow: true });
  let targetChannelId = 'all';
  if (channelMode === 'current') {
    const match = tabs[0]?.url?.match(/\/live\/([a-zA-Z0-9_]+)/);
    if (match) targetChannelId = match[1];
    else {
      targetChannelId = 'all'; // Fallback
    }
  }

  val.split(',').map((/** @type {any} */ s) => s.trim()).filter(Boolean).forEach((/** @type {any} */ u) => {
    const currentUsers = /** @type {any[]} */(chatFilterUsers);
    const exists = currentUsers.some(x => x.user === u && x.channelId === targetChannelId);
    if (!exists) {
      currentUsers.push({
        user: u,
        channelId: targetChannelId,
        channelName: (targetChannelId !== 'all') ? (ps?.channelName || '') : ''
      });
    }
  });
  input.value = '';
  cfFilterSave();
  cfFilterRenderDynamicRoles();
  cfFilterRenderDynamicOS();
  cfFilterUserRenderTags();
};

function cfFilterRenderDynamicOS() {
  const container = $('#cf-dynamic-os');
  if (!container || !cfg) return;

  const discovered = cfg.discoveredOS || [];
  const selected = cfg.chatFilterOS || [];

  if (discovered.length === 0) {
    container.innerHTML = '<div class="filter-empty" style="grid-column: 1 / -1;"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>기기 정보가 감지되면 자동으로 표시됩니다</div>';
    return;
  }

  container.innerHTML = discovered.map((/** @type {string} */ os) => {
    const isChecked = selected.includes(os);
    const displayName = os === 'PC' ? '컴퓨터(PC)' :
      os === 'AOS' ? '안드로이드' :
        os === 'IOS' ? '아이폰' : os;

    return `
      <label class="filter-chip">
        <input type="checkbox" data-os="${os}" class="cf-os-chk" ${isChecked ? 'checked' : ''}>
        <span class="filter-chip__indicator"></span>
        <span class="filter-chip__label">${displayName}</span>
      </label>
    `;
  }).join('');

  container.querySelectorAll('.cf-os-chk').forEach((/** @type {any} */ el) => {
    const chk = /** @type {HTMLInputElement} */(el);
    chk.addEventListener('change', () => {
      const os = chk.getAttribute('data-os');
      if (!cfg.chatFilterOS) cfg.chatFilterOS = [];
      if (chk.checked) {
        if (os && !cfg.chatFilterOS.includes(os)) cfg.chatFilterOS.push(os);
      } else {
        cfg.chatFilterOS = cfg.chatFilterOS.filter((/** @type {string} */ s) => s !== os);
      }
      save();
    });
  });
}

async function fetchEmojiPacks(channelId) {
  if (!channelId) return null;
  try {
    const res = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${channelId}/emoji-packs`);
    if (res.ok) {
      const json = await res.json();
      const normalPacks = json.content?.emojiPacks || [];
      const subPacks = json.content?.subscriptionEmojiPacks || [];
      const isEmojiPackLocked = json.content?.emojiPackLocked ?? true;
      return {
        packs: [...subPacks, ...normalPacks],
        isEmojiPackLocked,
        subEmojiIds: subPacks.flatMap((p: any) => p.emojis?.map((e: any) => e.emojiId) || [])
      };
    }
  } catch (e) {
    console.error('Failed to fetch emoji packs', e);
  }
  return null;
}

async function buildMacroEmojis(channelId: string) {
  if (!channelId) return [];
  let raw = [];
  try {
    const res = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${channelId}/emoji-packs`);
    if (!res.ok) return [];
    const c = (await res.json()).content || {};
    raw = [...(c.subscriptionEmojiPacks || []), ...(c.emojiPacks || [])];
  } catch (e) {
    console.error('Failed to fetch emoji packs', e);
    return [];
  }
  const packs = [];
  raw.forEach((p) => {
    if (!p || p.emojiPackLocked) return;
    const isSub = p.emojiType === 'SUBSCRIPTION_CHANNEL';
    const toItems = (arr) => (arr || [])
      .map((e) => ({ id: e.emojiId, url: e.imageUrl || e.emojiUrl }))
      .filter((e) => e.id && e.url);
    const groups = [];
    if (Array.isArray(p.tier1Emojis) || Array.isArray(p.tier2Emojis)) {
      if (!p.emojiTier2Locked) {
        // 방송 이모티콘 탭 처럼 2티어를 우선적으로 배치.
        const t2 = toItems(p.tier2Emojis);
        if (t2.length) groups.push({ label: '2티어', items: t2 });
      }
      // 그 이후 1티어 구독 티콘 배치.
      const t1 = toItems(p.tier1Emojis);
      if (t1.length) groups.push({ label: '1티어', items: t1 });
    } else {
      const all = toItems(p.emojis);
      if (all.length) groups.push({ label: null, items: all });
    }
    const count = groups.reduce((acc, g) => acc + g.items.length, 0);
    if (!count) return;
    packs.push({ name: p.emojiPackName || '이모티콘', isSub, tier2: isSub && !p.emojiTier2Locked, groups, count });
  });
  // 정렬 안 함: API 순서 그대로 유지 (구독 팩 먼저 → 공용 팩 뒤, concat 순서 = 스트리머 순서)
  // 티어 우선 정렬이 필요하면: packs.sort((a,b) => ((!a.isSub?2:(a.tier2?0:1)) - (!b.isSub?2:(b.tier2?0:1))))
  return packs;
}

async function cfFilterRenderEmojis() {
  const container = $('#cf-emoji-packs');
  if (!container) return;

  // channelId 결정 (ps 혹은 현재 탭 URL)
  let chId = ps?.channelId;
  if (!chId) {
    try {
      const tabs = await Browser.tabs.query({ active: true, currentWindow: true });
      const match = tabs[0]?.url?.match(/\/live\/([a-z0-9_]+)/i);
      chId = match?.[1];
    } catch (e) { }
  }

  if (!chId) {
    container.innerHTML = '<div class="filter-empty">현재 시청 중인 채널 정보를 찾을 수 없습니다.</div>';
    return;
  }

  const result = await fetchEmojiPacks(chId);
  const packs = result?.packs || [];
  if (!packs || packs.length === 0) {
    container.innerHTML = '<div class="filter-empty">이모티콘 정보를 불러올 수 없거나 팩이 없습니다.</div>';
    return;
  }

  container.innerHTML = packs.map((/** @type {any} */ pack, pIdx) => {
    const isLarge = pack.emojis.length > 36;
    return `
      <div class="emoji-pack">
        <div class="emoji-pack__title">${pack.emojiPackName} (${pack.emojis.length})</div>
        <div class="emoji-grid ${isLarge ? 'collapsed' : ''}" id="emoji-grid-${pIdx}">
          ${pack.emojis.map((/** @type {any} */ emoji) => {
      const isActive = chatFilterEmojis.includes(emoji.emojiId);
      return `
              <div class="emoji-item ${isActive ? 'active' : ''}" data-id="${emoji.emojiId}" title="${emoji.emojiId}">
                <img src="${emoji.imageUrl || emoji.emojiUrl}" alt="${emoji.emojiId}" loading="lazy">
              </div>
            `;
    }).join('')}
        </div>
        ${isLarge ? `
          <div class="emoji-more-btn" data-target="emoji-grid-${pIdx}">
            <span>더보기</span>
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  // 이모티콘 클릭 이벤트
  container.querySelectorAll('.emoji-item').forEach((/** @type {any} */ el) => {
    el.addEventListener('click', () => {
      const eid = el.getAttribute('data-id');
      if (!eid) return;

      const idx = chatFilterEmojis.indexOf(eid);
      if (idx > -1) {
        chatFilterEmojis.splice(idx, 1);
        el.classList.remove('active');
      } else {
        chatFilterEmojis.push(eid);
        el.classList.add('active');
      }
      cfFilterSave();
    });
  });

  // 더보기 버튼 클릭 이벤트
  container.querySelectorAll('.emoji-more-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const grid = document.getElementById(targetId);
      if (grid) {
        const isCollapsed = grid.classList.toggle('collapsed');
        btn.classList.toggle('expanded', !isCollapsed);
        btn.querySelector('span').textContent = isCollapsed ? '더보기' : '접기';
      }
    });
  });
}

const cfFilterBind = () => {
  cfFilterLoad();
  cfFilterRenderTags();

  $('#chat-filter-add')?.addEventListener('click', cfFilterAddKeyword);
  $('#chat-filter-keyword')?.addEventListener('keydown', (/** @type {any} */ e) => {
    if (e.key === 'Enter') cfFilterAddKeyword();
  });

  $('#chat-filter-user-add')?.addEventListener('click', cfFilterAddUser);
  $('#chat-filter-user')?.addEventListener('keydown', (/** @type {any} */ e) => {
    if (e.key === 'Enter') cfFilterAddUser();
  });

  // 필터링 방식 변경 이벤트
  $('#opt-chat-filter-mode')?.addEventListener('change', (/** @type {any} */ e) => {
    cfg.chatFilterMode = e.target.value;
    save();
  });
};

// ═══════════════════════════════════════════
//  이모티콘 매크로 (단축어) 로직
// ═══════════════════════════════════════════
/** @type {{keyword: string, emojiId: string, emojiUrl: string}[]} */
let chatEmojiMacros = [];
let selectedMacroEmoji = null;

const cfMacroLoad = () => {
  if (!cfg) return;
  chatEmojiMacros = cfg.chatEmojiMacros || [];
};

const cfMacroSave = () => {
  if (!cfg) return;
  cfg.chatEmojiMacros = chatEmojiMacros;
  save();
};

const cfMacroRenderList = () => {
  const container = $('#chat-macro-list');
  if (!container) return;

  if (chatEmojiMacros.length === 0) {
    container.innerHTML = '<div style="font-size:12px; color:var(--text-dim); padding: 12px 0; text-align: center; background: rgba(255,255,255,0.02); border-radius: 8px; border: 1px dashed rgba(255,255,255,0.1);">등록된 매크로가 없습니다.</div>';
    return;
  }

  container.innerHTML = chatEmojiMacros.map((macro, i) => `
    <span class="tag tag--macro" style="display:inline-flex; align-items:center; gap:6px; background: rgba(255, 255, 255, 0.08); border: 1px solid rgba(255, 255, 255, 0.1); padding: 4px 10px; border-radius: 16px; font-size: 12.5px; color: #fff; transition: all 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
      <img src="${macro.emojiUrl}" alt="${macro.emojiId}" style="width:18px; height:18px; object-fit:contain; filter: drop-shadow(0 1px 2px rgba(0,0,0,0.2));">
      <span style="font-weight:600; letter-spacing:0.2px;">${macro.keyword}</span>
      <span class="chat-macro__x" data-idx="${i}" style="cursor:pointer; margin-left:2px; color: #ff6b6b; font-size:14px; opacity:0.7; transition:opacity 0.2s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">&times;</span>
    </span>
  `).join('');

  document.querySelectorAll('#chat-macro-list .chat-macro__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      chatEmojiMacros.splice(idx, 1);
      cfMacroSave();
      cfMacroRenderList();
    });
  });
};

async function cfMacroRenderEmojis() {
  const container = $('#chat-macro-emoji-packs');
  if (!container) return;

  let chId = ps?.channelId;
  if (!chId) {
    try {
      const tabs = await Browser.tabs.query({ active: true, currentWindow: true });
      const match = tabs[0]?.url?.match(/\/live\/([a-z0-9_]+)/i);
      chId = match?.[1];
    } catch (e) { }
  }

  if (!chId) {
    container.innerHTML = '<div class="filter-empty">현재 시청 중인 채널 정보를 찾을 수 없습니다.</div>';
    return;
  }

  // buildMacroEmojis는 가공된 팩 "배열"을 반환 (구버전 {packs,...} 객체 아님)
  const packs = await buildMacroEmojis(chId);
  if (packs.length === 0) {
    container.innerHTML = '<div class="filter-empty">사용할 수 있는 이모티콘 팩이 없습니다.</div>';
    return;
  }

  container.innerHTML = packs.map((/** @type {any} */ pack, pIdx) => {
    const groupsHtml = pack.groups.map((/** @type {any} */ g, gIdx) => {
      const label = g.label ? `<div class="emoji-tier-label">${g.label}</div>` : '';
      const gridId = `macro-emoji-grid-${pIdx}-${gIdx}`;
      const isLarge = g.items.length > 36;
      const items = g.items.map((/** @type {any} */ em) =>
        `<div class="emoji-item macro-emoji-item" data-id="${em.id}" data-url="${em.url}" title="${em.id}">
           <img src="${em.url}" alt="${em.id}" loading="lazy"></div>`).join('');
      return `
        ${label}
        <div class="emoji-grid ${isLarge ? 'collapsed' : ''}" id="${gridId}">${items}</div>
        ${isLarge ? `
          <div class="emoji-more-btn macro-emoji-more-btn" data-target="${gridId}">
            <span>더보기</span>
            <svg viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
          </div>` : ''}`;
    }).join('');
    return `
      <div class="emoji-pack">
        <div class="emoji-pack__title">${pack.name} (${pack.count})</div>
        ${groupsHtml}
      </div>`;
  }).join('');

  // 이모티콘 단일 선택 이벤트
  container.querySelectorAll('.macro-emoji-item').forEach((/** @type {any} */ el) => {
    el.addEventListener('click', () => {
      container.querySelectorAll('.macro-emoji-item').forEach(item => item.classList.remove('active'));
      el.classList.add('active');
      selectedMacroEmoji = {
        id: el.getAttribute('data-id'),
        url: el.getAttribute('data-url')
      };
    });
  });

  // 더보기 버튼 클릭 이벤트
  container.querySelectorAll('.macro-emoji-more-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-target');
      const grid = document.getElementById(targetId);
      if (grid) {
        const isCollapsed = grid.classList.toggle('collapsed');
        btn.classList.toggle('expanded', !isCollapsed);
        btn.querySelector('span').textContent = isCollapsed ? '더보기' : '접기';
      }
    });
  });
}

const cfMacroAdd = () => {
  if (!selectedMacroEmoji) {
    alert('매크로로 사용할 이모티콘을 위에서 먼저 선택해주세요.');
    return;
  }
  const input = $('#chat-macro-keyword');
  const keyword = input?.value?.trim();
  if (!keyword) {
    alert('키워드를 입력해주세요.');
    return;
  }

  // 중복 키워드 확인
  const existingIdx = chatEmojiMacros.findIndex(m => m.keyword === keyword);
  if (existingIdx > -1) {
    chatEmojiMacros[existingIdx] = { keyword, emojiId: selectedMacroEmoji.id, emojiUrl: selectedMacroEmoji.url };
  } else {
    chatEmojiMacros.push({ keyword, emojiId: selectedMacroEmoji.id, emojiUrl: selectedMacroEmoji.url });
  }

  input.value = '';
  // 선택 해제
  const container = $('#chat-macro-emoji-packs');
  if (container) {
    container.querySelectorAll('.macro-emoji-item').forEach(item => item.classList.remove('active'));
  }
  selectedMacroEmoji = null;

  cfMacroSave();
  cfMacroRenderList();
};

const cfMacroBind = () => {
  cfMacroLoad();
  cfMacroRenderList();
  cfMacroRenderEmojis();

  $('#chat-macro-add')?.addEventListener('click', cfMacroAdd);
  $('#chat-macro-keyword')?.addEventListener('keydown', (/** @type {any} */ e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      cfMacroAdd();
    }
  });
};

const layoutBind = async () => {
  layoutLoad();

  $$('#layout-hide-menus input[type="checkbox"]').forEach((/** @type {HTMLInputElement} */ cb) => {
    cb.addEventListener('change', () => {
      const checkedBoxes = Array.from($$('#layout-hide-menus input[type="checkbox"]:checked'));
      cfg.hiddenSidebarMenus = checkedBoxes.map((/** @type {any} */ b) => b.value);
      save();
    });
  });

  // 헤더 탭 이벤트는 renderHeaderTabs 내부에서 바인딩됨

  $$('#layout-hide-sections input[type="checkbox"]').forEach((/** @type {HTMLInputElement} */ cb) => {
    cb.addEventListener('change', () => {
      const checkedBoxes = Array.from($$('#layout-hide-sections input[type="checkbox"]:checked'));
      cfg.layoutCleanupKeywords = checkedBoxes.map((/** @type {any} */ b) => b.value);
      save();
    });
  });

  $('#layout-cleanup-add')?.addEventListener('click', layoutAddKeyword);
  $('#layout-cleanup-keyword')?.addEventListener('keydown', (/** @type {any} */ e) => {
    if (e.key === 'Enter') layoutAddKeyword();
  });
  layoutRenderTags();
};

// ═══════════════════════════════════════════
//  카테고리 및 스트리머 차단
// ═══════════════════════════════════════════
/** @type {string[]} */
let blockedCategoryTags = [];
/** @type {string[]} */
let blockedStreamers = [];

const categoryBlockLoad = () => {
  if (!cfg) return;
  blockedCategoryTags = cfg.blockedCategoryTags ?? [];
  blockedStreamers = cfg.blockedStreamers ?? [];
};

const categoryBlockSave = () => {
  if (!cfg) return;
  cfg.blockedCategoryTags = blockedCategoryTags;
  cfg.blockedStreamers = blockedStreamers;
  save();
};

const categoryBlockRenderTags = () => {
  const container = $('#category-block-tags');
  if (container) {
    container.innerHTML = blockedCategoryTags.map((kw, i) =>
      `<span class="cf-tag">${kw}<span class="category-block-tag__x" data-idx="${i}">&times;</span></span>`
    ).join('');
  }

  const countEl = $('#cf-category-count');
  if (countEl) {
    countEl.textContent = blockedCategoryTags.length.toString();
  }

  const emptyEl = $('#cf-category-empty');
  if (emptyEl) {
    emptyEl.style.display = blockedCategoryTags.length === 0 ? 'flex' : 'none';
  }

  document.querySelectorAll('.category-block-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      blockedCategoryTags.splice(idx, 1);
      categoryBlockSave();
      categoryBlockRenderTags();
    });
  });
};

const streamerBlockRenderTags = () => {
  const container = $('#streamer-block-tags');
  if (container) {
    container.innerHTML = blockedStreamers.map((kw, i) =>
      `<span class="cf-tag">${kw}<span class="streamer-block-tag__x" data-idx="${i}">&times;</span></span>`
    ).join('');
  }

  const countEl = $('#cf-streamer-count');
  if (countEl) {
    countEl.textContent = blockedStreamers.length.toString();
  }

  const emptyEl = $('#cf-streamer-empty');
  if (emptyEl) {
    emptyEl.style.display = blockedStreamers.length === 0 ? 'flex' : 'none';
  }

  document.querySelectorAll('.streamer-block-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      blockedStreamers.splice(idx, 1);
      categoryBlockSave();
      streamerBlockRenderTags();
    });
  });
};

const categoryBlockAddKeyword = () => {
  const input = $('#category-block-tag') as HTMLInputElement | null;
  const val = input?.value?.trim();
  if (!val) return;
  val.split(',').map((s) => s.trim()).filter(Boolean).forEach((kw) => {
    const cleanKw = kw.replace(/\s+/g, '').toLowerCase();
    const existingIdx = blockedCategoryTags.findIndex(t => t.replace(/\s+/g, '').toLowerCase() === cleanKw);
    if (existingIdx > -1) {
      blockedCategoryTags.splice(existingIdx, 1);
    }
    blockedCategoryTags.push(kw);
  });
  if (input) input.value = '';
  categoryBlockSave();
  categoryBlockRenderTags();
};

const streamerBlockAddKeyword = async () => {
  const input = $('#streamer-block-name') as HTMLInputElement | null;
  const val = input?.value?.trim();
  if (!val) return;

  const keywords = val.split(',').map((s) => s.trim()).filter(Boolean);
  const addBtn = $('#streamer-block-add');
  if (addBtn) addBtn.style.pointerEvents = 'none';
  if (input) input.disabled = true;

  for (const kw of keywords) {
    let finalKw = kw;
    if (/^[a-f0-9]{32}$/i.test(kw)) {
      try {
        const resp = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${kw}`);
        if (resp.ok) {
          const json = await resp.json();
          if (json.content?.channelName) {
            finalKw = json.content.channelName;
          }
        }
      } catch (err) {
        console.error('[CQC:Popup] Failed to fetch channel info', err);
      }
    }

    const cleanKw = finalKw.replace(/\s+/g, '').toLowerCase();
    const existingIdx = blockedStreamers.findIndex(t => t.replace(/\s+/g, '').toLowerCase() === cleanKw);
    if (existingIdx > -1) {
      blockedStreamers.splice(existingIdx, 1);
    }
    blockedStreamers.push(finalKw);
  }

  if (addBtn) addBtn.style.pointerEvents = '';
  if (input) input.disabled = false;
  if (input) input.value = '';

  categoryBlockSave();
  streamerBlockRenderTags();
};

const categoryBlockBind = () => {
  categoryBlockLoad();

  $('#category-block-add')?.addEventListener('click', categoryBlockAddKeyword);
  $('#category-block-tag')?.addEventListener('keydown', (e: any) => {
    if (e.key === 'Enter') categoryBlockAddKeyword();
  });

  $('#streamer-block-add')?.addEventListener('click', streamerBlockAddKeyword);
  $('#streamer-block-name')?.addEventListener('keydown', (e: any) => {
    if (e.key === 'Enter') streamerBlockAddKeyword();
  });

  // 추천 옵션 추가
  $('#category-block-recommend-vtuber')?.addEventListener('click', () => {
    const vtuberTags = [
      '버츄얼', '픽셀네트워크', '버미육', '버튜얼', '스텔라이브', '버튜버',
      '플라네타', '프로젝트 아이', '허니즈', '브이레코드', '브이리지',
      '라이브루리', '보쿠하이', '몽상컴퍼니', '일루전 라이브', '브이럽',
      '에스더', '포코톤', '블루점프', '브이온', '카론유니버스', '리액트', '미츄'
    ];
    let added = false;
    vtuberTags.forEach((kw) => {
      const cleanKw = kw.replace(/\s+/g, '').toLowerCase();
      const existingIdx = blockedCategoryTags.findIndex(t => t.replace(/\s+/g, '').toLowerCase() === cleanKw);
      if (existingIdx > -1) {
        blockedCategoryTags.splice(existingIdx, 1);
      }
      blockedCategoryTags.push(kw);
      added = true;
    });
    if (added) {
      categoryBlockSave();
      categoryBlockRenderTags();
    }
  });

  categoryBlockRenderTags();
  streamerBlockRenderTags();
};

// ═══════════════════════════════════════════
//  방송 시작 시 자동 탭 열기
// ═══════════════════════════════════════════
interface AutoOpenChannel {
  channelId: string;
  channelName: string;
}

let liveAutoOpenChannels: AutoOpenChannel[] = [];

const liveAutoOpenLoad = () => {
  if (!cfg) return;
  liveAutoOpenChannels = cfg.liveAutoOpenChannels ?? [];
};

const liveAutoOpenSave = () => {
  if (!cfg) return;
  cfg.liveAutoOpenChannels = liveAutoOpenChannels;
  save();
};

const liveAutoOpenRenderChannels = () => {
  const container = $('#auto-open-channel-list');
  if (container) {
    container.innerHTML = liveAutoOpenChannels.map((ch, i) =>
      `<span class="cf-tag">${ch.channelName}<span class="live-auto-open-tag__x" data-idx="${i}">&times;</span></span>`
    ).join('');
  }

  document.querySelectorAll('.live-auto-open-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      const idx = parseInt((x as HTMLElement).dataset.idx || '0', 10);
      liveAutoOpenChannels.splice(idx, 1);
      liveAutoOpenSave();
      liveAutoOpenRenderChannels();
    });
  });
};

const liveAutoOpenAddChannel = async () => {
  const input = $('#auto-open-url') as HTMLInputElement | null;
  const val = input?.value?.trim();
  if (!val) return;

  const addBtn = $('#auto-open-add') as HTMLButtonElement | null;
  if (addBtn) {
    addBtn.disabled = true;
    addBtn.textContent = '확인중';
  }

  try {
    const resp = await Browser.runtime.sendMessage({
      type: 'RESOLVE_CHANNEL_ID',
      payload: val
    });

    if (resp?.success && resp?.channelId) {
      const { channelId, channelName } = resp;
      if (!liveAutoOpenChannels.some(ch => ch.channelId === channelId)) {
        liveAutoOpenChannels.push({ channelId, channelName });
        liveAutoOpenSave();
        liveAutoOpenRenderChannels();
        if (input) input.value = '';
      } else {
        alert('이미 등록된 채널입니다.');
      }
    } else {
      alert('유효하지 않은 채널 URL 또는 ID이거나, 채널을 찾을 수 없습니다.');
    }
  } catch (e) {
    console.error('[CQC:Popup] RESOLVE_CHANNEL_ID error:', e);
    alert('채널 정보를 확인하는 중 에러가 발생했습니다.');
  } finally {
    if (addBtn) {
      addBtn.disabled = false;
      addBtn.textContent = '추가';
    }
  }
};

const liveAutoOpenBind = () => {
  liveAutoOpenLoad();
  installAutoOpenPicker({
    getRecording: () => cfg?.liveAutoRecordChannels ?? [],
    setRecording: async (id, checked) => {
      const previous = cfg.liveAutoRecordChannels ?? [];
      cfg.liveAutoRecordChannels = [...previous.filter(x => x !== id), ...(checked ? [id] : [])];
      try { const result = await msg('SAVE_SETTINGS', cfg); if (!result?.success) throw new Error('Save failed'); }
      catch (error) { cfg.liveAutoRecordChannels = previous; throw error; }
    },
    getSelected: () => cfg?.liveAutoOpenChannels ?? [],
    setSelected: async (channels) => {
      const previous = cfg.liveAutoOpenChannels;
      cfg.liveAutoOpenChannels = channels;
      try {
        const result = await msg('SAVE_SETTINGS', cfg);
        if (!result?.success) throw new Error('Save failed');
        liveAutoOpenChannels = channels;
        liveAutoOpenRenderChannels();
      } catch (error) { cfg.liveAutoOpenChannels = previous; throw error; }
    }
  });

  $('#auto-open-add')?.addEventListener('click', liveAutoOpenAddChannel);
  $('#auto-open-url')?.addEventListener('keydown', (e: any) => {
    if (e.key === 'Enter') liveAutoOpenAddChannel();
  });
  liveAutoOpenRenderChannels();
};

// ═══════════════════════════════════════════
//  생방송 알림 제외 채널 설정
// ═══════════════════════════════════════════
interface NotiBlockChannel {
  channelId: string;
  channelName: string;
}

let liveNotificationDisabledChannels: NotiBlockChannel[] = [];

const liveNotificationBlockLoad = () => {
  if (!cfg) return;
  liveNotificationDisabledChannels = cfg.liveNotificationDisabledChannels ?? [];
};

const liveNotificationBlockSave = () => {
  if (!cfg) return;
  cfg.liveNotificationDisabledChannels = liveNotificationDisabledChannels;
  save();
};

const liveNotificationBlockRenderChannels = () => {
  const container = $('#live-noti-block-channel-list');
  if (container) {
    container.innerHTML = liveNotificationDisabledChannels.map((ch, i) =>
      `<span class="cf-tag">${ch.channelName}<span class="live-noti-block-tag__x" data-idx="${i}">&times;</span></span>`
    ).join('');
  }

  document.querySelectorAll('.live-noti-block-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      const idx = parseInt((x as HTMLElement).dataset.idx || '0', 10);
      liveNotificationDisabledChannels.splice(idx, 1);
      liveNotificationBlockSave();
      liveNotificationBlockRenderChannels();
    });
  });
};

const liveNotificationBlockAddChannel = async () => {
  const input = $('#live-noti-block-url') as HTMLInputElement | null;
  const val = input?.value?.trim();
  if (!val) return;

  const addBtn = $('#live-noti-block-add') as HTMLButtonElement | null;
  if (addBtn) {
    addBtn.disabled = true;
    addBtn.textContent = '확인중';
  }

  try {
    const resp = await Browser.runtime.sendMessage({
      type: 'RESOLVE_CHANNEL_ID',
      payload: val
    });

    if (resp?.success && resp?.channelId) {
      const { channelId, channelName } = resp;
      if (!liveNotificationDisabledChannels.some(ch => ch.channelId === channelId)) {
        liveNotificationDisabledChannels.push({ channelId, channelName });
        liveNotificationBlockSave();
        liveNotificationBlockRenderChannels();
        if (input) input.value = '';
      } else {
        alert('이미 등록된 채널입니다.');
      }
    } else {
      alert('유효하지 않은 채널 URL 또는 ID이거나, 채널을 찾을 수 없습니다.');
    }
  } catch (e) {
    console.error('[CQC:Popup] RESOLVE_CHANNEL_ID error:', e);
    alert('채널 정보를 확인하는 중 에러가 발생했습니다.');
  } finally {
    if (addBtn) {
      addBtn.disabled = false;
      addBtn.textContent = '추가';
    }
  }
};

const liveNotificationBlockBind = () => {
  liveNotificationBlockLoad();

  $('#live-noti-block-add')?.addEventListener('click', liveNotificationBlockAddChannel);
  $('#live-noti-block-url')?.addEventListener('keydown', (e: any) => {
    if (e.key === 'Enter') liveNotificationBlockAddChannel();
  });
  liveNotificationBlockRenderChannels();
};

// ═══════════════════════════════════════════
//  채팅 모아보기 (React Interceptor 지원)
// ═══════════════════════════════════════════

const renderChatCollector = () => {
  if (!cfg) return;

  // 1. 보관 기일
  const retentionSelect = /** @type {HTMLSelectElement|null} */ ($('#opt-chat-collector-retention'));
  if (retentionSelect) {
    retentionSelect.value = String(cfg.chatCollectorRetentionHours ?? 72);
  }

  // 2. 역할 체크박스 상태
  const streamerChk = /** @type {HTMLInputElement|null} */ ($('#opt-chat-collector-role-streamer'));
  const managerChk = /** @type {HTMLInputElement|null} */ ($('#opt-chat-collector-role-manager'));
  const donationChk = /** @type {HTMLInputElement|null} */ ($('#opt-chat-collector-role-donation'));
  const roles = cfg.chatCollectorRoles || ['streamer', 'manager'];

  if (streamerChk) streamerChk.checked = roles.includes('streamer');
  if (managerChk) managerChk.checked = roles.includes('manager');
  if (donationChk) donationChk.checked = roles.includes('donation');

  // 3. 지정 유저 태그 렌더링
  const users = cfg.chatCollectorTargetUsers || [];
  const container = $('#opt-chat-collector-user-tags');
  const emptyEl = $('#opt-chat-collector-user-empty');
  const countEl = $('#opt-chat-collector-user-count');

  if (container) {
    container.innerHTML = users.map((/** @type {string} */ user, /** @type {number} */ i) =>
      `<span class="tag tag--user"><span class="tag__text">${user}</span><span class="collector-tag__x" data-idx="${i}">&times;</span></span>`
    ).join('');
  }

  if (countEl) countEl.textContent = String(users.length);
  if (emptyEl) emptyEl.style.display = users.length > 0 ? 'none' : '';

  // 제거 이벤트 바인딩
  document.querySelectorAll('#opt-chat-collector-user-tags .collector-tag__x').forEach(x => {
    x.addEventListener('click', () => {
      // @ts-ignore
      const idx = parseInt(x.dataset.idx, 10);
      const currentUsers = cfg.chatCollectorTargetUsers || [];
      currentUsers.splice(idx, 1);
      cfg.chatCollectorTargetUsers = currentUsers;
      save();
      renderChatCollector();
    });
  });
};

const chatCollectorAddUser = () => {
  const input = /** @type {HTMLInputElement|null} */ ($('#opt-chat-collector-user-input'));
  const val = input?.value?.trim();
  if (!val) return;

  const currentUsers = cfg.chatCollectorTargetUsers || [];
  val.split(',').map(s => s.trim()).filter(Boolean).forEach(user => {
    if (!currentUsers.includes(user)) {
      currentUsers.push(user);
    }
  });

  cfg.chatCollectorTargetUsers = currentUsers;
  if (input) input.value = '';
  save();
  renderChatCollector();
};

const chatCollectorBind = () => {
  renderChatCollector();

  // 역할 체크박스 변경 이벤트
  const streamerChk = $('#opt-chat-collector-role-streamer');
  const managerChk = $('#opt-chat-collector-role-manager');
  const donationChk = $('#opt-chat-collector-role-donation');

  // 보관 기일 이벤트
  const retentionSelect = $('#opt-chat-collector-retention');
  retentionSelect?.addEventListener('change', (e) => {
    // @ts-ignore
    const val = parseInt(e.target.value, 10);
    cfg.chatCollectorRetentionHours = val;
    save();
  });

  const updateRoles = () => {
    const nextRoles = [];
    if (/** @type {HTMLInputElement} */ (streamerChk)?.checked) nextRoles.push('streamer');
    if (/** @type {HTMLInputElement} */ (managerChk)?.checked) nextRoles.push('manager');
    if (/** @type {HTMLInputElement} */ (donationChk)?.checked) nextRoles.push('donation');
    cfg.chatCollectorRoles = nextRoles;
    save();
  };

  streamerChk?.addEventListener('change', updateRoles);
  managerChk?.addEventListener('change', updateRoles);
  donationChk?.addEventListener('change', updateRoles);

  // 유저 추가 이벤트
  $('#opt-chat-collector-user-add')?.addEventListener('click', chatCollectorAddUser);
  $('#opt-chat-collector-user-input')?.addEventListener('keydown', (/** @type {any} */ e) => {
    if (e.key === 'Enter') chatCollectorAddUser();
  });
};

// ═══════════════════════════════════════════
//  멀티뷰 기능 (chrome.storage.local)
// ═══════════════════════════════════════════

/** @type {any[]} */
let mvChannels = [];

/** @type {any[]} */
let mcChannels = [];

const mvLoad = async () => {
  const res = await Browser.storage.local.get(['mvChannels']);
  const data = /** @type {any} */ (res);
  mvChannels = data.mvChannels || [];
};

const mvSave = () => Browser.storage.local.set({ mvChannels });

/**
 * 저장소 변경 감지 리스너 (멀티뷰/채팅 멀티뷰 동기화용)
 */
Browser.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.mvChannels) {
      mvChannels = /** @type {any[]} */ (changes.mvChannels.newValue ?? []);
      mvRenderTags();
    }

    if (changes.mcChannels) {
      mcChannels = /** @type {any[]} */ (changes.mcChannels.newValue ?? []);
      mcRenderList();
    }
  }
  if (area === 'sync') {
    if (changes.settings && changes.settings.newValue) {
      cfg = changes.settings.newValue;
      render();
    }
  }
});

const mvRenderTags = () => {
  const container = $('#mv-list');
  const countEl = $('#mv-count');
  if (!container || !countEl) return;

  const MAX_MV = 6;
  countEl.textContent = `${mvChannels.length}/${MAX_MV}`;
  if (mvChannels.length > 0) {
    countEl.className = 'st-val st-val--on';
  } else {
    countEl.className = 'st-val st-val--dim';
  }

  if (mvChannels.length === 0) {
    container.innerHTML = '<div style="text-align:center; color:var(--text3); padding:10px 0; font-size:11px;">추가된 채널이 없습니다.</div>';
    return;
  }

  container.innerHTML = mvChannels.map((ch, i) => `
    <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 4px; gap:6px; ${i > 0 ? 'border-top:1px solid rgba(255,255,255,0.05);' : ''}">
      <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; color:#fff; font-size:12px;">${ch.title || ch.id}</div>
      <button type="button" class="mv-chat-btn" data-id="${ch.id}" title="채팅 팝업 열기"
        style="background:none; border:none; color:#94a3b8; cursor:pointer; padding:2px; display:flex; align-items:center; flex-shrink:0;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
      </button>
      <button type="button" class="mv-del-btn" data-idx="${i}" style="background:none; border:none; color:#ff4444; font-size:16px; cursor:pointer; flex-shrink:0;" aria-label="삭제">&times;</button>
    </div>
  `).join('');

  container.querySelectorAll('.mv-chat-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('mouseenter', () => { btn.style.color = '#00ffa3'; });
    btn.addEventListener('mouseleave', () => { btn.style.color = '#94a3b8'; });
    btn.addEventListener('click', () => {
      Browser.windows.create({
        url: `https://chzzk.naver.com/live/${btn.dataset.id}/chat`,
        type: 'popup',
        width: 360,
        height: 680,
      });
    });
  });

  container.querySelectorAll('.mv-del-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.idx, 10);
      mvChannels.splice(idx, 1);
      mvSave();
      mvRenderTags();
    });
  });
};

/** @param {string} urlOrId */
const extractChzzkId = (urlOrId) => {
  let id = urlOrId.trim();
  const match = id.match(/chzzk\.naver\.com\/live\/([a-z0-9_]+)/i);
  if (match) {
    return match[1];
  }
  if (/^[a-fA-F0-9]{32}$/.test(id)) {
    return id;
  }
  return null;
};

const mvBind = async () => {
  await mvLoad();
  mvRenderTags();
  const btnAdd = $('#btn-mv-add');
  const input = $('#mv-input');
  const errorMsg = $('#mv-error');
  const btnStart = $('#btn-mv-start');

  if (btnAdd && input) {
    btnAdd.addEventListener('click', async () => {
      const val = input.value.trim();
      if (!val) return;

      const id = extractChzzkId(val);
      if (!id) {
        if (errorMsg) { errorMsg.textContent = '올바른 URL/ID가 아닙니다.'; errorMsg.style.display = 'block'; }
        return;
      }

      // 레이스 컨디션 방지를 위해 처리 중 버튼 비활성화
      btnAdd.disabled = true;
      const originalText = btnAdd.textContent;
      btnAdd.textContent = '확인 중...';

      try {
        // 저장소에서 최신 상태를 다시 가져옴 (Atomic read-modify-write 보장용)
        const resCurrent = /** @type {any} */ (await Browser.storage.local.get({ mvChannels: [] }));
        const currentChannels = resCurrent.mvChannels || [];

        if (currentChannels.length >= 6) {
          alert('최대 6개까지만 추가할 수 있습니다.');
          return;
        }

        if (currentChannels.find((/** @type {any} */ c) => c.id === id)) {
          if (errorMsg) { errorMsg.textContent = '이미 추가된 채널입니다.'; errorMsg.style.display = 'block'; }
          return;
        }

        if (errorMsg) errorMsg.style.display = 'none';

        // 채널 정보 가져오기
        let title = id;
        try {
          const apiResp = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${id}`);
          if (apiResp.ok) {
            const json = await apiResp.json();
            if (json?.content?.channelName) title = json.content.channelName;
          }
        } catch (e) { console.error('Failed to fetch channel name', e); }

        // 최종 저장 (이 시점에 다시 한 번 배열을 합침)
        const updated = [...currentChannels, { id, title }];
        await Browser.storage.local.set({ mvChannels: updated });

        input.value = '';
      } catch (err) {
        console.error('MV Add Error:', err);
      } finally {
        btnAdd.disabled = false;
        btnAdd.textContent = originalText;
      }
    });

    input.addEventListener('keydown', (/** @type {any} */ e) => {
      if (e.key === 'Enter') btnAdd.click();
      if (errorMsg) errorMsg.style.display = 'none';
    });

    const btnFollowing = $('#btn-mv-following');
    const followingContainer = $('#mv-following-container');
    const followingStatus = $('#mv-following-status');
    const followingList = $('#mv-following-list');

    if (btnFollowing && followingContainer && followingStatus && followingList) {
      btnFollowing.addEventListener('click', async () => {
        if (followingContainer.style.display === 'block') {
          followingContainer.style.display = 'none';
          return;
        }

        followingContainer.style.display = 'block';
        followingStatus.textContent = '팔로잉 채널을 불러오는 중...';
        followingStatus.style.display = 'block';
        followingList.innerHTML = '';

        try {
          const resp = await fetch('https://api.chzzk.naver.com/service/v1/channels/followings?size=300');
          if (!resp.ok) throw new Error('API 호출 실패');
          const json = await resp.json();
          let list = json?.content?.followingList || [];

          // 생방송 중인 채널이 위로 오도록 정렬
          list.sort((a, b) => {
            const aLive = !!a.streamer?.openLive;
            const bLive = !!b.streamer?.openLive;
            return aLive === bLive ? 0 : aLive ? -1 : 1;
          });

          if (list.length === 0) {
            followingStatus.textContent = '팔로잉 중인 채널이 없습니다.';
            return;
          }

          followingStatus.style.display = 'none';

          list.forEach((/** @type {any} */ item) => {
            const ch = item.channel;
            if (!ch) return;

            const isLive = !!item.streamer?.openLive;

            const btn = document.createElement('div');
            const defaultStyle = 'background: rgba(255,255,255,0.03); padding: 6px 10px; border-radius: 8px; font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.05); transition: all 0.2s ease; margin-bottom: 6px; gap: 10px;';
            const hoverStyle = 'background: rgba(255,255,255,0.08); padding: 6px 10px; border-radius: 8px; font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.15); transition: all 0.2s ease; margin-bottom: 6px; gap: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);';

            btn.style.cssText = defaultStyle;
            btn.addEventListener('mouseenter', () => btn.style.cssText = hoverStyle);
            btn.addEventListener('mouseleave', () => btn.style.cssText = defaultStyle);

            const leftContainer = document.createElement('div');
            leftContainer.style.cssText = 'display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0;';

            const profileImg = document.createElement('img');
            profileImg.src = ch.channelImageUrl || 'https://ssl.pstatic.net/static/nng/glive/icon/default_profile.png';
            profileImg.style.cssText = 'width: 24px; height: 24px; border-radius: 50%; object-fit: cover; flex-shrink: 0; border: 1px solid rgba(255,255,255,0.1);';

            const nameSpan = document.createElement('span');
            nameSpan.textContent = ch.channelName;
            nameSpan.style.cssText = 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--text-color); font-weight: 500; letter-spacing: -0.3px;';

            leftContainer.appendChild(profileImg);
            leftContainer.appendChild(nameSpan);

            const liveBadge = document.createElement('span');
            if (isLive) {
              liveBadge.textContent = 'LIVE';
              liveBadge.style.cssText = 'background: linear-gradient(135deg, #ff4b4b, #ff2121); color: white; font-size: 9px; padding: 2px 5px; border-radius: 4px; font-weight: 700; flex-shrink: 0; box-shadow: 0 2px 4px rgba(255,75,75,0.3);';
            } else {
              liveBadge.textContent = 'OFF';
              liveBadge.style.cssText = 'background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.6); font-size: 9px; padding: 2px 5px; border-radius: 4px; flex-shrink: 0; font-weight: 600;';
            }

            btn.appendChild(leftContainer);
            btn.appendChild(liveBadge);

            btn.addEventListener('click', () => {
              input.value = ch.channelId;
              btnAdd.click();
            });

            followingList.appendChild(btn);
          });
        } catch (err) {
          console.error('Failed to load following channels:', err);
          followingStatus.textContent = '불러오기 실패 (로그인이 필요할 수 있습니다)';
        }
      });
    }
  }

  if (btnStart) {
    btnStart.addEventListener('click', () => {
      if (mvChannels.length === 0) {
        alert('채널을 추가해주세요.');
        return;
      }
      Browser.tabs.create({ url: 'https://chzzk.naver.com/?multiview=true' });
    });
  }
};

const MC_MAX = 6;

const mcLoad = async () => {
  const res = /** @type {any} */ (await Browser.storage.local.get(['mcChannels']));
  mcChannels = res.mcChannels ?? [];
};

const mcSave = () => Browser.storage.local.set({ mcChannels });

/** @param {string} id */
const mcOpenChat = (id) => {
  Browser.windows.create({
    url: `https://chzzk.naver.com/live/${id}/chat`,
    type: 'popup',
    width: 360,
    height: 680,
  });
};

const mcRenderList = () => {
  const container = $('#mc-list');
  const countEl = $('#mc-count');
  if (!container || !countEl) return;

  countEl.textContent = `${mcChannels.length}/${MC_MAX}`;
  countEl.className = mcChannels.length > 0 ? 'st-val st-val--on' : 'st-val';

  if (mcChannels.length === 0) {
    container.innerHTML = '<div style="text-align:center; color:var(--text-muted); font-size:11px;">추가된 채널이 없습니다.</div>';
    return;
  }

  container.innerHTML = mcChannels.map((ch, i) => `
    <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 4px; gap:6px; ${i > 0 ? 'border-top:1px solid rgba(255,255,255,0.05);' : ''}">
      <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; flex:1; color:#fff; font-size:12px;">${ch.title || ch.id}</div>
      <button type="button" class="mc-open-btn" data-id="${ch.id}" title="채팅 팝업 열기"
        style="background:none; border:none; color:#94a3b8; cursor:pointer; padding:2px; display:flex; align-items:center; flex-shrink:0;">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
      </button>
      <button type="button" class="mc-del-btn" data-idx="${i}" style="background:none; border:none; color:#ff4444; font-size:16px; cursor:pointer; flex-shrink:0;" aria-label="삭제">&times;</button>
    </div>
  `).join('');

  container.querySelectorAll('.mc-open-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('mouseenter', () => { btn.style.color = '#00ffa3'; });
    btn.addEventListener('mouseleave', () => { btn.style.color = '#94a3b8'; });
    btn.addEventListener('click', () => mcOpenChat(btn.dataset.id));
  });

  container.querySelectorAll('.mc-del-btn').forEach((/** @type {any} */ btn) => {
    btn.addEventListener('click', () => {
      const idx = parseInt(btn.dataset.idx, 10);
      mcChannels.splice(idx, 1);
      mcSave();
      mcRenderList();
    });
  });
};

const mcBind = async () => {
  await mcLoad();
  mcRenderList();

  const input = /** @type {HTMLInputElement|null} */ ($('#mc-input'));
  const errorMsg = $('#mc-error');
  const btnAdd = $('#btn-mc-add');
  const btnOpenAll = $('#btn-mc-open-all');

  const doAdd = async () => {
    const raw = input?.value?.trim() ?? '';
    const id = extractChzzkId(raw);

    if (!id) {
      if (errorMsg) { errorMsg.textContent = '올바른 URL/ID가 아닙니다.'; errorMsg.style.display = 'block'; }
      return;
    }
    if (mcChannels.length >= MC_MAX) {
      if (errorMsg) { errorMsg.textContent = `최대 ${MC_MAX}개까지 추가 가능합니다.`; errorMsg.style.display = 'block'; }
      return;
    }
    if (mcChannels.some(ch => ch.id === id)) {
      if (errorMsg) { errorMsg.textContent = '이미 추가된 채널입니다.'; errorMsg.style.display = 'block'; }
      return;
    }

    if (errorMsg) errorMsg.style.display = 'none';

    let title = id;
    try {
      const res = await fetch(`https://api.chzzk.naver.com/service/v1/channels/${id}`);
      if (res.ok) {
        const json = await res.json();
        if (json?.content?.channelName) title = json.content.channelName;
      }
    } catch (_) { }

    mcChannels.push({ id, title });
    if (input) input.value = '';
    mcSave();
    mcRenderList();
  };

  btnAdd?.addEventListener('click', doAdd);
  input?.addEventListener('keydown', (/** @type {any} */ e) => {
    if (e.key === 'Enter') doAdd();
    if (errorMsg) errorMsg.style.display = 'none';
  });

  const btnFollowing = $('#btn-mc-following');
  const followingContainer = $('#mc-following-container');
  const followingStatus = $('#mc-following-status');
  const followingList = $('#mc-following-list');

  if (btnFollowing && followingContainer && followingStatus && followingList) {
    btnFollowing.addEventListener('click', async () => {
      if (followingContainer.style.display === 'block') {
        followingContainer.style.display = 'none';
        return;
      }

      followingContainer.style.display = 'block';
      followingStatus.textContent = '팔로잉 채널을 불러오는 중...';
      followingStatus.style.display = 'block';
      followingList.innerHTML = '';

      try {
        const resp = await fetch('https://api.chzzk.naver.com/service/v1/channels/followings?size=300');
        if (!resp.ok) throw new Error('API 호출 실패');
        const json = await resp.json();
        let list = json?.content?.followingList || [];

        // 생방송 중인 채널이 위로 오도록 정렬
        list.sort((a, b) => {
          const aLive = !!a.streamer?.openLive;
          const bLive = !!b.streamer?.openLive;
          return aLive === bLive ? 0 : aLive ? -1 : 1;
        });

        if (list.length === 0) {
          followingStatus.textContent = '팔로잉 중인 채널이 없습니다.';
          return;
        }

        followingStatus.style.display = 'none';

        list.forEach((/** @type {any} */ item) => {
          const ch = item.channel;
          if (!ch) return;

          const isLive = !!item.streamer?.openLive;
          const btn = document.createElement('div');
          const defaultStyle = 'background: rgba(255,255,255,0.03); padding: 6px 10px; border-radius: 8px; font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.05); transition: all 0.2s ease; margin-bottom: 6px; gap: 10px;';
          const hoverStyle = 'background: rgba(255,255,255,0.08); padding: 6px 10px; border-radius: 8px; font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.15); transition: all 0.2s ease; margin-bottom: 6px; gap: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);';

          btn.style.cssText = defaultStyle;
          btn.addEventListener('mouseenter', () => btn.style.cssText = hoverStyle);
          btn.addEventListener('mouseleave', () => btn.style.cssText = defaultStyle);

          const leftContainer = document.createElement('div');
          leftContainer.style.cssText = 'display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0;';

          const profileImg = document.createElement('img');
          profileImg.src = ch.channelImageUrl || 'https://ssl.pstatic.net/static/nng/glive/icon/default_profile.png';
          profileImg.style.cssText = 'width: 24px; height: 24px; border-radius: 50%; object-fit: cover; flex-shrink: 0; border: 1px solid rgba(255,255,255,0.1);';

          const nameSpan = document.createElement('span');
          nameSpan.textContent = ch.channelName;
          nameSpan.style.cssText = 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--text-color); font-weight: 500; letter-spacing: -0.3px;';

          leftContainer.appendChild(profileImg);
          leftContainer.appendChild(nameSpan);

          const liveBadge = document.createElement('span');
          if (isLive) {
            liveBadge.textContent = 'LIVE';
            liveBadge.style.cssText = 'background: linear-gradient(135deg, #ff4b4b, #ff2121); color: white; font-size: 9px; padding: 2px 5px; border-radius: 4px; font-weight: 700; flex-shrink: 0; box-shadow: 0 2px 4px rgba(255,75,75,0.3);';
          } else {
            liveBadge.textContent = 'OFF';
            liveBadge.style.cssText = 'background: rgba(255,255,255,0.1); color: rgba(255,255,255,0.6); font-size: 9px; padding: 2px 5px; border-radius: 4px; flex-shrink: 0; font-weight: 600;';
          }

          btn.appendChild(leftContainer);
          btn.appendChild(liveBadge);
          btn.addEventListener('click', () => {
            if (input) {
              input.value = ch.channelId;
              doAdd();
            }
          });
          followingList.appendChild(btn);
        });
      } catch (err) {
        console.error('Failed to load following channels:', err);
        followingStatus.textContent = '불러오기 실패 (로그인이 필요할 수 있습니다)';
      }
    });
  }

  btnOpenAll?.addEventListener('click', () => {
    if (mcChannels.length === 0) { alert('채널을 추가해주세요.'); return; }
    // 보안 및 로그인 문제를 위해 치지직 도메인 내에서 멀티뷰를 실행합니다.
    Browser.tabs.create({ url: 'https://chzzk.naver.com/?multiview=chat' });
  });
};

/**
 * @param {any} shortcut 
 * @returns {string}
 */
const formatShortcut = (shortcut) => {
  if (!shortcut) return 'None';
  const parts = [];
  if (shortcut.ctrl) parts.push('Ctrl');
  if (shortcut.shift) parts.push('Shift');
  if (shortcut.alt) parts.push('Alt');
  if (shortcut.meta) parts.push('Meta');

  let keyText = shortcut.key;
  if (keyText === ' ') keyText = 'Space';
  else if (keyText) keyText = keyText.toUpperCase();

  if (keyText) parts.push(keyText);
  return parts.join('+') || 'None';
};

const renderShortcuts = () => {
  if (!cfg || !cfg.customShortcuts) return;
  for (const [action, shortcut] of Object.entries(cfg.customShortcuts)) {
    const el = $(`#sc-val-${action}`);
    if (el) {
      el.textContent = formatShortcut(shortcut);
    }
  }
};

const shortcutBind = () => {
  const btnOpen = $('#btn-open-shortcut-modal');
  if (!btnOpen) return;

  btnOpen.addEventListener('click', async () => {
    const url = Browser.runtime.getURL('shortcut.html');
    try {
      await Browser.windows.create({
        url,
        type: 'popup',
        width: 500,
        height: 620
      });
    } catch (_err) {
      await Browser.tabs.create({ url });
    }
  });
};

const renderAdvanced = () => {
  const summaryEl = $('#override-summary');
  if (summaryEl && cfg) {
    const count = Object.keys(cfg.customSelectors || {}).length;
    summaryEl.textContent = `등록된 사용자 지정 셀렉터: ${count}개`;
  }
};

const advancedBind = () => {
  const btnStart = $('#btn-start-inspector');
  if (btnStart) {
    btnStart.addEventListener('click', async () => {
      // 1. 치지직 페이지 활성 탭이 있는지 확인
      const activeTab = await msg('GET_PLAYER_STATE');
      if (!activeTab) {
        alert('활성화된 치지직 방송/VOD 페이지 탭을 찾을 수 없습니다.\n먼저 치지직 페이지를 열거나 탭을 선택해주세요.');
        return;
      }

      // 2. 인스펙터 활성화 메시지 전송
      await Browser.runtime.sendMessage({ action: 'START_SELECTOR_INSPECTOR' });
      window.close(); // 조작 방해 금지 위해 팝업 자동 닫음
    });
  }

  const btnReset = $('#btn-reset-selectors');
  if (btnReset) {
    btnReset.addEventListener('click', async () => {
      if (!confirm('모든 사용자 지정 셀렉터를 초기화하고 기본값으로 복원할까요?')) return;
      cfg.customSelectors = {};
      await msg('SAVE_SETTINGS', cfg);

      // 갱신된 비어있는 설정을 탭들에 전파
      await Browser.runtime.sendMessage({ action: 'CQC_SELECTORS_UPDATED', payload: {} });
      renderAdvanced();
      alert('초기화되었습니다.');
    });
  }

  const btnRestart = $('#btn-restart-wizard');
  if (btnRestart) {
    btnRestart.addEventListener('click', async () => {
      if (!confirm('초기 설정 가이드(옵션 프리셋 선택 티켓)를 다시 실행할까요?\n실행 시 치지직 페이지가 새로고침됩니다.')) return;
      cfg.setupCompleted = false;
      await msg('SAVE_SETTINGS', cfg);

      try {
        const tabs = await Browser.tabs.query({ url: '*://chzzk.naver.com/*' });
        const activeTab = tabs.find(t => t.active) || tabs[0];
        if (activeTab && activeTab.id) {
          await Browser.tabs.reload(activeTab.id);
        }
      } catch (e) {
        console.error(e);
      }

      alert('설정 가이드가 리셋되었습니다. 치지직 탭을 확인해주세요.');
      window.close();
    });
  }
};
