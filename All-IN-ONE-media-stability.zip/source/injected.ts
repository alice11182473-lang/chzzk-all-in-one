import { installPlayerCompatibility } from './compatibility/player-compat.js';
import { InjectedRuntime } from './src/injected/core/InjectedRuntime';
import { PlayerModule } from './src/injected/modules/PlayerModule';
import { MultiviewModule } from './src/injected/modules/MultiviewModule';
import { ShortcutModule } from './src/injected/modules/ShortcutModule';
import { ChatFilterModule } from './src/injected/modules/ChatFilterModule';
import { SidebarModule } from './src/injected/modules/SidebarModule';
import { ToolbarUiModule } from './src/injected/modules/ToolbarUiModule';
import { CategoryBlockModule } from './src/modules/overlay/CategoryBlockModule';
import { EmojiCopyPasteModule } from './src/injected/modules/EmojiCopyPasteModule';

installPlayerCompatibility(PlayerModule);

const runtime = new InjectedRuntime();

runtime.register(new PlayerModule());
runtime.register(new MultiviewModule());
runtime.register(new ShortcutModule());
runtime.register(new ChatFilterModule());
runtime.register(new SidebarModule());
runtime.register(new ToolbarUiModule());
runtime.register(new CategoryBlockModule());
runtime.register(new EmojiCopyPasteModule());

runtime.init();
runtime.post('INJECTED_READY', null);