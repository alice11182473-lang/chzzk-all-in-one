// @ts-check
import { defineConfig } from 'vite';
import { crx } from '@crxjs/vite-plugin';
import fs from 'fs';
import path from 'path';
import { transformSync } from 'esbuild';

const manifest = JSON.parse(fs.readFileSync('./manifest.json', 'utf8'));

export default defineConfig({
    plugins: [
        crx({ manifest }),
    ],
    build: {
        outDir: 'dist',
        minify: 'esbuild',
        target: 'es2022',
        rollupOptions: {
            input: {
                popup: path.resolve(__dirname, 'popup.html'),
                overlay: path.resolve(__dirname, 'overlay.css'),
                'sidebar-folder-modal': path.resolve(__dirname, 'sidebar-folder-modal.css'),
                'chat-mv': path.resolve(__dirname, 'chat-mv.html'),
                'mock-mv': path.resolve(__dirname, 'mock-mv.html'),
                shortcut: path.resolve(__dirname, 'shortcut.html'),
                injected: path.resolve(__dirname, 'injected.ts'),
                'ad-skip': path.resolve(__dirname, 'ad-skip.ts'),
            },
            output: {
                entryFileNames: '[name].js',
                chunkFileNames: 'assets/[name].js',
                assetFileNames: (/** @type {any} */ assetInfo) => {
                    if (assetInfo.name === 'overlay.css') return 'overlay.css';
                    if (assetInfo.name === 'sidebar-folder-modal.css') return 'sidebar-folder-modal.css';
                    return 'assets/[name][extname]';
                }
            }
        }
    }
});
