// @ts-nocheck
/** @ts-check */
import { z } from 'zod';

/**
 * 치지직 올인원 확장프로그램의 설정 스키마
 * Zod를 사용하여 런타임 데이터 무결성을 보장합니다.
 */
export const SettingsSchema = z.object({
  enabled: z.boolean().default(true),
  autoAdSkip: z.boolean().default(true),
  autoQuality: z.boolean().default(false),
  preferredQuality: z.union([z.number(), z.string()]).default(1080),
  preferLowLatency: z.boolean().default(false),
  targetLatency: z.number().default(0),
  chaserMode: z.enum(['gradual', 'instant']).default('gradual'),
  adaptiveLatencyEnabled: z.boolean().default(false),
  autoReapplyOnRerender: z.boolean().default(false),
  showNotification: z.boolean().default(false),
  layoutCleanEnabled: z.boolean().default(true),
  ambientEnabled: z.boolean().default(false),
  powerClickEnabled: z.boolean().default(false),
  followingRefreshEnabled: z.boolean().default(false),
  followingExpandEnabled: z.boolean().default(false),
  hideInstallPopupEnabled: z.boolean().default(false),
  hoverPreviewEnabled: z.boolean().default(false),
  thumbnailPreviewEnabled: z.boolean().default(false),
  hoverPreviewUptimeFormat: z.enum(['off', 'hhmmss', 'hm', 'korean']).default('hhmmss'),
  hideOfflineFollowing: z.boolean().default(false),
  streamStatsEnabled: z.boolean().default(false),
  screenshotEnabled: z.boolean().default(false),
  screenshotAction: z.enum(['save', 'clipboard']).default('save'),
  recorderEnabled: z.boolean().default(false),
  recorderLowLoadEnabled: z.boolean().default(true),
  recorderFormat: z.enum(['webm', 'mp4', 'mkv']).default('mp4'),
  fileTimestampFormat: z.enum(['dash', 'dot', 'korean', 'date-only', 'unix']).default('dash'),
  fileTimestampTimezone: z.enum(['local', 'utc']).default('local'),
  watchTimerEnabled: z.boolean().default(false),
  gridBypassEnabled: z.boolean().default(true),
  gridVisible: z.boolean().default(true),
  sidebarFoldersEnabled: z.boolean().default(false),
  sidebarOfflineGroupDefaultState: z.enum(['collapsed', 'expanded', 'remember']).default('collapsed'),
  sidebarFoldersDefaultState: z.enum(['collapsed', 'expanded', 'remember']).default('remember'),
  sidebarResizeEnabled: z.boolean().default(false),
  chatResizeEnabled: z.boolean().default(false),
  leftChatEnabled: z.boolean().default(false),
  customFont: z.string().default(''),
  customFontImport: z.string().default(''),
  wideViewEnabled: z.boolean().default(false),
  chatStampEnabled: z.boolean().default(false),
  chatStampFormat: z.string().default('hh:mm:ss'),
  chatStampSize: z.number().default(10),
  chatStampSizeLinked: z.boolean().default(false),
  chatFontSize: z.number().default(0),
  playbackSpeedEnabled: z.boolean().default(false),
  playbackSeekTime: z.number().default(5),
  focusModeEnabled: z.boolean().default(false),
  customFontWeight: z.number().default(400),
  sidebarOfflineFoldEnabled: z.boolean().default(false),
  offlineGroupCollapsed: z.boolean().default(false),
  staticLogoEnabled: z.boolean().default(false),
  liveNotificationEnabled: z.boolean().default(false),
  liveNotificationDisabledChannels: z.array(z.object({
    channelId: z.string(),
    channelName: z.string(),
  })).default([]),
  liveAutoReloadEnabled: z.boolean().default(false),
  liveNotificationInterval: z.number().default(3),
  chatFilterEnabled: z.boolean().default(false),
  categoryBlockEnabled: z.boolean().default(false),
  blockedCategoryTags: z.array(z.string()).default([]),
  blockedStreamers: z.array(z.string()).default([]),
  chatEmojiMacros: z.array(z.object({
    keyword: z.string(),
    emojiId: z.string(),
    emojiUrl: z.string()
  })).default([]),
  chatFilterKeywords: z.array(z.object({ text: z.string(), isRegex: z.boolean() })).default([]),
  chatFilterUsers: z.array(z.object({
    user: z.string(),
    channelId: z.string(),
    channelName: z.string().optional()
  })).default([]),
  chatFilterRoles: z.array(z.string()).default([]),
  chatFilterMode: z.enum(['blur', 'hide']).default('hide'),
  hoverPreviewVideoEnabled: z.boolean().default(false),
  hoverPreviewVolume: z.number().min(0).max(100).default(15),
  hoverPreviewHomeEnabled: z.boolean().default(false),
  hoverPreviewRecommendEnabled: z.boolean().default(false),
  hoverPreviewDelay: z.number().default(500),
  hoverPreviewVideoDelay: z.number().default(1200),
  hoverPreviewInteractive: z.boolean().default(false),
  hoverCardSize: z.number().default(440),
  customVideoSortEnabled: z.boolean().default(false),
  gcMonitorEnabled: z.boolean().default(false),
  hideHomeBannerEnabled: z.boolean().default(false),
  hideHomeRecommendEnabled: z.boolean().default(false),
  hideHomeMidBannerEnabled: z.boolean().default(false),
  hideStreamerShopEnabled: z.boolean().default(false),
  layoutCleanupKeywords: z.array(z.string()).default(['인기 카테고리', '방송 일정', '파트너', '서비스 바로가기']),
  hiddenSidebarMenus: z.array(z.string()).default(['인기 클립', '편성표', '치즈팜']),
  discoveredSidebarMenus: z.array(z.string()).default(['전체 방송', '카테고리', '편성표', '팔로잉', '치즈팜', '인기 클립']),
  discoveredSidebarSections: z.array(z.string()).default(['인기 카테고리', '방송 일정', '파트너', '서비스 바로가기']),
  hiddenHeaderTabs: z.array(z.string()).default([]),
  discoveredHeaderTabs: z.array(z.string()).default([]),
  hideStudioButton: z.boolean().default(false),
  hideCheeseButton: z.boolean().default(false),
  hideNotiButton: z.boolean().default(false),
  hideCheatKeyButton: z.boolean().default(false),
  noticeIconEnabled: z.boolean().default(false),
  chatCollectorIconEnabled: z.boolean().default(false),
  chatCollectorEnabled: z.boolean().default(false),
  chatCollectorTargetUsers: z.array(z.string()).default([]),
  chatCollectorRoles: z.array(z.string()).default(['streamer', 'manager']),
  chatCollectorPosition: z.any().nullable().default(null),
  chatCollectorRetentionHours: z.number().default(72),
  powerCountResetHours: z.number().default(24),
  statsContextMenuEnabled: z.boolean().default(true),
  rankingHideEnabled: z.boolean().default(false),
  playbackBarEnabled: z.boolean().default(true),
  playbackBarTimeEnabled: z.boolean().default(true),
  playbackBarTimeTopRight: z.boolean().default(true),
  volumeIndicatorEnabled: z.boolean().default(true),
  wheelVolumeEnabled: z.boolean().default(false),
  chatFilterOS: z.array(z.string()).default([]),
  discoveredRoles: z.array(z.string()).default(['STREAMER', 'MANAGER', 'SUBSCRIBER', 'FAN']),
  discoveredOS: z.array(z.string()).default(['PC', 'AOS', 'IOS']),
  chatFilterEmojis: z.array(z.string()).default([]),
  chatDeviceIconEnabled: z.boolean().default(false),
  chatEmojiCopyPasteEnabled: z.boolean().default(false),
  chatMessageCopyEnabled: z.boolean().default(false),
  blindedRestoreEnabled: z.boolean().default(false),
  blindedAutoRestoreEnabled: z.boolean().default(false),
  customShortcuts: z.record(z.object({
    key: z.string(),
    ctrl: z.boolean().default(false),
    shift: z.boolean().default(false),
    alt: z.boolean().default(false),
    meta: z.boolean().default(false)
  }).nullable()).default({
    'screenshot': { key: 's', ctrl: true, shift: true, alt: false, meta: false },
    'record': { key: 'r', ctrl: true, shift: true, alt: false, meta: false },
    'stats': { key: 'd', ctrl: true, shift: true, alt: false, meta: false },
    'backward': { key: '[', ctrl: false, shift: false, alt: false, meta: false },
    'forward': { key: ']', ctrl: false, shift: false, alt: false, meta: false },
    'chatCollector': { key: 'k', ctrl: true, shift: true, alt: false, meta: false }
  }),
  customSelectors: z.record(z.string()).default({}),
  chatExportEnabled: z.boolean().default(false),
  chatCollectorSplitMode: z.boolean().default(false),
  setupCompleted: z.boolean().default(false),
  chatLatencyDisplayEnabled: z.boolean().default(false),
  vodRealTimeTooltipEnabled: z.boolean().default(true),
  playbackSpeedResetOnLive: z.boolean().default(false),
  hideChatNickname: z.boolean().default(false),
  hideChatBadge: z.boolean().default(false),
  // 뱃지 전체 숨김 중에도 특정 타입은 유지 (전체 숨김이 켜져 있을 때만 의미 있음)
  keepBadgeSubscription: z.boolean().default(false),
  keepBadgeActivity: z.boolean().default(false),
  keepBadgeCheatkey: z.boolean().default(false),
  keepBadgeRole: z.boolean().default(false),
  restoreTransparentNickname: z.boolean().default(false),
  chatNicknameMaxLength: z.number().default(0),
  liveAutoRecordChannels: z.array(z.string()).default([]),
  liveAutoOpenReturnToPrevious: z.boolean().default(false),
  liveAutoOpenEnabled: z.boolean().default(false),
  liveAutoOpenChannels: z.array(z.object({
    channelId: z.string(),
    channelName: z.string(),
  })).default([]),

});

/** @typedef {z.infer<typeof SettingsSchema>} Settings */

/**
 * 데이터를 설정 스키마에 맞게 파싱하고 검증합니다.
 * @param {any} data 
 * @returns {Settings}
 */
export const parseSettings = (data) => {
  return SettingsSchema.parse(data || {});
};

/**
 * 데이터를 안전하게 파싱합니다. 오류 발생 시 기본값을 반환합니다.
 * @param {any} data 
 * @returns {Settings}
 */
export const safeParseSettings = (data) => {
  const result = SettingsSchema.safeParse(data || {});
  let finalData;
  if (result.success) {
    finalData = result.data;
  } else {
    console.warn('[CQC:Schema] 설정 검증 실패, 기본값으로 복구합니다.', result.error);
    finalData = SettingsSchema.parse({});
  }

  return finalData;
};
