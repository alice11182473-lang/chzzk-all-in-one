import {test} from 'node:test';import assert from 'node:assert/strict';import {readFileSync} from 'node:fs';
const cid='a'.repeat(32),extension='b'.repeat(32);let onMessage,onPortMessage,onDisconnect,posted=[],settings={enabled:true,liveAutoOpenEnabled:true,liveAutoOpenChannels:[{channelId:cid}],liveAutoRecordChannels:[cid]},local={cqcRecordingFolder:'녹화'};
const realSetInterval=globalThis.setInterval;globalThis.setInterval=()=>1;
globalThis.chrome={runtime:{id:extension,lastError:null,onMessage:{addListener:fn=>onMessage=fn},connectNative(name){assert.equal(name,'com.chzzk.allinone.recorder');return {onMessage:{addListener:fn=>onPortMessage=fn},onDisconnect:{addListener:fn=>onDisconnect=fn},postMessage(m){posted.push(m);queueMicrotask(()=>onPortMessage({id:m.id,ok:true,job:m.op==='start'?{channelId:cid,status:'starting'}:null,ready:true}));}}}},storage:{sync:{get:async()=>({settings})},local:{get:async()=>local,set:async data=>Object.assign(local,data)},onChanged:{addListener(){}}}};
const bg=await import('./native-recording-background.js');
test('automatic recording follows selections; manual uses native protocol and MP4',async()=>{
 const result=await bg.startNativeRecording(cid,{automatic:true});assert.equal(result.job.status,'starting');assert.equal(posted.at(-1).format,'mp4');assert.equal(posted.at(-1).folder,'녹화');
 settings={...settings,liveAutoRecordChannels:[]};const count=posted.length;await bg.startNativeRecording(cid,{automatic:true});assert.equal(posted.length,count);
 await bg.startNativeRecording(cid);assert.equal(posted.length,count+1);
});
test('content page cannot substitute another channel; unrelated origins rejected',async()=>{
 const message={type:'CQC_NATIVE_START',channelId:'c'.repeat(32)};
 const response=await new Promise(resolve=>onMessage(message,{id:extension,tab:{id:1},url:'https://chzzk.naver.com/live/'+cid},resolve));assert.ok(response.ok);assert.equal(posted.at(-1).channelId,cid);
 let replied=false;onMessage(message,{id:extension,tab:{id:1},url:'https://example.com/live/'+cid},()=>replied=true);assert.equal(replied,false);
});
test('compiled recorder cannot enter MediaRecorder/captureStream path',()=>{
 const bundle=readFileSync(new URL('../../INSTALL-THIS/assets/content.ts.js',import.meta.url),'utf8');const a=bundle.indexOf('var [Vc,Qc]='),b=bundle.indexOf('var Zc=',a);const section=bundle.slice(a,b);
 assert.ok(section.includes('installNativeRecorder'));assert.ok(!/MediaRecorder|captureStream|createRecordingEngine|installAutoRecord/.test(section));
 const background=readFileSync(new URL('../../INSTALL-THIS/assets/background.ts.js',import.meta.url),'utf8');assert.ok(background.includes('startNativeRecording(e,{automatic:true})'));assert.ok(background.includes('startsWith("CQC_NATIVE_")?void 0'));
});
test('disconnect reports error instead of reporting recording success',async()=>{
 await bg.startNativeRecording(cid);onDisconnect();assert.equal(local.cqcNativeRecordingState.jobs[cid].status,'error');
});
process.on('exit',()=>{globalThis.setInterval=realSetInterval;});
