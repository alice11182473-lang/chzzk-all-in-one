import assert from 'node:assert/strict';
import {createRecordingEngine,monitorRecording,recordingDiagnostics} from './recording-engine.js';
let supports=()=>true,rejectH264=false,allFail=false,stopped=0,clock;
globalThis.setInterval=fn=>{clock=fn;return 1;};globalThis.clearInterval=()=>{};
globalThis.MediaRecorder=class extends EventTarget {
 static isTypeSupported(type){return supports(type);}
 constructor(stream,options){super();if(allFail||(rejectH264&&/avc1|h264/.test(options.mimeType)))throw Error('encoder unavailable');Object.assign(this,options);}
};
const video=Object.assign(new EventTarget(),{videoWidth:1920,videoHeight:1080,readyState:4,currentTime:98,playbackRate:1,buffered:{length:1,start:()=>0,end:()=>100},captureStream:()=>({getVideoTracks:()=>[{}],getAudioTracks:()=>[{}],getTracks:()=>[{stop(){stopped++;}}]}),getVideoPlaybackQuality:()=>({totalVideoFrames:600,droppedVideoFrames:5})});
let result=createRecordingEngine(video);assert.match(result.recorder.mimeType,/webm.*vp8/);assert.equal(result.recorder.videoBitsPerSecond,8000000);
supports=t=>t.includes('vp8')||t==='video/webm';result=createRecordingEngine(video);assert.match(result.recorder.mimeType,/vp8/);
supports=()=>true;rejectH264=true;result=createRecordingEngine(video);assert.match(result.recorder.mimeType,/vp8/);rejectH264=false;
result=createRecordingEngine(video,{recorderLowLoadEnabled:false,recorderFormat:'webm'});assert.match(result.recorder.mimeType,/vp8/);assert.equal(result.recorder.videoBitsPerSecond,15000000);
allFail=true;assert.throws(()=>createRecordingEngine(video));assert.equal(stopped,1,'failed construction releases captured tracks');allFail=false;
result=createRecordingEngine(video);monitorRecording(video,result.recorder,true);video.dispatchEvent(new Event('waiting'));const event=new Event('dataavailable');event.data={size:123};result.recorder.dispatchEvent(event);video.playbackRate=1.1;video.dispatchEvent(new Event('ratechange'));assert.equal(recordingDiagnostics().samples.at(-1).event,'ratechange');assert.equal(recordingDiagnostics().samples.at(-1).playbackRate,1.1);video.playbackRate=1;video.dispatchEvent(new Event('seeking'));assert.equal(recordingDiagnostics().samples.at(-1).event,'seeking');for(let i=0;i<100;i++)clock();
let d=recordingDiagnostics();assert.equal(d.waitingCount,1);assert.equal(d.bytes,123);assert.equal(d.samples.length,60);assert.equal(d.samples.at(-1).bufferAhead,2);assert.equal(d.samples.at(-1).droppedFrames,5);assert.equal(d.hardwareAcceleration,'unknown');
result.recorder.dispatchEvent(new Event('stop'));video.dispatchEvent(new Event('waiting'));d=recordingDiagnostics();assert.equal(d.status,'stopped');assert.equal(d.waitingCount,1,'stop removes listeners');
console.log('PASS shared engine: VP8 stable-mode preference, VP8 fallback, constructor fallback, opt-out, failed capture cleanup, bounded post-stop diagnostics');
