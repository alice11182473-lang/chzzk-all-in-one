import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const source=readFileSync(new URL('../chat-collector.ts',import.meta.url),'utf8');
const bundle=readFileSync(new URL('../../INSTALL-THIS/injected.js',import.meta.url),'utf8');
for (const code of [source,bundle]) {
 const scope={document:{createElement:()=>({style:{}})}};
 vm.createContext(scope);
 vm.runInContext(code.slice(0,code.indexOf('function cqcSavedCollectorHeight')),scope);
 for(const extras of [{payAmount:1000},'{"payAmount":"1000"}']) {
  assert.equal(scope.cqcCollectorDonationLabel({extras}),'후원 1,000치즈');
 }
 assert.equal(scope.cqcCollectorDonationLabel({_cqcParsedExtras:{payAmount:25000}}),'후원 25,000치즈');
 for (const payAmount of [undefined,null,'',true,{},[],0,-1,1.2,Infinity,'1e3','<img src=x>',Number.MAX_SAFE_INTEGER+1]) {
  assert.equal(scope.cqcCollectorDonationLabel({extras:{payAmount}}),'');
 }
 assert.equal(scope.cqcCollectorDonationLabel({extras:'invalid',content:'1000치즈'}),'');
 const clone={querySelector:()=>null,prepend(el){this.badge=el}};
 scope.cqcCollectorDecorateDonation(clone,{extras:{payAmount:1000}});
 assert.equal(clone.badge.textContent,'후원 1,000치즈');
 assert.equal(clone.badge.className,'cqc-collected-donation-amount');
 clone.querySelector=()=>clone.badge;clone.prepend=()=>assert.fail('duplicate');
 scope.cqcCollectorDecorateDonation(clone,{extras:{payAmount:1000}});
}
// Exercise the shipped collection path, including persisted HTML and de-duplication.
let saved;const chats=[];
const scope={Ge:()=>chats,ee:'channel',de:{addCollectorChat:async c=>{saved=c}},document:{createElement:()=>({style:{}}),querySelector:()=>null}};
vm.createContext(scope);
vm.runInContext(bundle.slice(0,bundle.indexOf('function cqcSavedCollectorHeight')),scope);
const start=bundle.indexOf('$t=(e,t)=>');const end=bundle.indexOf('window.cqcAddMessageToCollectedPanel=',start);
vm.runInContext(bundle.slice(start,end).replace(/;\s*$/,''),scope);
const el={cloneNode(){return {classList:{add(){}},querySelector:()=>null,prepend(b){this.badge=b},get outerHTML(){return '<div>'+this.badge.textContent+'</div>'}}}};
const msg={messageId:'donation1',time:123,extras:{payAmount:1000},profile:{nickname:'익명'}};
scope.$t(el,msg);scope.$t(el,msg);
assert.equal(chats.length,1);assert.equal(saved.html,'<div>후원 1,000치즈</div>');
console.log('PASS: source/bundle amount validation, formatting, DOM badge, persistence and de-duplication');
