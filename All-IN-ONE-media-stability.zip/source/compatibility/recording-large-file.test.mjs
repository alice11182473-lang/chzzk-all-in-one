// Real filesystem adapter test; not a browser/encoder or elapsed-duration test.
import {test} from 'node:test';import assert from 'node:assert/strict';
import {mkdtemp,open,rm,stat} from 'node:fs/promises';import {tmpdir} from 'node:os';import {join} from 'node:path';
import {createRecordingStorage} from './recording-storage.js';
test('writes and reads past 2 GiB without collecting all chunks',async()=>{
 const directory=await mkdtemp(join(tmpdir(),'cqc-large-'));const path=join(directory,'recording');let fd;
 try{
  fd=await open(path,'w+');
  const handle={createWritable:async()=>({write:async blob=>{const buf=Buffer.from(await blob.arrayBuffer());let pos=0;while(pos<buf.length){const result=await fd.write(buf,pos,buf.length-pos);pos+=result.bytesWritten;}},close:async()=>{await fd.sync();},abort:async()=>{}}),getFile:async()=>({size:(await stat(path)).size})};
  const sink=await createRecordingStorage({storage:{getDirectory:async()=>({getDirectoryHandle:async()=>({getFileHandle:async()=>handle,removeEntry:async()=>{}})})}});
  const blob=new Blob([Buffer.alloc(2*1024*1024,0x5a)]);for(let i=0;i<1100;i++)await sink.append(blob);
  const file=await sink.finish();assert.equal(file.size,2306867200);assert.equal(sink.stats().writtenBytes,file.size);assert.equal(sink.pendingBytes,0);assert.equal(sink.stats().peakPendingBytes,blob.size);
  const sample=Buffer.alloc(16);await fd.read(sample,0,16,2147483648);assert.ok(sample.every(b=>b===0x5a));
 }finally{await fd?.close();await rm(directory,{recursive:true,force:true});}
});
