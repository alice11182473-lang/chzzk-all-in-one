import vm from 'node:vm';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const code = fs.readFileSync(new URL('../sidebar-position-fix.js', import.meta.url), 'utf8');
function fixture(shift = 60, route = '/live/abc') {
  const props = new Map([['top', ['60px', '']]]);
  const style = {getPropertyValue: k => props.get(k)?.[0] || '',
    getPropertyPriority: k => props.get(k)?.[1] || '',
    setProperty: (k,v,p) => props.set(k,[v,p]), removeProperty: k => props.delete(k)};
  let tick;
  const state = {shift, pathname: route};
  const sidebar = {style, getBoundingClientRect: () => ({top: parseFloat(style.getPropertyValue('top') || '60') + state.shift})};
  const header = {getBoundingClientRect: () => ({bottom: 60, height: 60})};
  const document = {fullscreenElement: null, getElementById: k => k === 'sidebar' ? sidebar : header,
    querySelector: () => header, addEventListener() {}};
  vm.runInNewContext(code, {document, location: state, window: {addEventListener() {}},
    getComputedStyle: () => ({position: 'fixed',display: 'block',top: style.getPropertyValue('top') || '60px', transform: `matrix(1, 0, 0, 1, 0, ${state.shift})`}),
    setInterval: f => {tick = f;}});
  return {state, sidebar, document, tick};
}
const a = fixture();
assert.equal(a.sidebar.getBoundingClientRect().top, 60, '120px duplicate becomes 60px');
assert.equal(a.sidebar.style.getPropertyValue('transform'), '', 'site transform untouched');
a.tick(); assert.equal(a.sidebar.getBoundingClientRect().top, 60, 'no cumulative drift');
a.state.shift = 0; a.tick(); assert.equal(a.sidebar.getBoundingClientRect().top, 60, 'tracks removal of site transform');
a.state.pathname = '/'; a.tick(); assert.equal(a.sidebar.style.getPropertyValue('top'), '60px');
const b = fixture(0); assert.equal(b.sidebar.style.getPropertyPriority('top'), '', 'normal layout untouched');
const c = fixture(60, '/'); assert.equal(c.sidebar.getBoundingClientRect().top, 60, 'home offset corrected');
const d = fixture(); d.document.fullscreenElement = {}; d.tick(); assert.equal(d.sidebar.style.getPropertyValue('top'), '60px', 'fullscreen restores');
console.log('Sidebar offset regression checks passed');
