import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
const bundle=readFileSync(new URL('../../INSTALL-THIS/assets/content.ts.js',import.meta.url),'utf8');
const start=bundle.indexOf('var [Vc,Qc]='),end=bundle.indexOf('var Zc=',start);assert.ok(start>=0&&end>start);
const nodes=new Map(),toasts=[],timers=[],listeners={};let autoOptions,autoActive=false,stops=0,recorders=0;
function element(tag='div'){
 const n={tag,style:{},isConnected:false,children:[],attrs:{},events:{},textContent:'',setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,f){this.events[k]=f;},querySelector(q){if(q==='#cqc-record-btn')return nodes.get('cqc-record-btn')||null;if(q==='.cqc-rec-circle')return this.circle;if(q==='.tooltip')return this.tooltip;return null;},appendChild(child){this.children.push(child);child.isConnected=true;nodes.set(child.id,child);},append(child){this.appendChild(child);},remove(){this.isConnected=false;nodes.delete(this.id);},click(){this.events.click?.({preventDefault(){},stopPropagation(){}});}};
 Object.defineProperty(n,'innerHTML',{set(v){this.html=v;if(v.includes('cqc-rec-circle')){this.circle=element();this.tooltip=element();}if(v.includes('cqc-rec-timer')){const timer=element();timer.id='cqc-rec-timer';nodes.set(timer.id,timer);}},get(){return this.html;}});return n;
}
const player=element(),bar=element(),video={dataset:{},captureStream:()=>({getTracks:()=>[{stop(){}}]}),dispatchEvent(){}};
const engineText=readFileSync(new URL('../../INSTALL-THIS/assets/recording-engine.js',import.meta.url),'utf8').replace(/export /g,'');
let nativeOptions,toggles=0;
const ctx={installNativeRecorder(opts){nativeOptions=opts;return {toggle(){toggles++;}};},installAutoPlayback:async()=>{},wt(){},k:{PLAYER:'player',PLAYER_CONTROL_BAR_RIGHT:'bar',PLAYER_BUTTON_TOOLTIP:'.tooltip'},je:s=>toasts.push(s),yt:()=>true,Lo:()=> 'timestamp',document:{head:element(),body:element(),createElement:element,getElementById:id=>nodes.get(id)||null,querySelector:q=>q==='player'?player:q==='bar'?bar:q.includes('video')?video:null,addEventListener:(t,f)=>listeners[t]=f},window:{setInterval:f=>{timers.push(f);return timers.length;}},setInterval:f=>{timers.push(f);return timers.length;},clearInterval(){},setTimeout(){},Event};
vm.createContext(ctx);vm.runInContext(bundle.slice(start,end),ctx);ctx.Vc({customShortcuts:{record:{key:'r'}}});ctx.Qc();
const button=nodes.get('cqc-record-btn');button.click();assert.equal(toggles,1);
nativeOptions.onJob({status:'starting'});assert.equal(button.circle.attrs.fill,'#ff4444');for(const fn of timers)fn();assert.equal(nodes.has('cqc-rec-indicator'),false,'connection time is not recording time');
nativeOptions.onJob({status:'recording',startedAt:Date.now()-10000});assert.ok(nodes.has('cqc-rec-indicator'));assert.equal(button.circle.attrs.fill,'#ff4444');assert.match(button.tooltip.textContent,/녹화 중지/);
button.click();assert.equal(toggles,2);listeners.keydown({key:'r',preventDefault(){}});assert.equal(toggles,3);
nativeOptions.onJob({status:'stopped',path:'test.mp4'});assert.equal(nodes.has('cqc-rec-indicator'),false);assert.equal(button.circle.attrs.fill,'white');assert.ok(toasts.some(s=>s.includes('저장 완료')));
nativeOptions.onJob({status:'recording',startedAt:Date.now()});nativeOptions.onJob({status:'error'});assert.equal(nodes.has('cqc-rec-indicator'),false);
console.log('PASS compiled native recorder: connection state, real recording indicator, button/shortcut, saved/error UI');
