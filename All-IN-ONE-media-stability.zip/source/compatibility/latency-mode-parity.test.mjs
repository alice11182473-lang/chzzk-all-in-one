import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {LatencyController} from './latency-controller.js';
let now=100000;Date.now=()=>now;globalThis.location={pathname:'/live/test'};globalThis.document=new EventTarget();
function fixture(){const v=Object.assign(new EventTarget(),{dataset:{},currentTime:94,playbackRate:1,readyState:4,paused:false,seeking:false,seekable:{length:1,start:()=>0,end:()=>100},buffered:{length:1,start:()=>0,end:()=>100}});return {v,c:new LatencyController(v,Object.assign(new EventTarget(),{contains:()=>true}))};}
for(const chaserMode of ['instant','gradual']){
 const a=fixture(),b=fixture();
 const auto={enabled:true,targetLatency:0,playbackSpeedResetOnLive:true,chaserMode};const manual={...auto,targetLatency:3,playbackSpeedResetOnLive:false};
 for(let t=0;t<60;t++){
  now+=1000;
  if(t===5){for(const f of [a,b]){f.v.dataset.cqcRecording='true';f.v.dispatchEvent(new Event('cqc-recording-start'));}}
  if(t===12){for(const f of [a,b])f.v.dispatchEvent(new Event('waiting'));}
  if(t===40){for(const f of [a,b])delete f.v.dataset.cqcRecording;}
  a.c.tick(auto);b.c.tick(manual);
  assert.equal(a.v.playbackRate,b.v.playbackRate);assert.equal(a.v.currentTime,b.v.currentTime);assert.equal(a.c.status,b.c.status);
  if(t>=5&&t<40){assert.equal(a.v.playbackRate,1);assert.equal(a.v.dataset.cqcLatencyStatus,'recording-stable');}
 }
 a.c.dispose();b.c.dispose();
}
const shipped=readFileSync(new URL('../../chzzk-compat/injected.js',import.meta.url),'utf8');
assert.ok(shipped.includes('new CqcLatencyController('));
assert.ok(!shipped.includes('playbackSpeedResetOnLive'),'legacy bundle must not independently interpret automatic-chase option');
assert.ok(!shipped.includes('targetRate=1.15'));
console.log('PASS automatic 3s/manual 3s parity before/during/after recording; legacy independent chase removed');
