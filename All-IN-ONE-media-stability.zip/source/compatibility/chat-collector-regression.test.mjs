import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const base = new URL('../../INSTALL-THIS/', import.meta.url);
const js = readFileSync(new URL('injected.js',base),'utf8');
const start=js.indexOf('initChatFilterObserver(){');
const method=js.slice(start,js.indexOf('initProfilePopupObserver(){',start));
const classes=new Set(['cqc-processed']);
let message={profile:{nickname:'test',userRoleCode:'streamer'},content:'hello',time:1};
const el={classList:{contains:x=>classes.has(x),remove:(...xs)=>xs.forEach(x=>classes.delete(x)),add:x=>classes.add(x),toggle:(x,v)=>v?classes.add(x):classes.delete(x)},closest:()=>null,querySelector:()=>null,matches:()=>false};
let tick, collected=0;
const container={querySelectorAll:s=>s.includes(':not')&&classes.has('cqc-processed')?[]:[el]};
const context={cqcCollectorMounts:()=>({list:container}),cqcCollectorMessage:()=>null,document:{querySelectorAll:()=>[el],getElementById:()=>({}),querySelector:()=>container},p:{CHAT_ITEM:'.item',CHAT_LIST_CONTAINER:'.list',CHAT_DONATION:'.donation'},ne:()=>null,he:()=>message?{chatMessage:message}:null,setInterval:fn=>(tick=fn,1),clearInterval:()=>{},window:{cqcChatCollectorActive:true,cqcAddMessageToCollectedPanel:()=>collected++}};
const instance=vm.runInNewContext('({'+method+'})',context);
instance.runtime={settings:{chatCollectorSplitMode:true},log:()=>{}};
instance._chatFilterCleanup={intervalId:null};
instance.initChatFilterObserver();
assert.equal(collected,1,'previously processed message is reconsidered after settings change');
tick();assert.equal(collected,1,'processed messages not collected on each tick');
message=null;instance.initChatFilterObserver();assert.equal(classes.has('cqc-processed'),false);
message={profile:{nickname:'late'},content:'late'};tick();assert.equal(collected,2,'late React data is retried');
context.window.cqcChatCollectorActive=false;instance.initChatFilterObserver();assert.equal(collected,2);
for (const prefix of ['', '../source/']) {
 const html=readFileSync(new URL(prefix+'popup.html',base),'utf8');
 assert.equal((html.match(/id="opt-chat-collector"/g)||[]).length,1);
}
assert.ok(readFileSync(new URL('popup.js',base),'utf8').includes('"opt-chat-collector":"chatCollectorEnabled"'));
console.log('PASS: existing message rescan, delayed props retry, off state, popup binding');
