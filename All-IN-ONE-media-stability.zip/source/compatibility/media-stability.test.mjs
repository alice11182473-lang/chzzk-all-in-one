import assert from 'node:assert/strict';
import {LatencyController} from './latency-controller.js';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
let now=100000;Date.now=()=>now;globalThis.location={pathname:'/live/test'};const noop=()=>{};
globalThis.document={addEventListener:noop,removeEventListener:noop};
function fixture(end=100){const v={dataset:{},currentTime:92,playbackRate:1,readyState:4,paused:false,seeking:false,seekable:{length:1,start:()=>0,end:()=>100},buffered:{length:1,start:()=>0,end:()=>end},addEventListener:noop,removeEventListener:noop};return {v,c:new LatencyController(v,{contains:()=>true,addEventListener:noop,removeEventListener:noop})};}
const instant={enabled:true,targetLatency:1.5,chaserMode:'instant'};
let {v,c}=fixture(96);for(let i=0;i<10;i++){now+=1000;c.tick(instant);}assert.equal(v.currentTime,92,'must not seek to unbuffered 98.5');assert.ok(v.playbackRate>1);c.dispose();
({v,c}=fixture());v.dataset.cqcRecording='true';for(let i=0;i<60;i++){now+=1000;c.tick(instant);}assert.equal(v.currentTime,92,'recording must never automatically seek');assert.ok(v.playbackRate<=1.03);c.dispose();
({v,c}=fixture());c.tick({enabled:true,targetLatency:0,playbackSpeedResetOnLive:true});assert.ok(v.playbackRate>1,'auto chase must work with target=0');c.onWaiting();assert.equal(v.playbackRate,1);c.tick(instant);assert.equal(c.status,'buffer-recovery');now+=11000;c.tick(instant);assert.ok(c.effectiveTarget>1.5);c.tick({enabled:true,targetLatency:0,playbackSpeedResetOnLive:false});assert.equal(v.playbackRate,1);c.dispose();
// Exercise the shipped filter class, including the actual popup storage event path.
let stored={sharpnessEnabled:false,sharpnessIntensity:1,sharpnessMode:'default',settings:{enabled:true}},onChange;const nodes=new Map(),matrices=[];
function element(){return {media:'',id:'',innerHTML:'',textContent:'',setAttribute(k,v){this[k]=v;},querySelectorAll(){return matrices;},querySelector(){return null;},remove(){nodes.delete(this.id)}};}
matrices.push(element());const append=n=>nodes.set(n.id,n);
const context={EventTarget,Event,HTMLElement:class{},document:{createElement:element,getElementById:id=>nodes.get(id),body:{append},head:{append},querySelector:()=>null},Q:{default:{storage:{sync:{get:async defaults=>({...defaults,...stored})},onChanged:{addListener:f=>onChange=f}}}},rt:{saturate:1,brightness:1,contrast:1},Mn:'sharp_default',vo:'sharp_natural',On:'sharp_custom',gc:'sharpnessSVGContainer',mc:'sharpnessStyle',yo:'.pzp-pc__settings',Pn:'sharpnessEnabled',go:'sharpnessIntensity',mo:'sharpnessMode',kn:'sharpnessCustom',Kg:noop,ui:noop};
const text=readFileSync(new URL('../../chzzk-compat/assets/content.ts.js',import.meta.url),'utf8');const start=text.indexOf('jg=class');const end=text.indexOf(';let cqcSharpnessInstance',start);assert.ok(end>start);
vm.createContext(context);vm.runInContext('var '+text.slice(start,end)+';globalThis.Filter=jg;',context);
const f=new context.Filter();await f.init();assert.equal(nodes.get('sharpnessStyle').media,'none');assert.notEqual(matrices[0].kernelMatrix,'0 0 0 0 1 0 0 0 0');
stored.sharpnessEnabled=true;onChange({sharpnessEnabled:{newValue:true}},'sync');await new Promise(resolve=>setImmediate(resolve));assert.equal(nodes.get('sharpnessStyle').media,'all');assert.match(nodes.get('sharpnessStyle').textContent,/\.chzzk_player/);
stored.sharpnessMode='natural';await f.syncSettings();assert.match(nodes.get('sharpnessStyle').textContent,/sharp_natural/);
stored.settings.enabled=false;await f.syncSettings();assert.equal(nodes.get('sharpnessStyle').media,'none');
console.log('PASS safe buffer-only seek, recording no seek/capped rate, independent auto chase, stall recovery, filter realtime sync and non-neutral default');
