import './latency-controller.test.mjs';
