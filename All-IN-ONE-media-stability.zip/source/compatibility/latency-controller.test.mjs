import assert from 'node:assert/strict';
import {LatencyController} from './latency-controller.js';
import {installPlayerCompatibility} from './player-compat.js';
let now=100000;Date.now=()=>now;globalThis.location={pathname:'/live/test'};
const listeners=new Set();const events={addEventListener:(t,f)=>listeners.add(f),removeEventListener:(t,f)=>listeners.delete(f)};
globalThis.document={...events};
function fixture(){const v={...events,dataset:{},currentTime:71,playbackRate:1,readyState:4,paused:false,seeking:false,seekable:{length:1,start:()=>0,end:()=>100},buffered:{length:1,start:()=>0,end:()=>100}};const host={...events,contains:()=>true};return {v,c:new LatencyController(v,host)}}
const settings={enabled:true,targetLatency:3,chaserMode:'instant'};
let {v,c}=fixture();c.tick(settings);c.tick(settings);c.tick(settings);assert.equal(v.currentTime,97);assert.equal(c.gap(),3);assert.equal(c.status,'jumped');
c.tick(settings);assert.equal(v.playbackRate,1);c.dispose();
({v,c}=fixture());v.currentTime=94;c.tick({...settings,chaserMode:'gradual'});assert.equal(v.playbackRate,1.05);v.currentTime=97;c.tick({...settings,chaserMode:'gradual'});assert.equal(v.playbackRate,1);
v.currentTime=94;c.tick({...settings,chaserMode:'gradual'});c.tick({...settings,targetLatency:0});assert.equal(v.playbackRate,1);c.dispose();
({v,c}=fixture());v.paused=true;c.tick(settings);c.tick(settings);assert.equal(v.currentTime,71);v.paused=false;v.dataset.cqcTimeshifting='true';c.tick(settings);c.tick(settings);assert.equal(v.currentTime,71);c.dispose();
({v,c}=fixture());c.onPointer({isTrusted:true,target:{}});c.onSeeking();c.tick(settings);c.tick(settings);assert.equal(v.currentTime,71);assert.equal(c.status,'timeshift');assert.equal(c.goLive(3),true);assert.equal(v.currentTime,97);c.dispose();
({v,c}=fixture());v.playbackRate=1.5;c.tick(settings,1.5);assert.equal(v.playbackRate,1.5);c.dispose();assert.equal(v.playbackRate,1.5);
({v,c}=fixture());globalThis.location.pathname='/video/test';c.tick(settings);c.tick(settings);assert.equal(v.currentTime,71);globalThis.location.pathname='/live/test';c.dispose();
({v,c}=fixture());v.currentTime=94;v.buffered.end=()=>94.5;c.tick({...settings,chaserMode:'gradual'});assert.equal(v.playbackRate,1);c.dispose();assert.equal(listeners.size,0);
// A missing player/settings must fail safely; native low latency remains disabled.
class Stub {applyPreferred(){throw Error('quality')}changeQuality(){throw Error('quality')}forceLowLatency(){throw Error('mode')}onMessage(){throw Error('legacy message')}}
installPlayerCompatibility(Stub);const p=new Stub();let response;p.runtime={respond:(id,r)=>response=r};
assert.equal(await p.applyPreferred(),false);assert.equal((await p.changeQuality()).success,false);p.forceLowLatency();await p.onMessage('CHANGE_QUALITY',1080,1);assert.equal(response.success,false);await p.onMessage('FORCE_REAPPLY',null,2);assert.equal(response.success,false);
console.log('PASS: 29s -> 3s jump, gradual catchup, target restore/disable, pause/rewind, user seek, explicit go-live, manual speed, VOD, buffer protection, listeners cleanup, unconnected quality commands rejected.');
