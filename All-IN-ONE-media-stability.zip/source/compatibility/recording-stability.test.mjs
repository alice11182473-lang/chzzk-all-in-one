import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {LatencyController} from './latency-controller.js';
let now=100000;Date.now=()=>now;globalThis.location={pathname:'/live/test'};
globalThis.document=new EventTarget();
function fixture(){const video=Object.assign(new EventTarget(),{dataset:{},currentTime:92,playbackRate:1,readyState:4,paused:false,seeking:false,seekable:{length:1,start:()=>0,end:()=>100},buffered:{length:1,start:()=>0,end:()=>100}});const host=Object.assign(new EventTarget(),{contains:()=>true});return {v:video,c:new LatencyController(video,host)};}
const settings={enabled:true,targetLatency:1.5,chaserMode:'gradual',playbackSpeedResetOnLive:true};
for(const mode of ['gradual','instant']){
 const {v,c}=fixture();c.tick(settings);assert.ok(v.playbackRate>1);
 v.dataset.cqcRecording='true';v.dispatchEvent(new Event('cqc-recording-start'));
 assert.equal(v.playbackRate,1,'recording start must release catch-up immediately');
 for(let i=0;i<120;i++){now+=1000;c.tick({...settings,chaserMode:mode});assert.equal(v.playbackRate,1);assert.equal(v.currentTime,92);assert.equal(c.status,'recording-stable');}
 delete v.dataset.cqcRecording;c.tick(settings);assert.equal(v.playbackRate,1);assert.equal(c.status,'buffer-recovery');
 now+=9999;c.tick(settings);assert.equal(v.playbackRate,1);
 now+=1;c.tick(settings);assert.ok(v.playbackRate>1,'resume saved catch-up after recovery');c.dispose();
}
const {v,c}=fixture();v.playbackRate=1.25;v.dataset.cqcRecording='true';c.tick(settings,1.25);assert.equal(v.playbackRate,1.25,'preserve explicitly selected manual speed');c.dispose();
for(const p of ['../../chzzk-compat/assets/content.ts.js','../../chzzk-compat/assets/auto-record.js'])assert.match(readFileSync(new URL(p,import.meta.url),'utf8'),/cqc-recording-start/);
assert.equal(readFileSync(new URL('./latency-controller.js',import.meta.url),'utf8'),readFileSync(new URL('../../chzzk-compat/assets/latency-controller.js',import.meta.url),'utf8'));
console.log('PASS recording: immediate 1x restore, no rate/seek for both modes, 10s post-stop cooldown, manual speed preserved, shipped hooks');
