import assert from 'node:assert/strict';
import {installPlayerCompatibility} from './player-compat.js';
const noop=()=>{};let monitor,poll;
globalThis.setInterval=f=>(monitor=f,1);globalThis.clearInterval=noop;
globalThis.document={addEventListener:noop,removeEventListener:noop};
globalThis.location={pathname:'/live/'+'a'.repeat(32)};
const host={addEventListener:noop,removeEventListener:noop,contains:()=>false,querySelectorAll:()=>[]};
function video(){return {readyState:4,isConnected:true,closest:q=>q==='.pzp'?host:null,parentElement:host,buffered:{length:0},seekable:{length:0},playbackRate:1,videoHeight:1080,videoWidth:1920,addEventListener:noop,removeEventListener:noop,getBoundingClientRect:()=>({width:1000,height:600})};}
let current=video();document.querySelectorAll=()=>[current];document.querySelector=()=>current;
class Player{constructor(){this.runtime={settings:{enabled:true},state:{},post:noop};}reset(){this.stopMonitor();}stopPoll(){}initPlayer(){return false;}startPoll(){poll=true;}hasPlayer(){return true;}cleanup(){this.stopMonitor();}}
installPlayerCompatibility(Player);const p=new Player();
assert.equal(p.initPlayer(),true);assert.equal(p.exportState().ready,true);assert.equal(p.exportState().capabilities.internalTrackControl,false);
const first=current;first.isConnected=false;current=video();monitor();
assert.equal(p.cqcModern,null);monitor(); // poll reconnects without .chzzk_player or SDK
assert.equal(p.cqcModern.video,current);assert.equal(p.exportState().ready,true);
// SDK/ref on new ancestor fiber is discovered after remount.
const ref={getSelectedVideoTrack:()=>({height:720}),getVolume:()=>1};
const store={dispatch:noop,_actions:{selectVideoTrack:[]}};
host.__reactFiber$test={ref:{current:ref},memoizedState:{memoizedState:{_view:{_store:store}}}};
monitor();assert.equal(p.cqcModern.store,store);assert.equal(p.cqcModern.ref,ref);
p.cleanup();console.log('PASS wide remount native fallback, replacement video reconnect, later React SDK discovery');
