import assert from 'node:assert/strict';
import {installPlayerCompatibility} from './player-compat.js';
class Player {constructor(){this.runtime={settings:{enabled:true,autoQuality:true,preferredQuality:1080},state:{}};}}
installPlayerCompatibility(Player);
const p=new Player();let calls=0;
const tracks=[{id:'720-native',height:720,selected:true},{id:'1080-native',height:1080,selected:false}];
const video={isConnected:true};
const store={getters:{videoTracks:tracks},dispatch(action,id){assert.equal(action,'selectVideoTrack');assert.equal(id,'1080-native');calls++;tracks.forEach(t=>t.selected=t.id===id);}};
p.cqcModern={video,store,sdk:{videoTracks:tracks},ref:{getSelectedVideoTrack:()=>tracks.find(t=>t.selected)},host:{querySelectorAll:()=>[]}};
assert.equal(await p.applyPreferred(),true);assert.equal(calls,1);
assert.equal(await p.applyPreferred(),false);assert.equal(calls,1);
assert.equal((await p.changeQuality(1080,true)).success,true);assert.equal(calls,1);
assert.equal((await p.changeQuality(480)).success,false);assert.equal(calls,1);
assert.equal(p.getAvailable().length,2);
p.runtime.settings.autoQuality=false;p.cqcQualityAttempt=null;
assert.equal(await p.applyPreferred(),false);
console.log('PASS: native ID dispatch, confirmation, no duplicate automatic switch, unchanged target, unsupported resolution, disabled setting');
