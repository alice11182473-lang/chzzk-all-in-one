import assert from 'node:assert/strict';
import {openWithWarmup} from './tab-warmup.js';
let now=0;Date.now=()=>now;
function fixture({recording=true,interrupt=false,timeout=false}={}){
 let listener,active=1,polls=0;const updates=[];
 const api={tabs:{onActivated:{addListener:f=>listener=f,removeListener:f=>{assert.equal(f,listener);listener=null;}},query:async q=>q.active?[{id:1,windowId:10}]:[],create:async()=>{active=2;return {id:2,windowId:10};},get:async id=>({id,active:id===active}),update:async(id)=>{active=id;updates.push(id);listener?.({tabId:id,windowId:10});},sendMessage:async()=>{polls++;if(interrupt){active=3;listener({tabId:3,windowId:10});}return {playing:!timeout,recording:!timeout&&recording};}}};
 return {api,updates,wait:async()=>{now+=500;},polls:()=>polls,clean:()=>listener===null};
}
let f=fixture();assert.equal((await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,returnToPrevious:true,wait:f.wait})).status,'ready');assert.deepEqual(f.updates,[1]);assert.ok(f.clean());
f=fixture({interrupt:true});await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,returnToPrevious:true,wait:f.wait});assert.deepEqual(f.updates,[],'never steal focus back after user switched');assert.ok(f.clean());
f=fixture({timeout:true});assert.equal((await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,returnToPrevious:true,timeoutMs:1000,wait:f.wait})).status,'timeout');assert.deepEqual(f.updates,[1]);
f=fixture({recording:false});assert.equal((await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,returnToPrevious:true,timeoutMs:1000,wait:f.wait})).status,'timeout','playing alone is insufficient when recording requested');
f=fixture({recording:false});assert.equal((await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:false,returnToPrevious:true,wait:f.wait})).status,'ready');
console.log('PASS A: restore after confirmed startup, user choice preserved, bounded timeout, recording readiness required');

f=fixture();await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,wait:f.wait});assert.deepEqual(f.updates,[],'default must remain on broadcast');assert.ok(f.clean());
f=fixture();await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,returnToPrevious:false,wait:f.wait});assert.deepEqual(f.updates,[],'explicit OFF must not restore');
f=fixture({timeout:true});await openWithWarmup(f.api,'https://chzzk.naver.com/live/a',{record:true,timeoutMs:1000,wait:f.wait});assert.deepEqual(f.updates,[],'OFF must not restore on timeout');
const {n:parse}=await import('../../INSTALL-THIS/assets/settings-schema.js');assert.equal(parse({}).liveAutoOpenReturnToPrevious,false);assert.equal(parse({liveAutoOpenReturnToPrevious:true}).liveAutoOpenReturnToPrevious,true);
console.log('PASS default OFF, explicit OFF, OFF on timeout, schema persistence; previous ON/interaction tests retained');
