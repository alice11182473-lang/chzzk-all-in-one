import {test} from 'node:test';import assert from 'node:assert/strict';
import {typedRecordingBlob} from './recording-storage.js';
import {watchRecordingOutput,stopRecordingCapture} from './recording-engine.js';
test('disk file gets explicit video MIME without reading whole recording',async()=>{
 for(const [ext,type] of [['webm','video/webm'],['mp4','video/mp4'],['mkv','video/x-matroska']]){
  const source=new Blob([new Uint8Array([0x1a,0x45,0xdf,0xa3])]);const result=typedRecordingBlob(source,`chzzk_test.${ext}`);
  assert.equal(result.type,type);assert.deepEqual(await result.arrayBuffer(),await source.arrayBuffer());
 }
 let sliced=false;typedRecordingBlob({size:7300378484,slice(start,end,type){assert.equal(start,0);assert.equal(end,7300378484);assert.equal(type,'video/webm');sliced=true;return {};},arrayBuffer(){throw Error('must not materialize entire recording');}},'chzzk_test.webm');assert.ok(sliced);
});
test('stalled playback releases capture even while recording bytes keep arriving',()=>{
 let now=0,tick,released=0,stops=0,errors=0;
 const video={currentTime:100,paused:false,ended:false,seeking:false,readyState:2,buffered:{length:1,start:()=>99,end:()=>116}};
 const rec=Object.assign(new EventTarget(),{state:'recording',stream:{getTracks:()=>[{stop(){released++;}}]},stop(){stops++;this.state='inactive';},requestData(){}});
 watchRecordingOutput(rec,()=>errors++,{video,now:()=>now,schedule:fn=>(tick=fn,1),cancel(){}});
 for(let i=0;i<7;i++){now+=5000;const e=new Event('dataavailable');e.data={size:100};rec.dispatchEvent(e);tick();}
 assert.equal(errors,1);assert.equal(stops,1);assert.equal(released,1);
});
test('intentional pause, seek, network buffer shortage and progressing playback do not trip guard',()=>{
 for(const mode of ['paused','seeking','empty','progress']){
  let now=0,tick,stops=0;const v={currentTime:100,paused:mode==='paused',ended:false,seeking:mode==='seeking',readyState:2,buffered:{length:1,start:()=>0,end:()=>v.currentTime+(mode==='empty'?0.2:5)}};
  const rec=Object.assign(new EventTarget(),{state:'recording',stop(){stops++;},requestData(){}});
  const cleanup=watchRecordingOutput(rec,()=>{}, {video:v,now:()=>now,schedule:fn=>(tick=fn,1),cancel(){}});
  for(let i=0;i<30;i++){now+=5000;if(mode==='progress')v.currentTime+=5;const e=new Event('dataavailable');e.data={size:1};rec.dispatchEvent(e);tick();}assert.equal(stops,0,mode);cleanup();
 }
});
test('manual stop releases capture immediately, without waiting for stop event',()=>{
 let released=false;stopRecordingCapture({state:'recording',stop(){},stream:{getTracks:()=>[{stop(){released=true;}}]}});assert.ok(released);
});
test('download intent overrides guessed .txt and retains configured folder',async()=>{
 const values={},events={};let result;
 const storage={get:async k=>({[k]:values[k]}),set:async data=>Object.assign(values,data),remove:async k=>delete values[k]};
 const url='blob:https://chzzk.naver.com/known-recording';
 globalThis.chrome={storage:{session:storage,local:{get:async()=>({cqcRecordingFolder:'녹화'})}},runtime:{onMessage:{addListener:fn=>events.message=fn}},downloads:{onDeterminingFilename:{addListener:fn=>events.name=fn},onChanged:{addListener:fn=>events.change=fn},download:async opts=>{await new Promise(resolve=>events.name({url:opts.url,filename:'download.txt'},suggestion=>{result=suggestion;resolve();}));return 7;},search:async()=>[{url,state:'complete'}]}};
 await import('./recording-downloads.js?regression43');
 const response=await new Promise(resolve=>events.message({type:'CQC_DISK_RECORD_DOWNLOAD',url,filename:'chzzk_record.webm'},{tab:{id:1},url:'https://chzzk.naver.com/live/test'},resolve));
 assert.equal(response.id,7);assert.equal(result.filename,'녹화/chzzk_record.webm');
 events.change({id:7,state:{current:'complete'}});await new Promise(r=>setImmediate(r));assert.equal(Object.keys(values).length,0);delete globalThis.chrome;
});
