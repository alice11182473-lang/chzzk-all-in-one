import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const bundle = fs.readFileSync(new URL('../../INSTALL-THIS/injected.js', import.meta.url), 'utf8');
const start = bundle.indexOf('gt=class{'), end = bundle.indexOf(',re=new gt', start);
assert(start > 0 && end > start);
let resolveCount;
const count = new Promise(resolve => {resolveCount = resolve;});
const timers = [], events = [];
const context = vm.createContext({
  I: {getKV: () => count}, p: {VIDEO_INFO_DATA: 'info', PLAYER: 'player'},
  window: {dispatchEvent: event => events.push(event.detail)},
  CustomEvent: class {constructor(type, options) {this.type = type;this.detail = options.detail;}},
  document: {querySelector: () => null, getElementById: () => null},
  Ee: () => '', ct: () => false, fe: 'overlay',
  setTimeout: fn => timers.push(fn)
});
vm.runInContext('var ' + bundle.slice(start, end) + ';var ui=new gt;var initial=ui.renderStatus(0,true,"channel",true,false);ui.renderStatus(0,true,"channel",false,false);', context);
resolveCount(0);
await context.initial;
assert.equal(events.length, 0, 'an obsolete async green result must not be painted');
vm.runInContext('var latest;var render=ui.renderStatus.bind(ui);ui.renderStatus=(...args)=>(latest=render(...args));', context);
timers.shift()();
await context.latest;
assert.equal(events.at(-1).isFarming, false, 'latest waiting state is replayed without waiting for the three-second polling loop');
vm.runInContext('ui.renderStatus(0,true,"channel",true,false);ui.renderStatus(0,false,"channel",false,false);', context);
timers.shift()();
await context.latest;
assert.equal(events.at(-1).isPowerEnabled, false, 'a pending disable is not overwritten by a previous playing state');
console.log('PASS async status rendering retains latest update and discards obsolete results');
