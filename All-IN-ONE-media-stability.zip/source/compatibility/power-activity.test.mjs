import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../power-activity.js', import.meta.url), 'utf8');
const install = fs.readFileSync(new URL('../../INSTALL-THIS/power-activity.js', import.meta.url), 'utf8');
assert.equal(install, source);
const A = 'a'.repeat(32), B = 'b'.repeat(32);
const watchURL = 'https://api.chzzk.naver.com/polling/v1/watch-event/live';
let now = 1_000_000;
const store = new Map(), tabs = [];
class FakeSocket extends EventTarget {
  static OPEN = 1;
  constructor(url) { super(); this.url = url; }
  send(value) { this.sent = value; }
  receive(data) { this.dispatchEvent(Object.assign(new Event('message'), {data})); }
}
function makeTab(id, blockedStorage = false) {
  const window = new EventTarget();
  window.top = window;
  class XHR extends EventTarget {
    open(...args) { this.openArgs = args; }
    send(body) { this.body = body; }
    finish(status = 200, response = {code: 200, content: null}) {
      this.status = status;
      this.responseText = JSON.stringify(response);
      this.dispatchEvent(new Event('loadend'));
    }
  }
  window.WebSocket = FakeSocket;
  window.XMLHttpRequest = XHR;
  const requests = [];
  window.fetch = (...args) => {
    const response = new Response(JSON.stringify({code: 200}), {status: 200});
    const promise = Promise.resolve(response);
    requests.push({args, promise, response});
    return promise;
  };
  const location = {pathname: '/live/' + id, href: 'https://chzzk.naver.com/live/' + id};
  const localStorage = {
    getItem(key) { if (blockedStorage) throw Error('blocked'); return store.get(key) ?? null; },
    setItem(key, value) {
      if (blockedStorage) throw Error('blocked');
      const oldValue = store.get(key) ?? null;
      store.set(key, value);
      for (const tab of tabs) if (tab.window !== window) tab.window.dispatchEvent(Object.assign(new Event('storage'), {key, newValue: value, oldValue}));
    }
  };
  const context = vm.createContext({window, location, localStorage, URL, Event, Date: class extends Date {static now() {return now;}}});
  vm.runInContext(source, context);
  const tab = {window, location, requests, context, active: () => window.__cqcPowerActivity.isFarming(id)};
  tab.heartbeat = (type = 'WATCH_CONTINUED', overrides = {}, status = 200, json) => {
    const xhr = new window.XMLHttpRequest();
    xhr.open('POST', watchURL, true);
    const body = JSON.stringify({channelId: id, payload: {watchEventType: type}, autoPlay: false, radioMode: false, ...overrides});
    xhr.send(body);
    assert.equal(xhr.body, body);
    assert.deepEqual(xhr.openArgs, ['POST', watchURL, true]);
    xhr.finish(status, json);
    return xhr;
  };
  tab.socket = new window.WebSocket('wss://comm-api.game.naver.com/socket.io/1/websocket/session');
  tabs.push(tab);
  return tab;
}
const message = (id, type = 'WATCH_5_MIN') => ({type: 'LOG_POWER', subType: 'SAVE', channelId: id, data: {claimType: type, amount: 10}});
const modern = data => '42' + JSON.stringify(['personalMessage', JSON.stringify(data)]);
const legacy = data => '5:::' + JSON.stringify({name: 'personalMessage', args: [JSON.stringify(data)]});

const a = makeTab(A), b = makeTab(B);
a.heartbeat(); b.heartbeat();
assert.equal(a.active(), false); assert.equal(b.active(), false);
for (const type of ['focus', 'play', 'click']) b.window.dispatchEvent(new Event(type));
assert.equal(b.active(), false, 'playing/focus/heartbeat alone never establish earning');
for (const type of ['FOLLOW', 'DONATE', 'WATCH_1_HOUR']) a.socket.receive(modern(message(A, type)));
assert.equal(a.active(), false, 'non-periodic gains and delayed claims must not claim earning');
a.socket.receive(modern(message(A)));
assert.equal(a.active(), true); assert.equal(b.active(), false);
assert.equal(b.window.__cqcPowerActivity.isFarming(A), false, 'another route cannot inherit the active badge');
b.window.dispatchEvent(new Event('focus'));
assert.equal(a.active(), true, 'a hidden earning tab stays active');
assert.equal(b.active(), false);
assert.equal(a.socket instanceof FakeSocket, true);
assert.equal(a.window.WebSocket.OPEN, 1);
a.socket.send('unchanged'); assert.equal(a.socket.sent, 'unchanged');

now += 30_000;
a.heartbeat(); b.heartbeat();
b.socket.receive(legacy(message(B)));
assert.equal(a.active(), false); assert.equal(b.active(), true, 'actual reward in B switches both tabs');
b.heartbeat('WATCH_PAUSED'); assert.equal(b.active(), false);
b.heartbeat('WATCH_RESUMED'); assert.equal(b.active(), true);
b.heartbeat('WATCH_CONTINUED', {radioMode: true}); assert.equal(b.active(), false);
b.heartbeat('WATCH_CONTINUED', {autoPlay: true}); assert.equal(b.active(), false);
b.heartbeat('WATCH_CONTINUED', {}, 200, {code: 401}); assert.equal(b.active(), false);
b.heartbeat('WATCH_CONTINUED', {}, 503); assert.equal(b.active(), false);
b.heartbeat(); assert.equal(b.active(), true);
const reloaded = makeTab(B);
assert.equal(reloaded.active(), false, 'a reopened tab waits for its own live heartbeat');
reloaded.heartbeat(); assert.equal(reloaded.active(), true, 'confirmed channel is shared across reload');
reloaded.location.pathname = '/video/123'; assert.equal(reloaded.active(), false);
reloaded.location.pathname = '/live/' + B + '/chat'; assert.equal(reloaded.active(), false);
reloaded.location.pathname = '/live/' + B;
now += 90_001;
assert.equal(b.active(), false, 'stopped native heartbeats expire');
b.heartbeat(); assert.equal(b.active(), true);
now += 270_000;
b.heartbeat(); assert.equal(b.active(), false, 'expired reward confirmation cannot stay green forever');

const foreign = new b.window.WebSocket('wss://example.com/socket');
foreign.receive(modern(message(B))); assert.equal(b.active(), false);
for (const raw of ['LOG_POWER malformed', modern({...message(B), subType: 'PREDICTION_EVENT_COMPLETION'}),
  modern({...message(B), channelId: '<img>'}), '42' + JSON.stringify(['chat', message(B)])]) b.socket.receive(raw);
assert.equal(b.active(), false);
b.socket.receive(modern(message(B))); assert.equal(b.active(), true);
const nativeCtor = b.window.WebSocket;
vm.runInContext(source, b.context); assert.equal(b.window.WebSocket, nativeCtor, 'installation is idempotent');

const requestBody = JSON.stringify({channelId: B, payload: {watchEventType: 'WATCH_CONTINUED'}, radioMode: true});
const result = b.window.fetch(watchURL, {method: 'POST', body: requestBody});
const request = b.requests.at(-1);
assert.equal(result, request.promise, 'site receives its original fetch promise');
await new Promise(resolve => setTimeout(resolve, 20));
assert.equal(b.active(), false, 'fetch heartbeat path also observes radio mode');
assert.deepEqual(await request.response.json(), {code: 200}, 'observing a clone does not consume the site response');
assert.equal(request.args[1].body, requestBody);
const isolated = makeTab(A, true);
isolated.heartbeat(); isolated.socket.receive(legacy(message(A)));
assert.equal(isolated.active(), true, 'blocked storage does not break the local observer or native socket');

// Exercise the actual install bundle's manager decision, not a mirrored formula.
const bundle = fs.readFileSync(new URL('../../INSTALL-THIS/injected.js', import.meta.url), 'utf8');
const start = bundle.indexOf('vt=class{'), end = bundle.indexOf(',ke=new vt', start);
let farming = null;
const managerContext = vm.createContext({
  location: a.location, window: a.window,
  document: {querySelector: () => ({paused: false, ended: false})},
  re: {renderStatus: (_count, _enabled, _id, active) => {farming = active;}}
});
vm.runInContext('var ' + bundle.slice(start, end) + ';var manager=new vt;manager.updateUI();', managerContext);
assert.equal(farming, false, 'bundle refuses a playing channel without fresh confirmed earning');
now += 3000; a.heartbeat(); a.socket.receive(modern(message(A)));
vm.runInContext('manager.updateUI()', managerContext); assert.equal(farming, true);
vm.runInContext('manager.updateUI({enabled:false,powerClickEnabled:true})', managerContext); assert.equal(farming, false);
assert.equal(bundle.includes('LEADER_CLAIM'), false);
assert.equal((bundle.match(/벌목대기중/g) || []).length, 2, 'badge, overlay and React toolbar use waiting text');
const css = fs.readFileSync(new URL('../../INSTALL-THIS/assets/db.css', import.meta.url), 'utf8');
assert.match(css, /\.cqc-power-status-text\.is-idle\{color:var\(--cqc-power-text-muted\)/);
for (const path of ['../manifest.json', '../../INSTALL-THIS/manifest.json']) {
  const manifest = JSON.parse(fs.readFileSync(new URL(path, import.meta.url), 'utf8'));
  assert(manifest.content_scripts.some(s => s.js?.includes('power-activity.js') && s.run_at === 'document_start' && s.world === 'MAIN'));
}
console.log('PASS confirmed watch rewards, two tabs, hidden tab, reload, radio/preview/pause, expiry, unchanged networking, compiled UI and grey waiting style');
