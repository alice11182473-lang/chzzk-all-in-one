import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source = fs.readFileSync(new URL('../power-activity.js', import.meta.url), 'utf8');
assert.equal(source, fs.readFileSync(new URL('../../INSTALL-THIS/power-activity.js', import.meta.url), 'utf8'));
const A = 'a'.repeat(32), B = 'b'.repeat(32);
const watchURL = 'https://api.chzzk.naver.com/polling/v1/watch-event/live';
const flush = () => new Promise(resolve => setTimeout(resolve, 10));
const reward = (id, type = 'WATCH_5_MIN') => ({type: 'LOG_POWER', subType: 'SAVE', channelId: id, data: {claimType: type}});
const modern = data => '42' + JSON.stringify(['personalMessage', JSON.stringify(data)]);
const legacy = data => '5:::' + JSON.stringify({name: 'personalMessage', args: [JSON.stringify(data)]});
function world() {
  let now = 1_000_000, serial = 0, writes = 0;
  const store = new Map(), tabs = [], buses = [];
  function makeTab(id, {storage = true, broadcast = true, focused = false} = {}) {
    const window = new EventTarget(); window.top = window;
    const document = {visibilityState: focused ? 'visible' : 'hidden', focused, hasFocus() {return this.focused;}};
    const location = {pathname: '/live/' + id, href: 'https://chzzk.naver.com/live/' + id};
    class Socket extends EventTarget {
      static OPEN = 1;
      constructor(url) {super();this.url = url;}
      send(data) {this.sent = data;}
      receive(data) {this.dispatchEvent(Object.assign(new Event('message'), {data}));}
    }
    class XHR extends EventTarget {
      open(...args) {this.openArgs = args;}
      send(body) {this.body = body;}
      finish(status = 200, json = {code: 200}) {this.status = status;this.responseText = JSON.stringify(json);this.dispatchEvent(new Event('loadend'));}
    }
    class Bus {
      constructor(name) {this.name = name; buses.push(this);}
      postMessage(data) {for (const other of buses) if (other !== this && other.name === this.name) queueMicrotask(() => other.onmessage?.({data: structuredClone(data)}));}
    }
    const emitStorage = (key, value, oldValue) => {
      for (const tab of tabs) if (tab.window !== window && tab.storage) queueMicrotask(() => tab.window.dispatchEvent(Object.assign(new Event('storage'), {key, newValue: value, oldValue})));
    };
    const localStorage = {
      getItem(key) {if (!storage) throw Error('blocked');return store.get(key) ?? null;},
      setItem(key, value) {if (!storage) throw Error('blocked');const old = store.get(key) ?? null;if (old === value) return;store.set(key, value);writes++;emitStorage(key, value, old);},
      removeItem(key) {if (!storage) throw Error('blocked');const old = store.get(key);if (store.delete(key)) emitStorage(key, null, old);},
      key(i) {return [...store.keys()][i];},
      get length() {if (!storage) throw Error('blocked');return store.size;}
    };
    const requests = [];
    window.WebSocket = Socket; window.XMLHttpRequest = XHR;
    window.fetch = (...args) => {const response = new Response('{"code":200}');const promise = Promise.resolve(response);requests.push({args, response, promise});return promise;};
    const context = vm.createContext({window, document, location, localStorage, URL, Event,
      Date: class extends Date {static now() {return now;}}, crypto: {randomUUID: () => 'tab-' + (++serial)},
      ...(broadcast ? {BroadcastChannel: Bus} : {})});
    vm.runInContext(source, context);
    const activity = window.__cqcPowerActivity;
    const tab = {window, document, location, storage, context, requests, activity, playing: true, enabled: true, id,
      state: () => activity.getStatus(id), active: () => activity.isFarming(id),
      report() {activity.updatePlayback({channelId: this.id, enabled: this.enabled, playing: this.playing});},
      focus(value) {document.focused = value; document.visibilityState = value ? 'visible' : 'hidden';this.report();},
      heartbeat(type = 'WATCH_CONTINUED', options = {}, status = 200, json) {
        const xhr = new window.XMLHttpRequest();xhr.open('POST', watchURL, true);
        const body = JSON.stringify({channelId: this.id, payload: {watchEventType: type}, autoPlay: false, radioMode: false, ...options});
        xhr.send(body);assert.equal(xhr.body, body);assert.deepEqual(xhr.openArgs, ['POST', watchURL, true]);xhr.finish(status, json);return xhr;
      },
      close() {window.dispatchEvent(new Event('pagehide'));}
    };
    tab.socket = new window.WebSocket('wss://comm-api.game.naver.com/socket.io/1/websocket/session');
    window.addEventListener('cqc-power-activity-change', () => {if (!tab.frozen) tab.report();});
    tabs.push(tab);
    return tab;
  }
  return {makeTab, advance: ms => {now += ms;}, store, writes: () => writes};
}
const w = world(), a = w.makeTab(A, {focused: true}), b = w.makeTab(B);
a.report();assert.equal(a.state(), 'estimated', 'first playing channel appears without waiting for any reward or heartbeat');
b.report();await flush();assert.equal(a.active(), true);assert.equal(b.active(), false);
assert.match(a.activity.getStatusTitle(), /확인 전/);
w.advance(100);a.focus(false);b.focus(true);await flush();
assert.equal(a.active(), false);assert.equal(b.state(), 'estimated', 'focus changes the unconfirmed choice immediately');
b.focus(false);await flush();assert.equal(b.active(), true, 'leaving CHZZK for an unrelated tab keeps the background channel selected');
b.playing = false;b.report();await flush();assert.equal(a.active(), true);assert.equal(b.active(), false, 'pause releases the estimated channel immediately');
b.playing = true;w.advance(100);b.report();await flush();assert.equal(b.active(), true);
a.heartbeat();b.heartbeat();a.socket.receive(modern(reward(A)));await flush();
assert.equal(a.state(), 'confirmed');assert.equal(b.active(), false, 'actual earning overrides an incorrect immediate estimate');
assert.match(a.activity.getStatusTitle(), /확인된 채널/);
b.focus(true);await flush();assert.equal(a.active(), true, 'focus never steals a still-playing confirmed channel');
for (const type of ['FOLLOW', 'DONATE', 'WATCH_1_HOUR']) b.socket.receive(modern(reward(B, type)));
await flush();assert.equal(a.state(), 'confirmed');assert.equal(b.active(), false);
w.advance(100);b.socket.receive(legacy(reward(B)));await flush();assert.equal(a.active(), false);assert.equal(b.state(), 'confirmed');
b.heartbeat('WATCH_PAUSED');await flush();assert.equal(b.active(), false);assert.equal(a.state(), 'estimated');
b.heartbeat('WATCH_RESUMED');await flush();assert.equal(b.state(), 'confirmed');
b.heartbeat('WATCH_CONTINUED', {radioMode: true});await flush();assert.equal(b.active(), false);
b.heartbeat('WATCH_CONTINUED', {autoPlay: true});await flush();assert.equal(b.active(), false);
b.heartbeat('WATCH_CONTINUED', {}, 200, {code: 401});await flush();assert.equal(b.active(), false);
b.heartbeat('WATCH_CONTINUED', {}, 503);await flush();assert.equal(b.active(), false);
b.heartbeat();await flush();assert.equal(b.state(), 'confirmed');
b.close();await flush();assert.equal(a.active(), true, 'closing the active tab releases it without a five-minute wait');
const reload = w.makeTab(B);reload.report();await flush();assert.equal(reload.state(), 'confirmed', 'reopening a confirmed channel needs no new reward');
reload.location.pathname = '/video/123';reload.report();await flush();assert.equal(reload.active(), false);
reload.location.pathname = '/live/' + B + '/chat';reload.report();await flush();assert.equal(reload.active(), false);
reload.location.pathname = '/live/' + B;reload.report();await flush();assert.equal(reload.active(), true);
reload.enabled = false;reload.report();await flush();assert.equal(reload.active(), false);
reload.enabled = true;reload.report();await flush();assert.equal(reload.active(), true);
w.advance(6 * 60 * 1000 + 1);a.heartbeat();reload.heartbeat();reload.focus(true);await flush();
assert.equal(reload.state(), 'estimated', 'expired confirmation returns to immediate estimation, not mandatory waiting');
const before = w.writes();for (let i = 0; i < 20; i++) {a.report();reload.report();}await flush();
assert.equal(w.writes(), before, 'UI polling does not create a storage write or notification loop');
const ctor = reload.window.WebSocket;vm.runInContext(source, reload.context);assert.equal(reload.window.WebSocket, ctor);
assert.equal(ctor.OPEN, 1);assert.equal(reload.socket instanceof ctor, true);reload.socket.send('unchanged');assert.equal(reload.socket.sent, 'unchanged');
const raw = JSON.stringify({channelId: B, payload: {watchEventType: 'WATCH_CONTINUED'}, radioMode: true});
const promise = reload.window.fetch(watchURL, {method: 'POST', body: raw});const request = reload.requests.at(-1);
assert.equal(promise, request.promise);await flush();assert.equal(reload.active(), false);
assert.deepEqual(await request.response.json(), {code: 200});assert.equal(request.args[1].body, raw);

for (const options of [{storage: false}, {broadcast: false}]) {
  const x = world(), first = x.makeTab(A, options), second = x.makeTab(B, options);
  first.report();second.report();await flush();
  assert.equal(Number(first.active()) + Number(second.active()), 1, 'simultaneous starts agree with either sync mechanism');
  second.close();await flush();assert.equal(first.active(), true);
}
const x = world(), xa = x.makeTab(A, {focused: true}), xb = x.makeTab(B);
xa.report();xb.report();await flush();
const foreign = new xb.window.WebSocket('wss://example.com/socket');foreign.receive(modern(reward(B)));
for (const raw of ['LOG_POWER malformed', modern({...reward(B), channelId: '<img>'}), '42' + JSON.stringify(['chat', reward(B)])]) xb.socket.receive(raw);
await flush();assert.equal(xa.state(), 'estimated');assert.equal(xb.active(), false);
xa.frozen = true;x.advance(90001);xb.report();await flush();assert.equal(xb.active(), true, 'a crashed or frozen tab lease expires');

// Verify the actual shipped manager wires playback into the observer.
const bundle = fs.readFileSync(new URL('../../INSTALL-THIS/injected.js', import.meta.url), 'utf8');
const start = bundle.indexOf('vt=class{'), end = bundle.indexOf(',ke=new vt', start);
let farming = null;
const managerWorld = world(), live = managerWorld.makeTab(A, {focused: true});
const context = vm.createContext({location: live.location, window: live.window,
  document: {querySelector: () => ({paused: false, ended: false})},
  re: {renderStatus: (_count, _enabled, _id, active) => {farming = active;}}});
vm.runInContext('var ' + bundle.slice(start, end) + ';var manager=new vt;manager.updateUI();', context);
assert.equal(farming, true, 'compiled manager displays immediately before server confirmation');
vm.runInContext('manager.updateUI({enabled:false,powerClickEnabled:true})', context);assert.equal(farming, false);
assert.equal((bundle.match(/벌목대기중/g) || []).length, 2);
assert.equal((bundle.match(/getStatusTitle\(\)/g) || []).length, 2, 'both UI paths explain estimated and confirmed state');
const css = fs.readFileSync(new URL('../../INSTALL-THIS/assets/db.css', import.meta.url), 'utf8');
assert.match(css, /\.cqc-power-status-text\.is-idle\{color:var\(--cqc-power-text-muted\)/);
console.log('PASS immediate display, single-channel selection, pause/close/navigation/reload, background continuity, server correction, lease expiry, storage/BroadcastChannel fallback, unchanged requests and compiled UI');
