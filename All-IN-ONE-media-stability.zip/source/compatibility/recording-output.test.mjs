import {test} from 'node:test';import assert from 'node:assert/strict';
import {watchRecordingOutput,recordingExtension,monitorRecording,recordingDiagnostics} from './recording-engine.js';
test('continuous output never rotates or stops a long recording; stalled output is bounded',()=>{
 let now=0,tick,requests=0,stops=0,errors=0,cleared=0;
 const rec=Object.assign(new EventTarget(),{state:'recording',requestData(){requests++;},stop(){stops++;this.state='inactive';this.dispatchEvent(new Event('stop'));}});
 watchRecordingOutput(rec,()=>errors++,{now:()=>now,schedule:fn=>(tick=fn,1),cancel:()=>cleared++});
 for(let i=0;i<7200;i++){now+=2000;const e=new Event('dataavailable');e.data={size:2000000};rec.dispatchEvent(e);tick();}
 assert.equal(stops,0);assert.equal(requests,0);
 now+=10000;tick();assert.equal(requests,1);
 now+=50000;tick();assert.equal(stops,1);assert.equal(errors,1);assert.equal(cleared,1);
});
test('file extension matches H264 Matroska, WebM and MP4',()=>{assert.equal(recordingExtension('video/webm;codecs=h264,opus'),'mkv');assert.equal(recordingExtension('video/x-matroska;codecs=avc1,opus'),'mkv');assert.equal(recordingExtension('video/webm;codecs=vp8,opus'),'webm');assert.equal(recordingExtension('video/mp4;codecs=avc1'),'mp4');});
test('last diagnostics persist outside the page with queue and output stats',async()=>{
 let saved;
 globalThis.chrome={runtime:{getManifest:()=>({version:'1.4.9.42'})},storage:{local:{set:async data=>{saved=data;}}}};
 const video=Object.assign(new EventTarget(),{buffered:{length:0},dataset:{},playbackRate:1});
 const rec=new EventTarget();const cleanup=monitorRecording(video,rec,true,{stats:()=>({writtenBytes:2345678901,pendingBytes:0})});
 await new Promise(r=>setImmediate(r));
 assert.equal(saved.cqcLastRecordingDiagnostics.version,'1.4.9.42');assert.equal(saved.cqcLastRecordingDiagnostics.storage.writtenBytes,2345678901);
 cleanup();await new Promise(r=>setImmediate(r));assert.equal(recordingDiagnostics().status,'stopped');delete globalThis.chrome;
});
