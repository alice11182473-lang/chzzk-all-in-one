import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
import {installPlayerCompatibility} from './player-compat.js';
const timers=new Map();let next=0;
globalThis.setInterval=f=>{timers.set(++next,f);return next};globalThis.clearInterval=id=>timers.delete(id);
const noop=()=>{};globalThis.location={pathname:'/live/'+'a'.repeat(32)};
const host={addEventListener:noop,removeEventListener:noop,querySelectorAll:()=>[]};
const v={readyState:0,isConnected:true,closest:()=>host,parentElement:host,getBoundingClientRect:()=>({width:1000,height:600}),addEventListener:noop,removeEventListener:noop,buffered:{length:0},seekable:{length:0},playbackRate:1,videoWidth:1920,videoHeight:1080};
globalThis.document={querySelectorAll:()=>[v],querySelector:()=>v,addEventListener:noop,removeEventListener:noop};
let response;
class Player {
 constructor(){this.runtime={settings:{enabled:true},state:{ready:false},post:noop,respond:(id,state)=>response=state};}
 mount(){} // Simulates a missed initial navigation/poll.
 initPlayer(){return false;}
 exportState(){return {ready:false};}
 hasPlayer(){return true;}
 stopPoll(){}
 reset(){this.stopMonitor();this.runtime.state.ready=false;}
 cleanup(){this.stopMonitor();}
}
installPlayerCompatibility(Player);const p=new Player();p.mount();const recovery=timers.get(p.cqcRecoveryTimer);
assert.equal(p.runtime.state.ready,false);v.readyState=4;recovery();assert.equal(p.exportState().ready,true);
p.stopMonitor();assert.equal(p.monitorTimer,null);recovery();assert.ok(p.monitorTimer);
p.runtime.state.ready=false;await p.onMessage('REQUEST_STATE',null,42);assert.equal(response.ready,true);
const oldRecovery=p.cqcRecoveryTimer;p.mount();assert.equal(timers.has(oldRecovery),false);assert.equal(timers.size,2);
p.cleanup();assert.equal(timers.size,0);
// Exercise actual IPC source: a missed READY packet is repaired by continuous state,
// and popup queries get a fresh MAIN-world response rather than the stale cache.
let source=readFileSync(new URL('../src/modules/core/IpcModule.ts',import.meta.url),'utf8').replace(/^import .*;\s*$/gm,'').replace('export class IpcModule','class IpcModule');
const context={cqcLog:noop,location,window:{},BroadcastChannel:class{postMessage(){}},console};
vm.createContext(context);vm.runInContext(source+'\nglobalThis.IpcModule=IpcModule;',context);
const ipc=new context.IpcModule();ipc.handleWindowMessage({source:context.window,data:{direction:'CQC_TO_CONTENT',type:'PLAYER_STATE',payload:{ready:true}}});assert.equal(ipc.cachedState.ready,true);
ipc.cachedState={ready:false};ipc.send=async()=>({ready:true,resolution:'1920x1080'});let answer;
assert.equal(ipc.handleBackgroundMessage({type:'REQUEST_STATE'}, {}, s=>answer=s),true);await Promise.resolve();await Promise.resolve();assert.equal(answer.ready,true);assert.equal(ipc.cachedState.resolution,'1920x1080');
console.log('PASS delayed metadata recovery, lost-monitor recovery, live popup request, remount/cleanup, IPC cache repair');
