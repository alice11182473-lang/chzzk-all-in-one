(() => {
  if (window.top !== window) return;
  chrome.runtime.onMessage.addListener(message => {
    if (message.type === 'CQC_POWER_BACKGROUND_TICK')
      window.dispatchEvent(new Event('cqc-power-background-tick'));
  });
})();
