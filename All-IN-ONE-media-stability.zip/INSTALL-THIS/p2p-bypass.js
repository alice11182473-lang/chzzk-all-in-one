// ==UserScript==
// @name         Chzzk P2P Bypass
// @version      2.0.0.260918.6
// @description  Bypasses Grid (P2P), ads, anti-adblock popups, and quality limits.
// @author       NoCompromise
// @namespace    nocompromise
// @license      MIT
// @match        https://chzzk.naver.com/*
// @match        https://*.chzzk.naver.com/*
// @grant        none
// @run-at       document-start
// @inject-into  page
// @sandbox      raw
// @downloadURL https://update.greasyfork.org/scripts/565645/Chzzk%20P2P%20Bypass.user.js
// @updateURL https://update.greasyfork.org/scripts/565645/Chzzk%20P2P%20Bypass.meta.js
// ==/UserScript==
(() => {
  "use strict";

  const SCRIPT_NAME = "Chzzk P2P Bypass";
  const VERSION = "2.0.0.260918.6";
  const PREFIX = `[${SCRIPT_NAME}]`;
  const INSTALL_MARKER = Symbol.for("chzzk-p2p-bypass.installed");
  const ADGUARD_FILTER_MARKER = Symbol.for("chzzk-filter.runtime");
  const root = globalThis;

  const previousInstallation = root[INSTALL_MARKER];
  if (
    typeof previousInstallation === "string" ||
    previousInstallation?.status === "installing" ||
    previousInstallation?.status === "active"
  ) {
    return;
  }
  if (previousInstallation?.status === "failed") {
    delete root[INSTALL_MARKER];
  } else if (previousInstallation !== undefined) {
    throw new Error(`${PREFIX} installation marker collision.`);
  }

  const installation = Object.seal({
    failure: null,
    stage: "bootstrap",
    status: "installing",
    version: VERSION,
    startedAt: root.performance?.now?.() ?? null,
    documentReadyState: root.document?.readyState ?? null,
  });
  Object.defineProperty(root, INSTALL_MARKER, {
    configurable: true,
    value: installation,
  });

  const hasOwn = (value, key) =>
    Object.prototype.hasOwnProperty.call(value, key);
  const isObject = (value) => value !== null && typeof value === "object";
  const isRecord = (value) => isObject(value) && !Array.isArray(value);

  // Capture pristine functions before installing any hooks.
  const nativeJsonParse = JSON.parse;
  const nativeJsonStringify = JSON.stringify;
  const nativeAtob = root.atob?.bind(root);
  const utf8Decoder = new TextDecoder("utf-8", { fatal: true });
  const utf8Encoder = new TextEncoder();
  const enqueueMicrotask =
    typeof root.queueMicrotask === "function"
      ? root.queueMicrotask.bind(root)
      : (callback) => Promise.resolve().then(callback);

  const PLAYBACK_FIELDS = Object.freeze([
    "livePlaybackJson",
    "liveRewindPlaybackJson",
    "radioModePlaybackJson",
    "previewPlaybackJson",
    "playbackJson",
  ]);
  const PLAYBACK_FIELD_SET = new Set(PLAYBACK_FIELDS);
  const PLAYBACK_FIELD_PATTERN = /playbackJson$/i;
  const RESTRICTED_STATUSES = new Set([
    "PLAYABLE_LOW_RESOLUTION",
    "FORCE_LOW_RESOLUTION",
  ]);
  const TRUSTED_CDN_SUFFIXES = Object.freeze(["pstatic.net", "navercdn.com"]);
  const P2P_METADATA_KEYS = new Set([
    "p2p",
    "p2ppath",
    "p2ppathurlencoding",
    "p2pquality",
  ]);
  const EARLY_CONNECTION_ORIGINS = Object.freeze([
    "https://api.chzzk.naver.com",
    "https://chzzk-web-config.io.naver.com",
    "https://ssl.pstatic.net",
    "https://nvelop-livecloud.pstatic.net",
  ]);
  const TUNNEL_LABEL_PREFIX = utf8Encoder.encode("gfp-tunnel-response-");
  const TUNNEL_PROTOCOLS = Object.freeze([
    Object.freeze({
      aadLength: 40,
      algorithm: "AES-GCM",
      ivLength: 12,
      label: "gfp-tunnel-response-v1",
      labelBytes: utf8Encoder.encode("gfp-tunnel-response-v1"),
      tagLength: 128,
    }),
  ]);
  const MAX_TUNNEL_JSON_BYTES = 4 * 1024 * 1024;
  const PLAYBACK_REJECTION_EVENT = "AD_NOT_DISPLAYED";
  const PLAYBACK_ADVANCE_EVENT = "ui_ad_skip";
  const PLAYBACK_ROUTE = /^\/(?:live\/[0-9a-f]{32}|video\/\d+)(?:\/|$)/i;
  const stats = {
    jsonResponses: 0,
    lateStartupRecoveryAttempts: 0,
    lateStartupRecoveries: 0,
    startupRecoveryWindows: 0,
    startupRecoveryScans: 0,
    jsonTransformTimeMs: 0,
    responseTransformTimeMs: 0,
    tunnelDecrypts: 0,
    tunnelResponses: 0,
    tunnelTransformTimeMs: 0,
    maxTunnelTransformTimeMs: 0,
    tunnelFailures: 0,
    tunnelPassThroughs: 0,
    runtimeFailures: 0,
    jsonHookReleases: 0,
    directTracks: 0,
    adBlockFlags: 0,
    restrictions: 0,
    rejectedCdnUrls: 0,
    droppedTracks: 0,
    mockedAds: 0,
    blockedAdAudio: 0,
    blockedAdVolumeEvents: 0,
    blockedAdFailures: 0,
    advancedAds: 0,
    midrollCountdownsDetected: 0,
    midrollCountdownsAdvanced: 0,
    maxMidrollCountdownLatencyMs: 0,
    adAdvanceBindings: 0,
    adAdvanceAttempts: 0,
    nativeAdRateChanges: 0,
    nativeAdSeeks: 0,
    maxAdCompletionLatencyMs: 0,
    preconnectHints: 0,
    bitrateLimitsRemoved: 0,
    integritySignals: 0,
    hookRollbacks: 0,
    hookRollbackConflicts: 0,
    runtimeIssues: 0,
    unsupportedTunnelProtocols: 0,
    startupPlayAttempts: 0,
    startupPlayRecoveries: 0,
    startupPlayRejections: 0,
    discoveredPlaybackFields: 0,
    unsupportedRestrictions: 0,
  };
  const failures = [];
  const issues = [];
  const playbackIncidents = [];
  const MAX_ISSUE_KEYS = 256;
  const issueKeys = new Set();
  const preconnectedOrigins = new Map();
  let playbackAdvanceListeners;
  let playbackAdvanceGeneration = 0;
  const lifecycleCallbacks = Object.seal({
    reconcileAuxiliaryVideos: () => {},
    reconcilePrimaryPlayback: () => {},
    releaseJsonFallback: () => {},
  });
  const userMediaIntents = new WeakMap();
  const PLAYER_SCOPE_SELECTOR = ".pzp,[aria-label='video player']";

  const monotonicNow =
    typeof root.performance?.now === "function"
      ? root.performance.now.bind(root.performance)
      : Date.now;
  function recordTime(totalKey, maxKey, startedAt) {
    const elapsed = monotonicNow() - startedAt;
    stats[totalKey] += elapsed;
    if (maxKey) {
      stats[maxKey] = Math.max(stats[maxKey], elapsed);
    }
  }

  function preconnectOrigin(candidate) {
    if (!root.document) {
      return;
    }
    const url = new URL(candidate, location.href);
    const origin = url.origin;
    if (preconnectedOrigins.has(origin)) {
      return;
    }
    const parent = document.head || document.documentElement;
    if (!parent) {
      return;
    }
    const link = document.createElement("link");
    link.rel = "preconnect";
    link.href = origin;
    link.crossOrigin = "anonymous";
    parent.append(link);
    preconnectedOrigins.set(origin, link);
    hookRegistry.addCleanup(`preconnect:${origin}`, () => {
      if (preconnectedOrigins.get(origin) === link) {
        preconnectedOrigins.delete(origin);
        link.remove();
      }
    });
    stats.preconnectHints += 1;
  }

  function reportFailure(stage, error) {
    const normalized =
      error instanceof Error
        ? error
        : new Error(String(error ?? "unknown error"));
    stats.runtimeFailures += 1;
    failures.push(
      Object.freeze({
        stage,
        name: normalized.name,
        message: normalized.message,
        at: new Date().toISOString(),
      }),
    );
    if (failures.length > 20) {
      failures.shift();
    }
    console.error(PREFIX, `${stage} failed`, normalized);
    return normalized;
  }

  function reportIssue(stage, error, key = stage) {
    if (issueKeys.has(key)) {
      return;
    }
    issueKeys.add(key);
    if (issueKeys.size > MAX_ISSUE_KEYS) {
      issueKeys.delete(issueKeys.values().next().value);
    }
    const normalized =
      error instanceof Error
        ? error
        : new Error(String(error ?? "unknown issue"));
    stats.runtimeIssues += 1;
    issues.push(
      Object.freeze({
        stage,
        name: normalized.name,
        message: normalized.message,
        at: new Date().toISOString(),
      }),
    );
    if (issues.length > 20) {
      issues.shift();
    }
    console.warn(PREFIX, `${stage}: ${normalized.message}`);
  }

  function summarizeMediaSource(video) {
    const source = video.currentSrc || video.src || "";
    if (!source || source.startsWith("blob:")) {
      return source ? "blob:" : "";
    }
    try {
      const url = new URL(source, root.location?.href);
      return `${url.protocol}//${url.host}${url.pathname}`;
    } catch {
      return "invalid";
    }
  }

  function summarizeTimeRanges(ranges) {
    const result = [];
    for (let index = 0; index < ranges.length; index += 1) {
      result.push(
        Object.freeze({
          start: Number(ranges.start(index).toFixed(3)),
          end: Number(ranges.end(index).toFixed(3)),
        }),
      );
    }
    return Object.freeze(result);
  }

  function recordPlaybackIncident(type, video, detail = {}) {
    try {
      const incident = Object.freeze({
        type,
        route: currentPlaybackRoute(),
        source: summarizeMediaSource(video),
        currentTime: Number(video.currentTime.toFixed(3)),
        duration: Number.isFinite(video.duration)
          ? Number(video.duration.toFixed(3))
          : String(video.duration),
        paused: video.paused,
        ended: video.ended,
        seeking: video.seeking,
        readyState: video.readyState,
        networkState: video.networkState,
        error: video.error?.code ?? 0,
        buffered: summarizeTimeRanges(video.buffered),
        seekable: summarizeTimeRanges(video.seekable),
        detail: Object.freeze({ ...detail }),
        at: new Date().toISOString(),
      });
      playbackIncidents.push(incident);
      if (playbackIncidents.length > 20) {
        playbackIncidents.shift();
      }
      return incident;
    } catch (error) {
      reportFailure("Playback incident capture", error);
      return null;
    }
  }

  function createHookRegistry() {
    const entries = [];

    const descriptorMatches = (current, installed) =>
      Boolean(current) &&
      current.value === installed.value &&
      current.get === installed.get &&
      current.set === installed.set;

    const define = (target, key, descriptor, label) => {
      const previous = Object.getOwnPropertyDescriptor(target, key);
      if (previous && !previous.configurable) {
        throw new TypeError(`${label} is not configurable.`);
      }
      Object.defineProperty(target, key, descriptor);
      const entry = {
        descriptor,
        key,
        label,
        previous,
        released: false,
        target,
        type: "property",
      };
      entries.push(entry);
      return () => {
        if (entry.released) {
          return false;
        }
        const current = Object.getOwnPropertyDescriptor(target, key);
        if (!descriptorMatches(current, descriptor)) {
          return false;
        }
        if (previous) {
          Object.defineProperty(target, key, previous);
        } else {
          delete target[key];
        }
        entry.released = true;
        return true;
      };
    };

    const addCleanup = (label, cleanup) => {
      entries.push({ cleanup, label, type: "cleanup" });
    };

    const rollback = () => {
      for (let index = entries.length - 1; index >= 0; index -= 1) {
        const entry = entries[index];
        try {
          if (entry.type === "cleanup") {
            entry.cleanup();
            continue;
          }
          if (entry.released) {
            continue;
          }
          const current = Object.getOwnPropertyDescriptor(
            entry.target,
            entry.key,
          );
          if (!descriptorMatches(current, entry.descriptor)) {
            stats.hookRollbackConflicts += 1;
            continue;
          }
          if (entry.previous) {
            Object.defineProperty(entry.target, entry.key, entry.previous);
          } else {
            delete entry.target[entry.key];
          }
        } catch (error) {
          stats.hookRollbackConflicts += 1;
          console.error(PREFIX, `${entry.label} rollback failed`, error);
        }
      }
      stats.hookRollbacks += 1;
    };

    const health = () =>
      Object.freeze(
        entries
          .filter((entry) => entry.type === "property")
          .map((entry) => {
            const current = Object.getOwnPropertyDescriptor(
              entry.target,
              entry.key,
            );
            return Object.freeze({
              label: entry.label,
              state: entry.released
                ? "released"
                : descriptorMatches(current, entry.descriptor)
                  ? "direct"
                  : "superseded",
            });
          }),
      );

    return Object.freeze({ addCleanup, define, health, rollback });
  }

  const hookRegistry = createHookRegistry();
  const mediaEventHandlers = new Map();

  function addManagedEventListener(target, type, listener, options, label) {
    target.addEventListener(type, listener, options);
    hookRegistry.addCleanup(label ?? `${type} listener`, () =>
      target.removeEventListener(type, listener, options),
    );
  }

  function subscribeMediaEvents(eventNames, handler, label) {
    for (const eventName of eventNames) {
      let handlers = mediaEventHandlers.get(eventName);
      if (!handlers) {
        handlers = new Set();
        mediaEventHandlers.set(eventName, handlers);
      }
      handlers.add(handler);
    }
    hookRegistry.addCleanup(`${label} subscription`, () => {
      for (const eventName of eventNames) {
        mediaEventHandlers.get(eventName)?.delete(handler);
      }
    });
  }

  function installMediaEventHub() {
    if (!root.document) {
      return;
    }
    for (const [eventName, handlers] of mediaEventHandlers) {
      const dispatch = (event) => {
        for (const handler of handlers) {
          try {
            handler(event);
          } catch (error) {
            reportFailure(`Media event ${eventName}`, error);
          }
        }
      };
      addManagedEventListener(
        document,
        eventName,
        dispatch,
        true,
        `media:${eventName}`,
      );
    }
  }

  function installMediaIntentTracker() {
    if (!root.document || !root.Element) {
      return;
    }
    const mediaIntentSelector = [
      "video",
      "input[type='range']",
      "[role='slider']",
      "[data-role*='progress' i]",
      "[data-role*='seek' i]",
      "[data-role*='play' i]",
      "[data-role*='pause' i]",
      ".pzp-playback-switch",
      ".pzp-brand-playback-button",
      ".pzp-progress-slider",
      "pzp-progress-bar",
      "pzp-progress-slider",
    ].join(",");
    const recordMediaIntent = (target) => {
      const scope = target?.closest?.(PLAYER_SCOPE_SELECTOR);
      // A separate extension overlay or page slider has no implied owner.
      // Direct video input belongs to that video, even beside a native player.
      const directVideo = target?.closest?.("video");
      const preferred =
        scope?.querySelector("video[data-role='videoEl']") ??
        scope?.querySelector("video:not(.chzzk-p2p-bypass-auxiliary)");
      const video =
        directVideo ?? (preferred && findPrimaryPlaybackVideo(preferred));
      if (
        !video ||
        isAuxiliaryVideo(video) ||
        (scope && !scope.contains(video))
      ) {
        return;
      }
      userMediaIntents.set(video, {
        at: monotonicNow(),
        route: currentPlaybackRoute(),
      });
    };
    addManagedEventListener(
      document,
      "pointerdown",
      (event) => {
        const target = event.target;
        if (target instanceof Element && target.closest(mediaIntentSelector)) {
          recordMediaIntent(target);
        }
      },
      { capture: true, passive: true },
      "media intent pointer",
    );
    addManagedEventListener(
      document,
      "keydown",
      (event) => {
        const target = event.target;
        const toggleKey = ["k", "K", "ㅏ", " "].includes(event.key);
        // The official app handles these keys on window, outside the player
        // too. Modified keys and editing targets do not toggle its playback.
        if (
          toggleKey &&
          (event.ctrlKey ||
            event.altKey ||
            event.metaKey ||
            event.shiftKey ||
            !document.hasFocus())
        )
          return;
        if (
          target instanceof Element &&
          !target.closest(
            "input,textarea,select,pre,[contenteditable='true'],[contenteditable='']",
          ) &&
          [
            "ArrowLeft",
            "ArrowRight",
            "Home",
            "End",
            "j",
            "J",
            "k",
            "K",
            "ㅏ",
            "l",
            "L",
            " ",
          ].includes(event.key)
        ) {
          if (target.closest(PLAYER_SCOPE_SELECTOR)) {
            recordMediaIntent(target);
          } else if (toggleKey && currentPlaybackRoute()) {
            // A global key has no DOM player owner. Only a single designated
            // official main video is unambiguous; never select by area/order
            // among multiple players or borrow an extension's own HLS video.
            const candidates = document.querySelectorAll(
              "video[data-role='videoEl']",
            );
            if (candidates.length > 16) return;
            let owner = null;
            for (const video of candidates) {
              if (
                !video.closest(PLAYER_SCOPE_SELECTOR) ||
                isAuxiliaryVideo(video)
              )
                continue;
              if (owner) return;
              owner = video;
            }
            if (owner) recordMediaIntent(owner);
          }
        }
      },
      { capture: true, passive: true },
      "media intent keyboard",
    );
  }

  const hasRecentUserMediaIntent = (video) => {
    const intent = userMediaIntents.get(video);
    return Boolean(
      intent &&
      monotonicNow() - intent.at <= 2_000 &&
      intent.route === currentPlaybackRoute(),
    );
  };

  const currentPlaybackRoute = () => {
    const match = PLAYBACK_ROUTE.exec(root.location?.pathname ?? "");
    return match ? match[0].toLowerCase() : "";
  };
  function trustedCdnUrl(candidate) {
    try {
      const url = new URL(candidate);
      const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
      const trusted = TRUSTED_CDN_SUFFIXES.some(
        (suffix) => hostname === suffix || hostname.endsWith(`.${suffix}`),
      );

      if (
        url.protocol !== "https:" ||
        url.username ||
        url.password ||
        (url.port && url.port !== "443") ||
        !trusted
      ) {
        return null;
      }

      let bitrateLimitsRemoved = 0;
      if (/\.m3u8$/i.test(url.pathname)) {
        const restrictedKeys = [
          ...new Set(
            [...url.searchParams.keys()].filter(
              (key) => key.toLowerCase() === "max-bitrate",
            ),
          ),
        ];
        for (const key of restrictedKeys) {
          bitrateLimitsRemoved += url.searchParams.getAll(key).length;
          url.searchParams.delete(key);
        }
      }

      return Object.freeze({
        href: url.href,
        bitrateLimitsRemoved,
      });
    } catch {
      return null;
    }
  }

  function directUrlFromP2pPath(p2pPath) {
    if (typeof p2pPath !== "string" || !p2pPath || !nativeAtob) {
      return null;
    }

    try {
      const encoded = new URL(
        p2pPath,
        "https://chzzk.naver.com/",
      ).searchParams.get("cdn_url");
      if (!encoded) {
        return null;
      }

      const base64 = encoded
        .replace(/ /g, "+")
        .replace(/-/g, "+")
        .replace(/_/g, "/")
        .padEnd(Math.ceil(encoded.length / 4) * 4, "=");
      const binary = nativeAtob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
      }
      return trustedCdnUrl(utf8Decoder.decode(bytes));
    } catch {
      return null;
    }
  }

  function prepareTrackPath(record) {
    if (!isRecord(record) || typeof record.path !== "string") {
      return false;
    }

    // Keep every signed/session parameter except the player-side bitrate cap.
    const normalized = trustedCdnUrl(record.path);
    if (!normalized) {
      return false;
    }

    preconnectOrigin(normalized.href);
    if (!normalized.bitrateLimitsRemoved) {
      return false;
    }

    record.path = normalized.href;
    stats.bitrateLimitsRemoved += normalized.bitrateLimitsRemoved;
    return true;
  }

  function removeP2pMetadata(record) {
    let changed = false;

    for (const key of Object.keys(record)) {
      const normalizedKey = key.toLowerCase();
      if (!P2P_METADATA_KEYS.has(normalizedKey)) {
        continue;
      }

      if (normalizedKey === "p2p" && typeof record[key] === "boolean") {
        if (record[key] !== false) {
          record[key] = false;
          changed = true;
        }
        continue;
      }

      delete record[key];
      changed = true;
    }

    return changed;
  }

  function rewriteTrack(track) {
    if (!isRecord(track)) {
      return { keep: true, changed: false };
    }

    let changed = false;
    if (typeof track.p2pPath === "string") {
      const direct = directUrlFromP2pPath(track.p2pPath);
      if (direct) {
        track.path = direct.href;
        stats.bitrateLimitsRemoved += direct.bitrateLimitsRemoved;
        preconnectOrigin(direct.href);
        stats.directTracks += 1;
        changed = true;
      } else {
        stats.rejectedCdnUrls += 1;
        reportIssue(
          "P2P CDN path validation",
          "A P2P path did not contain a valid trusted HTTPS CDN URL.",
          "invalid-p2p-cdn-url",
        );
        if (typeof track.path !== "string" || !track.path) {
          stats.droppedTracks += 1;
          reportIssue(
            "P2P-only track removal",
            "An unusable P2P-only track was removed instead of being passed to the player.",
            "p2p-only-track-removed",
          );
          return { keep: false, changed: true };
        }
      }
    }

    changed = prepareTrackPath(track) || changed;

    return {
      keep: true,
      changed: removeP2pMetadata(track) || changed,
    };
  }

  function rewriteMedia(media) {
    if (!isRecord(media)) {
      return false;
    }

    let changed = false;
    if (typeof media.p2pPath === "string") {
      const direct = directUrlFromP2pPath(media.p2pPath);
      if (direct) {
        media.path = direct.href;
        stats.bitrateLimitsRemoved += direct.bitrateLimitsRemoved;
        preconnectOrigin(direct.href);
        stats.directTracks += 1;
        changed = true;
      } else {
        stats.rejectedCdnUrls += 1;
        reportIssue(
          "P2P CDN path validation",
          "A P2P path did not contain a valid trusted HTTPS CDN URL.",
          "invalid-p2p-cdn-url",
        );
      }
    }
    changed = prepareTrackPath(media) || changed;
    changed = removeP2pMetadata(media) || changed;

    if (!Array.isArray(media.encodingTrack)) {
      return changed;
    }

    const tracks = [];
    for (const track of media.encodingTrack) {
      const result = rewriteTrack(track);
      changed = result.changed || changed;
      if (result.keep) {
        tracks.push(track);
      }
    }
    if (tracks.length !== media.encodingTrack.length) {
      media.encodingTrack = tracks;
      changed = true;
    }
    return changed;
  }

  function rewritePlayback(playback) {
    if (
      !isRecord(playback) ||
      (!Array.isArray(playback.media) && !isRecord(playback.live))
    ) {
      return false;
    }

    let changed = removeP2pMetadata(playback);
    if (isRecord(playback.meta)) {
      changed = removeP2pMetadata(playback.meta) || changed;
      if (playback.meta.p2p !== false) {
        playback.meta.p2p = false;
        changed = true;
      }
    }

    if (Array.isArray(playback.media)) {
      for (const media of playback.media) {
        changed = rewriteMedia(media) || changed;
      }
    }
    if (isRecord(playback.live)) {
      changed = rewriteMedia(playback.live) || changed;
    }

    if (Array.isArray(playback.api)) {
      const filtered = playback.api.filter((entry) => {
        if (!isRecord(entry)) {
          return true;
        }
        const name = String(entry.name ?? "").toLowerCase();
        const path = String(entry.path ?? "").toLowerCase();
        return !name.includes("p2p") && !path.includes("/p2p/");
      });
      if (filtered.length !== playback.api.length) {
        playback.api = filtered;
        changed = true;
      }
    }

    return changed;
  }

  function clearPlaybackRestriction(value) {
    if (!isObject(value)) {
      return false;
    }

    let changed = false;
    const stack = [value];
    const visited = new WeakSet();

    while (stack.length) {
      const current = stack.pop();
      if (!isObject(current) || visited.has(current)) {
        continue;
      }
      visited.add(current);

      if (!Array.isArray(current)) {
        for (const key of ["playableStatus", "status"]) {
          if (RESTRICTED_STATUSES.has(current[key])) {
            current[key] = "PLAYABLE";
            if (hasOwn(current, "trafficThrottling")) {
              current.trafficThrottling = -1;
            }
            stats.restrictions += 1;
            changed = true;
          } else if (
            typeof current[key] === "string" &&
            /LOW_RESOLUTION/i.test(current[key])
          ) {
            stats.unsupportedRestrictions += 1;
            reportIssue(
              "Unsupported playback restriction",
              current[key],
              `restriction:${current[key]}`,
            );
          }
        }
      }

      for (const child of Array.isArray(current)
        ? current
        : Object.values(current)) {
        if (isObject(child)) {
          stack.push(child);
        }
      }
    }

    return changed;
  }

  function rewriteJsonString(record, key, rewrite) {
    const source = record[key];
    if (typeof source !== "string" || !source.trimStart().startsWith("{")) {
      return false;
    }

    let value;
    try {
      value = Reflect.apply(nativeJsonParse, JSON, [source]);
    } catch (error) {
      reportFailure(`Playback field ${key} parsing`, error);
      return false;
    }
    if (!rewrite(value)) {
      return false;
    }
    record[key] = Reflect.apply(nativeJsonStringify, JSON, [value]);
    return true;
  }

  function rewriteIntegrityProbe(value) {
    if (
      !isRecord(value) ||
      Array.isArray(value.media) ||
      (!hasOwn(value, "liveId") && !hasOwn(value, "chatChannelId"))
    ) {
      return false;
    }

    let changed = false;
    for (const key of ["liveId", "chatChannelId"]) {
      if (hasOwn(value, key) && typeof value[key] === "boolean" && value[key]) {
        value[key] = false;
        changed = true;
      }
    }
    if (changed) {
      stats.integritySignals += 1;
    }
    return changed;
  }

  function rewritePlaybackValue(value) {
    const playbackChanged = rewritePlayback(value);
    return rewriteIntegrityProbe(value) || playbackChanged;
  }

  function rewriteLiveContent(content) {
    if (!isRecord(content)) {
      return false;
    }

    const playbackFields = Object.keys(content).filter(
      (key) => PLAYBACK_FIELD_SET.has(key) || PLAYBACK_FIELD_PATTERN.test(key),
    );
    const isLivePayload =
      playbackFields.length > 0 ||
      hasOwn(content, "p2pQuality") ||
      hasOwn(content, "dab") ||
      hasOwn(content, "livePollingStatusJson");
    if (!isLivePayload) {
      return false;
    }

    let changed = false;

    if (hasOwn(content, "dab") && content.dab !== false) {
      content.dab = false;
      stats.adBlockFlags += 1;
      changed = true;
    }
    if (Array.isArray(content.p2pQuality) && content.p2pQuality.length) {
      content.p2pQuality = [];
      changed = true;
    }

    for (const key of playbackFields) {
      let fieldChanged;
      if (isRecord(content[key])) {
        fieldChanged = rewritePlaybackValue(content[key]);
      } else {
        fieldChanged = rewriteJsonString(content, key, rewritePlaybackValue);
      }
      if (fieldChanged && !PLAYBACK_FIELD_SET.has(key)) {
        stats.discoveredPlaybackFields += 1;
        reportIssue("Discovered playback field", key, `playback-field:${key}`);
      }
      changed = fieldChanged || changed;
    }

    if (isRecord(content.livePollingStatus)) {
      changed = clearPlaybackRestriction(content.livePollingStatus) || changed;
    }
    if (isRecord(content.livePollingStatusData)) {
      changed =
        clearPlaybackRestriction(content.livePollingStatusData) || changed;
    }
    if (hasOwn(content, "livePollingStatusJson")) {
      changed =
        rewriteJsonString(
          content,
          "livePollingStatusJson",
          clearPlaybackRestriction,
        ) || changed;
    }

    return changed;
  }

  function rewritePayload(payload) {
    if (!isObject(payload)) {
      return false;
    }

    let changed = false;
    if (isRecord(payload)) {
      changed = rewritePlayback(payload) || changed;
      changed = rewriteLiveContent(payload) || changed;

      if (isRecord(payload.content)) {
        changed = rewriteLiveContent(payload.content) || changed;
      }
    }
    return changed;
  }

  function hasLiveContent(value) {
    return (
      isObject(value) &&
      (PLAYBACK_FIELDS.some((key) => key in value) ||
        Object.keys(value).some(
          (key) =>
            !PLAYBACK_FIELD_SET.has(key) && PLAYBACK_FIELD_PATTERN.test(key),
        ) ||
        "p2pQuality" in value ||
        "dab" in value ||
        "livePollingStatusJson" in value ||
        "livePollingStatus" in value ||
        "livePollingStatusData" in value)
    );
  }
  function installJsonHook() {
    const descriptor = Object.getOwnPropertyDescriptor(JSON, "parse");
    function parse(text, reviver) {
      const result = Reflect.apply(nativeJsonParse, this, arguments);
      if (result === null || typeof result !== "object") {
        return result;
      }
      if ("content" in result) {
        if (!hasLiveContent(result.content)) {
          return result;
        }
      } else if (!("media" in result) && !("live" in result)) {
        return result;
      }
      try {
        const startedAt = monotonicNow();
        if (rewritePayload(result)) {
          recordTime("jsonTransformTimeMs", null, startedAt);
          stats.jsonResponses += 1;
        }
      } catch (error) {
        throw reportFailure("JSON response transformation", error);
      }
      return result;
    }

    const installedDescriptor = {
      ...descriptor,
      value: parse,
    };
    const releaseHook = hookRegistry.define(
      JSON,
      "parse",
      installedDescriptor,
      "JSON.parse",
    );

    let active = true;
    return () => {
      if (!active) {
        return;
      }
      active = false;
      if (releaseHook()) {
        stats.jsonHookReleases += 1;
      }
    };
  }

  function installResponseHook() {
    const prototype = root.Response?.prototype;
    const descriptor = prototype
      ? Object.getOwnPropertyDescriptor(prototype, "json")
      : null;
    if (!descriptor || typeof descriptor.value !== "function") {
      return;
    }

    const nativeResponseJson = descriptor.value;
    function json(...args) {
      const promise = Reflect.apply(nativeResponseJson, this, args);
      const url = this?.url;
      if (
        typeof url === "string" &&
        url &&
        !url.startsWith("https://api.chzzk.naver.com/")
      ) {
        return promise;
      }
      return promise.then((result) => {
        try {
          const startedAt = monotonicNow();
          if (rewritePayload(result)) {
            recordTime("responseTransformTimeMs", null, startedAt);
            stats.jsonResponses += 1;
            lifecycleCallbacks.releaseJsonFallback();
          }
        } catch (error) {
          throw reportFailure("Response JSON transformation", error);
        }
        return result;
      });
    }
    hookRegistry.define(
      prototype,
      "json",
      { ...descriptor, value: json },
      "Response.prototype.json",
    );
  }

  function bytesOf(bufferSource) {
    if (bufferSource instanceof ArrayBuffer) {
      return new Uint8Array(bufferSource);
    }
    if (ArrayBuffer.isView(bufferSource)) {
      return new Uint8Array(
        bufferSource.buffer,
        bufferSource.byteOffset,
        bufferSource.byteLength,
      );
    }
    return null;
  }

  function bytesMatch(source, expected, offset = 0) {
    if (!source || source.byteLength < offset + expected.byteLength) {
      return false;
    }
    for (let index = 0; index < expected.byteLength; index += 1) {
      if (source[offset + index] !== expected[index]) {
        return false;
      }
    }
    return true;
  }

  function inspectTunnelFamily(algorithm) {
    if (!isRecord(algorithm)) {
      return null;
    }
    const aad = bytesOf(algorithm.additionalData);
    if (!aad || aad.byteLength < 2) {
      return null;
    }
    const labelLength = (aad[0] << 8) | aad[1];
    if (
      labelLength < TUNNEL_LABEL_PREFIX.byteLength ||
      aad.byteLength < 2 + labelLength ||
      !bytesMatch(aad, TUNNEL_LABEL_PREFIX, 2)
    ) {
      return null;
    }
    const labelBytes = aad.subarray(2, 2 + labelLength);
    let label;
    try {
      label = utf8Decoder.decode(labelBytes);
    } catch {
      label = "invalid-utf8";
    }
    return {
      aad,
      algorithm: String(algorithm.name ?? "").toUpperCase(),
      iv: bytesOf(algorithm.iv),
      label,
      labelBytes,
      tagLength: algorithm.tagLength,
    };
  }

  function matchTunnelProtocol(algorithm) {
    const inspected = inspectTunnelFamily(algorithm);
    if (!inspected) {
      return null;
    }
    const profile = TUNNEL_PROTOCOLS.find(
      (candidate) =>
        inspected.algorithm === candidate.algorithm &&
        inspected.iv?.byteLength === candidate.ivLength &&
        inspected.aad.byteLength === candidate.aadLength &&
        inspected.labelBytes.byteLength === candidate.labelBytes.byteLength &&
        bytesMatch(inspected.labelBytes, candidate.labelBytes) &&
        (inspected.tagLength === undefined ||
          inspected.tagLength === candidate.tagLength),
    );
    if (!profile) {
      stats.unsupportedTunnelProtocols += 1;
      reportIssue(
        "Unsupported tunnel protocol",
        new Error(
          `${inspected.label}; algorithm=${inspected.algorithm || "unknown"}; ` +
            `iv=${inspected.iv?.byteLength ?? 0}; aad=${inspected.aad.byteLength}; ` +
            `tag=${inspected.tagLength ?? "default"}`,
        ),
        `tunnel:${inspected.label}:${inspected.algorithm}:${inspected.aad.byteLength}:${inspected.tagLength}`,
      );
    }
    return profile ?? null;
  }

  function rewriteTunnelPlaintext(buffer) {
    const startedAt = monotonicNow();
    const bytes = bytesOf(buffer);
    if (
      !bytes ||
      !bytes.byteLength ||
      bytes.byteLength > MAX_TUNNEL_JSON_BYTES
    ) {
      const error = new RangeError(
        `service/t plaintext size is out of range: ${bytes?.byteLength ?? 0}`,
      );
      stats.tunnelFailures += 1;
      stats.tunnelPassThroughs += 1;
      reportFailure("service/t plaintext validation", error);
      return buffer;
    }

    try {
      const text = utf8Decoder.decode(bytes);
      const jsonText = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
      if (!/^[\[{]/.test(jsonText.trimStart())) {
        const error = new TypeError("service/t plaintext is not JSON.");
        throw error;
      }

      const payload = Reflect.apply(nativeJsonParse, JSON, [jsonText]);
      if (!rewritePayload(payload)) {
        recordTime(
          "tunnelTransformTimeMs",
          "maxTunnelTransformTimeMs",
          startedAt,
        );
        return buffer;
      }

      stats.tunnelResponses += 1;
      lifecycleCallbacks.releaseJsonFallback();
      const rewritten = utf8Encoder.encode(
        Reflect.apply(nativeJsonStringify, JSON, [payload]),
      ).buffer;
      recordTime(
        "tunnelTransformTimeMs",
        "maxTunnelTransformTimeMs",
        startedAt,
      );
      return rewritten;
    } catch (error) {
      stats.tunnelFailures += 1;
      stats.tunnelPassThroughs += 1;
      reportFailure("service/t response transformation", error);
      return buffer;
    }
  }

  function findMethodDescriptor(object, key) {
    let current = object;
    while (current) {
      const descriptor = Object.getOwnPropertyDescriptor(current, key);
      if (descriptor) {
        return { owner: current, descriptor };
      }
      current = Object.getPrototypeOf(current);
    }
    return null;
  }

  function installTunnelHooks() {
    const subtle = root.crypto?.subtle;
    const decryptMethod = subtle
      ? findMethodDescriptor(subtle, "decrypt")
      : null;
    if (
      !decryptMethod ||
      typeof decryptMethod.descriptor.value !== "function"
    ) {
      throw new Error("Failed to install the WebCrypto decrypt hook.");
    }

    const nativeDecrypt = decryptMethod.descriptor.value;
    function decrypt(algorithm, key, data) {
      const targeted = Boolean(matchTunnelProtocol(algorithm));
      if (targeted) {
        stats.tunnelDecrypts += 1;
      }
      let promise;
      try {
        promise = Reflect.apply(nativeDecrypt, this, arguments);
      } catch (error) {
        if (targeted) {
          stats.tunnelFailures += 1;
          throw reportFailure("service/t decryption", error);
        }
        throw error;
      }
      if (!targeted) {
        return promise;
      }
      return Promise.resolve(promise).then(rewriteTunnelPlaintext, (error) => {
        stats.tunnelFailures += 1;
        throw reportFailure("service/t decryption", error);
      });
    }
    hookRegistry.define(
      decryptMethod.owner,
      "decrypt",
      { ...decryptMethod.descriptor, value: decrypt },
      "SubtleCrypto.prototype.decrypt",
    );
  }

  function definePrototypeSignal(name, setter) {
    if (Object.prototype.hasOwnProperty.call(Object.prototype, name)) {
      return false;
    }
    hookRegistry.define(
      Object.prototype,
      name,
      {
        configurable: true,
        get() {
          return undefined;
        },
        set: setter,
      },
      `Object.prototype.${name}`,
    );
    return true;
  }

  function setOwnValue(target, key, value) {
    Object.defineProperty(target, key, {
      value,
      configurable: true,
      enumerable: true,
      writable: true,
    });
  }

  function installPlaybackSignalGuards() {
    const rejectionInstalled = definePrototypeSignal(
      PLAYBACK_REJECTION_EVENT,
      function (value) {
        // Preserve enum creation, but reject listener/state assignments which
        // would clear the primary player's src after an ad delivery failure.
        if (value === PLAYBACK_REJECTION_EVENT) {
          setOwnValue(this, PLAYBACK_REJECTION_EVENT, value);
        } else {
          stats.blockedAdFailures += 1;
        }
      },
    );

    const advanceInstalled = definePrototypeSignal(
      PLAYBACK_ADVANCE_EVENT,
      function (value) {
        if (Array.isArray(value)) {
          playbackAdvanceListeners = value;
          playbackAdvanceGeneration += 1;
          enqueueMicrotask(() =>
            lifecycleCallbacks.reconcileAuxiliaryVideos(
              "listener-registration",
            ),
          );
        }
        setOwnValue(this, PLAYBACK_ADVANCE_EVENT, value);
      },
    );
    if (!rejectionInstalled || !advanceInstalled) {
      throw new Error("The ad playback signal hook names are already in use.");
    }
  }

  // CHZZK's blocker probe checks a fixed list of bait class names through
  // getComputedStyle. Exact matching avoids changing normal page elements.
  const AD_BAIT_CLASSES = new Set([
    "banner_ad_wrapper",
    "TopAdBox",
    "ad--dart",
    "ad-container-side",
    "ad-tag__wrapper",
    "ad_regular1",
    "ad_slot_inread",
    "adguru-modal-popup",
    "ads_box_headline",
    "adsmedrect",
    "advert-loader",
    "advertisementContainer",
    "advertising-top-box",
    "artnet-ads-ad",
    "dianomi_context",
    "divAdright",
    "footer__ads--content",
    "header-article-ads",
    "header-bannerad",
    "incontentAd",
    "js-anchor-ad",
    "module-box-ads",
    "moduletable_advertisement",
    "news-ad-square-a",
    "nfy-ad-wrapper",
    "rekl_left",
    "sidebar-advert",
    "slideshow-ad-wrapper",
    "widget--local-ads",
    "zaf-adhesion-container",
    "zerg-widget",
  ]);
  const adBaitCache = new WeakMap();

  function isAdBaitElement(element) {
    const classList = element?.classList;
    if (!classList) {
      return false;
    }
    const className = element.getAttribute?.("class") ?? "";
    const cached = adBaitCache.get(element);
    if (cached?.className === className) {
      return cached.matches;
    }
    let matches = false;
    for (const className of classList) {
      if (AD_BAIT_CLASSES.has(className)) {
        matches = true;
        break;
      }
    }
    adBaitCache.set(element, { className, matches });
    return matches;
  }

  function visibleStyle(style) {
    return new Proxy(style, {
      get(target, key) {
        if (key === "display") return "block";
        if (key === "visibility") return "visible";
        if (key === "opacity") return "1";
        if (key === "getPropertyValue") {
          return (property) => {
            if (property === "display") return "block";
            if (property === "visibility") return "visible";
            if (property === "opacity") return "1";
            return target.getPropertyValue(property);
          };
        }
        const value = Reflect.get(target, key, target);
        return typeof value === "function" ? value.bind(target) : value;
      },
    });
  }

  function installAdBaitHook() {
    const method = findMethodDescriptor(root, "getComputedStyle");
    if (!method || typeof method.descriptor.value !== "function") {
      return;
    }
    const nativeGetComputedStyle = method.descriptor.value;
    function getComputedStyle(element, pseudoElement) {
      const style = Reflect.apply(nativeGetComputedStyle, this, arguments);
      return isAdBaitElement(element) ? visibleStyle(style) : style;
    }
    hookRegistry.define(
      method.owner,
      "getComputedStyle",
      { ...method.descriptor, value: getComputedStyle },
      "Window.getComputedStyle",
    );
  }

  const AUXILIARY_VIDEO_SELECTORS = Object.freeze([
    "[data-role='adVideoContainerEl']",
    "[data-role='imaAdContainerEl']",
    "[data-role='gvAdContainerEl']",
    "#midAdVideoContainer",
    "#midAdPlayerWrapper",
    "video[title='Advertisement' i]",
  ]);
  const AUXILIARY_UI_SELECTORS = Object.freeze([
    "[data-role='adPlayerInterface']",
    "[data-role='adControlEl']",
    "[data-role='adBtnControlEl']",
    "[data-role='countDownEl']",
    "[data-role='countDownTxt']",
    "[data-role='skipBtn']",
    "[data-role='skipInfo']",
    "[data-role='adLink']",
    "[data-role='providerArea']",
    "[data-role='smrPostrollNoticeArea']",
    "[data-role='smrPostrollNoticeAreaTxt']",
    "[data-role='smrRemindBannerArea']",
    "[data-role='smrRemindBannerBtnClose']",
    "[data-role='smrRemindBannerLink']",
    "[data-role='smrRemindTextArea']",
    "[data-role='smrRemindTextBtnClose']",
    "[data-role='smrRemindTextBtnUnfold']",
    "[data-role='smrRemindTextItem']",
    "[data-role='smrRemindTextLink']",
    "pzp-ad-break-indicator",
    ".pzp-ad-break-indicator",
    "pzp-midroll-dimmed",
    ".pzp-midroll-dimmed",
    "pzp-ad-click-through-button",
    ".webplayer-internal-core-ad-ui",
    ".advertisement_guide",
  ]);
  const AUXILIARY_VIDEO_SELECTOR = AUXILIARY_VIDEO_SELECTORS.join(",");
  const AUXILIARY_UI_SELECTOR = AUXILIARY_UI_SELECTORS.join(",");
  const AUXILIARY_VIDEO_CLASS = "chzzk-p2p-bypass-auxiliary";
  // VOD adBreakCountdown is represented by this component/class pair. Its
  // native animationend handler clears the state and calls startAd().
  const MIDROLL_COUNTDOWN_CLASS = "pzp-midroll-dimmed";
  const MIDROLL_COUNTDOWN_SELECTOR = ".pzp-midroll-dimmed";
  const MIDROLL_COUNTDOWN_STARTED_CLASS = "pzp-midroll-dimmed--started";
  const AD_MEDIA_HOST =
    /(^|\.)((tvetamovie\.pstatic\.net)|(glad-vod\.pstatic\.net)|(video-gfa\.pstatic\.net))$/i;
  const auxiliaryVideoCache = new WeakMap();
  let auxiliaryDomRevision = 0;
  // Display slots registered by the current CHZZK app with gladsdk. These are
  // separate from the player's video-ad lifecycle and may be removed from flow.
  const DISPLAY_AD_SLOT_SELECTOR = [
    "#home_banner",
    "#live_end_banner",
    "#vod_end_banner",
    "#live_rs_banner",
    "#vod_rs_banner",
  ].join(",");
  const DISPLAY_AD_MARKER = "data-chzzk-display-ad-slot";
  const VERIFIED_DISPLAY_AD_SELECTOR = DISPLAY_AD_SLOT_SELECTOR.split(",")
    .map(
      (selector) => `${selector}[${DISPLAY_AD_MARKER}="${selector.slice(1)}"]`,
    )
    .join(",");

  // A reused ID is not evidence of advertising. Require the current official
  // React tree's ad component/configuration, without changing React or the SDK.
  function isOwnedDisplayAdSlot(element) {
    const app = document.getElementById("root");
    if (
      !app ||
      !app.contains(element) ||
      !element.matches(DISPLAY_AD_SLOT_SELECTOR)
    )
      return false;
    const data = (object, key) =>
      object && Object.getOwnPropertyDescriptor(object, key)?.value;
    const committed = (fiber) => {
      let top = fiber;
      for (let depth = 0; top && depth < 64; depth++) {
        const parent = data(top, "return");
        if (!parent) {
          const state = data(top, "stateNode");
          return data(top, "tag") === 3 &&
            data(state, "current") === top &&
            data(state, "containerInfo") === app
            ? fiber
            : null;
        }
        top = parent;
      }
      return null;
    };
    try {
      const key = Object.keys(element).find((name) =>
        name.startsWith("__reactFiber$"),
      );
      const candidate = key && data(element, key);
      let fiber =
        committed(candidate) || committed(data(candidate, "alternate"));
      if (!fiber || data(fiber, "stateNode") !== element) return false;
      for (
        let depth = 0;
        fiber && depth < 12;
        depth++, fiber = data(fiber, "return")
      ) {
        const info = data(data(fiber, "memoizedProps"), "adSlotInfo");
        const custom = data(info, "customParam");
        const expectedService =
          element.id === "home_banner"
            ? "chzzk_main"
            : element.id.startsWith("live_")
              ? "chzzk_live"
              : "chzzk_video";
        if (
          [11, 14].includes(data(fiber, "tag")) &&
          data(info, "adSlotElementId") === element.id &&
          typeof data(info, "adUnitId") === "string" &&
          data(info, "adUnitId").length > 0 &&
          data(custom, "cp") === "chzzk" &&
          data(custom, "pcmo") === "pc" &&
          data(custom, "svc") === expectedService
        )
          return true;
      }
    } catch {
      // Unknown/future application or third-party shape remains visible.
    }
    return false;
  }

  function reconcileDisplayAdSlot(element) {
    if (!(element instanceof Element)) return;
    const owned = isOwnedDisplayAdSlot(element);
    if (owned && element.getAttribute(DISPLAY_AD_MARKER) !== element.id)
      element.setAttribute(DISPLAY_AD_MARKER, element.id);
    else if (!owned && element.hasAttribute(DISPLAY_AD_MARKER))
      element.removeAttribute(DISPLAY_AD_MARKER);
  }

  function visitDisplayAdSlots(node) {
    if (!(node instanceof Element)) return;
    const selector = `${DISPLAY_AD_SLOT_SELECTOR},[${DISPLAY_AD_MARKER}]`;
    if (node.matches(selector)) reconcileDisplayAdSlot(node);
    for (const slot of node.querySelectorAll(selector))
      reconcileDisplayAdSlot(slot);
  }

  function installEarlyStyle() {
    const style = document.createElement("style");
    style.id = "chzzk-p2p-bypass-style";
    style.textContent = `
      ${AUXILIARY_VIDEO_SELECTOR},
      ${AUXILIARY_UI_SELECTOR},
      video.${AUXILIARY_VIDEO_CLASS},
      [data-nlog-area="ad_blocking_info_layer"],
      [data-nlog-area^="ad_blocking_"] {
        position: fixed !important;
        inset: auto auto 0 0 !important;
        width: 1px !important;
        height: 1px !important;
        min-width: 0 !important;
        min-height: 0 !important;
        opacity: 0 !important;
        visibility: hidden !important;
        pointer-events: none !important;
        clip-path: inset(100%) !important;
        contain: strict !important;
      }

      ${VERIFIED_DISPLAY_AD_SELECTOR} {
        display: none !important;
        min-height: 0 !important;
      }

      /* The native component's text is always "Muted". Its button label
         changes to "Mute" when unmuted, before the exit animation completes.
         Preserve the real muted notice and the normal volume controls. */
      .pzp-mute-indicator:has(> .pzp-mute-indicator__label[aria-label="음소거"]),
      .pzp-mute-indicator:has(> .pzp-mute-indicator__label[aria-label="Mute"]) {
        visibility: hidden !important;
        pointer-events: none !important;
      }

    `;

    const attach = () => {
      if (style.isConnected) {
        return true;
      }
      const existing = document.getElementById(style.id);
      if (existing && existing !== style) {
        reportIssue(
          "Early style installation",
          `Element id ${style.id} is already in use; installing an unnumbered style.`,
          "early-style-id-collision",
        );
        style.removeAttribute("id");
      }
      const parent = document.head || document.documentElement;
      if (!parent) {
        return false;
      }
      parent.append(style);
      for (const origin of EARLY_CONNECTION_ORIGINS) {
        preconnectOrigin(origin);
      }
      return true;
    };

    let observer = null;
    hookRegistry.addCleanup("early ad style", () => {
      observer?.disconnect();
      style.remove();
      for (const slot of document.querySelectorAll(`[${DISPLAY_AD_MARKER}]`))
        slot.removeAttribute(DISPLAY_AD_MARKER);
    });
    if (!attach()) {
      observer = new MutationObserver(() => {
        if (attach()) {
          observer.disconnect();
        }
      });
      observer.observe(document, { childList: true });
    }
  }

  function hasAdMediaSource(video, source = video.currentSrc || video.src) {
    if (!source || source.startsWith("blob:")) {
      return false;
    }
    try {
      const url = new URL(source, location.href);
      return (
        AD_MEDIA_HOST.test(url.hostname) ||
        (url.hostname === "api.chzzk.naver.com" &&
          url.pathname.startsWith("/service/t/"))
      );
    } catch {
      return false;
    }
  }

  function isAuxiliaryVideo(video, fresh = false) {
    if (!(video instanceof HTMLVideoElement)) {
      return false;
    }
    if (!fresh && video.classList.contains(AUXILIARY_VIDEO_CLASS)) {
      return true;
    }
    const parent = video.parentElement;
    const cached = auxiliaryVideoCache.get(video);
    if (
      !fresh &&
      cached?.revision === auxiliaryDomRevision &&
      cached.parent === parent
    ) {
      return cached.auxiliary;
    }
    const declaredSource = video.hasAttribute("src") ? video.src : "";
    const source =
      (fresh && declaredSource) || video.currentSrc || video.src || "";
    const auxiliary =
      Boolean(video.closest(AUXILIARY_VIDEO_SELECTOR)) ||
      hasAdMediaSource(video, source);
    auxiliaryVideoCache.set(video, {
      auxiliary,
      parent,
      revision: auxiliaryDomRevision,
      source,
    });
    return auxiliary;
  }

  function findPrimaryPlaybackVideo(preferred) {
    if (
      preferred instanceof HTMLVideoElement &&
      document.pictureInPictureElement === preferred &&
      !isAuxiliaryVideo(preferred)
    ) {
      return preferred;
    }
    const chooseBest = (candidates) => {
      let primary = null;
      let bestScore = -Infinity;
      for (const video of candidates) {
        if (isAuxiliaryVideo(video)) {
          continue;
        }
        const area = Math.max(
          video.videoWidth * video.videoHeight,
          video.clientWidth * video.clientHeight,
        );
        const score =
          (video.currentSrc || video.src ? 1_000_000_000 : 0) +
          (!video.ended ? 100_000_000 : 0) +
          video.readyState * 1_000_000 +
          area;
        if (score >= bestScore) {
          bestScore = score;
          primary = video;
        }
      }
      return primary;
    };
    // Official players can coexist in one document. Keep recovery and DVR
    // decisions inside the owning player; unrelated custom HLS stays separate.
    const scope = preferred?.closest?.(PLAYER_SCOPE_SELECTOR) ?? document;
    const designated = chooseBest(
      scope.querySelectorAll("video[data-role='videoEl']"),
    );
    if (designated) {
      return designated;
    }
    return chooseBest(scope.querySelectorAll("video"));
  }
  function installAdPlaybackMock() {
    if (!root.document || !root.HTMLVideoElement) {
      return;
    }

    installEarlyStyle();
    const lastSource = new WeakMap();
    const advancedSource = new WeakMap();
    const advanceBindings = new WeakMap();
    const advanceStates = new WeakMap();
    const advanceDiagnosticTimers = new Set();
    const videosAwaitingAdvanceBinding = new WeakSet();
    const midrollCountdownStates = new WeakMap();
    const midrollCountdownObservers = new WeakMap();
    const activeMidrollCountdownObservers = new Set();
    hookRegistry.addCleanup("ad advance diagnostics", () => {
      for (const timer of advanceDiagnosticTimers) {
        root.clearTimeout(timer);
      }
      advanceDiagnosticTimers.clear();
    });
    hookRegistry.addCleanup("mid-roll countdown observers", () => {
      for (const observer of activeMidrollCountdownObservers) {
        observer.disconnect();
      }
      activeMidrollCountdownObservers.clear();
    });

    const advanceMidrollCountdown = (element) => {
      let state = midrollCountdownStates.get(element);
      if (!state) {
        state = { active: false };
        midrollCountdownStates.set(element, state);
      }
      if (!element.classList.contains(MIDROLL_COUNTDOWN_STARTED_CLASS)) {
        state.active = false;
        return;
      }
      if (state.active) {
        return;
      }

      state.active = true;
      stats.midrollCountdownsDetected += 1;
      const detectedAt = monotonicNow();
      enqueueMicrotask(() => {
        if (
          !element.isConnected ||
          !element.classList.contains(MIDROLL_COUNTDOWN_STARTED_CLASS)
        ) {
          state.active = false;
          return;
        }
        try {
          const animationName = root
            .getComputedStyle(element)
            .animationName.split(",", 1)[0]
            .trim();
          const event =
            typeof root.AnimationEvent === "function"
              ? new root.AnimationEvent("animationend", {
                  animationName,
                  bubbles: true,
                  elapsedTime: 10,
                })
              : new root.Event("animationend", { bubbles: true });
          element.dispatchEvent(event);
          stats.midrollCountdownsAdvanced += 1;
          stats.maxMidrollCountdownLatencyMs = Math.max(
            stats.maxMidrollCountdownLatencyMs,
            monotonicNow() - detectedAt,
          );
        } catch (error) {
          state.active = false;
          reportFailure("VOD mid-roll countdown transition", error);
          return;
        }

        const timer = root.setTimeout(() => {
          advanceDiagnosticTimers.delete(timer);
          if (
            element.isConnected &&
            element.classList.contains(MIDROLL_COUNTDOWN_STARTED_CLASS)
          ) {
            reportFailure(
              "VOD mid-roll countdown transition",
              new Error(
                "The player's animationend handler did not clear the countdown state.",
              ),
            );
          } else {
            state.active = false;
          }
        }, 100);
        advanceDiagnosticTimers.add(timer);
      });
    };

    const observeMidrollCountdown = (element) => {
      if (
        !(element instanceof Element) ||
        !element.classList.contains(MIDROLL_COUNTDOWN_CLASS) ||
        midrollCountdownObservers.has(element)
      ) {
        return;
      }
      const observer = new MutationObserver(() =>
        advanceMidrollCountdown(element),
      );
      observer.observe(element, {
        attributeFilter: ["class"],
        attributes: true,
      });
      midrollCountdownObservers.set(element, observer);
      activeMidrollCountdownObservers.add(observer);
      advanceMidrollCountdown(element);
    };

    const visitMidrollCountdowns = (node, callback) => {
      if (!(node instanceof Element)) {
        return;
      }
      if (node.classList.contains(MIDROLL_COUNTDOWN_CLASS)) {
        callback(node);
      }
      if (!node.firstElementChild) {
        return;
      }
      for (const element of node.querySelectorAll(MIDROLL_COUNTDOWN_SELECTOR)) {
        callback(element);
      }
    };

    const stopObservingMidrollCountdown = (element) => {
      const observer = midrollCountdownObservers.get(element);
      if (!observer) {
        return;
      }
      observer.disconnect();
      activeMidrollCountdownObservers.delete(observer);
      midrollCountdownObservers.delete(element);
      midrollCountdownStates.delete(element);
    };
    const playMethod = findMethodDescriptor(
      root.HTMLMediaElement.prototype,
      "play",
    );
    if (!playMethod || typeof playMethod.descriptor.value !== "function") {
      throw new Error("Failed to install the HTMLMediaElement.play hook.");
    }
    const nativeMediaPlay = playMethod.descriptor.value;
    const currentTimeMethod = findMethodDescriptor(
      root.HTMLMediaElement.prototype,
      "currentTime",
    );
    const playbackRateMethod = findMethodDescriptor(
      root.HTMLMediaElement.prototype,
      "playbackRate",
    );
    const defaultPlaybackRateMethod = findMethodDescriptor(
      root.HTMLMediaElement.prototype,
      "defaultPlaybackRate",
    );
    if (
      !currentTimeMethod ||
      typeof currentTimeMethod.descriptor.get !== "function" ||
      typeof currentTimeMethod.descriptor.set !== "function" ||
      !playbackRateMethod ||
      typeof playbackRateMethod.descriptor.get !== "function" ||
      typeof playbackRateMethod.descriptor.set !== "function" ||
      !defaultPlaybackRateMethod ||
      typeof defaultPlaybackRateMethod.descriptor.set !== "function"
    ) {
      throw new Error(
        "Failed to obtain the native ad media time and playback-rate setters.",
      );
    }
    const nativeCurrentTimeGetter = currentTimeMethod.descriptor.get;
    const nativeCurrentTimeSetter = currentTimeMethod.descriptor.set;
    const nativePlaybackRateGetter = playbackRateMethod.descriptor.get;
    const nativePlaybackRateSetter = playbackRateMethod.descriptor.set;
    const nativeDefaultPlaybackRateSetter =
      defaultPlaybackRateMethod.descriptor.set;

    const finishPlayerState = (video, source, reason) => {
      const container = video.closest(AUXILIARY_VIDEO_SELECTOR);
      const containerIsActive =
        container instanceof HTMLElement && container.style.display === "block";
      if (
        !containerIsActive &&
        reason !== "play-call" &&
        reason !== "play" &&
        reason !== "playing" &&
        reason !== "ended" &&
        reason !== "timeupdate"
      ) {
        return;
      }

      let binding = advanceBindings.get(video);
      const shouldBindCurrentGeneration =
        !binding ||
        reason === "play-call" ||
        (containerIsActive && reason === "container:style");
      if (
        shouldBindCurrentGeneration &&
        Array.isArray(playbackAdvanceListeners) &&
        binding?.generation !== playbackAdvanceGeneration
      ) {
        binding = {
          generation: playbackAdvanceGeneration,
          listeners: playbackAdvanceListeners,
        };
        advanceBindings.set(video, binding);
        stats.adAdvanceBindings += 1;
      }
      if (!binding) {
        if (containerIsActive && !videosAwaitingAdvanceBinding.has(video)) {
          videosAwaitingAdvanceBinding.add(video);
          const timer = root.setTimeout(() => {
            advanceDiagnosticTimers.delete(timer);
            videosAwaitingAdvanceBinding.delete(video);
            if (
              video.isConnected &&
              !advanceBindings.has(video) &&
              video.closest(AUXILIARY_VIDEO_SELECTOR)?.style?.display ===
                "block"
            ) {
              reportIssue(
                "Ad completion contract",
                "An active auxiliary player has no compatible completion listener.",
                "missing-ad-completion-listener",
              );
            }
          }, 1_000);
          advanceDiagnosticTimers.add(timer);
        }
        return;
      }

      const listeners = binding.listeners.filter(
        (listener) => typeof listener === "function",
      );
      if (!listeners.length) {
        return;
      }

      let advanceState = advanceStates.get(video);
      if (
        !advanceState ||
        advanceState.source !== source ||
        advanceState.generation !== binding.generation
      ) {
        advanceState = {
          attempted: false,
          generation: binding.generation,
          source,
        };
        advanceStates.set(video, advanceState);
      }
      if (advanceState.attempted) {
        return;
      }
      // The listener is the player's own skip transition. Invoke it once only
      // after REQUESTED_TO_START made the container active, or after native
      // playback started. Empty-source discovery must not consume this chance.
      advanceState.attempted = true;

      const previousSource = advancedSource.get(video);
      if (
        previousSource === undefined ||
        (source !== previousSource && !(previousSource === "" && source))
      ) {
        stats.advancedAds += 1;
      }
      if (previousSource !== source) {
        advancedSource.set(video, source);
      }
      const scheduledAt = monotonicNow();
      enqueueMicrotask(() => {
        stats.adAdvanceAttempts += 1;
        stats.maxAdCompletionLatencyMs = Math.max(
          stats.maxAdCompletionLatencyMs,
          monotonicNow() - scheduledAt,
        );
        for (const listener of listeners) {
          try {
            listener();
          } catch (error) {
            reportFailure("Ad completion listener", error);
          }
        }
        lifecycleCallbacks.reconcilePrimaryPlayback("ad-complete");
      });
    };

    const prepare = (video, reason) => {
      const structuralChange =
        reason === "play-call" ||
        reason === "loadstart" ||
        reason === "node-added" ||
        reason === "subtree-added" ||
        reason === "container-added" ||
        reason === "listener-registration" ||
        reason.startsWith("attribute:") ||
        reason.startsWith("container:");
      if (!isAuxiliaryVideo(video, structuralChange)) {
        video.classList.remove(AUXILIARY_VIDEO_CLASS);
        return false;
      }

      video.classList.add(AUXILIARY_VIDEO_CLASS);
      video.muted = true;
      video.defaultMuted = true;
      video.volume = 0;

      const source = video.currentSrc || video.src || "";
      const previousSource = lastSource.get(video);
      if (
        previousSource === undefined ||
        (source !== previousSource && !(previousSource === "" && source))
      ) {
        stats.mockedAds += 1;
      }
      if (previousSource !== source) {
        lastSource.set(video, source);
      }

      try {
        finishPlayerState(video, source, reason);
        Reflect.apply(nativeDefaultPlaybackRateSetter, video, [16]);
        if (Reflect.apply(nativePlaybackRateGetter, video, []) !== 16) {
          Reflect.apply(nativePlaybackRateSetter, video, [16]);
          stats.nativeAdRateChanges += 1;
        }

        const currentTime = Reflect.apply(nativeCurrentTimeGetter, video, []);
        if (
          Number.isFinite(video.duration) &&
          video.duration > 0.1 &&
          video.duration <= 300 &&
          currentTime < video.duration - 0.1
        ) {
          Reflect.apply(nativeCurrentTimeSetter, video, [
            Math.max(0, video.duration - 0.05),
          ]);
          stats.nativeAdSeeks += 1;
        }
      } catch (error) {
        reportFailure("Ad media processing", error);
      }
      return true;
    };

    const advance = (video, reason) => {
      const container = video.closest(AUXILIARY_VIDEO_SELECTOR);
      const active =
        container instanceof HTMLElement && container.style.display === "block";
      if (
        prepare(video, reason) &&
        active &&
        video.paused &&
        video.readyState >= 2
      ) {
        Reflect.apply(nativeMediaPlay, video, []).catch((error) => {
          reportFailure("Ad media playback", error);
        });
      }
    };

    function play(...args) {
      if (this instanceof HTMLVideoElement) {
        prepare(this, "play-call");
      }
      return Reflect.apply(nativeMediaPlay, this, args);
    }
    hookRegistry.define(
      playMethod.owner,
      "play",
      { ...playMethod.descriptor, value: play },
      "HTMLMediaElement.prototype.play",
    );

    for (const [property, forcedValue] of [
      ["muted", true],
      ["defaultMuted", true],
      ["volume", 0],
    ]) {
      const method = findMethodDescriptor(
        root.HTMLMediaElement.prototype,
        property,
      );
      if (!method || typeof method.descriptor.set !== "function") {
        throw new Error(
          `Failed to install the HTMLMediaElement.${property} hook.`,
        );
      }
      const nativeSetter = method.descriptor.set;
      hookRegistry.define(
        method.owner,
        property,
        {
          ...method.descriptor,
          set(value) {
            if (
              this instanceof HTMLVideoElement &&
              isAuxiliaryVideo(this) &&
              value !== forcedValue
            ) {
              stats.blockedAdAudio += 1;
              return Reflect.apply(nativeSetter, this, [forcedValue]);
            }
            return Reflect.apply(nativeSetter, this, [value]);
          },
        },
        `HTMLMediaElement.prototype.${property}`,
      );
    }

    const onMediaEvent = (event) => {
      if (
        event.target instanceof HTMLVideoElement &&
        isAuxiliaryVideo(event.target, event.type === "volumechange")
      ) {
        advance(event.target, event.type);
        // The native ad adapter forwards volumechange into AdVolumeChange,
        // which writes the ad's forced mute/volume into the primary store.
        // Contain only our silenced ad event; primary/user events stay native.
        if (
          event.type === "volumechange" &&
          event.target.muted &&
          event.target.volume === 0
        ) {
          event.stopImmediatePropagation();
          stats.blockedAdVolumeEvents += 1;
        }
      }
    };
    subscribeMediaEvents(
      [
        "loadstart",
        "loadedmetadata",
        "durationchange",
        "loadeddata",
        "canplay",
        "play",
        "playing",
        "ended",
        "seeked",
        "timeupdate",
        "volumechange",
      ],
      onMediaEvent,
      "ad playback",
    );

    lifecycleCallbacks.reconcileAuxiliaryVideos = (reason = "reconcile") => {
      for (const video of document.querySelectorAll("video")) {
        if (isAuxiliaryVideo(video)) {
          advance(video, reason);
        }
      }
    };

    const observer = new MutationObserver((records) => {
      let shouldReconcilePrimary = false;
      for (const record of records) {
        if (record.type === "attributes") {
          const target = record.target;
          if (
            target instanceof Element &&
            (target.matches(DISPLAY_AD_SLOT_SELECTOR) ||
              target.hasAttribute(DISPLAY_AD_MARKER))
          )
            reconcileDisplayAdSlot(target);
          switch (record.attributeName) {
            case "src":
              auxiliaryDomRevision += 1;
              if (target instanceof HTMLVideoElement) {
                advance(target, "attribute:src");
              }
              break;
            case "data-role":
            case "id":
              auxiliaryDomRevision += 1;
              if (target instanceof HTMLVideoElement) {
                advance(target, `attribute:${record.attributeName}`);
              } else if (target instanceof Element) {
                for (const video of target.querySelectorAll("video")) {
                  advance(video, `container:${record.attributeName}`);
                }
              }
              break;
            case "style":
              if (
                !(target instanceof Element) ||
                !target.matches(AUXILIARY_VIDEO_SELECTOR)
              ) {
                break;
              }
              for (const video of target.querySelectorAll("video")) {
                advance(video, "container:style");
              }
              shouldReconcilePrimary = true;
              break;
          }
          continue;
        }
        const displaySlot =
          record.target instanceof Element &&
          record.target.closest(DISPLAY_AD_SLOT_SELECTOR);
        if (displaySlot) reconcileDisplayAdSlot(displaySlot);
        for (const node of record.removedNodes) {
          if (!(node instanceof Element)) {
            continue;
          }
          visitMidrollCountdowns(node, stopObservingMidrollCountdown);
          const removedContainer =
            node.matches(AUXILIARY_VIDEO_SELECTOR) ||
            Boolean(node.querySelector(AUXILIARY_VIDEO_SELECTOR));
          if (
            node instanceof HTMLVideoElement ||
            removedContainer ||
            node.querySelector("video")
          ) {
            auxiliaryDomRevision += 1;
          }
          shouldReconcilePrimary ||= removedContainer;
        }
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) {
            continue;
          }
          visitDisplayAdSlots(node);
          visitMidrollCountdowns(node, observeMidrollCountdown);
          const nodeIsContainer = node.matches(AUXILIARY_VIDEO_SELECTOR);
          const nestedVideos = node.querySelectorAll("video");
          if (
            node instanceof HTMLVideoElement ||
            nodeIsContainer ||
            nestedVideos.length > 0
          ) {
            auxiliaryDomRevision += 1;
          }
          if (node instanceof HTMLVideoElement) {
            advance(node, "node-added");
          }
          for (const video of nestedVideos) {
            advance(
              video,
              nodeIsContainer ? "container-added" : "subtree-added",
            );
          }
        }
      }
      if (shouldReconcilePrimary) {
        lifecycleCallbacks.reconcilePrimaryPlayback("auxiliary-mutation");
      }
    });
    observer.observe(document, {
      attributeFilter: ["src", "style", "data-role", "id"],
      attributes: true,
      childList: true,
      subtree: true,
    });
    hookRegistry.addCleanup("auxiliary video observer", () =>
      observer.disconnect(),
    );
    for (const element of document.querySelectorAll(
      MIDROLL_COUNTDOWN_SELECTOR,
    )) {
      observeMidrollCountdown(element);
    }
    lifecycleCallbacks.reconcileAuxiliaryVideos("initial");
    if (document.documentElement) visitDisplayAdSlots(document.documentElement);
  }
  function installStartupPlaybackSafetyNet() {
    if (!root.document || !root.HTMLVideoElement) {
      return;
    }

    const MAX_STARTUP_AGE_MS = 15_000;
    // The current player intentionally pauses and replays within 23 ms after
    // its first playing event. Only intervene well after that transition and
    // only when the current position is backed by real buffered media.
    const MIN_READY_STALL_MS = 750;
    const MAX_STARTUP_ATTEMPTS = 1;
    const videoStates = new WeakMap();
    const pendingTimers = new Set();

    hookRegistry.addCleanup("startup safety-net timers", () => {
      for (const timer of pendingTimers) {
        root.clearTimeout(timer);
      }
      pendingTimers.clear();
    });

    const hasActiveAuxiliaryPlayback = (primary) => {
      const scope = primary.closest(PLAYER_SCOPE_SELECTOR) ?? document;
      for (const container of scope.querySelectorAll(
        AUXILIARY_VIDEO_SELECTOR,
      )) {
        if (
          container instanceof HTMLElement &&
          container.style.display === "block"
        ) {
          return true;
        }
        const videos =
          container instanceof HTMLVideoElement
            ? [container]
            : container.querySelectorAll("video");
        for (const video of videos) {
          if (!video.paused && !video.ended) {
            return true;
          }
        }
      }
      return false;
    };

    const stateFor = (video) => {
      const route = currentPlaybackRoute();
      const source = video.currentSrc || video.src || "";
      let state = videoStates.get(video);
      if (!state || state.route !== route || state.source !== source) {
        state = {
          attempts: 0,
          firstSeenAt: monotonicNow(),
          hasProgressed: false,
          pending: false,
          readySince: -Infinity,
          safetyNetPending: false,
          route,
          source,
          userPaused: false,
        };
        videoStates.set(video, state);
      }
      return state;
    };

    const hasPlayableBuffer = (video) => {
      const currentTime = video.currentTime;
      for (let index = 0; index < video.buffered.length; index += 1) {
        if (
          video.buffered.start(index) <= currentTime + 0.25 &&
          video.buffered.end(index) > currentTime + 0.1
        ) {
          return true;
        }
      }
      return false;
    };

    const updateReadyWindow = (video, state) => {
      if (video.readyState >= 2 && hasPlayableBuffer(video)) {
        if (!Number.isFinite(state.readySince)) {
          state.readySince = monotonicNow();
        }
        return;
      }
      state.readySince = -Infinity;
    };

    const scheduleSafetyNet = (video, reason, delay = MIN_READY_STALL_MS) => {
      const state = stateFor(video);
      if (state.pending || state.hasProgressed || state.userPaused) {
        return;
      }
      state.pending = true;
      const timer = root.setTimeout(() => {
        pendingTimers.delete(timer);
        state.pending = false;
        attemptSafetyNet(video, reason);
      }, delay);
      pendingTimers.add(timer);
    };

    const attemptSafetyNet = (video, reason) => {
      const state = stateFor(video);
      const now = monotonicNow();
      updateReadyWindow(video, state);
      if (
        !state.route ||
        !state.source ||
        state.hasProgressed ||
        state.userPaused ||
        state.safetyNetPending ||
        state.attempts >= MAX_STARTUP_ATTEMPTS ||
        now - state.firstSeenAt > MAX_STARTUP_AGE_MS ||
        findPrimaryPlaybackVideo(video) !== video ||
        isAuxiliaryVideo(video) ||
        hasActiveAuxiliaryPlayback(video) ||
        !video.paused ||
        video.ended ||
        video.seeking ||
        video.readyState < 2 ||
        !hasPlayableBuffer(video) ||
        !Number.isFinite(video.currentTime) ||
        video.currentTime > 0.5
      ) {
        return;
      }

      const readyForMs = now - state.readySince;
      if (readyForMs < MIN_READY_STALL_MS) {
        scheduleSafetyNet(video, reason, MIN_READY_STALL_MS - readyForMs);
        return;
      }

      state.safetyNetPending = true;
      state.attempts += 1;
      stats.startupPlayAttempts += 1;
      recordPlaybackIncident("startup-ready-stall", video, {
        reason,
        readyForMs: Number(readyForMs.toFixed(1)),
      });
      reportIssue(
        "Startup playback safety net",
        new Error(
          `Playable primary media remained paused for ${Math.round(readyForMs)} ms; issuing the single guarded play attempt.`,
        ),
        `startup-stall:${state.route}:${summarizeMediaSource(video)}`,
      );
      let result;
      try {
        result = video.play();
      } catch (error) {
        state.safetyNetPending = false;
        stats.startupPlayRejections += 1;
        recordPlaybackIncident("startup-play-rejected", video, {
          errorName: error?.name ?? "Error",
          reason,
        });
        reportIssue(
          `Startup playback safety net rejected (${reason})`,
          error,
          `startup-play:${state.route}:${error?.name ?? "error"}`,
        );
        return;
      }
      Promise.resolve(result).then(
        () => {
          state.safetyNetPending = false;
        },
        (error) => {
          state.safetyNetPending = false;
          stats.startupPlayRejections += 1;
          recordPlaybackIncident("startup-play-rejected", video, {
            errorName: error?.name ?? "Error",
            reason,
          });
          reportIssue(
            `Startup playback safety net rejected (${reason})`,
            error,
            `startup-play:${state.route}:${error?.name ?? "error"}`,
          );
        },
      );
    };

    const onMediaEvent = (event) => {
      const video = event.target;
      if (!(video instanceof HTMLVideoElement) || !currentPlaybackRoute()) {
        return;
      }
      const state = stateFor(video);
      if (event.type === "progress" && video.currentTime > 0.5) {
        state.hasProgressed = true;
        state.safetyNetPending = false;
        return;
      }
      if (event.type === "playing") {
        if (
          !state.hasProgressed &&
          (state.safetyNetPending || state.attempts > 0)
        ) {
          stats.startupPlayRecoveries += 1;
          state.hasProgressed = true;
        } else if (video.currentTime > 0.5) {
          state.hasProgressed = true;
        }
        state.safetyNetPending = false;
        return;
      }
      if (event.type === "pause" && hasRecentUserMediaIntent(video)) {
        state.userPaused = true;
        return;
      }
      if (event.type === "play") {
        state.userPaused = false;
        return;
      }
      updateReadyWindow(video, state);
      scheduleSafetyNet(video, event.type);
    };

    subscribeMediaEvents(
      [
        "loadstart",
        "loadedmetadata",
        "loadeddata",
        "canplay",
        "progress",
        "pause",
        "play",
        "playing",
        "stalled",
        "waiting",
      ],
      onMediaEvent,
      "startup playback",
    );

    lifecycleCallbacks.reconcilePrimaryPlayback = (reason = "reconcile") => {
      const primaries = new Set();
      for (const video of document.querySelectorAll("video")) {
        const primary = findPrimaryPlaybackVideo(video);
        if (primary) {
          primaries.add(primary);
        }
      }
      for (const primary of primaries) {
        const state = stateFor(primary);
        updateReadyWindow(primary, state);
        scheduleSafetyNet(primary, reason);
      }
    };
    for (const [target, type, options] of [
      [document, "visibilitychange", undefined],
      [document, "resume", undefined],
      [root, "focus", true],
      [root, "online", undefined],
      [root, "pageshow", undefined],
    ]) {
      addManagedEventListener(
        target,
        type,
        () => lifecycleCallbacks.reconcilePrimaryPlayback(type),
        options,
        `startup safety net ${type}`,
      );
    }
    lifecycleCallbacks.reconcilePrimaryPlayback("initial");
  }

  // Late document-start delivery can leave already-consumed LIVE data in the
  // application's store. Repair that data through its own setter; hiding the
  // installation layer cannot update the player's P2P/quality state.
  // Contract: current React root + Jotai useAtomValue [value, store, atom].
  function findStartupFiberRoot() {
    const container = root.document.getElementById("root");
    if (!container) return null;
    const candidates = [container];
    for (let index = 0; index < candidates.length && index < 32; index += 1) {
      const candidate = candidates[index];
      const keys = Object.keys(candidate);
      const containerKey = keys.find((name) =>
        name.startsWith("__reactContainer$"),
      );
      if (containerKey) {
        const fiber = candidate[containerKey];
        return fiber?.stateNode?.current ?? fiber ?? null;
      }
      const fiberKey = keys.find((name) => name.startsWith("__reactFiber$"));
      if (fiberKey) {
        let fiber = candidate[fiberKey];
        let depth = 0;
        while (fiber?.return && depth++ < 256) fiber = fiber.return;
        return fiber?.stateNode?.current ?? fiber ?? null;
      }
      for (const child of candidate.children ?? []) {
        if (candidates.length >= 32) break;
        candidates.push(child);
      }
    }
    return null;
  }

  function findStartupPlaybackAtoms(
    channelId,
    fiberRoot = findStartupFiberRoot(),
  ) {
    if (!fiberRoot) return [];

    const stack = [fiberRoot];
    const seenFibers = new WeakSet();
    const seenAtoms = new WeakSet();
    const matches = [];
    let visited = 0;
    while (stack.length && visited++ < 4_000) {
      const fiber = stack.pop();
      if (!isObject(fiber) || seenFibers.has(fiber)) continue;
      seenFibers.add(fiber);
      if (fiber.sibling) stack.push(fiber.sibling);
      if (fiber.child) stack.push(fiber.child);
      if (![0, 11, 14, 15].includes(fiber.tag)) continue;
      let hook = fiber.memoizedState;
      let hooks = 0;
      while (hook && hooks++ < 128) {
        const tuple = hook.memoizedState;
        hook = hook.next;
        if (!Array.isArray(tuple) || tuple.length !== 3) continue;
        const [value, store, atom] = tuple;
        if (
          !isRecord(value) ||
          value.channel?.channelId !== channelId ||
          typeof value.liveId !== "number" ||
          value.status !== "OPEN" ||
          typeof value.livePlaybackJson !== "string" ||
          !value.livePlaybackJson.includes('"p2pPath"') ||
          !isObject(store) ||
          typeof store.get !== "function" ||
          typeof store.set !== "function" ||
          typeof store.sub !== "function" ||
          !isObject(atom) ||
          !hasOwn(atom, "init") ||
          atom.init !== undefined ||
          typeof atom.read !== "function" ||
          typeof atom.write !== "function" ||
          seenAtoms.has(atom)
        )
          continue;
        seenAtoms.add(atom);
        if (store.get(atom) === value) matches.push({ value, store, atom });
      }
    }
    return matches;
  }

  // The current LIVE page keeps playback data in a React useState hook instead
  // of the older Jotai atom. Use the hook's own dispatch function and require the
  // rendered state, queue state, route and payload identity to agree.
  function findStartupPlaybackStateHooks(
    channelId,
    fiberRoot = findStartupFiberRoot(),
  ) {
    if (!fiberRoot) return [];

    const stack = [fiberRoot];
    const seenFibers = new WeakSet();
    const seenQueues = new WeakSet();
    const matches = [];
    let visited = 0;
    while (stack.length && visited++ < 4_000) {
      const fiber = stack.pop();
      if (!isObject(fiber) || seenFibers.has(fiber)) continue;
      seenFibers.add(fiber);
      if (fiber.sibling) stack.push(fiber.sibling);
      if (fiber.child) stack.push(fiber.child);
      if (![0, 11, 14, 15].includes(fiber.tag)) continue;
      let hook = fiber.memoizedState;
      let hooks = 0;
      while (hook && hooks++ < 128) {
        const value = hook.memoizedState;
        const queue = hook.queue;
        hook = hook.next;
        if (
          !isRecord(value) ||
          value.channelId !== channelId ||
          typeof value.liveId !== "number" ||
          typeof value.livePlaybackJson !== "string" ||
          !isObject(queue) ||
          typeof queue.dispatch !== "function" ||
          typeof queue.lastRenderedReducer !== "function" ||
          queue.lastRenderedState !== value ||
          seenQueues.has(queue)
        )
          continue;
        seenQueues.add(queue);
        matches.push({ value, queue });
      }
    }
    return matches;
  }

  function installStartupStateRecovery() {
    const document = root.document;
    if (
      !document?.getElementById ||
      !root.MutationObserver ||
      typeof root.setTimeout !== "function"
    )
      return;

    let disposed = false;
    let route = null;
    let active = null;
    const liveChannel = () =>
      root.location?.pathname
        ?.match(/^\/live\/([0-9a-f]{32})(?:\/|$)/i)?.[1]
        ?.toLowerCase() ?? "";

    function stop() {
      const job = active;
      if (!job) return;
      active = null;
      job.observer.disconnect();
      if (job.deadline !== null) root.clearTimeout(job.deadline);
      if (job.verification !== null) root.clearTimeout(job.verification);
      job.deadline = null;
      job.verification = null;
    }
    function installationGateVisible() {
      const help = document.querySelector(
        'a[href="https://help.naver.com/alias/navergame/chzzk6.naver"]',
      );
      if (!help) return false;
      const rect = help.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0;
    }
    function check(job) {
      job.scheduled = false;
      if (disposed || active !== job) return;
      if (liveChannel() !== job.channelId) return refreshRoute();
      const fiberRoot = findStartupFiberRoot();
      const stateHooks = findStartupPlaybackStateHooks(
        job.channelId,
        fiberRoot,
      );
      for (const { value, queue } of stateHooks) {
        if (job.pendingState.get(queue) !== value) continue;
        job.pendingState.delete(queue);
        stats.lateStartupRecoveries += 1;
        stop();
        return;
      }
      // Successful early interception needs no application-state adapter.
      if (
        stats.directTracks > job.initialDirectTracks &&
        !installationGateVisible()
      ) {
        stop();
        return;
      }
      const initial = job.first;
      job.first = false;
      if (!initial && !installationGateVisible()) return;
      try {
        let recovered = false;
        stats.startupRecoveryScans += 1;
        for (const { value, store, atom } of findStartupPlaybackAtoms(
          job.channelId,
          fiberRoot,
        )) {
          if (job.attempted.has(atom)) continue;
          const playback = Reflect.apply(nativeJsonParse, JSON, [
            value.livePlaybackJson,
          ]);
          const usable = playback?.media?.some(
            (media) =>
              Array.isArray(media?.encodingTrack) &&
              media.encodingTrack.some((track) =>
                Boolean(directUrlFromP2pPath(track?.p2pPath)),
              ),
          );
          if (!usable || store.get(atom) !== value) continue;
          job.attempted.add(atom);
          stats.lateStartupRecoveryAttempts += 1;
          const replacement = Reflect.apply(nativeJsonParse, JSON, [
            Reflect.apply(nativeJsonStringify, JSON, [value]),
          ]);
          if (!rewriteLiveContent(replacement)) continue;
          store.set(atom, replacement);
          if (store.get(atom) === replacement) {
            stats.lateStartupRecoveries += 1;
            recovered = true;
          }
        }
        for (const { value, queue } of stateHooks) {
          if (
            job.attemptedState.has(queue) ||
            !value.livePlaybackJson.includes('"p2pPath"')
          )
            continue;
          const playback = Reflect.apply(nativeJsonParse, JSON, [
            value.livePlaybackJson,
          ]);
          const usable = playback?.media?.some(
            (media) =>
              Array.isArray(media?.encodingTrack) &&
              media.encodingTrack.some((track) =>
                Boolean(directUrlFromP2pPath(track?.p2pPath)),
              ),
          );
          if (!usable || queue.lastRenderedState !== value) continue;
          job.attemptedState.add(queue);
          stats.lateStartupRecoveryAttempts += 1;
          const replacement = Reflect.apply(nativeJsonParse, JSON, [
            Reflect.apply(nativeJsonStringify, JSON, [value]),
          ]);
          if (!rewriteLiveContent(replacement)) continue;
          job.pendingState.set(queue, replacement);
          Reflect.apply(queue.dispatch, undefined, [replacement]);
          if (job.verification === null)
            job.verification = root.setTimeout(function verifyStateUpdate() {
              job.verification = null;
              schedule(job);
            }, 0);
        }
        if (recovered) stop();
      } catch (error) {
        reportIssue(
          "Late startup state recovery",
          error,
          "late-startup-state-recovery",
        );
        stop();
      }
    }
    function schedule(job) {
      if (!disposed && active === job && !job.scheduled) {
        job.scheduled = true;
        enqueueMicrotask(() => check(job));
      }
    }
    function refreshRoute(force = false) {
      if (disposed) return;
      const next = liveChannel();
      if (next === route && !force) return;
      stop();
      route = next;
      if (!next) return;
      const job = {
        channelId: next,
        attempted: new WeakSet(),
        attemptedState: new WeakSet(),
        pendingState: new Map(),
        first: true,
        scheduled: false,
        deadline: null,
        verification: null,
        initialDirectTracks: stats.directTracks,
        observer: null,
      };
      job.observer = new root.MutationObserver(() => schedule(job));
      active = job;
      stats.startupRecoveryWindows += 1;
      job.observer.observe(document, { childList: true, subtree: true });
      job.deadline = root.setTimeout(function stopWindow() {
        if (active === job) {
          if (job.pendingState.size)
            reportIssue(
              "Late startup state recovery",
              new Error(
                "React state update was not committed before deadline.",
              ),
              "late-startup-state-recovery",
            );
          stop();
        }
      }, 30_000);
      schedule(job);
    }
    const routeChanged = () => {
      // Keep native History API return values and exceptions independent of the
      // recovery adapter, and let the application's synchronous navigation finish.
      enqueueMicrotask(() => {
        try {
          refreshRoute();
        } catch (error) {
          stop();
          reportIssue("LIVE route recovery", error, "live-route-recovery");
        }
      });
    };
    hookRegistry.addCleanup("late startup state recovery", () => {
      disposed = true;
      stop();
    });
    for (const name of ["pushState", "replaceState"]) {
      const method = root.history && findMethodDescriptor(root.history, name);
      if (!method || typeof method.descriptor.value !== "function") continue;
      const nativeMethod = method.descriptor.value;
      hookRegistry.define(
        method.owner,
        name,
        {
          ...method.descriptor,
          value: function (...args) {
            const result = Reflect.apply(nativeMethod, this, args);
            routeChanged();
            return result;
          },
        },
        `History.prototype.${name}`,
      );
    }
    addManagedEventListener(
      root,
      "popstate",
      routeChanged,
      false,
      "LIVE route popstate",
    );
    addManagedEventListener(
      root,
      "pageshow",
      (event) => {
        if (event.persisted) {
          route = null;
          routeChanged();
        }
      },
      false,
      "LIVE route pageshow",
    );
    refreshRoute();
  }
  function installDiagnostics() {
    const knownConflicts = () => {
      const conflicts = [];
      if (root[ADGUARD_FILTER_MARKER]) {
        conflicts.push(
          Object.freeze({
            id: "chzzk-adguard-filter",
            message:
              "The overlapping chzzk.com AdGuard scriptlet rewrites ad session responses; disable that rule while this userscript is active.",
          }),
        );
      }
      return Object.freeze(conflicts);
    };

    const auditHookHealth = (reason) => {
      for (const hook of hookRegistry.health()) {
        if (hook.state === "superseded") {
          reportIssue(
            `Hook health audit (${reason})`,
            `${hook.label} was superseded by another script.`,
            `hook-superseded:${hook.label}`,
          );
        }
      }
      for (const conflict of knownConflicts()) {
        reportIssue(
          `Compatibility audit (${reason})`,
          conflict.message,
          `known-conflict:${conflict.id}`,
        );
      }
    };
    const api = Object.freeze({
      version: VERSION,
      getStats: () => Object.freeze({ ...stats }),
      getFailures: () => Object.freeze([...failures]),
      getIssues: () => Object.freeze([...issues]),
      getPlaybackIncidents: () => Object.freeze([...playbackIncidents]),
      getHealth: () => {
        const hooks = hookRegistry.health();
        return Object.freeze({
          healthy: hooks.every(
            ({ state }) => state === "direct" || state === "released",
          ),
          hooks,
          installation: installation.status,
          installationStage: installation.stage,
          knownConflicts: knownConflicts(),
          tunnelProtocols: Object.freeze(
            TUNNEL_PROTOCOLS.map(({ algorithm, label }) =>
              Object.freeze({ algorithm, label }),
            ),
          ),
        });
      },
    });
    hookRegistry.define(
      root,
      "__CHZZK_P2P_BYPASS__",
      { configurable: true, value: api },
      "diagnostics API",
    );
    if (typeof root.addEventListener === "function") {
      for (const type of ["load", "pageshow", "focus"]) {
        addManagedEventListener(
          root,
          type,
          () => auditHookHealth(type),
          true,
          `hook health ${type}`,
        );
      }
    }
    if (root.document?.addEventListener) {
      addManagedEventListener(
        root.document,
        "visibilitychange",
        () => {
          if (root.document.visibilityState === "visible") {
            auditHookHealth("visibilitychange");
          }
        },
        true,
        "hook health visibility",
      );
    }
    auditHookHealth("installation");
  }
  // Order is intentional: early protocol hooks precede application code,
  // subscribers are registered before the shared media-event hub is attached,
  // and diagnostics is published only after every functional hook exists.
  const INSTALLATION_STAGES = Object.freeze([
    Object.freeze({
      id: "playback-signal-guards",
      install: installPlaybackSignalGuards,
    }),
    Object.freeze({
      id: "json-hook",
      install: () => {
        lifecycleCallbacks.releaseJsonFallback = installJsonHook();
      },
    }),
    Object.freeze({ id: "response-hook", install: installResponseHook }),
    Object.freeze({ id: "tunnel-hooks", install: installTunnelHooks }),
    Object.freeze({ id: "ad-bait-hook", install: installAdBaitHook }),
    Object.freeze({ id: "ad-playback-mock", install: installAdPlaybackMock }),
    Object.freeze({
      id: "media-intent-tracker",
      install: installMediaIntentTracker,
    }),
    Object.freeze({
      id: "startup-playback-safety-net",
      install: installStartupPlaybackSafetyNet,
    }),
    Object.freeze({ id: "media-event-hub", install: installMediaEventHub }),
    Object.freeze({
      id: "startup-state-recovery",
      install: installStartupStateRecovery,
    }),
    Object.freeze({ id: "diagnostics", install: installDiagnostics }),
  ]);

  try {
    for (const stage of INSTALLATION_STAGES) {
      installation.stage = stage.id;
      stage.install();
    }
    installation.stage = "complete";
    installation.status = "active";
    Object.defineProperty(root, INSTALL_MARKER, {
      configurable: false,
      value: installation,
    });
    console.info(PREFIX, `v${VERSION} active`);
  } catch (error) {
    const failure = reportFailure(
      `Initialization (${installation.stage})`,
      error,
    );
    installation.failure = Object.freeze({
      message: failure.message,
      name: failure.name,
    });
    installation.status = "failed";
    hookRegistry.rollback();
    throw failure;
  }
})();
