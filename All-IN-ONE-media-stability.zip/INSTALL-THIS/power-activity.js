// Show one estimated channel immediately, then prefer CHZZK's confirmed watch
// rewards. This observer never sends additional watch/reward requests.
(() => {
  if (window.top !== window || window.__cqcPowerActivity) return;
  const KEY = 'cqc_power_activity_v1';
  const CHANGE = 'cqc-power-activity-change';
  const REWARD_TTL = 6 * 60 * 1000; // WATCH_5_MIN plus delivery allowance.
  const WATCH_TTL = 90 * 1000; // The native watch heartbeat normally runs every 30 s.
  const TAB_KEY = 'cqc_power_presence_v1:';
  const tabId = globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2);
  const peers = new Map();
  let own = null, playback = null, lastFocus = false, pageActive = true, bus = null;
  const channelPattern = /^[a-f0-9]{32}$/i;
  let confirmed = null;
  let watch = null;
  const parse = value => {
    try { return typeof value === 'string' ? JSON.parse(value) : value; }
    catch { return null; }
  };
  const channelId = value => typeof value === 'string' && channelPattern.test(value) ? value.toLowerCase() : '';
  const currentChannel = () => /\/chat\/?$/.test(location.pathname) ? '' :
    channelId(location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1]);
  const fresh = (at, ttl) => Number.isFinite(at) && Date.now() >= at && Date.now() - at <= ttl;
  const notify = () => window.dispatchEvent(new Event(CHANGE));
  function readConfirmation(value) {
    const data = parse(value);
    return channelId(data?.channelId) && fresh(data?.confirmedAt, REWARD_TTL) ?
      {channelId: channelId(data.channelId), confirmedAt: data.confirmedAt} : null;
  }
  function readPresence(value) {
    const data = parse(value);
    if (!data || typeof data.tabId !== 'string' || data.tabId.length > 100 ||
        !channelId(data.channelId) || !fresh(data.at, WATCH_TTL) ||
        !Number.isFinite(data.startedAt) || !Number.isFinite(data.focusedAt)) return null;
    return {tabId: data.tabId, channelId: channelId(data.channelId), at: data.at,
      startedAt: data.startedAt, focusedAt: data.focusedAt, eligible: data.eligible === true};
  }
  function receivePresence(value) {
    const data = readPresence(value);
    if (!data || data.tabId === tabId) return false;
    const old = peers.get(data.tabId);
    if (old && (old.at > data.at || JSON.stringify(old) === JSON.stringify(data))) return false;
    peers.set(data.tabId, data);
    return true;
  }
  function broadcast(data) { try { bus?.postMessage(data); } catch {} }
  function releasePresence() {
    if (!own) return;
    own = null;
    peers.delete(tabId);
    try { localStorage.removeItem(TAB_KEY + tabId); } catch {}
    broadcast({type: 'leave', tabId});
  }
  function refreshPresence() {
    const id = currentChannel();
    if (!pageActive || !playback?.enabled || !id || id !== playback.channelId) {
      releasePresence();
      return;
    }
    const focused = document.visibilityState === 'visible' && document.hasFocus();
    const native = watch?.channelId === id ? watch : null;
    const eligible = !!playback.playing && (!native || (native.active && fresh(native.at, WATCH_TTL)));
    const now = Date.now();
    const changedChannel = !own || own.channelId !== id;
    const next = {tabId, channelId: id, at: now, eligible,
      startedAt: changedChannel || (eligible && !own.eligible) ? now : own.startedAt,
      focusedAt: focused && (!lastFocus || changedChannel) ? now : (own?.focusedAt || 0)};
    lastFocus = focused;
    if (own && own.channelId === next.channelId && own.eligible === eligible &&
        own.startedAt === next.startedAt && own.focusedAt === next.focusedAt && now - own.at < 20000) return;
    own = next;
    peers.set(tabId, next);
    for (const [key, value] of peers) if (!fresh(value.at, WATCH_TTL)) peers.delete(key);
    try { localStorage.setItem(TAB_KEY + tabId, JSON.stringify(next)); } catch {}
    broadcast({type: 'presence', value: next});
  }
  function status(id = currentChannel()) {
    id = channelId(id);
    if (!pageActive || !id || id !== currentChannel() || own?.channelId !== id || !own.eligible || !fresh(own.at, WATCH_TTL)) return 'waiting';
    const active = [...peers.values()].filter(peer => peer.eligible && fresh(peer.at, WATCH_TTL));
    if (confirmed && fresh(confirmed.confirmedAt, REWARD_TTL) && active.some(peer => peer.channelId === confirmed.channelId)) {
      return confirmed.channelId === id ? 'confirmed' : 'waiting';
    }
    // Preserve the most recently focused playing channel when all tabs are hidden.
    // A deterministic tie-break prevents simultaneous starts electing two channels.
    active.sort((a, b) => b.focusedAt - a.focusedAt || b.startedAt - a.startedAt || a.tabId.localeCompare(b.tabId));
    return active[0]?.channelId === id ? 'estimated' : 'waiting';
  }
  try { confirmed = readConfirmation(localStorage.getItem(KEY)); } catch {}
  try {
    for (let i = localStorage.length - 1; i >= 0; i--) {
      const key = localStorage.key(i);
      if (!key?.startsWith(TAB_KEY)) continue;
      const data = readPresence(localStorage.getItem(key));
      if (data) peers.set(data.tabId, data);
      else localStorage.removeItem(key);
    }
  } catch {}
  try {
    bus = new BroadcastChannel('cqc_power_activity_v2');
    bus.onmessage = event => {
      const data = event.data;
      if (data?.type === 'request') {
        if (own) broadcast({type: 'presence', value: own});
        if (confirmed && fresh(confirmed.confirmedAt, REWARD_TTL)) broadcast({type: 'confirmed', value: confirmed});
      } else if (data?.type === 'presence' && receivePresence(data.value)) notify();
      else if (data?.type === 'leave' && data.tabId !== tabId && peers.delete(data.tabId)) notify();
      else if (data?.type === 'confirmed') {
        const next = readConfirmation(data.value);
        if (next && (!confirmed || next.confirmedAt > confirmed.confirmedAt)) { confirmed = next; notify(); }
      }
    };
    broadcast({type: 'request'});
  } catch {}
  window.addEventListener('storage', event => {
    if (event.key === KEY || event.key === null) {
      confirmed = readConfirmation(event.newValue);
      if (event.key === null) { peers.clear(); if (own) peers.set(tabId, own); }
      notify();
    } else if (event.key?.startsWith(TAB_KEY)) {
      if (event.newValue === null) {
        if (peers.delete(event.key.slice(TAB_KEY.length))) notify();
      } else if (receivePresence(event.newValue)) notify();
    }
  });

  function acceptReward(raw) {
    // Skip chat/media traffic before parsing; do not retain any message text.
    if (typeof raw !== 'string' || raw.length > 131072 || !raw.includes('LOG_POWER')) return;
    let packet = parse(raw), message = null;
    if (!packet) {
      // Socket.IO 1+/Engine.IO event (42[...]) or legacy Socket.IO 0.9 (5:::{...}).
      if (/^42(?:\/[^,]*,)?\d*\[/.test(raw)) packet = parse(raw.slice(raw.indexOf('[')));
      else if (/^5:[^:]*:[^:]*:/.test(raw)) packet = parse(raw.slice(raw.indexOf('{')));
    }
    if (Array.isArray(packet) && packet[0] === 'personalMessage') message = parse(packet[1]);
    else if (packet?.name === 'personalMessage') message = parse(packet.args?.[0]);
    else if (packet?.type === 'LOG_POWER') message = packet;
    const data = parse(message?.data);
    const id = channelId(message?.channelId);
    // FOLLOW, donations, prediction payouts and delayed WATCH_1_HOUR claims do
    // not establish that this channel is currently accumulating watch time.
    if (!id || message.type !== 'LOG_POWER' || message.subType !== 'SAVE' || data?.claimType !== 'WATCH_5_MIN') return;
    try { confirmed = readConfirmation(localStorage.getItem(KEY)) || confirmed; } catch {}
    if (confirmed?.channelId === id && fresh(confirmed.confirmedAt, 2000)) return;
    confirmed = {channelId: id, confirmedAt: Date.now()};
    try { localStorage.setItem(KEY, JSON.stringify(confirmed)); } catch {}
    broadcast({type: 'confirmed', value: confirmed});
    notify();
  }

  const NativeWebSocket = window.WebSocket;
  if (typeof NativeWebSocket === 'function') {
    try {
      window.WebSocket = new Proxy(NativeWebSocket, {
        construct(target, args, newTarget) {
          const socket = Reflect.construct(target, args, newTarget);
          try {
            const url = new URL(String(args[0]), location.href);
            if (url.hostname === 'naver.com' || url.hostname.endsWith('.naver.com')) {
              socket.addEventListener('message', event => { try { acceptReward(event.data); } catch {} });
            }
          } catch {}
          return socket;
        }
      });
    } catch {}
  }

  function isWatchURL(value) {
    try {
      const url = new URL(String(value), location.href);
      return url.origin === 'https://api.chzzk.naver.com' && url.pathname === '/polling/v1/watch-event/live';
    } catch { return false; }
  }
  function readWatch(body, startedAt) {
    const data = parse(body), id = channelId(data?.channelId), type = data?.payload?.watchEventType;
    if (!id || !['WATCH_STARTED', 'WATCH_RESUMED', 'WATCH_CONTINUED', 'WATCH_PAUSED', 'WATCH_ENDED'].includes(type)) return null;
    return {channelId: id, at: startedAt, active: data.autoPlay !== true && data.radioMode !== true &&
      ['WATCH_STARTED', 'WATCH_RESUMED', 'WATCH_CONTINUED'].includes(type)};
  }
  function acceptWatch(info, status, body) {
    if (!info || info.channelId !== currentChannel() || (watch && info.at < watch.at)) return;
    const json = parse(body);
    const ok = status >= 200 && status < 300 && json && (json.code == null || Number(json.code) === 200);
    watch = {...info, active: !!(info.active && ok)};
    refreshPresence();
    notify();
  }
  // CHZZK uses Axios/XHR for watch-event/live. Observe only this small response;
  // leave its request, credentials, timing and response untouched.
  const xhrPrototype = window.XMLHttpRequest?.prototype;
  if (xhrPrototype) {
    const open = xhrPrototype.open, send = xhrPrototype.send, requests = new WeakMap();
    xhrPrototype.open = function(method, url, ...rest) {
      const result = Reflect.apply(open, this, [method, url, ...rest]);
      requests.set(this, String(method).toUpperCase() === 'POST' && isWatchURL(url));
      return result;
    };
    xhrPrototype.send = function(body) {
      if (requests.get(this)) {
        const info = readWatch(body, Date.now());
        if (info) this.addEventListener('loadend', () => {
          try { acceptWatch(info, this.status, this.responseType === 'json' ? this.response : this.responseText); } catch {}
        }, {once: true});
      }
      return Reflect.apply(send, this, arguments);
    };
  }
  const nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = function(input, init) {
      const result = Reflect.apply(nativeFetch, this, arguments);
      if (isWatchURL(typeof input === 'string' || input instanceof URL ? input : input?.url) &&
          String(init?.method || input?.method || 'GET').toUpperCase() === 'POST') {
        const startedAt = Date.now();
        try {
          const body = init?.body ?? input?.clone?.().text();
          Promise.resolve(body).then(value => {
            const info = readWatch(value, startedAt);
            if (info) return result.then(async response => acceptWatch(info, response.status, await response.clone().json()));
          }).catch(() => {});
        } catch {}
      }
      return result;
    };
  }
  window.addEventListener('pagehide', () => { pageActive = false; watch = null; releasePresence(); });
  window.addEventListener('pageshow', () => { pageActive = true; refreshPresence(); notify(); });
  window.addEventListener('cqc-power-background-tick', () => { refreshPresence(); notify(); });
  Object.defineProperty(window, '__cqcPowerActivity', {value: Object.freeze({
    updatePlayback(value) {
      playback = {channelId: channelId(value?.channelId), enabled: !!value?.enabled, playing: !!value?.playing};
      refreshPresence();
    },
    getStatus: status,
    getStatusTitle() {
      switch (status()) {
        case 'confirmed': return '치지직 시청 적립 알림으로 확인된 채널';
        case 'estimated': return '현재 시청 상태로 예상한 적립 채널 · 서버 적립 확인 전';
        default: return '다른 채널이 선택되어 있거나 시청 적립 대기 중';
      }
    },
    isFarming(id) {
      return status(id) !== 'waiting';
    }
  }), configurable: true});
})();
