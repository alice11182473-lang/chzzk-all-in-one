// Read-only observation of CHZZK's own watch rewards. Never elect an earning tab
// from focus/play events or send additional watch/reward requests.
(() => {
  if (window.top !== window || window.__cqcPowerActivity) return;
  const KEY = 'cqc_power_activity_v1';
  const CHANGE = 'cqc-power-activity-change';
  const REWARD_TTL = 6 * 60 * 1000; // WATCH_5_MIN plus delivery allowance.
  const WATCH_TTL = 90 * 1000; // The native watch heartbeat normally runs every 30 s.
  const channelPattern = /^[a-f0-9]{32}$/i;
  let confirmed = null;
  let watch = null;
  const parse = value => {
    try { return typeof value === 'string' ? JSON.parse(value) : value; }
    catch { return null; }
  };
  const channelId = value => typeof value === 'string' && channelPattern.test(value) ? value.toLowerCase() : '';
  const currentChannel = () => /\/chat\/?$/.test(location.pathname) ? '' :
    channelId(location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1]);
  const fresh = (at, ttl) => Number.isFinite(at) && Date.now() >= at && Date.now() - at <= ttl;
  const notify = () => window.dispatchEvent(new Event(CHANGE));
  function readConfirmation(value) {
    const data = parse(value);
    return channelId(data?.channelId) && fresh(data?.confirmedAt, REWARD_TTL) ?
      {channelId: channelId(data.channelId), confirmedAt: data.confirmedAt} : null;
  }
  try { confirmed = readConfirmation(localStorage.getItem(KEY)); } catch {}
  window.addEventListener('storage', event => {
    if (event.key === KEY || event.key === null) {
      confirmed = readConfirmation(event.newValue);
      notify();
    }
  });

  function acceptReward(raw) {
    // Skip chat/media traffic before parsing; do not retain any message text.
    if (typeof raw !== 'string' || raw.length > 131072 || !raw.includes('LOG_POWER')) return;
    let packet = parse(raw), message = null;
    if (!packet) {
      // Socket.IO 1+/Engine.IO event (42[...]) or legacy Socket.IO 0.9 (5:::{...}).
      if (/^42(?:\/[^,]*,)?\d*\[/.test(raw)) packet = parse(raw.slice(raw.indexOf('[')));
      else if (/^5:[^:]*:[^:]*:/.test(raw)) packet = parse(raw.slice(raw.indexOf('{')));
    }
    if (Array.isArray(packet) && packet[0] === 'personalMessage') message = parse(packet[1]);
    else if (packet?.name === 'personalMessage') message = parse(packet.args?.[0]);
    else if (packet?.type === 'LOG_POWER') message = packet;
    const data = parse(message?.data);
    const id = channelId(message?.channelId);
    // FOLLOW, donations, prediction payouts and delayed WATCH_1_HOUR claims do
    // not establish that this channel is currently accumulating watch time.
    if (!id || message.type !== 'LOG_POWER' || message.subType !== 'SAVE' || data?.claimType !== 'WATCH_5_MIN') return;
    try { confirmed = readConfirmation(localStorage.getItem(KEY)) || confirmed; } catch {}
    if (confirmed?.channelId === id && fresh(confirmed.confirmedAt, 2000)) return;
    confirmed = {channelId: id, confirmedAt: Date.now()};
    try { localStorage.setItem(KEY, JSON.stringify(confirmed)); } catch {}
    notify();
  }

  const NativeWebSocket = window.WebSocket;
  if (typeof NativeWebSocket === 'function') {
    try {
      window.WebSocket = new Proxy(NativeWebSocket, {
        construct(target, args, newTarget) {
          const socket = Reflect.construct(target, args, newTarget);
          try {
            const url = new URL(String(args[0]), location.href);
            if (url.hostname === 'naver.com' || url.hostname.endsWith('.naver.com')) {
              socket.addEventListener('message', event => { try { acceptReward(event.data); } catch {} });
            }
          } catch {}
          return socket;
        }
      });
    } catch {}
  }

  function isWatchURL(value) {
    try {
      const url = new URL(String(value), location.href);
      return url.origin === 'https://api.chzzk.naver.com' && url.pathname === '/polling/v1/watch-event/live';
    } catch { return false; }
  }
  function readWatch(body, startedAt) {
    const data = parse(body), id = channelId(data?.channelId), type = data?.payload?.watchEventType;
    if (!id || !['WATCH_STARTED', 'WATCH_RESUMED', 'WATCH_CONTINUED', 'WATCH_PAUSED', 'WATCH_ENDED'].includes(type)) return null;
    return {channelId: id, at: startedAt, active: data.autoPlay !== true && data.radioMode !== true &&
      ['WATCH_STARTED', 'WATCH_RESUMED', 'WATCH_CONTINUED'].includes(type)};
  }
  function acceptWatch(info, status, body) {
    if (!info || info.channelId !== currentChannel() || (watch && info.at < watch.at)) return;
    const json = parse(body);
    const ok = status >= 200 && status < 300 && json && (json.code == null || Number(json.code) === 200);
    watch = {...info, active: !!(info.active && ok)};
    notify();
  }
  // CHZZK uses Axios/XHR for watch-event/live. Observe only this small response;
  // leave its request, credentials, timing and response untouched.
  const xhrPrototype = window.XMLHttpRequest?.prototype;
  if (xhrPrototype) {
    const open = xhrPrototype.open, send = xhrPrototype.send, requests = new WeakMap();
    xhrPrototype.open = function(method, url, ...rest) {
      const result = Reflect.apply(open, this, [method, url, ...rest]);
      requests.set(this, String(method).toUpperCase() === 'POST' && isWatchURL(url));
      return result;
    };
    xhrPrototype.send = function(body) {
      if (requests.get(this)) {
        const info = readWatch(body, Date.now());
        if (info) this.addEventListener('loadend', () => {
          try { acceptWatch(info, this.status, this.responseType === 'json' ? this.response : this.responseText); } catch {}
        }, {once: true});
      }
      return Reflect.apply(send, this, arguments);
    };
  }
  const nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = function(input, init) {
      const result = Reflect.apply(nativeFetch, this, arguments);
      if (isWatchURL(typeof input === 'string' || input instanceof URL ? input : input?.url) &&
          String(init?.method || input?.method || 'GET').toUpperCase() === 'POST') {
        const startedAt = Date.now();
        try {
          const body = init?.body ?? input?.clone?.().text();
          Promise.resolve(body).then(value => {
            const info = readWatch(value, startedAt);
            if (info) return result.then(async response => acceptWatch(info, response.status, await response.clone().json()));
          }).catch(() => {});
        } catch {}
      }
      return result;
    };
  }
  window.addEventListener('pagehide', () => { watch = null; });
  Object.defineProperty(window, '__cqcPowerActivity', {value: Object.freeze({
    isFarming(id) {
      id = channelId(id);
      return !!(id && id === currentChannel() && confirmed?.channelId === id &&
        fresh(confirmed.confirmedAt, REWARD_TTL) && watch?.channelId === id && watch.active && fresh(watch.at, WATCH_TTL));
    }
  }), configurable: true});
})();
