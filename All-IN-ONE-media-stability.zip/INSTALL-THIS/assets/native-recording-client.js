const api=globalThis.chrome||globalThis.browser;
const channel=()=>location.pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1]||null;
const active=job=>['starting','recording','stopping'].includes(job?.status);
export function installNativeRecorder({onJob,onNotice}){
 let current=null,lastChannel=null,busy=false,lastSignature='',lastError='';
 async function send(message){const response=await api.runtime.sendMessage(message);if(response?.ok===false)throw new Error(response.error||'보조 프로그램 연결 실패');return response;}
 function update(state){
  const cid=channel();const job=cid?state?.jobs?.[cid]||null:null;
  current=job;lastChannel=cid;
  const signature=JSON.stringify([cid,job?.status,job?.startedAt,job?.path,job?.error]);
  if(signature!==lastSignature){lastSignature=signature;onJob(job);}
  if(job?.error&&job.error!==lastError){lastError=job.error;onNotice(job.error);}
 }
 async function refresh(){try{update(await send({type:'CQC_NATIVE_STATUS'}));}catch{}}
 async function start(automatic=false){
  const cid=channel();if(!cid||busy)return;
  busy=true;
  try{
   const data=await send({type:'CQC_NATIVE_START',channelId:cid,automatic});
   if(data?.job)update({jobs:{[cid]:data.job}});
  }catch(error){onNotice('원본 녹화 연결 실패: '+error.message+' · 설정에서 보조 프로그램 연결을 확인하세요.');}
  finally{busy=false;}
 }
 async function stop(){
  const cid=channel();if(!cid||busy)return;busy=true;
  try{await send({type:'CQC_NATIVE_STOP',channelId:cid});onNotice('녹화 정지 요청 · 파일을 마무리하고 있습니다.');await refresh();}
  catch(error){onNotice(error.message);}finally{busy=false;}
 }
 api.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.cqcNativeRecordingState)update(changes.cqcNativeRecordingState.newValue);});
 api.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.type==='CQC_AUTO_RECORD_START'){void start(true);reply({success:true});}
  if(message.type==='CQC_RECORD_STATUS')reply({recording:busy||active(current)});
  if(message.type==='CQC_STARTUP_STATUS'){
   const v=document.querySelector('.pzp video, .chzzk_player video, video.webplayer-internal-video');
   reply({playing:!!v&&!v.paused&&v.readyState>=2,recording:current?.status==='recording'});
  }
  if(message.type==='CQC_RECORD_DIAGNOSTICS')reply({mode:'native-stream-copy',status:current?.status||'no-recording',...current});
 });
 setInterval(refresh,2000);
 void (async()=>{
  await refresh();
  const {settings}=await api.storage.sync.get('settings');const cid=channel();
  if(!current&&cid&&settings?.enabled&&settings.liveAutoOpenEnabled&&settings.liveAutoOpenChannels?.some(c=>c.channelId===cid)&&settings.liveAutoRecordChannels?.includes(cid))await start(true);
 })().catch(()=>{});
 return {toggle:()=>active(current)?stop():start(false),stop,isActive:()=>busy||active(current)};
}
