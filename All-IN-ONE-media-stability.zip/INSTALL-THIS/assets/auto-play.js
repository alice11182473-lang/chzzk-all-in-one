const pending = new WeakMap();
function soundPrompt(video, blocked = false) {
  let button=document.getElementById('cqc-auto-play-sound');
  if(!button){button=document.createElement('button');button.id='cqc-auto-play-sound';button.type='button';button.style.cssText='position:fixed;top:80px;right:20px;z-index:2147483647;padding:10px 16px;border:1px solid #00ffa3;border-radius:8px;background:#18181f;color:white;cursor:pointer';document.documentElement.append(button);}
  button.textContent=blocked?'방송 재생·소리 켜기':'자동 재생 중 · 소리 켜기';
  button.onclick=async()=>{
    const current=document.querySelector('.pzp video, .chzzk_player video, video.webplayer-internal-video')||video;
    try{current.muted=false;if(current.volume===0)current.volume=.5;await current.play();button.remove();}
    catch{button.textContent='재생이 차단되었습니다 · 플레이어 재생 버튼을 눌러 주세요';}
  };
}
export function ensureAutoPlayback(video) {
  if(pending.has(video))return pending.get(video);
  const promise=(async()=>{
    video.muted=false;if(video.volume===0)video.volume=.5;
    try{await video.play();return {playing:!video.paused,muted:video.muted};}
    catch(error){
      if(error?.name!=='NotAllowedError')throw error;
      video.muted=true;
      try{await video.play();soundPrompt(video);return {playing:!video.paused,muted:true};}
      catch{soundPrompt(video,true);return {playing:false,muted:true,blocked:true};}
    }
  })();
  pending.set(video,promise);promise.finally(()=>pending.delete(video)).catch(()=>{});return promise;
}
export async function installAutoPlayback(){
  if(window.top!==window.self)return;
  const url=new URL(location.href);
  if(url.searchParams.get('cqc_auto_play')!=='1')return;
  const channel=url.pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1];if(!channel)return;
  const api=globalThis.chrome||globalThis.browser;
  const {settings}=await api.storage.sync.get('settings');
  if(!settings?.enabled||!settings.liveAutoOpenEnabled||!settings.liveAutoOpenChannels?.some(c=>c.channelId===channel))return;
  const clean=new URL(location.href);clean.searchParams.delete('cqc_auto_play');history.replaceState(history.state,'',clean);
  const deadline=Date.now()+120000;
  async function attempt(){
    if(location.pathname!==url.pathname||Date.now()>deadline)return;
    const video=document.querySelector('.pzp video, .chzzk_player video, video.webplayer-internal-video');
    if(video&&video.readyState>=1){try{const result=await ensureAutoPlayback(video);if(result.playing||result.blocked)return;}catch{}}
    setTimeout(attempt,1000);
  }
  void attempt();
}
