const STYLE_ID = 'cqc-sidebar-hidden-rules';
const SCOPE = ':is(#sidebar, aside[class*="aside_container"], [class*="_wrapper_1vdxf_"])';
export function sidebarHiddenCss(settings) {
  if (!settings || settings.enabled === false) return '';
  const hidden = new Set(settings.hiddenSidebarMenus || []);
  const selectors = [];
  for (const [name,path] of [['전체 방송','/lives'],['카테고리','/category'],['편성표','/schedule'],['팔로잉','/following'],['인기 클립','/clips']]) {
    if (hidden.has(name)) selectors.push(`${SCOPE} a[href="${path}"]`,`${SCOPE} li:has(> a[href="${path}"])`);
  }
  if (hidden.has('치즈팜')) {
    // Persistent selectors apply to new sidebar nodes before their first paint.
    const banner = ':is(a[href="/cheezefarm"], a[href^="/cheezefarm?"], [class*="aside_banner"], [class*="banner"])';
    selectors.push(`${SCOPE} ${banner}`, `${SCOPE} li:has(> ${banner})`);
  }
  return selectors.length ? selectors.join(',\n') + ' { display: none !important; }' : '';
}
export function installSidebarImmediate(settings, patch) {
  window.__cqcSidebarImmediateStop?.();
  let style = document.getElementById(STYLE_ID);
  if (!style) {style=document.createElement('style');style.id=STYLE_ID;(document.head || document.documentElement).appendChild(style);}
  style.textContent=sidebarHiddenCss(settings);
  const options={subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','href','style','hidden']};
  const observer=new MutationObserver(records=>{
    const relevant=records.some(r=>{
      const target=r.target.nodeType===1?r.target:r.target.parentElement;
      return target?.closest?.(SCOPE) || [...r.addedNodes].some(n=>n.matches?.(SCOPE)||n.querySelector?.(SCOPE));
    });
    if (!relevant) return;
    // Ignore our own display writes, preventing a MutationObserver feedback loop.
    observer.disconnect();
    try {patch();} finally {observer.observe(document.documentElement,options);}
  });
  patch();observer.observe(document.documentElement,options);
  window.__cqcSidebarImmediateStop=()=>{observer.disconnect();};
}
export function cleanupSidebarImmediate() {
  window.__cqcSidebarImmediateStop?.();delete window.__cqcSidebarImmediateStop;
  document.getElementById(STYLE_ID)?.remove();
}
