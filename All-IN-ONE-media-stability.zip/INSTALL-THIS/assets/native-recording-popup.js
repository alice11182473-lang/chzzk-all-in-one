const api=globalThis.chrome||globalThis.browser;
function setup(){
 const status=document.getElementById('cqc-native-status'),list=document.getElementById('cqc-native-jobs');
 const send=async message=>{const r=await api.runtime.sendMessage(message);if(r?.ok===false)throw new Error(r.error);return r;};
 document.getElementById('cqc-native-id')?.addEventListener('click',async()=>{await navigator.clipboard.writeText(api.runtime.id);status.textContent='확장 ID를 복사했습니다. NATIVE-RECORDER/INSTALL.cmd에 붙여넣으세요.';});
 document.getElementById('cqc-native-check')?.addEventListener('click',async()=>{
  status.textContent='보조 프로그램에 연결하고 있습니다…';
  try{const r=await send({type:'CQC_NATIVE_PING'});status.textContent=r.ready?'연결됨 · 기본 저장 폴더: '+r.outputRoot:'필수 프로그램이 없습니다. INSTALL.cmd를 다시 실행하세요.';render(r.jobs||{});}
  catch(error){status.textContent='연결 실패: '+error.message+' · NATIVE-RECORDER/INSTALL.cmd를 실행하세요.';}
 });
 document.getElementById('cqc-native-stop-all')?.addEventListener('click',async()=>{try{await send({type:'CQC_NATIVE_STOP_ALL'});status.textContent='전체 녹화 정지 요청 · 파일 마무리 중';}catch(error){status.textContent=error.message;}});
 function render(jobs){
  if(!list)return;list.replaceChildren();
  const labels={starting:'연결 중',recording:'녹화 중',stopping:'마무리 중',stopped:'저장 완료',error:'오류'};
  for(const job of Object.values(jobs)){
   const row=document.createElement('div');row.className='opt-desc';row.style.cssText='overflow-wrap:anywhere;padding:6px 0';
   const text=document.createElement('span');text.textContent=`${job.channelId.slice(0,8)} · ${labels[job.status]||job.status} · ${(job.bytes/1024/1024).toFixed(1)}MB\n${job.error||job.path||''}`;row.append(text);
   if(['starting','recording','stopping'].includes(job.status)){
    const button=document.createElement('button');button.className='btn btn--sec';button.textContent='정지';button.onclick=()=>send({type:'CQC_NATIVE_STOP',channelId:job.channelId}).catch(error=>{status.textContent=error.message;});row.append(button);
   }
   list.append(row);
  }
 }
 api.storage.local.get('cqcNativeRecordingState').then(data=>{render(data.cqcNativeRecordingState?.jobs||{});if(data.cqcNativeRecordingState?.lastError)status.textContent=data.cqcNativeRecordingState.lastError;});
 api.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.cqcNativeRecordingState)render(changes.cqcNativeRecordingState.newValue?.jobs||{});});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
