import { recordingDownloadName } from './recording-path.js';
const api = globalThis.chrome || globalThis.browser;
const intents = api.storage.session || api.storage.local;
const key = url => 'cqcRecordingDownload:' + url;
const validURL = url => /^blob:https:\/\/chzzk\.naver\.com\//.test(url || '');
const validName = name => /^chzzk_[^/\\]+\.(mp4|webm|mkv)$/i.test(name || '');
// Match the intended name by URL, even if MIME sniffing proposes .txt.
api.downloads.onDeterminingFilename.addListener((item,suggest)=>{
  if(!validURL(item.url)){suggest();return;}
  Promise.all([intents.get(key(item.url)),api.storage.local.get('cqcRecordingFolder').catch(()=>({}))]).then(([saved,settings])=>{
    const name=saved[key(item.url)]?.filename || (item.filename||'').split(/[\\/]/).pop();
    if(!validName(name)){suggest();return;}
    let filename=name;
    try{filename=recordingDownloadName({...item,filename:name},settings.cqcRecordingFolder)||name;}catch{}
    suggest({filename,conflictAction:'uniquify'});
  },()=>suggest());
  return true;
});
api.runtime.onMessage.addListener((message,sender,reply)=>{
  if(!sender.tab || !/^https:\/\/chzzk\.naver\.com\//.test(sender.url||''))return;
  if(message.type==='CQC_DISK_RECORD_DOWNLOAD'){
    if(!validURL(message.url)||!validName(message.filename))return;
    (async()=>{
      const k=key(message.url);
      await intents.set({[k]:{filename:message.filename}});
      try{return {id:await api.downloads.download({url:message.url,filename:message.filename,conflictAction:'uniquify'})};}
      catch(error){await intents.remove(k);throw error;}
    })().then(reply,error=>reply({error:error.message}));return true;
  }
  if(message.type==='CQC_DISK_RECORD_DOWNLOAD_STATUS'&&Number.isInteger(message.id)){
    api.downloads.search({id:message.id}).then(items=>reply({state:items[0]?.state||'missing'}),()=>reply({state:'missing'}));return true;
  }
});
api.downloads.onChanged?.addListener(delta=>{
  if(!['complete','interrupted'].includes(delta.state?.current))return;
  api.downloads.search({id:delta.id}).then(items=>{
    if(validURL(items[0]?.url))return intents.remove(key(items[0].url));
  }).catch(()=>{});
});
