import { recordingDownloadName } from './recording-path.js';
const api = globalThis.chrome || globalThis.browser;
// Registered synchronously so MV3 can wake the worker for a finished recording.
api.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (!/^blob:https:\/\/chzzk\.naver\.com\//.test(item.url || '') ||
      !/^chzzk_[^/\\]+\.(webm|mp4)$/i.test((item.filename || '').split(/[\\/]/).pop())) {
    suggest(); return;
  }
  api.storage.local.get('cqcRecordingFolder').then(data => {
    try {
      const filename = recordingDownloadName(item, data.cqcRecordingFolder);
      suggest(filename ? {filename, conflictAction: 'uniquify'} : undefined);
    } catch { suggest(); }
  }, () => suggest());
  return true;
});
