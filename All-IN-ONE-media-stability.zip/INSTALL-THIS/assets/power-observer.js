// React can show a reward while the tab is hidden. Observe it without rAF/timers.
export function observePowerRewards(collect) {
  let queued = false;
  const run = () => { if (queued) return; queued = true; queueMicrotask(() => {queued=false;collect();}); };
  const observer = new MutationObserver(records => {
    if (records.some(r => r.type === 'attributes' || r.target?.closest?.('button') ||
      [...r.addedNodes].some(n => n.matches?.('button') || n.querySelector?.('button')))) run();
  });
  observer.observe(document.documentElement, {childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['disabled']});
  window.addEventListener('cqc-power-background-tick', run);
  window.addEventListener('pageshow', run);
  run();
  return () => {observer.disconnect();window.removeEventListener('cqc-power-background-tick',run);window.removeEventListener('pageshow',run);};
}
