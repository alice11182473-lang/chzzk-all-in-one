// One controller owns playback-position corrections; never reloads or changes source.
export class LatencyController {
  constructor(video,host){
    Object.assign(this,{video,host,ownedRate:null,lastJump:-Infinity,userGesture:-Infinity,ownSeekUntil:0,userTimeshift:false,highTicks:0,status:'disabled',cooldownUntil:0,stallCount:0,stableTicks:0});
    this.onPointer=e=>{if(e.isTrusted&&host.contains(e.target))this.userGesture=Date.now()};
    this.onKey=e=>{if(e.isTrusted&&['ArrowLeft','ArrowRight','Home','End'].includes(e.key)&&!['INPUT','TEXTAREA'].includes(e.target?.tagName))this.userGesture=Date.now()};
    this.onSeeking=()=>{if(Date.now()>this.ownSeekUntil&&Date.now()-this.userGesture<2000)this.userTimeshift=true};
    this.onWaiting=()=>{if(video.paused||video.seeking||this.userTimeshift)return;this.release();this.cooldownUntil=Date.now()+10000;this.stallCount=Math.min(4,this.stallCount+1);this.highTicks=0;this.stableTicks=0;this.status='buffer-recovery'};
    host.addEventListener('pointerdown',this.onPointer,true);document.addEventListener('keydown',this.onKey,true);
    video.addEventListener('seeking',this.onSeeking);video.addEventListener('waiting',this.onWaiting);
  }
  gap(){try{const v=this.video;return v.seekable.length?Math.max(0,v.seekable.end(v.seekable.length-1)-v.currentTime):-1}catch{return -1}}
  bufferRange(){try{const v=this.video;for(let i=0;i<v.buffered.length;i++)if(v.buffered.start(i)<=v.currentTime+.05&&v.buffered.end(i)>=v.currentTime)return {start:v.buffered.start(i),end:v.buffered.end(i)};}catch{}return null;}
  release(){const v=this.video;if(this.ownedRate!==null&&Math.abs(v.playbackRate-this.ownedRate)<.001)v.playbackRate=1;this.ownedRate=null;}
  rate(value){if(Math.abs(this.video.playbackRate-value)>.001)this.video.playbackRate=value;this.ownedRate=value===1?null:value;}
  recording(){return this.video.dataset?.cqcRecording==='true';}
  jump(target){
    const v=this.video,range=this.bufferRange();
    if(!v.seekable.length||v.readyState<3||v.paused||v.seeking||!range)return false;
    const position=v.seekable.end(v.seekable.length-1)-target;
    // seekable can be ahead of downloaded data. Never jump across an unbuffered gap.
    if(!Number.isFinite(position)||position<range.start||position>range.end-.8||position<=v.currentTime+.5)return false;
    this.release();this.ownSeekUntil=Date.now()+3000;this.lastJump=Date.now();v.currentTime=position;this.highTicks=0;return true;
  }
  goLive(target=3){this.userTimeshift=false;this.video.dataset.cqcTimeshifting='false';return this.jump(Math.max(1,Number(target)||3));}
  tick(settings,manualRate=1){
    const v=this.video,configured=Number(settings?.targetLatency),automatic=!!settings?.playbackSpeedResetOnLive;
    const target=configured>0?configured:(automatic?3:0),gap=this.gap();
    if(!settings?.enabled||!/^\/live\//.test(location.pathname)||!target){this.release();this.highTicks=0;this.status='disabled';return;}
    if(v.paused||v.seeking||v.readyState<2||gap<0){this.release();this.status='waiting';return;}
    if(this.userTimeshift||v.dataset?.cqcTimeshifting==='true'||Date.now()-Number(v.dataset?.cqcLastSeekTime||0)<5000){this.release();this.status='timeshift';return;}
    if((Number(manualRate)>0&&Number(manualRate)!==1)||(Math.abs(v.playbackRate-1)>.001&&(this.ownedRate===null||Math.abs(v.playbackRate-this.ownedRate)>.001))){this.ownedRate=null;this.status='manual-speed';return;}
    if(Date.now()<this.cooldownUntil){this.release();this.status='buffer-recovery';return;}
    const range=this.bufferRange(),ahead=range?range.end-v.currentTime:0;
    // After a stall temporarily leave extra headroom, relaxing it after stable playback.
    if(ahead>1&&++this.stableTicks>=30){this.stallCount=Math.max(0,this.stallCount-1);this.stableTicks=0;}
    const desired=Math.max(1,target)+this.stallCount*.5;this.effectiveTarget=desired;
    const excess=gap-desired;
    if(excess<=.25){this.release();this.highTicks=0;this.status='on-target';return;}
    if(ahead<.8||v.readyState<3){this.release();this.highTicks=0;this.status='buffering';return;}
    this.highTicks++;
    // Gradual mode and all automatic correction during recording use rate only.
    const instant=settings.chaserMode==='instant'&&!this.recording();
    if(instant&&excess>1&&this.highTicks>=3&&Date.now()-this.lastJump>=30000&&this.jump(desired)){this.status='jumped';return;}
    if(Date.now()-this.lastJump<5000){this.release();this.status='settling';return;}
    // Cap speed by BOTH remaining target distance and actually downloaded headroom.
    const cap=this.recording()?1.03:1.05;
    const extra=Math.min(cap-1,excess*.02,Math.max(0,ahead-.65)*.04);
    if(extra<.005){this.release();this.status='buffering';return;}
    this.rate(1+extra);this.status='catching-up';
  }
  dispose(){this.release();this.host.removeEventListener('pointerdown',this.onPointer,true);document.removeEventListener('keydown',this.onKey,true);this.video.removeEventListener('seeking',this.onSeeking);this.video.removeEventListener('waiting',this.onWaiting);}
}
