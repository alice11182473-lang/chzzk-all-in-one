import { normalizeRecordingFolder } from './recording-path.js';
const api = globalThis.chrome || globalThis.browser;
async function install() {
  const input = document.getElementById('cqc-recording-folder');
  const save = document.getElementById('cqc-recording-folder-save');
  const status = document.getElementById('cqc-recording-folder-status');
  if (!input || !save) return;
  try { input.value = (await api.storage.local.get('cqcRecordingFolder')).cqcRecordingFolder || ''; }
  catch { status.textContent = '저장된 경로를 불러오지 못했습니다.'; }
  save.addEventListener('click', async () => {
    save.disabled = true;
    try {
      const folder = normalizeRecordingFolder(input.value);
      await api.storage.local.set({cqcRecordingFolder: folder});
      input.value = folder;
      status.textContent = folder ? `저장됨: 기본 다운로드 폴더 / ${folder}` : '저장됨: 기본 다운로드 폴더';
    } catch (error) { status.textContent = error.message || '경로 저장에 실패했습니다.'; }
    finally { save.disabled = false; }
  });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', install, {once:true});
else install();
