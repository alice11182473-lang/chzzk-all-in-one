export function setChannelSelected(current, channel, checked) {
  const next = current.filter(item => item.channelId !== channel.channelId);
  if (checked) next.push({channelId: channel.channelId, channelName: channel.channelName});
  return next;
}
export function normalizeFollowings(items) {
  const result = new Map();
  for (const item of items) {
    const channel = item.channel || item;
    const channelId = channel.channelId || item.channelId;
    if (typeof channelId !== 'string' || !/^[a-f0-9]{32}$/i.test(channelId)) continue;
    result.set(channelId, {channelId, channelName: channel.channelName || item.channelName || channelId,
      live: !!(item.streamer?.openLive ?? channel.openLive)});
  }
  return [...result.values()];
}
export function installAutoOpenPicker({getSelected, setSelected, getRecording = () => [], setRecording = async () => {}}) {
  const section = document.getElementById('auto-open-channels-section');
  if (!section || section.querySelector('[data-auto-open-picker]')) return;
  const root = document.createElement('div');
  root.dataset.autoOpenPicker = 'true';
  root.style.cssText = 'margin:12px 0;padding:10px;border:1px solid #414147;border-radius:8px;';
  const button = document.createElement('button');
  button.type = 'button'; button.className = 'btn'; button.textContent = '팔로우 목록 불러오기';
  const search = document.createElement('input');
  search.type = 'search'; search.className = 'input'; search.placeholder = '채널 이름 검색';
  search.setAttribute('aria-label', '자동으로 열 채널 검색'); search.style.cssText = 'width:100%;margin:8px 0;';
  const count = document.createElement('p'); count.style.cssText = 'font-size:12px;margin:8px 0;color:#ccc';
  const status = document.createElement('p'); status.setAttribute('role', 'status'); status.style.cssText = 'font-size:12px;color:#bbb;margin:8px 0;';
  const list = document.createElement('div'); list.style.cssText = 'max-height:260px;overflow:auto;';
  root.append(button, search, count, status, list); section.prepend(root);
  let channels = [], saving = false;
  function syncSwitches() {
    const selected = new Set(getSelected().map(ch => ch.channelId));
    const recordings = new Set(getRecording());
    for (const control of list.querySelectorAll('[data-channel-id]')) {
      const on = (control.dataset.kind === 'record' ? recordings : selected).has(control.dataset.channelId);
      control.setAttribute('aria-checked', String(on));
    }
    count.textContent = `선택 ${selected.size}개 · 자동 열기를 켠 채널만 자동으로 열립니다.`;
  }
  function render() {
    if (saving) return;
    const selected = getSelected();
    const ids = new Set(selected.map(ch => ch.channelId));
    count.textContent = `선택 ${ids.size}개 · 자동 열기를 켠 채널만 자동으로 열립니다.`;
    const rows = new Map(channels.map(ch => [ch.channelId, ch]));
    for (const ch of selected) if (!rows.has(ch.channelId)) rows.set(ch.channelId, {...ch, registered: true});
    const query = search.value.trim().toLocaleLowerCase();
    list.replaceChildren();
    for (const ch of [...rows.values()].sort((a,b) => a.channelName.localeCompare(b.channelName, 'ko'))) {
      if (!ch.channelName.toLocaleLowerCase().includes(query)) continue;
      const row = document.createElement('div');
      row.style.cssText = 'display:grid;grid-template-columns:minmax(0,1fr) 58px 42px;align-items:center;gap:8px;padding:10px 4px;font-size:13px;border-bottom:1px solid rgba(255,255,255,.06)';
      const checkbox = document.createElement('button'); checkbox.type = 'button'; checkbox.className='toggle toggle--sm'; checkbox.setAttribute('role','switch'); checkbox.setAttribute('aria-checked',String(ids.has(ch.channelId))); checkbox.disabled = saving;
      checkbox.style.padding='0'; checkbox.dataset.channelId=ch.channelId; checkbox.dataset.kind='open';
      const openLabel = document.createElement('span'); openLabel.textContent = '자동 열기';
      const recordLabel = document.createElement('div'); recordLabel.style.cssText='display:flex;flex-direction:column;gap:6px;align-items:center;white-space:nowrap;font-size:11px';
      const openGroup=document.createElement('div'); openGroup.style.cssText=recordLabel.style.cssText; openGroup.append(openLabel,checkbox);
      const recordBox = document.createElement('button'); recordBox.type='button'; recordBox.className='toggle toggle--sm'; recordBox.setAttribute('role','switch'); recordBox.setAttribute('aria-checked',String(getRecording().includes(ch.channelId))); recordBox.disabled=saving; recordBox.style.padding='0';
      recordBox.dataset.channelId=ch.channelId; recordBox.dataset.kind='record';
      recordBox.setAttribute('aria-label', ch.channelName + ' 자동 녹화'); checkbox.setAttribute('aria-label',ch.channelName + ' 자동 열기');
      recordLabel.append(document.createTextNode('녹화'),recordBox);
      recordBox.addEventListener('click',async()=>{if(saving)return;saving=true;const checked=recordBox.getAttribute('aria-checked')!=='true';recordBox.setAttribute('aria-checked',String(checked));try{await setRecording(ch.channelId,checked);status.textContent='녹화 선택을 저장했습니다. 자동 열기도 켜야 작동합니다.';}catch{status.textContent='녹화 설정 저장 실패';}finally{saving=false;syncSwitches();}});
      const name = document.createElement('span'); name.textContent = ch.channelName + (ch.live ? ' · 방송 중' : ch.registered ? ' · 등록된 채널' : '');
      checkbox.addEventListener('click', async () => {
        if(saving)return;
        saving = true;
        const next = setChannelSelected(getSelected(), ch, checkbox.getAttribute('aria-checked') !== 'true');
        checkbox.setAttribute('aria-checked',String(next.some(item=>item.channelId===ch.channelId)));
        try { await setSelected(next); status.textContent = '선택을 저장했습니다.'; }
        catch { status.textContent = '저장하지 못했습니다. 다시 선택해 주세요.'; }
        finally { saving = false; syncSwitches(); }
      });
      name.style.cssText="min-width:0;overflow-wrap:anywhere;line-height:1.5;font-family:'Pretendard Variable',-apple-system,'Malgun Gothic',sans-serif;font-weight:600;font-size:13px"; row.append(name, openGroup, recordLabel); list.append(row);
    }
  }
  button.addEventListener('click', async () => {
    button.disabled = true; status.textContent = '팔로우 목록을 불러오는 중…';
    try {
      const response = await fetch('https://api.chzzk.naver.com/service/v1/channels/followings?size=300', {credentials:'include'});
      const data = await response.json();
      if (!response.ok || data.code !== 200 || !Array.isArray(data.content?.followingList)) throw new Error('following response');
      channels = normalizeFollowings(data.content.followingList);
      status.textContent = channels.length ? `${channels.length}개 채널을 불러왔습니다.` : '팔로우한 채널이 없습니다.';
      if (data.content.followingList.length >= 300 || data.content.totalCount > channels.length) status.textContent += ' 목록에 없는 채널은 아래 URL 입력으로 추가해 주세요.';
      render();
    } catch { status.textContent = '목록을 불러오지 못했습니다. 같은 브라우저에서 치지직에 로그인한 뒤 다시 눌러 주세요.'; }
    finally { button.disabled = false; }
  });
  search.addEventListener('input', render);
  // URL로 직접 추가/삭제하거나 설정을 가져왔을 때도 같은 선택 목록을 표시합니다.
  const tags = document.getElementById('auto-open-channel-list');
  if (tags) new MutationObserver(render).observe(tags, {childList:true, subtree:true});
  status.textContent = '자동 열기와 녹화를 모두 켜면 방송 시작 시 자동 녹화합니다. 녹화는 직접 정지하면 한 파일로 저장됩니다.';
  render();
}
