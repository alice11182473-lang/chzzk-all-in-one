// Browser-owned alarms keep collection checks independent of page timer throttling.
export function newlyEnabledChannels(before = {}, after = {}) {
  if (!after.enabled || !after.liveAutoOpenEnabled) return [];
  const oldOpen = new Set(before.enabled && before.liveAutoOpenEnabled ? (before.liveAutoOpenChannels || []).map(c => c.channelId) : []);
  const oldRecord = new Set(before.liveAutoRecordChannels || []);
  return (after.liveAutoOpenChannels || []).map(c => c.channelId).filter(id =>
    !oldOpen.has(id) || ((after.liveAutoRecordChannels || []).includes(id) && !oldRecord.has(id)));
}
export function installBackgroundActions(service, api) {
  // Serialize open/start operations per channel, including regular live checks.
  const running = new Map(), open = service.openStreamerTab.bind(service);
  service.openStreamerTab = id => {
    if (running.has(id)) return running.get(id);
    const task = open(id).finally(() => running.delete(id));
    running.set(id, task); return task;
  };
  let queue = Promise.resolve();
  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync' || !changes.settings) return;
    const ids = newlyEnabledChannels(changes.settings.oldValue, changes.settings.newValue);
    queue = queue.then(async () => {
      for (const id of new Set(ids)) {
        if (!/^[a-f0-9]{32}$/i.test(id)) continue;
        try {
          const res = await fetch(`https://api.chzzk.naver.com/polling/v1/channels/${id}/live-status`, {credentials:'include', signal:AbortSignal.timeout(10000)});
          if (!res.ok) continue;
          const json = await res.json();
          if (json.content?.status === 'OPEN') await service.openStreamerTab(id);
        } catch (error) { console.warn('[CQC] Immediate live check failed', error?.message); }
      }
    }).catch(error => console.warn('[CQC]', error?.message));
  });
  api.alarms.onAlarm.addListener(async alarm => {
    if (alarm.name !== 'CQC_POWER_CHECK') return;
    const {settings} = await api.storage.sync.get('settings');
    if (!settings?.enabled || !settings.powerClickEnabled) return;
    const tabs = await api.tabs.query({url:'*://chzzk.naver.com/live/*'});
    await Promise.all(tabs.filter(t => t.id && !t.discarded).map(t =>
      api.tabs.sendMessage(t.id, {type:'CQC_POWER_BACKGROUND_TICK'}).catch(() => {})));
  });
  api.alarms.create('CQC_POWER_CHECK', {periodInMinutes:1});
}
