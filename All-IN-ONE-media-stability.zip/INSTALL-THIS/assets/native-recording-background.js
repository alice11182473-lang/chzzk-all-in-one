const api=globalThis.chrome||globalThis.browser;
const HOST='com.chzzk.allinone.recorder';
let port=null,serial=0,poll=null,jobs={},lastError=null;
const pending=new Map();
const active=s=>['starting','recording','stopping'].includes(s);
function save(){return api.storage.local.set({cqcNativeRecordingState:{jobs,lastError,updatedAt:Date.now()}}).catch(()=>{});}
function ingest(response){if(response.jobs)jobs=response.jobs;else if(response.job)jobs[response.job.channelId]=response.job;void save();}
function ensurePort(){
 if(port)return port;
 const current=api.runtime.connectNative(HOST);port=current;
 current.onMessage.addListener(response=>{
  ingest(response);const request=pending.get(response.id);if(!request)return;
  pending.delete(response.id);clearTimeout(request.timer);
  response.ok?request.resolve(response):request.reject(new Error(response.error||'원본 녹화 오류'));
 });
 current.onDisconnect.addListener(()=>{
  const reason=api.runtime.lastError?.message||'보조 프로그램 연결이 종료되었습니다.';
  if(port!==current)return;port=null;clearInterval(poll);poll=null;lastError=reason;
  for(const request of pending.values()){clearTimeout(request.timer);request.reject(new Error(reason));}pending.clear();
  for(const job of Object.values(jobs))if(active(job.status)){job.status='error';job.error='보조 프로그램 연결 끊김 · 저장 파일을 확인하세요.';}
  void save();
 });
 poll=setInterval(()=>{if(port)requestNative('status').catch(()=>{});},2000);
 return current;
}
export function requestNative(op,parameters={}){
 return new Promise((resolve,reject)=>{
  const id=++serial;let current;
  try{current=ensurePort();}catch(error){reject(error);return;}
  const timer=setTimeout(()=>{pending.delete(id);reject(new Error('보조 프로그램 응답 시간 초과'));},10000);
  pending.set(id,{resolve,reject,timer});
  try{current.postMessage({id,op,...parameters});}catch(error){clearTimeout(timer);pending.delete(id);reject(error);}
 });
}
export async function startNativeRecording(channelId,{automatic=false}={}){
 if(!/^[a-f0-9]{32}$/i.test(channelId))throw new Error('잘못된 채널 ID');
 const {settings}=await api.storage.sync.get('settings');
 if(!settings?.enabled)throw new Error('확장프로그램이 꺼져 있습니다.');
 if(automatic&&(!settings.liveAutoOpenEnabled||!settings.liveAutoOpenChannels?.some(c=>c.channelId===channelId)||!settings.liveAutoRecordChannels?.includes(channelId)))return null;
 const {cqcRecordingFolder}=await api.storage.local.get('cqcRecordingFolder');
 lastError=null;
 try{return await requestNative('start',{channelId,folder:cqcRecordingFolder||'',format:settings.recorderFormat==='mkv'?'mkv':'mp4'});}
 catch(error){lastError=error.message;void save();throw error;}
}
api.runtime.onMessage.addListener((message,sender,reply)=>{
 if(!message?.type?.startsWith('CQC_NATIVE_'))return;
 if(sender.id!==api.runtime.id)return;
 const page=sender.tab?new URL(sender.url||sender.tab.url).pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1]:null;
 const isPopup=!sender.tab;
 if(sender.tab&&!/^https:\/\/chzzk\.naver\.com\//.test(sender.url||sender.tab.url||''))return;
 const channelId=page||message.channelId;
 const op=async()=>{
  if(message.type==='CQC_NATIVE_STATUS')return {ok:true,jobs,lastError};
  if(message.type==='CQC_NATIVE_PING'&&isPopup)return requestNative('ping');
  if(message.type==='CQC_NATIVE_STOP_ALL'&&isPopup)return requestNative('stop_all');
  if(message.type==='CQC_NATIVE_START')return startNativeRecording(channelId,{automatic:message.automatic===true});
  if(message.type==='CQC_NATIVE_STOP')return requestNative('stop',{channelId});
  throw new Error('지원하지 않는 원본 녹화 명령');
 };
 op().then(result=>reply(result||{ok:true}),error=>reply({ok:false,error:error.message}));return true;
});
// Turning off automatic recording stops only affected automatically selected channels.
api.storage.onChanged.addListener((changes,area)=>{
 if(area!=='sync'||!changes.settings||!port)return;
 const old=changes.settings.oldValue||{},next=changes.settings.newValue||{};
 for(const id of old.liveAutoRecordChannels||[]){
  const keep=next.enabled&&next.liveAutoOpenEnabled&&next.liveAutoRecordChannels?.includes(id)&&next.liveAutoOpenChannels?.some(c=>c.channelId===id);
  if(!keep&&active(jobs[id]?.status))requestNative('stop',{channelId:id}).catch(()=>{});
 }
});
