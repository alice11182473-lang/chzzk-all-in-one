export function eligible(settings, id) {
  return !!(settings?.enabled && settings.liveAutoOpenEnabled &&
    settings.liveAutoOpenChannels?.some(c => c.channelId === id) &&
    settings.liveAutoRecordChannels?.includes(id));
}
export function installAutoRecord({isManualRecording = () => false} = {}) {
  const api = globalThis.chrome || globalThis.browser;
  let active = false, pending = false, stopped = false, media = null, stream = null, timer = null, session = 0;
  let channel = '', panel = null, video = null;
  const id = () => location.pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1];
  function notice(text, canStop = false) {
    if (!panel) { panel = document.createElement('div'); panel.id = 'cqc-auto-rec-status'; panel.style.cssText = 'position:fixed;right:20px;top:80px;z-index:2147483647;background:#18181f;color:white;padding:12px;border:1px solid #fa5555;border-radius:8px;font-size:13px'; document.documentElement.append(panel); }
    panel.replaceChildren(document.createTextNode(text + ' '));
    const button = document.createElement('button'); button.textContent = canStop ? '녹화 중지·저장' : '닫기';
    button.onclick = canStop ? stop : () => {panel.remove(); panel=null;}; panel.append(button);
  }
  function stop() {
    stopped = true; pending = false; active = false; session++; clearTimeout(timer);
    if (media && media.state !== 'inactive') media.stop();
    else { stream?.getTracks().forEach(t => t.stop()); notice('자동 녹화가 중지되었습니다.'); }
  }
  function beginRecording(token) {
    if (!active || token !== session) return;
    const types = ['video/webm;codecs=vp8,opus','video/webm;codecs=vp9,opus','video/webm','video/mp4'];
    const mime = types.find(type => MediaRecorder.isTypeSupported(type));
    const chunks = []; let failed = false;
    const current = new MediaRecorder(stream, { ...(mime ? {mimeType:mime} : {}), videoBitsPerSecond:8000000, audioBitsPerSecond:192000 });
    media = current;
    current.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
    current.onerror = () => { if(video?.dataset)delete video.dataset.cqcRecording; failed=true; active=false; notice('자동 녹화 오류: 재생 상태와 브라우저 권한을 확인해 주세요.'); };
    current.onstop = () => {
      if(video?.dataset)delete video.dataset.cqcRecording;
      clearTimeout(timer);
      if (chunks.length) {
        const blob = new Blob(chunks, {type:current.mimeType});
        const url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = `chzzk_${channel}_${new Date().toISOString().replace(/[:.]/g,'-')}.${current.mimeType.includes('mp4')?'mp4':'webm'}`;
        a.click(); setTimeout(() => URL.revokeObjectURL(url),60000);
      }
      active=false; pending=false; media=null; stream?.getTracks().forEach(t=>t.stop());
      if(!failed)notice('녹화 종료 · 생성된 파일은 다운로드 목록에서 확인하세요.');
    };
    current.start(1000);
    if(video?.dataset)video.dataset.cqcRecording="true";
    notice('● 연속 녹화 중 · 정지하면 한 파일로 저장', true);
  }
  async function start() {
    if(active || pending || isManualRecording()) return;
    const target=id(); if(!target) return;
    const {settings}=await api.storage.sync.get('settings');
    if(!eligible(settings,target) || active || pending) return;
    pending=true;stopped=false;channel=target;const token=++session;
    notice('자동 녹화: 영상 재생을 기다리는 중…',true);
    const deadline=Date.now()+120000;
    async function attempt(){
      if(stopped||token!==session||id()!==target) return;
      video=document.querySelector('video.webplayer-internal-video') || document.querySelector('.pzp video');
      if(video?.paused) {try{await video.play();}catch{}}
      if(stopped||token!==session) return;
      if(video && !video.paused && video.readyState>=2 && video.videoWidth>0){
        try{
          if(isManualRecording()){pending=false;notice('수동 녹화 중이므로 자동 녹화를 시작하지 않았습니다.');return;}
          stream=video.captureStream();
          if(!stream.getVideoTracks().length) throw new Error('No video track');
          pending=false;active=true;beginRecording(token);
        }catch{pending=false;active=false;stream?.getTracks().forEach(t=>t.stop());notice('자동 녹화를 시작하지 못했습니다. 영상 재생 및 captureStream 지원을 확인해 주세요.');}
        return;
      }
      if(Date.now()>deadline){pending=false;notice('영상이 재생되지 않아 자동 녹화를 시작하지 못했습니다. 재생 후 방송 탭을 다시 열어 주세요.');return;}
      timer=setTimeout(attempt,1500);
    }
    attempt();
  }
  api.runtime.onMessage.addListener((message,sender,reply)=>{
    if(message.type==='CQC_AUTO_RECORD_START'){start().catch(()=>notice('자동 녹화 설정을 읽지 못했습니다.'));reply({success:true});}
    if(message.type==='CQC_RECORD_STATUS'){reply({recording:active||pending||isManualRecording()});}
  });
  api.storage.onChanged.addListener((changes,area)=>{if(area==='sync'&&changes.settings&&(active||pending)&&!eligible(changes.settings.newValue,channel))stop();});
  setInterval(()=>{if((active||pending)&&(id()!==channel||video?.ended))stop();},1000);
  // 수동 녹화와 중복 실행하지 않도록 기존 녹화 버튼으로도 자동 녹화를 중지합니다.
  document.addEventListener('click',e=>{if((active||pending)&&e.target.closest?.('#cqc-record-btn')){e.preventDefault();e.stopImmediatePropagation();stop();}},true);
  window.addEventListener('beforeunload',e=>{if(active){e.preventDefault();e.returnValue='';}});
  const url=new URL(location.href);
  if(url.searchParams.get('cqc_auto_record')==='1'){
    url.searchParams.delete('cqc_auto_record');history.replaceState(history.state,'',url);
  }
  // Eligible live tabs also start after loading; message delivery may precede content initialization.
  start().catch(()=>notice('자동 녹화 설정을 읽지 못했습니다.'));
}
