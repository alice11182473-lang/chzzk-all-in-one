import { createRecordingStorage } from './recording-storage.js';
import { ensureAutoPlayback } from './auto-play.js';
import { createRecordingEngine, recordingExtension, stopRecordingCapture, watchRecordingOutput, monitorRecording } from './recording-engine.js';
export function eligible(settings, id) {
  return !!(settings?.enabled && settings.liveAutoOpenEnabled &&
    settings.liveAutoOpenChannels?.some(c => c.channelId === id) &&
    settings.liveAutoRecordChannels?.includes(id));
}
export function installAutoRecord({isManualRecording = () => false, onState = null, onNotice = null} = {}) {
  const api = globalThis.chrome || globalThis.browser;
  let active = false, pending = false, stopped = false, media = null, stream = null, timer = null, session = 0;
  let channel = '', panel = null, video = null;
  const id = () => location.pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1];
  function notice(text, canStop = false) {
    if(onNotice){onNotice(text);return;}
    if (!panel) { panel = document.createElement('div'); panel.id = 'cqc-auto-rec-status'; panel.style.cssText = 'position:fixed;right:20px;top:80px;z-index:2147483647;background:#18181f;color:white;padding:12px;border:1px solid #fa5555;border-radius:8px;font-size:13px'; document.documentElement.append(panel); }
    panel.replaceChildren(document.createTextNode(text + ' '));
    const button = document.createElement('button'); button.textContent = canStop ? '녹화 중지·저장' : '닫기';
    button.onclick = canStop ? stop : () => {panel.remove(); panel=null;}; panel.append(button);
  }
  function stop() {
    stopped = true; pending = false; session++; clearTimeout(timer);
    if (media && media.state !== 'inactive') stopRecordingCapture(media);
    else { stream?.getTracks().forEach(t => t.stop()); notice('자동 녹화가 중지되었습니다.'); }
  }
  async function beginRecording(token, settings) {
    if (!active || token !== session) return;
    const sink = await createRecordingStorage();
    if (!active || token !== session) {await sink.discard();active=false;return;}
    let engine;
    try {engine = createRecordingEngine(video, {...settings, recordingVideoBitsPerSecond:8000000});}
    catch(error){await sink.discard();throw error;}
    stream = engine.stream;
    let failed = false;
    const current = engine.recorder;
    let finishMonitor = () => {};
    media = current;
    current.ondataavailable = e => {if(e.data.size) sink.append(e.data).catch(error=>{failed=true;notice(error.message);stopRecordingCapture(current);});};
    current.onerror = () => {failed=true;notice('자동 녹화 오류가 발생했습니다.');stopRecordingCapture(current);};
    current.onstop = async () => {
      finishMonitor();
      if(video?.dataset)delete video.dataset.cqcRecording;
      clearTimeout(timer);
      stream?.getTracks().forEach(t=>t.stop());
      try {await sink.download(`chzzk_${channel}_${new Date().toISOString().replace(/[:.]/g,'-')}.${recordingExtension(current.mimeType)}`);}
      catch(error){failed=true;notice(`녹화 저장 실패: ${error.message}`);}
      active=false; pending=false; media=null; stream?.getTracks().forEach(t=>t.stop());
      onState?.(false, failed);
      if(!failed&&!onState)notice('녹화 종료 · 생성된 파일은 다운로드 목록에서 확인하세요.');
    };
    try {current.start(2000);} catch(error){await sink.discard();throw error;}
    watchRecordingOutput(current, error=>{failed=true;notice(error.message);},{video});
    finishMonitor = monitorRecording(video, current, engine.lowLoad, sink);
    if(video?.dataset)video.dataset.cqcRecording="true";
    video?.dispatchEvent?.(new Event("cqc-recording-start"));
    onState?.(true);
    if(!onState)notice('● 연속 녹화 중 · 정지하면 한 파일로 저장', true);
  }
  async function start() {
    if(active || pending || isManualRecording()) return;
    const target=id(); if(!target) return;
    const {settings}=await api.storage.sync.get('settings');
    if(!eligible(settings,target) || active || pending) return;
    pending=true;stopped=false;channel=target;const token=++session;
    notice('자동 녹화: 영상 재생을 기다리는 중…',true);
    const deadline=Date.now()+120000;
    async function attempt(){
      if(stopped||token!==session||id()!==target) return;
      video=document.querySelector('video.webplayer-internal-video') || document.querySelector('.pzp video');
      if(video?.paused) {try{await ensureAutoPlayback(video);}catch{}}
      if(stopped||token!==session) return;
      if(video && !video.paused && video.readyState>=2 && video.videoWidth>0){
        try{
          if(isManualRecording()){pending=false;notice('수동 녹화 중이므로 자동 녹화를 시작하지 않았습니다.');return;}
          pending=false;active=true;await beginRecording(token,settings);
        }catch{pending=false;active=false;stream?.getTracks().forEach(t=>t.stop());notice('자동 녹화를 시작하지 못했습니다. 영상 재생 및 captureStream 지원을 확인해 주세요.');}
        return;
      }
      if(Date.now()>deadline){pending=false;notice('영상이 재생되지 않아 자동 녹화를 시작하지 못했습니다. 재생 후 방송 탭을 다시 열어 주세요.');return;}
      timer=setTimeout(attempt,1500);
    }
    attempt();
  }
  api.runtime.onMessage.addListener((message,sender,reply)=>{
    if(message.type==='CQC_AUTO_RECORD_START'){start().catch(()=>notice('자동 녹화 설정을 읽지 못했습니다.'));reply({success:true});}
    if(message.type==='CQC_STARTUP_STATUS'){const v=document.querySelector('.pzp video, .chzzk_player video, video.webplayer-internal-video');reply({playing:!!v&&!v.paused&&v.readyState>=2,recording:active||isManualRecording()});}
    if(message.type==='CQC_RECORD_STATUS'){reply({recording:active||pending||isManualRecording()});}
  });
  api.storage.onChanged.addListener((changes,area)=>{if(area==='sync'&&changes.settings&&(active||pending)&&!eligible(changes.settings.newValue,channel))stop();});
  setInterval(()=>{if((active||pending)&&(id()!==channel||video?.ended))stop();},1000);
  // 수동 녹화와 중복 실행하지 않도록 기존 녹화 버튼으로도 자동 녹화를 중지합니다.
  document.addEventListener('click',e=>{if(!onState&&(active||pending)&&e.target.closest?.('#cqc-record-btn')){e.preventDefault();e.stopImmediatePropagation();stop();}},true);
  window.addEventListener('beforeunload',e=>{if(active){e.preventDefault();e.returnValue='';}});
  const url=new URL(location.href);
  if(url.searchParams.get('cqc_auto_record')==='1'){
    url.searchParams.delete('cqc_auto_record');history.replaceState(history.state,'',url);
  }
  // Eligible live tabs also start after loading; message delivery may precede content initialization.
  start().catch(()=>notice('자동 녹화 설정을 읽지 못했습니다.'));
  return {stop, isActive:()=>active||pending};
}
