// Shared recording policy. Codec support does not prove hardware acceleration.
let report = null;
export function recordingExtension(mimeType) {
  if (/mp4/i.test(mimeType)) return 'mp4';
  return /matroska|h264|avc1/i.test(mimeType) ? 'mkv' : 'webm';
}

export function recordingDiagnostics(){return report ? JSON.parse(JSON.stringify(report)) : {status:'no-recording'};}
export function createRecordingEngine(video, settings = {}) {
  const stream = video.captureStream();
  try {
    if (stream.getVideoTracks && !stream.getVideoTracks().length) throw new Error('영상 트랙을 찾지 못했습니다.');
    const lowLoad = settings.recorderLowLoadEnabled !== false;
    const audio = !stream.getAudioTracks || stream.getAudioTracks().length > 0;
    const level = video.videoHeight > 1080 ? '34' : '2a';
    const h264 = `video/mp4;codecs=avc1.4200${level}${audio?',mp4a.40.2':''}`;
    const vp8 = `video/webm;codecs=vp8${audio?',opus':''}`;
    const types = lowLoad ? [vp8] : settings.recorderFormat === 'mp4' ? [h264,'video/mp4',vp8,'video/webm'] : [vp8,'video/webm'];
    const bits = lowLoad ? 8000000 : (settings.recordingVideoBitsPerSecond || 15000000);
    let recorder, lastError;
    for (const mimeType of types) {
      if (!MediaRecorder.isTypeSupported(mimeType)) continue;
      try { recorder = new MediaRecorder(stream,{mimeType,videoBitsPerSecond:bits,audioBitsPerSecond:192000,videoKeyFrameIntervalDuration:2000}); break; }
      catch (error) {lastError = error;}
    }
    if (!recorder) throw lastError || new Error('지원되는 녹화 코덱이 없습니다.');
    return {stream,recorder,lowLoad};
  } catch(error) {stream.getTracks().forEach(t=>t.stop());throw error;}
}
export function monitorRecording(video, recorder, lowLoad, sink = null) {
  const started=Date.now();
  const state=report={version:(globalThis.chrome||globalThis.browser)?.runtime?.getManifest?.().version,channelId:globalThis.location?.pathname?.match(/\/live\/([a-f0-9]{32})/)?.[1]||null,startedAt:new Date(started).toISOString(),storageMode:'opfs',status:'recording',lowLoad,mimeType:recorder.mimeType,videoBitsPerSecond:recorder.videoBitsPerSecond||null,hardwareAcceleration:'unknown',width:video.videoWidth,height:video.videoHeight,waitingCount:0,bytes:0,chunks:0,samples:[]};
  let timer=null,finished=false,lastData=Date.now(),lastPersist=0,persisting=false;
  function persist(force=false) {
    const api=globalThis.chrome||globalThis.browser;
    if(!api?.storage?.local || persisting || (!force && Date.now()-lastPersist<10000))return;
    lastPersist=Date.now();persisting=true;
    api.storage.local.set({cqcLastRecordingDiagnostics:JSON.parse(JSON.stringify(state))}).catch(()=>{}).finally(()=>{persisting=false;});
  }
  function sample(event='sample') {
    state.updatedAt=new Date().toISOString();state.storage=sink?.stats?.()||null;state.secondsSinceData=Math.round((Date.now()-lastData)/1000);
    const memory=globalThis.performance?.memory;state.jsHeapUsedBytes=memory?.usedJSHeapSize??null;state.jsHeapLimitBytes=memory?.jsHeapSizeLimit??null;
    let ahead=0;try{for(let i=0;i<video.buffered.length;i++)if(video.buffered.start(i)<=video.currentTime&&video.buffered.end(i)>=video.currentTime)ahead=video.buffered.end(i)-video.currentTime;}catch{}
    let quality;try{quality=video.getVideoPlaybackQuality?.();}catch{}
    state.samples.push({seconds:Math.round((Date.now()-started)/1000),event,bufferAhead:Math.round(ahead*1000)/1000,readyState:video.readyState,playbackRate:video.playbackRate,currentTime:video.currentTime,paused:video.paused,ended:video.ended,seeking:video.seeking,recordingFlag:video.dataset?.cqcRecording==='true',latencyController:video.dataset?.cqcLatencyStatus??null,droppedFrames:quality?.droppedVideoFrames??null,totalFrames:quality?.totalVideoFrames??null});
    if(state.samples.length>60)state.samples.shift();persist(event!=='sample');
  }
  const waiting=()=>{state.waitingCount++;sample('waiting');};
  const ratechange=()=>sample('ratechange');
  const seeking=()=>sample('seeking');
  const data=e=>{if(e.data?.size)lastData=Date.now();state.bytes+=e.data?.size||0;state.chunks++;};
  const stop=()=>{if(finished)return;finished=true;clearInterval(timer);state.status='stopped';sample('stop');video.removeEventListener?.('waiting',waiting);video.removeEventListener?.('ratechange',ratechange);video.removeEventListener?.('seeking',seeking);recorder.removeEventListener?.('dataavailable',data);recorder.removeEventListener?.('stop',stop);recorder.removeEventListener?.('error',error);};
  const error=()=>{stop();state.status='error';persist(true);};
  video.addEventListener?.('waiting',waiting);video.addEventListener?.('ratechange',ratechange);video.addEventListener?.('seeking',seeking);recorder.addEventListener?.('dataavailable',data);recorder.addEventListener?.('stop',stop);recorder.addEventListener?.('error',error);
  sample('start');timer=setInterval(sample,2000);return stop;
}

export function watchRecordingOutput(recorder, onFailure, {video=null,now=()=>Date.now(),schedule=setInterval,cancel=clearInterval}={}) {
  let last=now(),requested=0,ended=false,previousTime=null,stalledSince=null;
  const data=e=>{if(e.data?.size)last=now();};
  const cleanup=()=>{if(ended)return;ended=true;cancel(timer);recorder.removeEventListener('dataavailable',data);recorder.removeEventListener('stop',cleanup);};
  const timer=schedule(()=>{
    if(recorder.state!=='recording')return;
    if(video){
      let ahead=0;try{for(let i=0;i<video.buffered.length;i++){if(video.buffered.start(i)<=video.currentTime && video.buffered.end(i)>=video.currentTime)ahead=video.buffered.end(i)-video.currentTime;}}catch{}
      const stalled=!video.paused&&!video.ended&&!video.seeking&&video.readyState<=2&&ahead>=2&&previousTime!==null&&Math.abs(video.currentTime-previousTime)<0.05;
      previousTime=video.currentTime;
      if(!stalled)stalledSince=null;
      else if(stalledSince===null)stalledSince=now();
      else if(now()-stalledSince>=20000){
        onFailure(new Error('영상 재생이 멈춰 녹화를 중지하고 저장합니다. 방송을 확인해 주세요.'));
        cleanup();stopRecordingCapture(recorder);return;
      }
    }
    const age=now()-last;
    if(age>=60000){onFailure(new Error('녹화 데이터가 60초 동안 출력되지 않아 누적 방지를 위해 녹화를 중지했습니다.'));cleanup();stopRecordingCapture(recorder);}
    else if(age>=10000 && now()-requested>=10000){requested=now();try{recorder.requestData();}catch{}}
  },5000);
  recorder.addEventListener('dataavailable',data);recorder.addEventListener('stop',cleanup);
  return cleanup;
}

// Release captured tracks immediately; do not wait for muxing/file finalization.
export function stopRecordingCapture(recorder){
  if(!recorder)return;
  try{if(recorder.state!=='inactive')recorder.stop();}
  finally{recorder.stream?.getTracks?.().forEach(track=>track.stop());}
}
