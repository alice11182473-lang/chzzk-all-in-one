const api=globalThis.chrome||globalThis.browser;
function setup(){
 const button=document.getElementById('cqc-recording-diagnostics'),status=document.getElementById('cqc-recording-diagnostics-status');
 button?.addEventListener('click',async()=>{
  try{const data=await api.storage.local.get('cqcNativeRecordingState');await navigator.clipboard.writeText(JSON.stringify({version:api.runtime.getManifest().version,mode:'native-stream-copy',...data.cqcNativeRecordingState},null,2));status.textContent='원본 녹화 진단을 복사했습니다.';}
  catch(error){status.textContent=error.message;}
 });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup,{once:true});else setup();
