let queue=Promise.resolve();
// Serialize activations so simultaneous live channels cannot fight over focus.
export function openWithWarmup(api,url,{record=false,returnToPrevious=false,timeoutMs=30000,wait=ms=>new Promise(r=>setTimeout(r,ms))}={}){
 const task=async()=>{
  const [previous]=await api.tabs.query({active:true,lastFocusedWindow:true});
  let tab,interrupted=false,armed=false;
  const activated=info=>{if(armed&&info.windowId===tab?.windowId&&info.tabId!==tab.id)interrupted=true;};
  api.tabs.onActivated.addListener(activated);
  try{
   // De-duplicate again after waiting for other channels in the queue.
   const path=new URL(url).pathname;
   const existing=await api.tabs.query({url:`*://chzzk.naver.com${path}*`});
   if(existing.length)return {status:'existing',tabId:existing[0].id};
   tab=await api.tabs.create({url,active:true,...(previous?.windowId!=null?{windowId:previous.windowId}:{})});
   armed=true;
   const deadline=Date.now()+timeoutMs;let status='timeout';
   while(Date.now()<deadline){
    if(interrupted){status='user-switched';break;}
    const current=await api.tabs.get(tab.id);
    if(!current.active){interrupted=true;status='user-switched';break;}
    try{
     const state=await api.tabs.sendMessage(tab.id,{type:'CQC_STARTUP_STATUS'},{frameId:0});
     if(state?.playing&&(!record||state?.recording===true)){status='ready';break;}
    }catch{}
    await wait(500);
   }
   return {status,tabId:tab.id};
  }finally{
   try{
    if(returnToPrevious&&tab&&previous?.id!=null&&!interrupted){
     const current=await api.tabs.get(tab.id);
     if(current.active)await api.tabs.update(previous.id,{active:true});
    }
   }catch{}
   api.tabs.onActivated.removeListener(activated);
  }
 };
 const result=queue.then(task,task);queue=result.catch(()=>{});return result;
}
