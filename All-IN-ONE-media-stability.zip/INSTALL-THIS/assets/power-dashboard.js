export function recordBalance(previous, amount, now, name) {
  const state = previous || {amount, at:now, logs:[], intervals:[], lastGain:0};
  if (previous && now - state.at <= 90000 && amount !== state.amount) {
    const delta = amount - state.amount;
    state.logs = [{at:now, delta, amount, name}, ...(state.logs || [])].slice(0,200);
    if (delta > 0) {
      const interval = now - (state.lastGain || 0);
      if (state.lastGain && interval >= 30000 && interval <= 3600000)
        state.intervals = [...(state.intervals || []),interval].slice(-6);
      state.lastGain = now;
    }
  } else if (previous && now - state.at > 90000) {
    state.lastGain = 0; state.intervals = [];
  }
  return {...state,amount,at:now,name};
}
export function estimateNext(state, now) {
  if (!state || state.intervals?.length < 3 || !state.lastGain) return null;
  const values = [...state.intervals].sort((a,b)=>a-b);
  const median = values[Math.floor(values.length/2)];
  if (values.at(-1) > median * 1.7 || values[0] < median * .5) return null;
  return Math.max(0, Math.ceil((state.lastGain + median - now)/1000));
}
export function normalizeBalances(items) {
  if (!Array.isArray(items)) throw new Error('보유량 응답을 확인할 수 없습니다.');
  return items.filter(x => /^[a-f0-9]{32}$/i.test(x.channelId) && typeof x.amount === 'number' && Number.isFinite(x.amount))
    .map(x => ({id:x.channelId,name:x.channelName || x.channelId,amount:x.amount}))
    .sort((a,b)=>b.amount-a.amount);
}
export function installPowerDashboard({db, ui, getChannel}) {
  if (ui.__dashboardInstalled) return;
  ui.__dashboardInstalled = true;
  let enabled=false, channel='', box=null, panel=null, view='rank', state=null, lastPoll=0, busy=false, error='', session=0;
  const remove = ui.removeUI.bind(ui);
  ui.removeUI = function() { enabled=false; box?.remove(); box=null; panel?.remove(); panel=null; session++; return remove(); };
  const original = ui.renderStatus.bind(ui);
  ui.renderStatus = function(count,on,id,farming,focus) {
    const next = location.pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1] || '';
    if (channel !== next) { channel=next; state=null; lastPoll=0; error='';session++;panel?.remove();panel=null; }
    enabled=!!on && !focus && !!next;
    if (!enabled) {box?.remove();box=null;panel?.remove();panel=null;}
    return original(count,on,id,farming,focus);
  };
  const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n;};
  function chatRoot() {return document.querySelector('#aside-chatting, [class*="live_chatting_container"], [class*="_chatting_container_"]');}
  function nativeButton(root) {
    return [...root.querySelectorAll('button')].find(b=>!b.closest('[data-cqc-power-dashboard]') &&
      !/획득|받기/.test(b.textContent || '') && /통나무|log.?power/i.test([b.className,b.title,b.getAttribute('aria-label')].join(' ')));
  }
  function positionBar() {
    if (!box) return;
    const root=chatRoot();
    const send=root && [...root.querySelectorAll('button')].filter(b=>
      !b.closest('[data-cqc-power-dashboard]') &&
      (b.textContent.trim()==='채팅' || /^(채팅|메시지) (전송|보내기)$/.test(b.getAttribute('aria-label') || ''))
    ).filter(b=>{const r=b.getBoundingClientRect();return r.width>0 && r.height>0;}).at(-1);
    if (!send || document.fullscreenElement) {box.hidden=true;return;}
    const r=send.getBoundingClientRect();
    const chat=root.getBoundingClientRect();
    if(r.top<0 || r.bottom>innerHeight || r.left-chat.left<105){box.hidden=true;return;}
    const centerY=r.top+r.height/2;
    const previous=[...root.querySelectorAll('button, a, [role="button"]')]
      .filter(node=>node!==send && !node.closest('[data-cqc-power-dashboard]'))
      .map(node=>(node.querySelector('svg, img') || node).getBoundingClientRect())
      .filter(rect=>rect.width>0 && rect.height>0 && rect.right<=r.left &&
        Math.abs(rect.top+rect.height/2-centerY)<Math.min(rect.height,r.height)/2)
      .sort((a,b)=>b.right-a.right)[0];
    if(!previous || r.left-previous.right<40){box.hidden=true;return;}
    const gap=r.left-previous.right;
    box.hidden=false;
    box.style.width=`${gap-8}px`;
    box.style.left=`${previous.right+4}px`;
    box.style.top=`${centerY-16}px`;
  }
  function mount() {
    if (!box?.isConnected) {
      if(!chatRoot())return;
      box=el('div',null,'cqc-power-dashboard-bar');box.dataset.cqcPowerDashboard='true';
      const rank=el('button');rank.type='button';rank.setAttribute('aria-label','통나무 보유량 순위와 획득 로그 열기');
      rank.onclick=()=>open('menu');
      const balance=el('span','🪵 확인 중');balance.dataset.balance='true';
      rank.append(balance);box.append(rank);
      // Fixed positioning does not consume space in the chat flex layout.
      document.body.append(box);
    }
    positionBar();
  }
  window.addEventListener('resize',positionBar);
  window.addEventListener('scroll',positionBar,true);
  async function poll() {
    if(busy||Date.now()-lastPoll<30000)return;
    busy=true;lastPoll=Date.now();const id=channel,token=session;
    try {
      const amount=await ui.getOfficialPower(id);
      if(typeof amount!=='number'||!Number.isFinite(amount))throw Error('보유량 조회 실패 · 로그인 상태를 확인하세요.');
      if(token!==session||!enabled)return;
      const work=async()=>{
        const key='power_dashboard_'+id;
        const previous=await db.getKV(key);
        const data=getChannel(document.body);
        const next=recordBalance(previous,amount,Date.now(),data?.channelName || previous?.name || id);
        const saved=await db.setKV(key,next);
        if(saved===false)throw Error('보유량 기록 저장 실패');
        if(token===session){state=next;error='';}
      };
      if(navigator.locks)await navigator.locks.request('cqc-power-dashboard-'+id,work);else await work();
    } catch(e){if(token===session)error=e.message;}
    finally{busy=false;}
  }
  async function open(which) {
    view=which;
    panel?.remove();panel=el('section',null,'cqc-power-dashboard-panel');panel.dataset.cqcPowerDashboard='true';
    panel.setAttribute('role','dialog');panel.setAttribute('aria-label','통나무 파워');
    const heading=el('div',null,'cqc-power-dashboard-heading');
    for(const [label,action] of [['보유량 순위',()=>open('rank')],['획득 로그',()=>open('logs')],['새로고침',()=>open(view)],['닫기',()=>{panel.remove();panel=null;}]]){
      const b=el('button',label);b.type='button';b.onclick=action;heading.append(b);
    }
    const body=el('div','불러오는 중…','cqc-power-dashboard-body');panel.append(heading,body);
    (chatRoot()||document.body).append(panel);
    const current=panel;
    try {
      if(which==='menu'){
        body.replaceChildren(el('h3',`🪵${state?.amount ?? '확인 중'}`),
          el('p','위에서 보유량 순위 또는 획득 로그를 선택하세요.'));
      } else if(which==='rank'){
        const ranks=normalizeBalances(await ui.getAllBalances());
        if(panel!==current)return;
        body.replaceChildren(el('h3',`보유 파워 합계: ${ranks.reduce((n,x)=>n+x.amount,0).toLocaleString()}`),el('p','내 채널별 보유량 순위 · 서버가 반환한 채널 기준'));
        ranks.filter(x=>x.amount>0).forEach((x,index)=>{
          const row=el('a',null,'cqc-power-dashboard-row');row.href='/live/'+x.id;row.target='_blank';row.rel='noopener';
          row.append(el('span',`${index+1}. ${x.name}`),el('strong',x.amount.toLocaleString()));body.append(row);
        });
        if(!ranks.some(x=>x.amount>0))body.append(el('p','보유 중인 통나무가 없습니다.'));
      } else {
        const keys=(await db.getAllKeys()).filter(k=>String(k).startsWith('power_dashboard_'));
        const states=await Promise.all(keys.map(k=>db.getKV(k)));
        const logs=states.flatMap(s=>s?.logs || []).sort((a,b)=>b.at-a.at).slice(0,200);
        const attempts=await db.getPowerLogs(50);
        if(panel!==current)return;
        body.replaceChildren(el('h3','확인된 보유량 변화'),el('p','설치 후 약 30초마다 관측 · 증가분은 획득, 감소분은 사용·차감입니다. 시청하지 않은 기간은 합산하지 않습니다.'));
        for(const x of logs){const row=el('div',null,'cqc-power-dashboard-row');row.append(el('span',`${new Date(x.at).toLocaleString()} · ${x.name}`),el('strong',`${x.delta>0?'+':''}${x.delta.toLocaleString()} → ${x.amount.toLocaleString()}`));body.append(row);}
        if(!logs.length)body.append(el('p','아직 확인된 변화가 없습니다.'));
        const details=el('details');details.append(el('summary','기존 자동 클릭 기록 (성공 확인 전)'));
        for(const x of attempts)details.append(el('p',`${new Date(x.timestamp).toLocaleString()} · ${x.channelName} · +${x.amount} 클릭 시도`));body.append(details);
      }
    }catch(e){if(panel===current)body.textContent=e.message+' 잠시 후 새로고침해 주세요.';}
  }
  document.addEventListener('click',e=>{
    if(!enabled)return;
    const root=chatRoot(),button=e.target.closest?.('button');
    if(root&&button&&button===nativeButton(root)) {e.preventDefault();e.stopImmediatePropagation();open('menu');}
  },true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&panel){panel.remove();panel=null;}});
  setInterval(()=>{
    if(!enabled)return;
    const id=location.pathname.match(/^\/live\/([a-f0-9]{32})/i)?.[1];
    if(id!==channel){enabled=false;box?.remove();box=null;panel?.remove();panel=null;session++;return;}
    mount();poll();
    if(!box)return;
    box.querySelector('[data-balance]').textContent=error ? '🪵 조회 실패' : `🪵${state?.amount ?? '확인 중'}`;
    box.title=(error ? error+' · ' : '')+'클릭: 보유량 순위 / 획득 로그';
  },1000);
}
