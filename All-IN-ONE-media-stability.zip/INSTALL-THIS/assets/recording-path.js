export function normalizeRecordingFolder(value) {
  const folder = String(value ?? '').trim().replace(/\\/g, '/');
  if (!folder) return '';
  if (folder.length > 180 || folder.split('/').some(part => !part || part === '.' || part === '..' ||
      /[<>:"|?*\x00-\x1f]/.test(part) || /[. ]$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) {
    throw new Error('기본 다운로드 폴더 아래의 폴더명을 입력하세요. 예: 치지직/녹화 (드라이브 경로·.. 사용 불가)');
  }
  return folder;
}
export function recordingDownloadName(item, folder) {
  if (!/^blob:https:\/\/chzzk\.naver\.com\//.test(item.url || '')) return null;
  const name = (item.filename || '').split(/[\\/]/).pop();
  if (!/^chzzk_[^/\\]+\.(webm|mp4|mkv)$/i.test(name || '')) return null;
  const normalized = normalizeRecordingFolder(folder);
  return normalized ? `${normalized}/${name}` : null;
}
