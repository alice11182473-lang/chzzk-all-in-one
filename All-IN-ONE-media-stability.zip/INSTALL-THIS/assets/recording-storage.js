export function typedRecordingBlob(file, filename) {
  const ext = filename.split('.').pop().toLowerCase();
  const type = {mp4:'video/mp4',webm:'video/webm',mkv:'video/x-matroska'}[ext];
  if(!type)throw new Error('지원하지 않는 녹화 파일 확장자입니다.');
  return file.slice(0,file.size,type);
}
// Bounded write queue: never retain the entire recording in an array.
export async function createRecordingStorage({storage = navigator.storage, maxPendingBytes = 16 * 1024 * 1024} = {}) {
  if (!storage?.getDirectory) throw new Error('이 브라우저는 디스크 임시 녹화를 지원하지 않습니다.');
  const root = await storage.getDirectory();
  const dir = await root.getDirectoryHandle('cqc-recordings', {create:true});
  const name = `recording-${Date.now()}-${crypto.randomUUID()}`;
  const handle = await dir.getFileHandle(name, {create:true});
  const writer = await handle.createWritable();
  let pending=0,peakPending=0,written=0,failure=null,closed=false,running=false;
  const queue=[];let idle=[];
  async function pump(){
    if(running)return;running=true;
    while(queue.length){
      let job=queue.shift();
      try{if(failure)throw failure;await writer.write(job.blob);written+=job.blob.size;job.resolve();}
      catch(error){failure=error;job.reject(error);}
      finally{pending-=job.blob.size;job.blob=null;job=null;}
    }
    running=false;for(const done of idle)done();idle=[];
  }
  const drain=()=>running?new Promise(resolve=>idle.push(resolve)):Promise.resolve();
  return {
    get pendingBytes(){return pending;},
    stats(){return {pendingBytes:pending,peakPendingBytes:peakPending,writtenBytes:written,maxPendingBytes,error:failure?.message||null};},
    append(blob){
      if(closed||failure)return Promise.reject(failure||new Error('저장이 종료되었습니다.'));
      if(pending+blob.size>maxPendingBytes){failure=new Error('디스크 저장 대기량이 한도를 넘어 녹화를 중지했습니다.');return Promise.reject(failure);}
      pending+=blob.size;peakPending=Math.max(peakPending,pending);
      return new Promise((resolve,reject)=>{queue.push({blob,resolve,reject});void pump();});
    },
    async finish(){
      closed=true;await drain();
      if(failure){await writer.abort().catch(()=>{});throw failure;}
      await writer.close();return handle.getFile();
    },
    async discard(){closed=true;await drain();await writer.abort().catch(()=>{});await dir.removeEntry(name).catch(()=>{});},
    async download(filename) {
      const file = await this.finish();
      const url = URL.createObjectURL(typedRecordingBlob(file,filename));
      const api = globalThis.chrome || globalThis.browser;
      try {
        const result = await api.runtime.sendMessage({type:'CQC_DISK_RECORD_DOWNLOAD',url,filename});
        if (!result?.id) throw new Error(result?.error || '다운로드를 시작하지 못했습니다.');
        // Keep the backing file alive until the browser finishes consuming it.
        const cleanup = async()=>{
          try {
            const state = await api.runtime.sendMessage({type:'CQC_DISK_RECORD_DOWNLOAD_STATUS',id:result.id});
            if (state?.state === 'complete') {URL.revokeObjectURL(url);await dir.removeEntry(name);return;}
            if (state?.state === 'interrupted' || state?.state === 'missing') {URL.revokeObjectURL(url);return;}
          } catch {return;}
          setTimeout(cleanup,2000);
        };
        setTimeout(cleanup,2000);
      } catch(error) {URL.revokeObjectURL(url);throw error;}
    }
  };
}
