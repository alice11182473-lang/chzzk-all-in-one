import { LatencyController } from './latency-controller.js';
export function installPlayerCompatibility(PlayerModule) {
  const p=PlayerModule.prototype, original={};
  for(const name of ['mount','initPlayer','exportState','getAvailable','getDetailedStats','onMessage','startMonitor','stopMonitor','reset','cleanup'])original[name]=p[name];
  function locate() {
    const candidates = typeof document.querySelectorAll === 'function'
      ? [...document.querySelectorAll('video')]
          .filter(v => !v.closest?.('[data-cqc-power-dashboard], .cqc-hover-preview, #cqc-hover-preview, .cqc-hover-card') && v.isConnected !== false && v.readyState >= 1)
      : [];
    const video = candidates.sort((a,b) => {
      const size = v => {const r=v.getBoundingClientRect?.();return (r?.width||0)*(r?.height||0);};
      const main = v => !!v.closest?.('.chzzk_player, .pzp');
      return Number(main(b))-Number(main(a)) || size(b)-size(a);
    })[0] || document.querySelector('video.webplayer-internal-video') || document.querySelector('.pzp video');
    if (!video || video.readyState < 1) return null;
    const host = video.closest('.chzzk_player') || video.closest('.pzp') || video.parentElement;
    if (!host) return null;
    let fiber = null;
    for (let element = video, depth=0; element && depth<12; element=element.parentElement,depth++) {
      const key = Object.getOwnPropertyNames(element).find(k => /^__react(Fiber|InternalInstance)\$/.test(k));
      if (key) {fiber=element[key];break;}
    }
    // Older hosts may expose only their own fiber (also supports disconnected test doubles).
    if (!fiber) {const key=Object.getOwnPropertyNames(host).find(k=>/^__react(Fiber|InternalInstance)\$/.test(k));fiber=key?host[key]:null;}
    let foundRef = null, sdk = null;
    for (let depth = 0; fiber && depth < 30; depth++, fiber = fiber.return) {
      for (const node of [fiber, fiber.alternate]) {
        const ref = node?.ref?.current;
        if (!foundRef && ref && typeof ref.getSelectedVideoTrack === 'function' && typeof ref.getVolume === 'function') foundRef = ref;
        let hook = node?.memoizedState;
        for (let index = 0; hook && index < 250; index++, hook = hook.next) {
          // Discover by capabilities, never by a fixed hook number.
          for (const candidate of [hook.memoizedState, hook.memoizedState?.current]) {
            const store = candidate?._view?._store;
            if (!sdk && typeof store?.dispatch === 'function' && store?._actions?.selectVideoTrack) sdk = candidate;
          }
        }
      }
      if (foundRef && sdk) break;
    }
    return { video, host, ref: foundRef, sdk, store: sdk?._view?._store };
  }
  function internalTracks(ctx) {
    if (!ctx.store) return [];
    // Use the player's existing track lists without modifying paths or metadata.
    let selectedId;
    try { const current = ctx.ref.getSelectedVideoTrack(); selectedId = typeof current === 'object' ? current?.id : current; } catch {}
    const sources = [];
    for (const read of [() => ctx.sdk.videoTracks, () => ctx.store.getters?.videoTracks, () => ctx.store.getters?.getVideoTracks, () => ctx.store.state?.videoTracks]) {
      try { sources.push(read()); } catch {}
    }
    for (const list of sources) {
      if (!list || typeof list !== 'object') continue;
      let values;
      try {
        values = Number.isInteger(list.length) && list.length >= 0 && list.length < 300
          ? Array.from({length:list.length}, (_, i) => list[i]) : Object.values(list);
      } catch { continue; }
      const tracks = [];
      for (const t of values) {
        if (!t || !['string','number'].includes(typeof t.id) || String(t.id).length === 0) continue;
        const label = typeof t.label === 'string' ? t.label : '';
        const automatic = /^(ABR|auto|자동)$/i.test(label) || /^ABR(?:$|[._-])/i.test(String(t.id));
        const height = automatic ? 'ABR' : Number(t.height || t.videoHeight || label.match(/(\d{3,4})p/i)?.[1]);
        if (height !== 'ABR' && !(height > 0 && height < 20000)) continue;
        if (t.disabled === true) continue;
        tracks.push({id:t.id, height, label:height === 'ABR' ? '자동' : `${height}p`, selected:t.selected === true || t._selected === true || (selectedId != null && String(selectedId) === String(t.id))});
      }
      if (tracks.length) return tracks;
    }
    return [];
  }
  function readTrack(ctx) {
    const selected = internalTracks(ctx).find(t => t.selected);
    if (selected) return selected;
    let raw;
    try { raw = ctx.ref.getSelectedVideoTrack(); } catch {}
    const object = raw && typeof raw === 'object' ? raw : {};
    const height = Number(object.height) || ctx.video.videoHeight || 0;
    return height ? { label: `${height}p`, height, id: `native-${height}` } : null;
  }
  function qualities(ctx) {
    const native = internalTracks(ctx);
    if (native.length) {
      const found = new Map();
      for (const q of native) if (!found.has(q.height) || q.selected) found.set(q.height, {...q, method:'store'});
      return [...found.values()];
    }
    const found = new Map();
    for (const item of ctx.host.querySelectorAll('.pzp-ui-setting-quality-item')) {
      if (item.getAttribute('aria-disabled') === 'true' || item.hasAttribute('disabled')) continue;
      const label = (item.querySelector('.pzp-ui-setting-quality-item__prefix')?.textContent || item.textContent || '').trim();
      const match = label.match(/(?:^|\s)(\d{3,4})p\b/i);
      const automatic = /^(자동|auto)(?:\s|$)/i.test(label);
      if (!match && !automatic) continue;
      const height = automatic ? 'ABR' : Number(match[1]);
      found.set(height, { height, label: automatic ? '자동' : `${height}p`, id: `native-${height}`, selected: item.classList?.contains('pzp-ui-setting-pane-item--checked') || item.getAttribute('aria-checked') === 'true' || item.getAttribute('aria-selected') === 'true', item, method:'dom' });
    }
    return [...found.values()];
  }

  p.recoverConnection=function(){
    if(this.runtime.settings?.enabled===false || !this.hasPlayer())return false;
    try {
      if(!this.cqcModern?.video?.isConnected || !this.runtime.state.ready || !this.monitorTimer){
        return !!this.initPlayer();
      }
    } catch(error) {this.cqcConnectionError=error?.message || String(error);}
    return false;
  };
  p.mount=function(settings){
    try{return original.mount?.call(this,settings);}
    finally{
      if(this.cqcRecoveryTimer)clearInterval(this.cqcRecoveryTimer);
      this.cqcRecoveryTimer=null;
      if(this.runtime.settings?.enabled!==false){
        this.cqcRecoveryTimer=setInterval(()=>this.recoverConnection(),1500);
        this.recoverConnection();
      }
    }
  };
  p.forceLowLatency=function(){};
  p.changeQuality=async function(height,isManual=false){
    const ctx=this.cqcModern;
    if(!ctx?.store)return {success:false,reason:'화질 제어 연결을 기다리는 중입니다.'};
    if(this.cqcQualityBusy)return {success:false,reason:'이전 화질 변경을 확인하는 중입니다.'};
    const target=height==='ABR'?'ABR':Number(height);
    const tracks=internalTracks(ctx);
    const matches=tracks.filter(t=>t.height===target);
    const track=matches.find(t=>t.selected)||matches[0];
    if(!track)return {success:false,reason:'이 방송에서 제공하지 않는 화질입니다.'};
    if(isManual)this.runtime.state.manualQualitySelection=true;
    if(track.selected)return {success:true,unchanged:true};
    this.cqcQualityBusy=true;
    this.cqcQualitySettlingUntil=Date.now()+8000;
    try{
      // Use the same action and unmodified track ID as the native quality menu.
      // Never rewrite a track URL, low-latency flag or player source.
      const dispatch=ctx.store.dispatch('selectVideoTrack',track.id);
      await Promise.race([Promise.resolve(dispatch),new Promise((_,reject)=>setTimeout(()=>reject(new Error('화질 요청 응답 시간이 초과되었습니다.')),6000))]);
      for(let i=0;i<20;i++){
        if(this.cqcModern?.video!==ctx.video || !ctx.video.isConnected)return {success:false,reason:'방송 페이지가 변경되었습니다.'};
        if(internalTracks(ctx).some(t=>t.selected&&String(t.id)===String(track.id)))return {success:true};
        await new Promise(resolve=>setTimeout(resolve,250));
      }
      return {success:false,reason:'화질 변경을 확인하지 못했습니다. 재적용 버튼으로 다시 시도하세요.'};
    }catch(error){return {success:false,reason:error?.message||'화질 변경 실패'};}
    finally{this.cqcQualityBusy=false;}
  };
  p.applyPreferred=async function(force=false){
    const settings=this.runtime.settings,ctx=this.cqcModern;
    if(!settings?.enabled||(!force&&!settings.autoQuality)||!ctx?.store||this.cqcQualityBusy)return false;
    if(!force&&this.runtime.state.manualQualitySelection)return false;
    const key=String(settings.preferredQuality);
    let attempt=this.cqcQualityAttempt;
    if(!attempt||attempt.key!==key||attempt.video!==ctx.video||attempt.store!==ctx.store){
      attempt=this.cqcQualityAttempt={key,video:ctx.video,store:ctx.store,count:0,at:0,done:false};
    }
    if(!force&&(attempt.done||attempt.count>=3||Date.now()-attempt.at<15000))return false;
    if(!internalTracks(ctx).length)return false;
    if(force)this.runtime.state.manualQualitySelection=false;
    attempt.at=Date.now();attempt.count++;
    const result=await this.changeQuality(settings.preferredQuality,false);
    attempt.done=result.success;
    this.cqcQualityResult=result;
    return result.success;
  };
  p.initPlayer=function(){
    const ctx=locate();
    if(!ctx)return original.initPlayer.call(this);
    // Repeated INIT/settings messages must not reset the active controller or quality attempts.
    if(this.cqcModern?.video===ctx.video&&this.monitorTimer){
      this.cqcModern=ctx;this.runtime.state.ready=true;this.runtime.state.root=ctx.ref||ctx.video;
      return true;
    }
    this.cqcModern=ctx;
    Object.assign(this.runtime.state,{ready:true,root:ctx.ref || ctx.video,core:null,currentTrack:readTrack(ctx),gridBypassed:false});
    this.startMonitor();this.runtime.post('PLAYER_READY',this.exportState());return true;
  };
  p.exportState=function(){
    const ctx=this.cqcModern;if(!ctx)return original.exportState.call(this);
    const v=ctx.video,s=ctx.store?.state;
    const native=[s?.lowLatencyEnabled,s?.lowLatency,s?.lowLatencyMode].find(value=>typeof value==='boolean')??null;
    const gap=this.cqcLatency?.gap()??-1;
    this.runtime.state.currentLatency=gap;
    let buffer=0;for(let i=0;i<v.buffered.length;i++)if(v.buffered.start(i)<=v.currentTime && v.buffered.end(i)>=v.currentTime)buffer=v.buffered.end(i)-v.currentTime;
    return {ready:v.isConnected,connectionMode:'react-latency',currentTrack:readTrack(ctx),resolution:`${v.videoWidth}x${v.videoHeight}`,fps:0,
      currentLatency:gap,absoluteLatency:-1,bufferLength:buffer,isLive:/^\/live\//.test(location.pathname),channelName:'',liveTitle:'',
      isLowLatency:native,nativeLLActive:native,gridBypassed:false,availableQualities:this.getAvailable(),settings:this.runtime.settings,
      isQualityRestoring:false,manualQualitySelection:!!this.runtime.state.manualQualitySelection,qualityControl:this.cqcQualityResult??null,latencyControl:this.cqcLatency?.status??'waiting',playbackRate:v.playbackRate,
      capabilities:{internalTrackControl:!!ctx.store,latencyControl:true,forceLowLatency:false},debug:{currentTime:v.currentTime,videoWidth:v.videoWidth,videoHeight:v.videoHeight}};
  };
  p.getAvailable=function(){return this.cqcModern?qualities(this.cqcModern).map(({height,label,selected})=>({height,label,selected})):[]};
  p.getDetailedStats=function(){return this.cqcModern?this.exportState():original.getDetailedStats.call(this)};
  p.onMessage=async function(type,payload,id){
    if(type==='REQUEST_STATE'){this.recoverConnection();this.runtime.respond(id,this.exportState());return true;}
    if(type==='CHANGE_QUALITY'){this.runtime.respond(id,await this.changeQuality(payload,true));return true}
    if(type==='FORCE_REAPPLY'){const success=await this.applyPreferred(true);this.runtime.respond(id,{success,reason:this.cqcQualityResult?.reason});return true}
    if(this.cqcModern && (type==='GO_LIVE'||type==='CQC_GO_LIVE')){this.runtime.respond(id,{ok:this.cqcLatency?.goLive(this.runtime.settings?.targetLatency)});return true}
    return original.onMessage.call(this,type,payload,id);
  };
  p.startMonitor=function(){
    if(!this.cqcModern)return original.startMonitor.call(this);
    this.stopMonitor();this.cqcLatency=new LatencyController(this.cqcModern.video,this.cqcModern.host);
    this.monitorTimer=setInterval(()=>{
      try{
      const next=locate();
      if(!next||next.video!==this.cqcModern?.video){this.reset();this.startPoll();return}
      // A quality userscript may replace SDK/ref without replacing the video.
      this.cqcModern=next;this.runtime.state.root=next.ref || next.video;
      if(!this.runtime.settings?.autoQuality)this.cqcQualityAttempt=null;
      void this.applyPreferred();
      if(this.cqcLatency.recording()||(!this.cqcQualityBusy&&Date.now()>(this.cqcQualitySettlingUntil||0)))this.cqcLatency.tick(this.runtime.settings,this.runtime.state.manualPlaybackRate??1);
      this.runtime.post('PLAYER_STATE',this.exportState());
      }catch(error){this.cqcConnectionError=error?.message || String(error);this.reset();this.startPoll();}
    },1000);
  };
  p.stopMonitor=function(){
    if(this.cqcLatency||this.cqcModern){if(this.monitorTimer)clearInterval(this.monitorTimer);this.monitorTimer=null;this.cqcLatency?.dispose();this.cqcLatency=null;return}
    return original.stopMonitor.call(this);
  };
  p.startPoll=function(){this.stopPoll();if(this.runtime.settings?.enabled===false||!this.hasPlayer())return;
    this.pollTimer=setInterval(()=>{if(this.runtime.settings?.enabled===false||!this.hasPlayer()){this.stopPoll();return}try{if(this.initPlayer())this.stopPoll()}catch(error){console.warn('[CQC:Latency]',error?.message)}},1000);
  };
  p.reset=function(){const result=original.reset.call(this);this.cqcModern=null;this.cqcQualityAttempt=null;return result};
  p.cleanup=function(){if(this.cqcRecoveryTimer)clearInterval(this.cqcRecoveryTimer);this.cqcRecoveryTimer=null;const result=original.cleanup.call(this);this.cqcModern=null;this.cqcQualityAttempt=null;return result};
}
