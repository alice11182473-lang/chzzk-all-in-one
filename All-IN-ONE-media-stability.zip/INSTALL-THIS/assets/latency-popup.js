function setupLatencyPopup(){
  for(const id of ['opt-grid-bypass','opt-grid-visible','opt-ll']){
    const el=document.getElementById(id);if(el){el.disabled=true;el.title='트랙 우회와 네이티브 저지연 강제 변경은 사용하지 않습니다.';}
  }
  const target=document.getElementById('opt-target-latency');
  if(target){target.min='0';const desc=target.closest('.opt-item')?.querySelector('.opt-desc');if(desc)desc.textContent='0=끔 · 권장 3초 · 1초 미만은 1초로 적용';}
  const latency=document.getElementById('st-latency');if(latency){const label=latency.parentElement.querySelector('.st-label');if(label)label.textContent='라이브 지점과 차이';}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setupLatencyPopup,{once:true});else setupLatencyPopup();
