// Align only the demonstrated double header offset; preserve the site's transform.
(() => {
  let tracked = null, saved = null, applied = null;
  function restore() {
    if (tracked && saved && tracked.style.getPropertyValue('top') === applied) {
      if (saved.value) tracked.style.setProperty('top', saved.value, saved.priority);
      else tracked.style.removeProperty('top');
    }
    tracked = saved = applied = null;
  }
  function correct() {
    if (document.fullscreenElement) {
      restore(); return;
    }
    const sidebar = document.getElementById('sidebar');
    if (tracked && tracked !== sidebar) restore();
    if (!sidebar) return;
    const style = getComputedStyle(sidebar);
    if (style.position !== 'fixed' || style.display === 'none') return;
    const header = document.getElementById('header') || document.querySelector('header');
    if (!header) return;
    const headerRect = header.getBoundingClientRect();
    const target = headerRect.bottom;
    if (headerRect.height < 30 || target < 30 || target > 200) return;
    const top = parseFloat(style.top);
    const actual = sidebar.getBoundingClientRect().top;
    if (!Number.isFinite(top) || !Number.isFinite(actual)) return;
    const gap = actual - target;
    if (!tracked) {
      const match = style.transform.match(/^matrix\(([^)]+)\)$/);
      const m = match?.[1].split(',').map(Number);
      if (!m || m.length !== 6 || m.some(n => !Number.isFinite(n)) ||
          m[0] !== 1 || m[1] !== 0 || m[2] !== 0 || m[3] !== 1) return;
      // The reported case: top=60, translateY=60, rendered top=120.
      if (gap < 40 || gap > 100 || Math.abs(top - target) > 3 ||
          Math.abs(m[5] - gap) > 3) return;
      tracked = sidebar;
      saved = {value: sidebar.style.getPropertyValue('top'),
               priority: sidebar.style.getPropertyPriority('top')};
    }
    if (Math.abs(gap) < 1) return;
    const next = top - gap;
    if (next < -100 || next > 200 || Math.abs(gap) > 150) return;
    applied = `${Math.round(next * 100) / 100}px`;
    if (sidebar.style.getPropertyValue('top') !== applied ||
        sidebar.style.getPropertyPriority('top') !== 'important') {
      sidebar.style.setProperty('top', applied, 'important');
    }
  }
  correct();
  window.addEventListener('resize', correct);
  window.addEventListener('pageshow', correct);
  document.addEventListener('fullscreenchange', correct);
  setInterval(correct, 1000);
})();
