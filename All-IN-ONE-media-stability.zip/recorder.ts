import { installAutoRecord } from './compatibility/auto-record.js';
// @ts-nocheck
import { log as cqcLog, SELECTORS, showToast, isPlayerPage } from './dom-utils';
import { formatFileTimestamp } from './file-timestamp';

/**
 * 로그 출력용 로컬 헬퍼
 * @param {...any} args
 */
const log = (...args) => cqcLog('Recorder', ...args);

const SETTING_BTN_SELECTOR = SELECTORS.PLAYER_SETTING_BTN;

let currentSettings = null;

export const updateRecorderSettings = (settings) => {
    currentSettings = settings;
};

/** @type {MediaRecorder|null} */
let recorder = null;
/** @type {Blob[]} */
let chunks = [];
/** 녹화 중 여부 */
let recording = false;
/** 시작 시간 */
let startTime = 0;
/** 녹화 표시기 엘리먼트 @type {HTMLElement|null} */
let indicator = null;
/** 타이머 인터벌 ID @type {number|null} */
let timerInterval = null;

/**
 * 비디오 엘리먼트를 찾습니다.
 * @returns {HTMLVideoElement|null}
 */
const findVideo = () =>
    (document.querySelector('video.webplayer-internal-video')) ??
    (document.querySelector('video'));

/**
 * 밀리초를 HH:MM:SS 형식으로 변환합니다.
 * @param {number} ms 
 * @returns {string}
 */
const formatTime = (ms) => {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    return `${String(h).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};

/**
 * 녹화 표시기를 표시합니다.
 */
const showIndicator = () => {
    removeIndicator();
    indicator = document.createElement('div');
    indicator.id = 'cqc-rec-indicator';
    indicator.style.cssText = `
      position:absolute;top:12px;right:12px;z-index:2000000;
      display:flex;align-items:center;gap:6px;
      background:rgba(0,0,0,0.7);color:#ff4444;
      padding:4px 10px;border-radius:6px;font-size:12px;font-weight:bold;
      font-family:'Pretendard',-apple-system,sans-serif;
      pointer-events:none;backdrop-filter:blur(4px);
      border:1px solid rgba(255,68,68,0.3);
    `;
    indicator.innerHTML = `<span style="width:8px;height:8px;border-radius:50%;background:#ff4444;animation:cqc-blink 1s infinite;"></span><span id="cqc-rec-timer">00:00:00</span>`;

    if (!document.getElementById('cqc-rec-style')) {
        const style = document.createElement('style');
        style.id = 'cqc-rec-style';
        style.textContent = `@keyframes cqc-blink { 0%,100%{opacity:1} 50%{opacity:0.3} }`;
        document.head.append(style);
    }

    const player = document.querySelector(SELECTORS.PLAYER);
    (player ?? document.body).appendChild(indicator);

    // @ts-ignore
    timerInterval = setInterval(() => {
        const el = document.getElementById('cqc-rec-timer');
        if (el) el.textContent = formatTime(Date.now() - startTime);
    }, 1000);
};

/**
 * 녹화 표시기를 제거합니다.
 */
const removeIndicator = () => {
    indicator?.remove();
    indicator = null;
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
};

/**
 * 녹화를 시작하거나 중지합니다.
 */
const startRecording = () => {
    const video = findVideo();
    if (!video) { return; }
    if (recording) { stopRecording(); return; }

    try {
        const stream = video.captureStream();
        const format = currentSettings?.recorderFormat === 'mp4' ? 'mp4' : 'webm';
        let mimeType = 'video/webm;codecs=vp8,opus';
        
        if (format === 'mp4' && MediaRecorder.isTypeSupported('video/mp4')) {
            mimeType = 'video/mp4';
        } else if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = 'video/webm';
        }

        // 기본 비트레이트가 낮아 화질 저하가 발생하므로, 명시적으로 높은 비트레이트(15Mbps) 할당
        recorder = new MediaRecorder(stream, { 
            mimeType,
            videoBitsPerSecond: 15000000, // 15 Mbps
            audioBitsPerSecond: 192000    // 192 kbps
        });

        chunks = [];
        recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
        recorder.onstop = () => {
            delete video.dataset.cqcRecording;
            stream.getTracks().forEach(track => track.stop());
            const actualFormat = mimeType.includes('mp4') ? 'mp4' : 'webm';
            const blob = new Blob(chunks, { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            const ts = formatFileTimestamp(currentSettings?.fileTimestampFormat, currentSettings?.fileTimestampTimezone);
            a.download = `chzzk_${ts}.${actualFormat}`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(url), 3000);
            showToast(`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00ffa3" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px;margin-right:4px;"><rect x="2" y="4" width="20" height="16" rx="2"/><line x1="2" y1="8" x2="22" y2="8"/></svg> 녹화 저장됨 (${formatTime(Date.now() - startTime)})`);
            removeIndicator();
            updateButtonState();
        };

        recorder.onerror = () => { delete video.dataset.cqcRecording; };
        recorder.start(1000);
        video.dataset.cqcRecording = "true";
        recording = true;
        startTime = Date.now();
        showIndicator();
        updateButtonState();
        showToast('<svg width="20" height="20" viewBox="0 0 24 24" fill="#ff4444" stroke="none" style="vertical-align:-4px;margin-right:4px;"><circle cx="12" cy="12" r="8"/></svg> 녹화 시작');
    } catch (e) {
    }
};

/**
 * 녹화를 중지합니다.
 */
const stopRecording = () => {
    if (!recorder || !recording) return;
    recording = false;
    recorder.stop();
    recorder = null;
};

/** 녹화 상태를 토글합니다. */
const toggleRecording = () => { recording ? stopRecording() : startRecording(); };

/**
 * 버튼 상태를 업데이트합니다.
 */
const updateButtonState = () => {
    const btn = document.getElementById('cqc-record-btn');
    if (!btn) return;
    const circle = btn.querySelector('.cqc-rec-circle');
    const tooltip = btn.querySelector(SELECTORS.PLAYER_BUTTON_TOOLTIP);
    
    const shortcut = currentSettings?.customShortcuts?.record;
    const shortcutText = formatShortcut(shortcut);
    
    if (recording) {
        if (circle) { circle.setAttribute('fill', '#ff4444'); circle.setAttribute('r', '6'); }
        if (tooltip) tooltip.textContent = `녹화 중지 (${shortcutText})`;
    } else {
        if (circle) { circle.setAttribute('fill', 'white'); circle.setAttribute('r', '5'); }
        if (tooltip) tooltip.textContent = `녹화 시작 (${shortcutText})`;
    }
};

const isShortcutMatched = (e, shortcut) => {
  if (!shortcut) return false;
  const eventKey = e.key.toLowerCase();
  const targetKey = shortcut.key.toLowerCase();
  
  return eventKey === targetKey &&
         !!e.ctrlKey === !!shortcut.ctrl &&
         !!e.shiftKey === !!shortcut.shift &&
         !!e.altKey === !!shortcut.alt &&
         !!e.metaKey === !!shortcut.meta;
};

const formatShortcut = (shortcut) => {
  if (!shortcut) return '없음';
  const parts = [];
  if (shortcut.ctrl) parts.push('Ctrl');
  if (shortcut.shift) parts.push('Shift');
  if (shortcut.alt) parts.push('Alt');
  if (shortcut.meta) parts.push('Meta');
  
  let keyText = shortcut.key;
  if (keyText === ' ') keyText = 'Space';
  else if (keyText) keyText = keyText.toUpperCase();
  
  if (keyText) parts.push(keyText);
  return parts.join('+') || '없음';
};

document.addEventListener('keydown', (e) => {
    if (currentSettings?.recorderEnabled === false) return;
    const shortcut = currentSettings?.customShortcuts?.record;
    if (shortcut && isShortcutMatched(e, shortcut)) {
        if (isPlayerPage()) {
            e.preventDefault();
            toggleRecording();
        }
    }
});

/**
 * 플레이어 바에 녹화 버튼을 추가합니다.
 * @param {Element} bar 
 */
const addPlayerButton = (bar) => {
    if (bar.querySelector('#cqc-record-btn')) return;

    const shortcut = currentSettings?.customShortcuts?.record;
    const btn = document.createElement('button');
    btn.id = 'cqc-record-btn';
    btn.className = 'pzp-button pzp-pc-ui-button';
    btn.setAttribute('aria-label', '녹화');
    btn.innerHTML = `
      <span class="pzp-button__tooltip pzp-button__tooltip--top">녹화 시작 (${formatShortcut(shortcut)})</span>
      <span class="pzp-ui-icon">
        <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg" class="pzp-ui-icon__svg">
          <circle cx="18" cy="18" r="10" stroke="white" stroke-width="1.7" fill="none"/>
          <circle class="cqc-rec-circle" cx="18" cy="18" r="5" fill="white"/>
        </svg>
      </span>`;


    btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleRecording();
    });

    const screenshotBtn = bar.querySelector('#cqc-screenshot-btn');
    const settingBtn = bar.querySelector(SETTING_BTN_SELECTOR);
    const ref = screenshotBtn?.nextSibling ?? settingBtn;
    if (ref && ref.parentElement) {
        ref.parentElement.insertBefore(btn, ref);
    } else {
        bar.appendChild(btn);
    }
};

/**
 * 관찰을 시작합니다.
 */
const observe = () => {
    const tryAdd = () => {
        const bar = document.querySelector(SELECTORS.PLAYER_CONTROL_BAR_RIGHT);
        if (bar) addPlayerButton(bar);
    };
    tryAdd();
    // DOM 변화 감지 대신 2초 간격으로 UI 삽입 여부를 확인합니다.
    window.setInterval(tryAdd, 2000);
};

/**
 * 리코더 모듈 초기화
 */
export function initRecorder() {
    observe();
    log('모듈 초기화됨');
}

installAutoRecord({isManualRecording: () => recording});
