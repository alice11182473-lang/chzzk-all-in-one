// Use the site's hourly reward button and observe its actual claim response.
(() => {
  let pending = null;
  const channel = () => location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1] || '';
  const publish = detail => window.dispatchEvent(new CustomEvent('cqc-mobile-native-result', {detail: JSON.stringify(detail)}));
  function request(url, method) {
    if (!pending || Date.now() - pending.at > 15000 || String(method).toUpperCase() !== 'PUT') return null;
    try {
      const u = new URL(url, location.href);
      const m = u.pathname.match(/^\/service\/v1\/channels\/([a-f0-9]{32})\/log-power\/claims\/([^/]+)$/i);
      if (u.origin !== 'https://api.chzzk.naver.com' || !m || m[1] !== pending.channelId) return null;
      return {...pending, claimId: decodeURIComponent(m[2])};
    } catch {return null;}
  }
  function finish(ticket, data, ok) {
    if (!ticket || pending?.at !== ticket.at) return;
    pending = null;
    publish({...ticket, ok: !!ok && data?.code === 200 && Number.isFinite(data?.content?.amount), balance: data?.content?.amount});
  }
  const fetchOriginal = window.fetch;
  window.fetch = function(input, options) {
    const ticket = request(typeof input === 'string' ? input : input?.url, options?.method || input?.method || 'GET');
    const result = fetchOriginal.apply(this, arguments);
    if(ticket) result.then(r=>r.clone().json().then(data=>finish(ticket,data,r.ok)).catch(()=>finish(ticket,null,false)),()=>finish(ticket,null,false));
    return result;
  };
  const open = XMLHttpRequest.prototype.open, send = XMLHttpRequest.prototype.send;
  const requests = new WeakMap();
  XMLHttpRequest.prototype.open = function(method,url) {requests.set(this,{method,url});return open.apply(this,arguments);};
  XMLHttpRequest.prototype.send = function() {
    const r=requests.get(this), ticket=r && request(r.url,r.method);
    if(ticket) this.addEventListener('loadend',()=>{let data;try{data=this.responseType==='json'?this.response:JSON.parse(this.responseText);}catch{}finish(ticket,data,this.status>=200&&this.status<300);},{once:true});
    return send.apply(this,arguments);
  };
  window.addEventListener('cqc-mobile-native-click', e => {
    let data;try{data=JSON.parse(e.detail);}catch{return;}
    if(data.channelId!==channel() || pending) return;
    // Exact hourly reward wording; do not click chat messages, donations or predictions.
    const button=[...document.querySelectorAll('button')].find(b=>
      /^1시간\s*시청\s*통나무\s*파워\s*배달\s*완료!\s*[\d,]+\s*받기$/.test(b.textContent.trim()) &&
      !b.disabled && b.getClientRects().length && getComputedStyle(b).visibility!=='hidden');
    if(!button) return;
    const amount=Number(button.textContent.match(/([\d,]+)\s*받기$/)?.[1].replaceAll(',',''));
    pending={channelId:data.channelId,amount,at:Date.now()};
    const ticket=pending;
    publish({...ticket,started:true});
    setTimeout(()=>{if(pending===ticket){pending=null;publish({...ticket,ok:false,timeout:true});}},15000);
    button.click();
  });
})();
