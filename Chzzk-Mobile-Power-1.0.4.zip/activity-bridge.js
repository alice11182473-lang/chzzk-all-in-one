// Only status values cross into the isolated UI. No cookies or chat content.
(() => {
  const publish = () => {
    const activity = window.__cqcPowerActivity;
    const channelId = location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1] || '';
    const video = activity?.getPlaybackVideo();
    activity?.updatePlayback({channelId, enabled: !!channelId, playing: !!video && !video.paused && !video.ended});
    window.dispatchEvent(new CustomEvent('cqc-mobile-status', {detail: JSON.stringify({channelId, status: activity?.getStatus() || 'unknown'})}));
  };
  window.addEventListener('cqc-mobile-query', publish);
  window.addEventListener('cqc-power-activity-change', publish);
  document.addEventListener('play', publish, true);
  document.addEventListener('pause', publish, true);
})();
