(() => {
// Callback-only mobile implementations and Promise-based Chromium are both supported.
function cqcMobileCall(target, method, value, timeout = 15000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (error, result) => {
      if (done) return;
      done = true; clearTimeout(timer);
      error ? reject(new Error(error.message || String(error))) : resolve(result);
    };
    const timer = setTimeout(() => finish(new Error('확장 응답 시간 초과 · 다시 확인하거나 방송 페이지를 새로고침하세요.')), timeout);
    try {
      const pending = target[method](value, result => {
        const error = chrome.runtime.lastError;
        finish(error, result);
      });
      if (pending && typeof pending.then === 'function') pending.then(result => finish(null, result), error => finish(error));
    } catch (error) { finish(error); }
  });
}
const cqcMobileStorage = {
  get: value => cqcMobileCall(chrome.storage.local, 'get', value),
  set: value => cqcMobileCall(chrome.storage.local, 'set', value)
};

  if (window.top !== window || document.getElementById('cqc-mobile-power')) return;
  const host = document.createElement('div');
  host.id = 'cqc-mobile-power';
  const shadow = host.attachShadow({mode: 'open'});
  shadow.innerHTML = `<style>
    :host{all:initial!important;position:fixed!important;right:max(10px,env(safe-area-inset-right))!important;bottom:max(90px,calc(env(safe-area-inset-bottom) + 80px))!important;z-index:2147483647!important;pointer-events:auto!important;font:14px/1.5 system-ui,sans-serif!important;color:#eef7f4!important;max-width:calc(100vw - 20px)!important}
    :host([hidden]){display:none!important}:host([data-top]){bottom:auto!important;top:max(12px,env(safe-area-inset-top))!important}
    [hidden]{display:none!important}*{box-sizing:border-box}button,input,a{pointer-events:auto}button{font:inherit;color:inherit;border:1px solid #3b5652;border-radius:12px;background:#172925;min-height:44px;padding:9px 12px;touch-action:manipulation;cursor:pointer}button:focus-visible{outline:2px solid #00e6ad;outline-offset:2px}
    #bar{display:flex;align-items:center;gap:10px;box-shadow:0 3px 16px #0007;max-width:100%;flex-wrap:wrap}#state{font-size:12px;color:#a8b7b3}#state[data-state=confirmed]{color:#00e6ad}
    #panel{position:absolute;bottom:54px;right:0;background:#101e1b;border:1px solid #3b5652;border-radius:16px;padding:16px;width:min(330px,calc(100vw - 20px));max-height:calc(100dvh - 180px);overflow:auto;box-shadow:0 8px 30px #0009}
    :host([data-top]) #panel{top:54px;bottom:auto}h2{font-size:18px;margin:0 0 12px}p{margin:10px 0;color:#bacac5}label{display:flex;gap:10px;align-items:center;min-height:44px}input{width:22px;height:22px;accent-color:#00dba5}#buttons{display:flex;gap:8px;flex-wrap:wrap}ol{padding-left:22px;font-size:12px}#error{color:#ffc48e}#support{font-size:12px}#close{float:right}a{color:#00e6ad}small{display:block;color:#a8b7b3}
    @media(max-height:450px){:host{bottom:12px!important}:host([data-top]){bottom:auto!important}#panel{max-height:calc(100dvh - 80px)}}
  </style><button id="bar" type="button" aria-expanded="false" aria-controls="panel"><strong id="balance">🪵 확인 중</strong><span id="state">적립 확인 중</span></button>
  <section id="panel" hidden aria-label="통나무 설정"><button id="close" type="button" aria-label="닫기">닫기</button><h2>모바일 통나무 1.0.4</h2>
  <label><input id="auto" type="checkbox">1시간 보상 자동 수령</label>
  <div id="buttons"><button id="position" type="button">표시 위치 변경</button><button id="refresh" type="button">보유량 확인</button><button id="reload" type="button">페이지 새로고침</button></div>
  <p id="nativeState" role="status"></p><p id="connection" role="status"></p><p id="detail"></p><p id="error" role="status"></p><small id="updated"></small>
  <p id="support">서버에 수령 가능한 1시간 보상이 생기면 받습니다. 화면 잠금·백그라운드에서는 중단될 수 있습니다. 적립이 늘지 않으면 PC 웹 보기로 비교해 주세요.</p>
  <a id="desktop">같은 방송 PC 웹 주소 열기</a><h3>자동 수령 처리 내역</h3><ol id="logs"></ol><small>아래 잔액 변동과 별도의 처리 확인입니다. 두 목록을 합산하지 마세요. 이 브라우저에만 저장됩니다.</small><h3>획득·사용 로그</h3><ol id="balanceLogs"></ol><small>조회 사이의 잔액 순변동입니다. 시청·후원·승부예측 등의 원인은 구분하지 않습니다.</small></section>`;
  document.documentElement.append(host);
  const $ = id => shadow.getElementById(id);
  let channel = '', amount = null, status = 'unknown', busy = false, lastPoll = 0, error = '', updated = 0;
  let settings = {autoClaim: true, top: false};
  let generation = 0;
  const getChannel = () => /\/chat\/?$/.test(location.pathname) ? '' : location.pathname.match(/^\/live\/([a-f0-9]{32})(?:\/|$)/i)?.[1] || '';
  const setText = (id, value) => { if ($(id).textContent !== value) $(id).textContent = value; };
  function render() {
    host.hidden = !channel || !!document.fullscreenElement;
    host.toggleAttribute('data-top', settings.top);
    $('auto').checked = settings.autoClaim;
    const labels = {confirmed: '벌목중 · 적립 확인', estimated: '적립 확인 중', waiting: '벌목대기중 · 추정', unknown: '적립 확인 중'};
    setText('balance', '🪵 ' + (amount === null ? (error ? '연결 확인 필요' : '확인 중') : amount.toLocaleString()));
    setText('state', labels[status] || labels.unknown);
    $('state').dataset.state = status;
    setText('detail', status === 'confirmed' ? '최근 5분 시청 적립 알림이 확인됐습니다. 현재도 계속 적립되는지는 다음 알림으로 확인합니다.' : '재생·탭 상태만으로 실제 적립 여부를 확정하지 않습니다. 다른 기기의 시청 상태는 확인할 수 없습니다.');
    setText('error', error);
    setText('connection', busy ? '확장 연결 · 보유량 조회 중…' : error ? '조회/수령 오류 · 자동 수령 성공을 확인할 수 없습니다.' : updated ? '확장 연결됨 · 30초마다 보유량과 수령 가능한 보상을 확인합니다.' : '확장 연결 확인 전');
    $('refresh').disabled = busy;
    setText('refresh', busy ? '조회 중…' : '보유량 확인');
    setText('updated', updated ? '보유량 확인: ' + new Date(updated).toLocaleTimeString('ko-KR') : '보유량 확인 전');
    $('desktop').href = 'https://chzzk.naver.com/live/' + channel;
  }
  async function logs() {
    const id = channel;
    const values = await cqcMobileStorage.get('channel_' + id);
    if (id !== channel) return;
    const state = values['channel_' + id] || {};
    const changes = state.balanceLogs || [];
    $('balanceLogs').replaceChildren(...changes.slice(0, 30).map(log => {
      const item = document.createElement('li');
      const sign = log.amount > 0 ? '+' : '';
      item.textContent = `${new Date(log.at).toLocaleString('ko-KR')} · ${sign}${log.amount.toLocaleString()} · 잔액 ${log.balance.toLocaleString()}${log.gap ? ' (조회 공백 동안 순변동)' : ''}`;
      return item;
    }));
    if (!changes.length) {
      const li = document.createElement('li');
      li.textContent = Number.isFinite(state.balance) ? '기준 잔액을 저장했습니다. 이후 변동부터 기록합니다.' : '보유량 조회 후 기록을 시작합니다.';
      $('balanceLogs').append(li);
    }
    const list = state.logs || [];
    $('logs').replaceChildren(...list.slice(0, 10).map(log => {
      const item = document.createElement('li');
      item.textContent = `${new Date(log.at).toLocaleString('ko-KR')} · 1시간 보상 수령${log.schema === 2 && Number.isFinite(log.amount) ? ' +' + log.amount : ' (금액 재확인 불가)'}`;
      return item;
    }));
    if (!list.length) { const li = document.createElement('li'); li.textContent = '확인된 수령 기록이 없습니다.'; $('logs').append(li); }
  }
  function setPanel(open) { $('panel').hidden = !open; $('bar').setAttribute('aria-expanded', String(open)); if(open) logs().catch(() => { error = '로그를 읽지 못했습니다. 방송 페이지를 새로고침하세요.'; render(); }); }
  // Keep the site's bubbling click handlers away from extension controls.
  shadow.addEventListener('click', e => e.stopPropagation());
  $('reload').onclick = () => location.reload();
  $('bar').onclick = () => setPanel($('panel').hidden);
  $('close').onclick = () => {setPanel(false); $('bar').focus();};
  shadow.addEventListener('keydown', e => { if (e.key === 'Escape') setPanel(false); });
  $('auto').onchange = async () => {
    settings.autoClaim = $('auto').checked;
    try { await cqcMobileStorage.set({autoClaim: settings.autoClaim}); }
    catch { error = '설정 저장 실패 · 다시 시도하세요.'; }
    render();
  };
  $('position').onclick = async () => { settings.top = !settings.top; render(); await cqcMobileStorage.set({top: settings.top}).catch(()=>{}); };
  $('refresh').onclick = () => {lastPoll = 0; tick();};
  window.addEventListener('cqc-mobile-status', e => {
    try {
      const data = JSON.parse(e.detail);
      if (data.channelId === channel && ['confirmed','estimated','waiting','unknown'].includes(data.status)) { status = data.status; render(); }
    } catch {}
  });
  let lastNativeClick = 0;
  const nativeVisible = () => [...document.querySelectorAll('button')].some(b =>
    /^1시간\s*시청\s*통나무\s*파워\s*배달\s*완료!\s*[\d,]+\s*받기$/.test(b.textContent.trim()) && !b.disabled && b.getClientRects().length);
  window.addEventListener('cqc-mobile-native-result', async e => {
    let data;try{data=JSON.parse(e.detail);}catch{return;}
    if(data.channelId !== channel) return;
    if(data.started) {setText('nativeState','공식 받기 버튼 클릭 · 서버 응답 확인 중');return;}
    if(!data.ok) {setText('nativeState','공식 버튼 수령 성공을 확인하지 못했습니다. 잔액과 받기 버튼을 확인하세요.');return;}
    setText('nativeState','공식 버튼 수령 응답 확인 · 기록 저장 중');
    try {
      const r=await cqcMobileCall(chrome.runtime,'sendMessage',{...data,type:'CQC_MOBILE_NATIVE_RESULT'});
      if(!r?.ok) throw Error('기록 저장 실패');
      setText('nativeState','1시간 보상 수령 성공 · +' + data.amount);
      lastPoll=0; await tick(); if(!$('panel').hidden) await logs();
    } catch {setText('nativeState','수령 응답 확인 · 기록 저장 실패');}
  });
  async function tick() {
    const next = getChannel();
    if (channel !== next) {
      channel = next; generation++; amount = null; status = 'unknown'; lastPoll = 0; updated = 0; error = ''; setPanel(false);
    }
    render();
    if (!channel) return;
    window.dispatchEvent(new Event('cqc-mobile-query'));
    if (busy || Date.now() - lastPoll < 30000) return;
    busy = true; render(); lastPoll = Date.now(); const token = generation, id = channel;
    try {
      const response = await cqcMobileCall(chrome.runtime, 'sendMessage', {type: 'CQC_MOBILE_POLL', channelId: id, nativeVisible: nativeVisible()}, 25000);
      if (token !== generation || getChannel() !== id) return;
      if (!response?.ok) throw Error(response?.error || '확장 응답 없음 · 확장 활성화 확인 후 페이지를 새로고침하세요.');
      if (!Number.isFinite(response.amount)) throw Error('보유량 응답을 확인할 수 없습니다.');
      amount = response.amount; updated = Date.now(); error = response.claimError || '';
      if (settings.autoClaim && nativeVisible() && Date.now()-lastNativeClick > 60000) {
        lastNativeClick=Date.now();
        window.dispatchEvent(new CustomEvent('cqc-mobile-native-click',{detail:JSON.stringify({channelId:id})}));
      }
      if (!$('panel').hidden) await logs();
    } catch (e) { if (token === generation) error = e.message; }
    finally {busy = false; render();}
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    for (const key of ['autoClaim','top']) if (changes[key]) settings[key] = !!changes[key].newValue;
    render();
    if (changes['channel_' + channel] && !$('panel').hidden) logs().catch(() => {error = '로그를 읽지 못했습니다.'; render();});
  });
  cqcMobileStorage.get(settings).then(value => {settings = {...settings, ...value}; tick();}).catch(() => {error = '설정을 읽지 못했습니다.'; render();});
  setInterval(tick, 3000);
  document.addEventListener('visibilitychange', () => {if(!document.hidden) {lastPoll = 0; tick();}});
  window.addEventListener('pageshow', tick);
  window.addEventListener('popstate', tick);
  document.addEventListener('fullscreenchange', render);
})();
