const {test}=require('node:test'),assert=require('node:assert/strict'),vm=require('node:vm'),fs=require('node:fs');
const code=fs.readFileSync(__dirname+'/../native-claim.js','utf8'),id='a'.repeat(32);
function harness({text='1시간 시청 통나무 파워 배달 완료! 100 받기',status=200,code:responseCode=200,mode='xhr',hidden=false}={}){
 const window=new EventTarget(),events=[],timers=[];let clicks=0;
 class CE extends Event{constructor(type,options){super(type);this.detail=options.detail;}}
 class XHR extends EventTarget {open(method,url){this.url=url;}send(){this.status=status;this.responseText=JSON.stringify({code:responseCode,content:{amount:40542}});this.dispatchEvent(new Event('loadend'));}}
 window.fetch=async()=>({ok:status===200,clone:()=>({json:async()=>({code:responseCode,content:{amount:40542}})})});
 const button={textContent:text,disabled:false,getClientRects:()=>hidden?[]:[{}],click(){clicks++;const url='https://api.chzzk.naver.com/service/v1/channels/'+id+'/log-power/claims/server-claim';if(mode==='xhr'){const x=new XHR();x.open('PUT',url);x.send();}else if(mode==='fetch'){window.fetch(url,{method:'PUT'});}}};
 window.addEventListener('cqc-mobile-native-result',e=>events.push(JSON.parse(e.detail)));
 vm.runInNewContext(code,{window,document:{querySelectorAll:()=>[button]},location:{pathname:'/live/'+id,href:'https://chzzk.naver.com/live/'+id},URL,XMLHttpRequest:XHR,CustomEvent:CE,WeakMap,Date,setTimeout:f=>timers.push(f),getComputedStyle:()=>({visibility:'visible'})});
 return {events,timers,clicks:()=>clicks,click:()=>window.dispatchEvent(new CE('cqc-mobile-native-click',{detail:JSON.stringify({channelId:id})}))};
}
test('official hourly button uses native XHR response for receipt',()=>{const h=harness();h.click();assert.equal(h.clicks(),1);assert.equal(h.events[0].started,true);assert.equal(h.events[1].ok,true);assert.equal(h.events[1].amount,100);assert.equal(h.events[1].balance,40542);assert.equal(h.events[1].claimId,'server-claim');});
test('fetch claim response also confirms receipt',async()=>{const h=harness({mode:'fetch'});h.click();await new Promise(r=>setImmediate(r));assert.equal(h.events[1].ok,true);});
test('failed request never becomes successful receipt',()=>{const h=harness({status:403,code:403});h.click();assert.equal(h.events[1].ok,false);});
test('no response times out and pending clicks are not repeated',()=>{const h=harness({mode:'none'});h.click();h.click();assert.equal(h.clicks(),1);h.timers[0]();assert.equal(h.events[1].timeout,true);assert.equal(h.events[1].ok,false);});
test('other buttons and invisible hourly rewards are ignored',()=>{for(const opts of [{text:'100 받기'},{text:'후원 100 받기'},{text:'승부예측 100 받기'},{hidden:true}]){const h=harness(opts);h.click();assert.equal(h.clicks(),0);}});
