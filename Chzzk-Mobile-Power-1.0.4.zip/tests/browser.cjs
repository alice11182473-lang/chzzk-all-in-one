const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
const assert=require('node:assert/strict');
const path=require('node:path');
(async()=>{
const extension=path.resolve(__dirname,'..');
const context=await chromium.launchPersistentContext('',{headless:true,executablePath:'/usr/bin/chromium',args:[`--disable-extensions-except=${extension}`,`--load-extension=${extension}`],viewport:{width:390,height:844},deviceScaleFactor:1,isMobile:true,hasTouch:true});
try {
 let worker=context.serviceWorkers()[0] || await context.waitForEvent('serviceworker');
 let puts=0;
 await worker.evaluate(()=>{
  let amount=650,claims=[{claimType:'WATCH_1_HOUR',claimId:'test-hour',amount:100}];
  globalThis.__puts=0;
  globalThis.fetch=async(url,opts)=>{
   if(opts.method==='PUT'){globalThis.__puts++;amount+=100;claims=[];return {ok:true,json:async()=>({code:200,content:{amount}})}}
   return {ok:true,json:async()=>({code:200,content:{amount,claims}})};
  };
 });
 await context.route('https://m.chzzk.naver.com/**',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{background:#111;color:white;margin:0}video{width:100%;height:220px;background:#242424}</style><video></video><h2>테스트 방송</h2><div style="height:500px">모바일 채팅 영역</div>'}));
 const page=await context.newPage();
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('https://m.chzzk.naver.com/live/'+'a'.repeat(32));
 await page.locator('#balance').filter({hasText:'750'}).waitFor();
 assert.equal(await worker.evaluate(()=>globalThis.__puts),1);
 await page.locator('#bar').tap();await page.locator('#panel').waitFor({state:'visible'});
 await page.locator('#auto').uncheck();
 assert.equal((await worker.evaluate(()=>chrome.storage.local.get('autoClaim'))).autoClaim,false);
 await page.locator('#position').tap();
 for(const size of [{width:390,height:844},{width:320,height:568},{width:844,height:390}]){
  await page.setViewportSize(size);
  const box=await page.locator('#panel').boundingBox();
  assert(box.x>=0&&box.y>=0&&box.x+box.width<=size.width+1&&box.y+box.height<=size.height+1,JSON.stringify({size,box}));
 }
 await page.setViewportSize({width:390,height:844});
 await page.screenshot({path:path.resolve(__dirname,'../../mobile-ui-check.png')});
 await page.evaluate(()=>history.pushState({},'', '/'));
 await page.locator('#cqc-mobile-power').waitFor({state:'hidden'});
 assert.deepEqual(errors,[]);
 console.log('PASS: real MV3 load, server-issued claim, balance UI, touch toggles, 320/390px + landscape layout, SPA cleanup');
}finally{await context.close()}
})().catch(e=>{console.error(e);process.exit(1)});
