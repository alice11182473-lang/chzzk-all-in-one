import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source = fs.readFileSync(new URL('../activity.js', import.meta.url), 'utf8');
const A = 'a'.repeat(32), B = 'b'.repeat(32);
const watchURL = 'https://api.chzzk.naver.com/polling/v1/watch-event/live';
const flush = () => new Promise(resolve => setTimeout(resolve, 10));
const reward = (id, type = 'WATCH_5_MIN') => ({type: 'LOG_POWER', subType: 'SAVE', channelId: id, data: {claimType: type}});
const modern = data => '42' + JSON.stringify(['personalMessage', JSON.stringify(data)]);
const legacy = data => '5:::' + JSON.stringify({name: 'personalMessage', args: [JSON.stringify(data)]});
function video({main = false, preview = false, sidebar = false, width = 640, height = 360, paused = false, connected = true, readyState = 4} = {}) {
  return {paused, ended: false, readyState, isConnected: connected,
    closest(selector) {
      if (selector.includes('.cqc-hover-preview')) return preview || sidebar ? {} : null;
      if (selector.includes('.pzp')) return main ? {} : null;
      return null;
    },
    matches: () => false,
    getBoundingClientRect: () => ({width, height})};
}
function world() {
  let now = 1_000_000, serial = 0, writes = 0;
  const store = new Map(), tabs = [], buses = [];
  function makeTab(id, {storage = true, broadcast = true, focused = false} = {}) {
    const window = new EventTarget(); window.top = window;
    const document = {visibilityState: focused ? 'visible' : 'hidden', focused, videos: [],
      hasFocus() {return this.focused;}, querySelectorAll() {return this.videos;}};
    const location = {pathname: '/live/' + id, href: 'https://chzzk.naver.com/live/' + id};
    class Socket extends EventTarget {
      static OPEN = 1;
      constructor(url) {super();this.url = url;}
      send(data) {this.sent = data;}
      receive(data) {this.dispatchEvent(Object.assign(new Event('message'), {data}));}
    }
    class XHR extends EventTarget {
      open(...args) {this.openArgs = args;}
      send(body) {this.body = body;}
      finish(status = 200, json = {code: 200}) {this.status = status;this.responseText = JSON.stringify(json);this.dispatchEvent(new Event('loadend'));}
    }
    class Bus {
      constructor(name) {this.name = name; buses.push(this);}
      postMessage(data) {for (const other of buses) if (other !== this && other.name === this.name) queueMicrotask(() => other.onmessage?.({data: structuredClone(data)}));}
    }
    const emitStorage = (key, value, oldValue) => {
      for (const tab of tabs) if (tab.window !== window && tab.storage) queueMicrotask(() => tab.window.dispatchEvent(Object.assign(new Event('storage'), {key, newValue: value, oldValue})));
    };
    const localStorage = {
      getItem(key) {if (!storage) throw Error('blocked');return store.get(key) ?? null;},
      setItem(key, value) {if (!storage) throw Error('blocked');const old = store.get(key) ?? null;if (old === value) return;store.set(key, value);writes++;emitStorage(key, value, old);},
      removeItem(key) {if (!storage) throw Error('blocked');const old = store.get(key);if (store.delete(key)) emitStorage(key, null, old);},
      key(i) {return [...store.keys()][i];},
      get length() {if (!storage) throw Error('blocked');return store.size;}
    };
    const requests = [];
    window.WebSocket = Socket; window.XMLHttpRequest = XHR;
    window.fetch = (...args) => {const response = new Response('{"code":200}');const promise = Promise.resolve(response);requests.push({args, response, promise});return promise;};
    const nativeFetch = window.fetch, nativeOpen = XHR.prototype.open, nativeSend = XHR.prototype.send;
    const context = vm.createContext({window, document, location, localStorage, URL, Event,
      Date: class extends Date {static now() {return now;}}, crypto: {randomUUID: () => 'tab-' + (++serial)},
      ...(broadcast ? {BroadcastChannel: Bus} : {})});
    vm.runInContext(source, context);
    assert.equal(window.fetch, nativeFetch, 'status monitoring does not wrap fetch');
    assert.equal(XHR.prototype.open, nativeOpen, 'status monitoring does not wrap XHR');
    assert.equal(XHR.prototype.send, nativeSend, 'status monitoring does not wrap XHR');
    const activity = window.__cqcPowerActivity;
    const tab = {window, document, location, storage, context, requests, activity, playing: true, enabled: true, id,
      state: () => activity.getStatus(id), active: () => activity.isFarming(id),
      report() {activity.updatePlayback({channelId: this.id, enabled: this.enabled, playing: this.playing});},
      focus(value) {document.focused = value; document.visibilityState = value ? 'visible' : 'hidden';this.report();},
      heartbeat(type = 'WATCH_CONTINUED', options = {}, status = 200, json) {
        const xhr = new window.XMLHttpRequest();xhr.open('POST', watchURL, true);
        const body = JSON.stringify({channelId: this.id, payload: {watchEventType: type}, autoPlay: false, radioMode: false, ...options});
        xhr.send(body);assert.equal(xhr.body, body);assert.deepEqual(xhr.openArgs, ['POST', watchURL, true]);xhr.finish(status, json);return xhr;
      },
      close() {window.dispatchEvent(new Event('pagehide'));}
    };
    tab.socket = new window.WebSocket('wss://comm-api.game.naver.com/socket.io/1/websocket/session');
    window.addEventListener('cqc-power-activity-change', () => {if (!tab.frozen) tab.report();});
    tabs.push(tab);
    return tab;
  }
  return {makeTab, advance: ms => {now += ms;}, store, writes: () => writes};
}
const w = world(), a = w.makeTab(A), b = w.makeTab(B);
a.report();w.advance(100);b.report();await flush();
assert.equal(a.state(), 'estimated');assert.equal(b.state(), 'waiting');
a.socket.receive(modern(reward(A)));await flush();
b.playing=false;b.report();w.advance(100);b.playing=true;b.report();await flush();
assert.equal(a.state(), 'confirmed', 'new playback must not override server evidence');
assert.equal(b.state(), 'waiting');
for (const type of ['FOLLOW','DONATE','WATCH_1_HOUR']) b.socket.receive(modern(reward(B,type)));
await flush();assert.equal(a.state(),'confirmed');
w.advance(2100);b.socket.receive(legacy(reward(B)));await flush();
assert.equal(b.state(),'confirmed');assert.equal(a.state(),'waiting');
b.close();await flush();assert.equal(a.state(),'estimated');
w.advance(360001);a.report();await flush();assert.equal(a.state(),'estimated');
a.location.pathname='/';a.report();assert.equal(a.state(),'waiting');
console.log('PASS: first-tab estimate, real reward priority, non-watch exclusions, stale confirmation, navigation, no analytics interception');
