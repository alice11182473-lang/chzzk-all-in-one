const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
const content=fs.readFileSync(__dirname+'/../content.js','utf8');
const background=fs.readFileSync(__dirname+'/../background.js','utf8');
const helper=background.slice(0,background.indexOf('// Endpoints'));
function api(){const chrome={runtime:{}};const ctx={chrome,setTimeout,clearTimeout};vm.createContext(ctx);vm.runInContext(helper,ctx);return {...ctx,call:ctx.cqcMobileCall};}
test('callback-only, Promise-only and dual-return API responses',async()=>{
 const h=api();assert.equal(await h.call({get(v,cb){queueMicrotask(()=>cb(123))}},'get',{}),123);
 assert.equal(await h.call({get:async()=>456},'get',{}),456);
 assert.equal(await h.call({get(v,cb){cb(789);return Promise.resolve(999)}},'get',{}),789);
});
test('runtime errors, invalidated contexts and hung channels reject',async()=>{
 const h=api();await assert.rejects(h.call({get(v,cb){h.chrome.runtime.lastError={message:'disconnected'};cb();delete h.chrome.runtime.lastError}},'get',{}),/disconnected/);
 await assert.rejects(h.call({get(){throw Error('Extension context invalidated')}},'get',{}),/invalidated/);
 await assert.rejects(h.call({get(){}},'get',{},5),/시간 초과/);
});
function ui({hang=false}={}){
 const elements={};const element=()=>({textContent:'',style:{},dataset:{},hidden:false,checked:false,children:[],setAttribute(){},toggleAttribute(){},addEventListener(){},focus(){},replaceChildren(...c){this.children=c},append(c){this.children.push(c)}});
 const shadow={set innerHTML(s){for(const match of s.matchAll(/id="([^"]+)"/g))elements[match[1]]=element();elements.panel.hidden=true},getElementById:id=>elements[id],addEventListener(){}};
 const host={...element(),attachShadow:()=>shadow};const document={getElementById:()=>null,createElement:tag=>tag==='div'?host:element(),documentElement:{append(){}},addEventListener(){}};
 const store={autoClaim:true,top:false};let polls=0,reloaded=false;
 const chrome={runtime:{sendMessage(m,cb){polls++;if(!hang)queueMicrotask(()=>cb({ok:true,amount:750}))}},storage:{local:{get(keys,cb){queueMicrotask(()=>cb(typeof keys==='string'?{[keys]:store[keys]}:{...keys,...store}))},set(values,cb){Object.assign(store,values);queueMicrotask(()=>cb())}},onChanged:{addListener(){}}}};
 const window={addEventListener(){},dispatchEvent(){}};window.top=window;
 vm.runInNewContext(content,{window,document,chrome,location:{pathname:'/live/'+'a'.repeat(32),reload(){reloaded=true}},setInterval(){},setTimeout:(f,ms)=>setTimeout(f,Math.min(ms,20)),clearTimeout,Event});
 return {elements,store,polls:()=>polls,reloaded:()=>reloaded};
}
const settle=()=>new Promise(r=>setTimeout(r,35));
test('callback-only mobile: balance, panel close, position and setting controls work',async()=>{
 const h=ui();await settle();const e=h.elements;assert.match(e.balance.textContent,/750/);assert.match(e.connection.textContent,/연결됨/);
 e.bar.onclick();assert.equal(e.panel.hidden,false);e.close.onclick();assert.equal(e.panel.hidden,true);
 await e.position.onclick();assert.equal(h.store.top,true);
 e.auto.checked=false;await e.auto.onchange();assert.equal(h.store.autoClaim,false);
 e.reload.onclick();assert.equal(h.reloaded(),true);
});
test('stalled reply releases refresh button and permits retry; close still works',async()=>{
 const h=ui({hang:true});await settle();const e=h.elements;assert.match(e.error.textContent,/시간 초과/);assert.equal(e.refresh.disabled,false);
 e.bar.onclick();e.close.onclick();assert.equal(e.panel.hidden,true);
 e.refresh.onclick();await settle();assert.equal(h.polls(),2);assert.equal(e.refresh.disabled,false);
});
